package knowledge

import "encoding/json"

//nolint:gochecknoglobals // Immutable lookup data shared by concurrent scans; initialized once to avoid rebuilding it per input.
var additionalPatterns = func() map[string][]Pattern {
	b, e := content.ReadFile("data/patterns.json")
	if e != nil {
		panic("missing embedded patterns")
	}

	var p map[string][]Pattern
	if json.Unmarshal(b, &p) != nil {
		panic("invalid embedded patterns")
	}

	return p
}()

type Pattern struct {
	Expression string `json:"expression"`
	Source     string `json:"source"`
	Adaptation string `json:"adaptation"`
}

func Patterns(id string) []Pattern { return append([]Pattern(nil), additionalPatterns[id]...) }
func PatternCatalog() map[string][]Pattern {
	out := map[string][]Pattern{}
	for id := range additionalPatterns {
		out[id] = Patterns(id)
	}

	return out
}
