// Package knowledge contains trusted, embedded review instructions and rule
// guidance. It never loads policy or prompts from the inspected artifact.
// NVIDIA-derived materials retain Apache-2.0 attribution in NOTICE and sources.
package knowledge

import (
	"crypto/sha256"
	"embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"slices"
	"sort"
	"strings"
)

const Version = "scout-curated-review-v4"

//go:embed prompts/*.md data/*.json sources/*.md
var content embed.FS

//nolint:gochecknoglobals // Immutable prompt-mode ordering used to build the embedded catalog.
var modes = []string{valueDiscovery, valueIntent, valueQuality, "tool_consistency", "assessment", "proposal_assessment"}

//nolint:gochecknoglobals // Immutable lookup data shared by concurrent scans; initialized once to avoid rebuilding it per input.
var catalog = loadCatalog()

type Reference struct {
	URL          string `json:"url"`
	Symbol       string `json:"symbol"`
	UpstreamID   string `json:"upstream_id,omitempty"`
	Relationship string `json:"relationship"` // adapted; never an unverified exact-port claim
}
type Guide struct {
	Explanation          string      `json:"explanation"`
	Remediation          string      `json:"remediation"`
	ReviewChecks         []string    `json:"review_checks"`
	BenignConsiderations []string    `json:"benign_considerations"`
	Sources              []Reference `json:"sources"`
}
type PromptDescriptor struct {
	Mode        string   `json:"mode"`
	SHA256      string   `json:"sha256"`
	Bytes       int      `json:"bytes"`
	UpstreamIDs []string `json:"upstream_ids"`
}
type Asset struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
	Bytes  int    `json:"bytes"`
}
type Manifest struct {
	Version      string             `json:"version"`
	SHA256       string             `json:"sha256"`
	SourceStatus string             `json:"source_status"`
	Prompts      []PromptDescriptor `json:"prompts"`
	Assets       []Asset            `json:"assets"`
}

// Modes returns the supported review stages in their stable export order.
// The returned slice cannot change prompt selection or provider routing.
func Modes() []string { return append([]string(nil), modes...) }

func Hash(b []byte) string { s := sha256.Sum256(b); return hex.EncodeToString(s[:]) }

// Prompt returns only build-time instructions, never artifact-supplied text.
func Prompt(mode string) (string, error) {
	valid := slices.Contains(modes, mode)
	if !valid {
		return "", errors.New("unsupported review mode")
	}

	base, _ := content.ReadFile("prompts/boundary.md")
	body, _ := content.ReadFile("prompts/" + mode + ".md")
	out := string(base) + "\n" + string(body)
	// Verification must have the original category definitions, not only a name.
	if mode == "proposal_assessment" {
		b, _ := content.ReadFile("prompts/verification-rubric.md")
		out += "\n" + string(b)
	}

	out += reviewHints(mode)

	return out, nil
}

func Describe(mode string) (PromptDescriptor, error) {
	p, e := Prompt(mode)
	if e != nil {
		return PromptDescriptor{}, e
	}

	ids := map[string][]string{valueDiscovery: {"SSD-1", "SSD-2", "SSD-3", "SSD-4"}, valueIntent: {"SDI-1", "SDI-2", "SDI-3", "SDI-4"}, valueQuality: {"SQP-1", "SQP-2", "SQP-3"}}
	ids["tool_consistency"] = []string{"TP4"}

	return PromptDescriptor{Mode: mode, SHA256: Hash([]byte(p)), Bytes: len(p), UpstreamIDs: append([]string{}, ids[mode]...)}, nil
}

func Lookup(id string) (Guide, bool) {
	g, ok := catalog[id]
	if !ok {
		return Guide{}, false
	}

	g.ReviewChecks = append([]string{}, g.ReviewChecks...)
	g.BenignConsiderations = append([]string{}, g.BenignConsiderations...)
	g.Sources = append([]Reference{}, g.Sources...)

	return g, true
}

func Catalog() map[string]Guide {
	out := make(map[string]Guide, len(catalog))
	for id := range catalog {
		g, _ := Lookup(id)
		out[id] = g
	}

	return out
}

func Inventory() Manifest {
	files := 0
	for _, s := range curated.sources {
		files += len(s.Artifacts)
	}

	m := Manifest{Version: Version, SourceStatus: fmt.Sprintf("Historical SkillSpector adaptations retain their original provenance in sources/skillspector.md. Additional original Scout review guidance references %d repositories at fixed revisions; %d inspected files have SHA-256 and Git blob identities in data/review_sources.json (2026-10-27). No additional upstream detector code, patterns or prompts imported. Asset digests identify this review pack, not upstream engines or measured detection quality.", len(curated.sources), files), Prompts: []PromptDescriptor{}, Assets: []Asset{}}

	for _, mode := range modes {
		d, _ := Describe(mode)
		m.Prompts = append(m.Prompts, d)
	}

	for _, dir := range []string{"prompts", "data", "sources"} {
		entries, _ := content.ReadDir(dir)
		for _, e := range entries {
			if e.IsDir() {
				continue
			}

			p := dir + "/" + e.Name()
			b, _ := content.ReadFile(p)
			m.Assets = append(m.Assets, Asset{p, Hash(b), len(b)})
		}
	}

	sort.Slice(m.Assets, func(i, j int) bool { return m.Assets[i].Path < m.Assets[j].Path })
	b, _ := json.Marshal(struct {
		Version string
		Assets  []Asset
	}{Version, m.Assets})
	m.SHA256 = Hash(b)

	return m
}

// UpstreamID labels an adapted semantic taxonomy, not a proof of equal recall.
func UpstreamID(reason string) string {
	return map[string]string{
		"tool_description_code_mismatch":   "NV-TP4",
		"semantic_prompt_injection":        "SSD-1",
		"paraphrased_attack":               "SSD-2",
		"natural_language_exfiltration":    "SSD-3",
		"gradual_deception":                "SSD-4",
		"description_behavior_mismatch":    "SDI-1",
		"context_inappropriate_capability": "SDI-2",
		"declared_scope_creep":             "SDI-3",
		"intent_code_divergence":           "SDI-4",
		"quality_vague_triggers":           "SQP-1",
		"quality_missing_warnings":         "SQP-2",
		"quality_language_policy":          "SQP-3",
	}[reason]
}

// ReasonMode restricts new specialized classes to their intended independent task.
func ReasonMode(reason string) string {
	if _, ok := TopicForReason(reason); ok {
		return valueDiscovery
	}

	id := UpstreamID(reason)
	switch {
	case id == "NV-TP4":
		return "tool_consistency"
	case strings.HasPrefix(id, "SSD-"):
		return valueDiscovery
	case strings.HasPrefix(id, "SDI-"):
		return valueIntent
	case strings.HasPrefix(id, "SQP-"):
		return valueQuality
	}

	return ""
}

func loadCatalog() map[string]Guide {
	data, err := content.ReadFile("data/guidance.json")
	if err != nil {
		panic("missing embedded guidance")
	}

	var result map[string]Guide

	decoder := json.NewDecoder(strings.NewReader(string(data)))
	decoder.DisallowUnknownFields()

	if err := decoder.Decode(&result); err != nil {
		panic("invalid embedded guidance: " + err.Error())
	}

	for id, g := range result {
		if id == "" || g.Explanation == "" || g.Remediation == "" || len(g.ReviewChecks) == 0 {
			panic("incomplete embedded guidance")
		}
	}

	enrichCatalog(result)

	return result
}
