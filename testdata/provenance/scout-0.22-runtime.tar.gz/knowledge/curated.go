package knowledge

import (
	"encoding/json"
	"fmt"
	"io"
	"slices"
	"strings"
)

//nolint:gochecknoglobals // Immutable lookup data shared by concurrent scans; initialized once to avoid rebuilding it per input.
var curated = loadCurated()

// SourceArtifact records inspected upstream bytes, not shipped detector code.
type SourceArtifact struct {
	Path        string `json:"path"`
	URL         string `json:"url"`
	SHA256      string `json:"sha256"`
	GitBlobSHA1 string `json:"git_blob_sha1"`
	Bytes       int    `json:"bytes"`
}

type ReviewSource struct {
	ID              string           `json:"id"`
	Name            string           `json:"name"`
	Repository      string           `json:"repository"`
	Revision        string           `json:"revision"`
	Retrieved       string           `json:"retrieved"`
	DeclaredLicense string           `json:"declared_license"`
	Use             string           `json:"use"`
	SelectionReason string           `json:"selection_reason"`
	Limitations     string           `json:"limitations"`
	Artifacts       []SourceArtifact `json:"artifacts"`
}

type TopicReference struct {
	SourceID string `json:"source_id"`
	Path     string `json:"path"`
}

// ReviewExample is an authored contrast scenario, not a detector acceptance test.
type ReviewExample struct {
	Kind     string `json:"kind"`
	Scenario string `json:"scenario"`
}

// ReviewTopic is a contextual lens. RelatedRules are guidance associations only;
// they do not assert that those rules implement the topic's complete semantics.
type ReviewTopic struct {
	ID                   string           `json:"id"`
	Title                string           `json:"title"`
	Languages            []string         `json:"languages"`
	Category             string           `json:"category"`
	Coverage             string           `json:"coverage"`
	Modes                []string         `json:"modes"`
	PromptHint           string           `json:"prompt_hint"`
	ReviewChecks         []string         `json:"review_checks"`
	Remediation          string           `json:"remediation"`
	BenignConsiderations []string         `json:"benign_considerations"`
	Examples             []ReviewExample  `json:"examples"`
	Sources              []TopicReference `json:"sources"`
	RelatedRules         []string         `json:"related_rules"`
}

type curatedPack struct {
	sources []ReviewSource
	topics  []ReviewTopic
}

// Pack is shared by CLI and standalone exports so neither silently loses the
// curated sources/topics. Old rule guidance and supplemental patterns remain.
type Pack struct {
	Manifest Manifest             `json:"manifest"`
	Guidance map[string]Guide     `json:"guidance"`
	Patterns map[string][]Pattern `json:"supplemental_patterns"`
	Topics   []ReviewTopic        `json:"review_topics"`
	Sources  []ReviewSource       `json:"review_sources"`
}

// ReviewSources and ReviewTopics return fully detached build-time knowledge.
func ReviewSources() []ReviewSource {
	out := slices.Clone(curated.sources)
	for i := range out {
		out[i].Artifacts = slices.Clone(out[i].Artifacts)
	}

	return out
}

func ReviewTopics() []ReviewTopic {
	out := slices.Clone(curated.topics)
	for i := range out {
		out[i] = cloneTopic(out[i])
	}

	return out
}

// TopicForReason resolves only compiled topic identities. A model can select a
// lens, but cannot supply its guidance, source URLs or an upstream rule identity.
func TopicForReason(reason string) (ReviewTopic, bool) {
	if !strings.HasPrefix(reason, "knowledge:") {
		return ReviewTopic{}, false
	}

	id := strings.TrimPrefix(reason, "knowledge:")
	for _, topic := range curated.topics {
		if topic.ID == id {
			return cloneTopic(topic), true
		}
	}

	return ReviewTopic{}, false
}

func ReviewReasons() []string {
	out := make([]string, 0, len(curated.topics))
	for _, topic := range curated.topics {
		out = append(out, "knowledge:"+topic.ID)
	}

	return out
}

// ReviewTopicIDs records the lenses in a task's selected compiled prompt. It
// does not prove provider compliance, model use or detection of every risk.
func ReviewTopicIDs(mode string) []string {
	out := []string{}

	for _, topic := range curated.topics {
		if slices.Contains(topic.Modes, mode) {
			out = append(out, topic.ID)
		}
	}

	return out
}

func GuideForReason(reason string) (Guide, bool) {
	topic, ok := TopicForReason(reason)
	if !ok {
		return Lookup(UpstreamID(reason))
	}

	g := Guide{
		Explanation: topic.PromptHint, Remediation: topic.Remediation,
		ReviewChecks: topic.ReviewChecks, BenignConsiderations: topic.BenignConsiderations, Sources: []Reference{},
	}
	for _, ref := range topic.Sources {
		for _, source := range curated.sources {
			if source.ID != ref.SourceID {
				continue
			}

			for _, artifact := range source.Artifacts {
				if artifact.Path == ref.Path {
					g.Sources = append(g.Sources, Reference{URL: artifact.URL, Symbol: topic.ID, Relationship: "original Scout review guidance informed by pinned source; not a detector port"})
				}
			}
		}
	}

	return g, true
}

func Export() Pack {
	return Pack{Inventory(), Catalog(), PatternCatalog(), ReviewTopics(), ReviewSources()}
}

func readAsset(path string, value any) {
	b, err := content.ReadFile(path)
	if err != nil {
		panic("missing knowledge asset: " + path)
	}

	d := json.NewDecoder(strings.NewReader(string(b)))
	d.DisallowUnknownFields()

	if err := d.Decode(value); err != nil {
		panic("invalid knowledge asset " + path + ": " + err.Error())
	}

	if err := d.Decode(new(any)); err != io.EOF {
		panic("trailing data in knowledge asset: " + path)
	}
}

func loadCurated() curatedPack {
	var p curatedPack
	readAsset("data/review_sources.json", &p.sources)
	readAsset("data/review_topics.json", &p.topics)

	files := make(map[string]map[string]bool)
	for _, s := range p.sources {
		if s.ID == "" || files[s.ID] != nil || s.Repository == "" || len(s.Revision) != 40 || len(s.Artifacts) == 0 {
			panic("invalid review source: " + s.ID)
		}

		files[s.ID] = make(map[string]bool)
		for _, a := range s.Artifacts {
			if a.Path == "" || files[s.ID][a.Path] || a.Bytes < 1 || len(a.SHA256) != 64 || len(a.GitBlobSHA1) != 40 {
				panic("invalid review source artifact: " + s.ID)
			}

			files[s.ID][a.Path] = true
		}
	}

	seen := make(map[string]bool)
	for _, t := range p.topics {
		if t.ID == "" || seen[t.ID] || t.Title == "" || t.Category == "" || t.Coverage != "review-guidance-only" || t.PromptHint == "" || t.Remediation == "" || len(t.Languages) == 0 || len(t.ReviewChecks) == 0 || len(t.BenignConsiderations) == 0 || len(t.Sources) == 0 {
			panic("invalid review topic: " + t.ID)
		}

		seen[t.ID] = true
		for _, mode := range t.Modes {
			if !slices.Contains(modes, mode) || mode == valueQuality {
				panic("invalid review topic mode: " + t.ID)
			}
		}

		for _, r := range t.Sources {
			if !files[r.SourceID][r.Path] {
				panic("unresolved review topic source: " + t.ID)
			}
		}
	}

	return p
}

func cloneTopic(t ReviewTopic) ReviewTopic {
	t.Languages = slices.Clone(t.Languages)
	t.Modes = slices.Clone(t.Modes)
	t.ReviewChecks = slices.Clone(t.ReviewChecks)
	t.BenignConsiderations = slices.Clone(t.BenignConsiderations)
	t.Examples = slices.Clone(t.Examples)
	t.Sources = slices.Clone(t.Sources)
	t.RelatedRules = slices.Clone(t.RelatedRules)

	return t
}

func reviewHints(mode string) string {
	if mode == valueQuality {
		return ""
	}

	var b strings.Builder
	b.WriteString("\nCURATED REVIEW LENSES — original Scout guidance, not additional static detectors.\n")
	b.WriteString("Use only lenses relevant to the supplied language, evidence and CURRENT MODE. Topic IDs and source references are not excerpt citations. Preserve the mode's proposal/assessment restrictions. Examples in the catalog are authored scenarios, not proof of measured recall.\n")

	if mode == valueDiscovery {
		b.WriteString("For a concrete security defect covered by a lens, return the exact reason knowledge:<topic ID> (for example knowledge:K-SQL-PARAMS), with scanner-issued citations to the actual unsafe construction/operation and any necessary source or authorization context. This includes code vulnerabilities such as unbound SQL query construction; malicious intent or a purpose mismatch is NOT required. Do not force these into instruction_override or unapproved_execution. A capability, keyword, unused string, safe parameter binding or authorized bounded operation alone is not a defect. No proposal where the necessary evidence is absent. Known attack-semantic reasons remain available for their original meaning.\n")
	} else {
		b.WriteString("knowledge:<topic ID> reasons are discovery-only. In intent/tool_consistency keep the original mismatch definitions; in assessment/proposal_assessment evaluate the supplied hypothesis using its compiled guidance and original evidence. Do not invent new proposals or treat the topic catalog as source evidence.\n")
	}

	for _, t := range curated.topics {
		if slices.Contains(t.Modes, mode) {
			fmt.Fprintf(&b, "- %s [%s]: %s\n", t.ID, strings.Join(t.Languages, ","), t.PromptHint)
		}
	}

	return b.String()
}

// enrichCatalog improves explanations for existing rules without changing their
// methods, severities, occurrence identity, coverage or policy.
func enrichCatalog(c map[string]Guide) {
	sources := make(map[string]ReviewSource)
	for _, s := range curated.sources {
		sources[s.ID] = s
	}

	for _, t := range curated.topics {
		for _, id := range t.RelatedRules {
			g, ok := c[id]
			if !ok {
				panic("unknown related rule for " + t.ID + ": " + id)
			}

			g.ReviewChecks = append(g.ReviewChecks, t.ReviewChecks...)

			g.BenignConsiderations = append(g.BenignConsiderations, t.BenignConsiderations...)
			for _, r := range t.Sources {
				s := sources[r.SourceID]
				for _, a := range s.Artifacts {
					if a.Path == r.Path {
						g.Sources = append(g.Sources, Reference{URL: a.URL, Symbol: t.ID, Relationship: "original Scout review guidance informed by pinned source; not a detector port"})
					}
				}
			}

			c[id] = g
		}
	}
}
