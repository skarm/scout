package knowledge

// Shared vocabulary used by this package's protocols and reports.
const (
	valueDiscovery = "discovery"
	valueQuality   = "quality"
)
