package fetch

import (
	"bytes"
	"context"
	"errors"
	"io"
	"net/http"
	"strings"
)

// PostJSON makes an explicitly authorized API call with the same DNS/address,
// redirect, TLS and response bounds as the downloader. It never sends credentials
// or inherits proxies. Callers MUST separately obtain permission to send the body.
func PostJSON(ctx context.Context, endpoint string, body []byte, o Options) ([]byte, error) {
	if ctx == nil {
		return nil, fail("nil_context")
	}

	if err := ctx.Err(); err != nil {
		return nil, err
	}

	if err := o.Validate(); err != nil {
		return nil, err
	}

	if !o.Enabled {
		return nil, fail("network_permission_required")
	}

	if o.Revision != "" || o.ExpectedSHA256 != "" {
		return nil, fail("download_options_not_applicable")
	}

	if len(body) > 256<<10 {
		return nil, fail("request_byte_limit")
	}

	u, err := parseURL(endpoint, o.AllowLoopback)
	if err != nil {
		return nil, err
	}

	client, transport := newClient(o)
	defer transport.CloseIdleConnections()

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, u.String(), bytes.NewReader(body))
	if err != nil {
		return nil, fail("invalid_request")
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Accept-Encoding", "identity")
	req.Header.Set("User-Agent", "scout-explicit-api-client")

	resp, err := client.Do(req)
	if err != nil {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}

		if e, ok := errors.AsType[*Error](err); ok {
			return nil, e
		}

		return nil, fail("request_failed")
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		return nil, fail("http_status")
	}

	if enc := resp.Header.Get("Content-Encoding"); enc != "" && !strings.EqualFold(enc, "identity") {
		return nil, fail("content_encoding_refused")
	}

	if resp.ContentLength > o.MaxBytes {
		return nil, fail("byte_limit")
	}

	data, err := io.ReadAll(io.LimitReader(resp.Body, o.MaxBytes+1))
	if err != nil {
		return nil, fail("body_read_failed")
	}

	if int64(len(data)) > o.MaxBytes {
		return nil, fail("byte_limit")
	}

	if err = ctx.Err(); err != nil {
		return nil, err
	}

	return data, nil
}
