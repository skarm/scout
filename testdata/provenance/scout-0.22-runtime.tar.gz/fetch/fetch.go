// Package fetch captures explicitly requested remote bytes. It never clones a
// repository, follows links inside an artifact, runs Git or starts package tools.
package fetch

import (
	"context"
	"crypto/sha256"
	"crypto/subtle"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"errors"
	"io"
	"net"
	"net/http"
	"net/netip"
	"net/url"
	"path"
	"strings"
	"time"
)

//nolint:gochecknoglobals // Immutable lookup data shared by concurrent scans; initialized once to avoid rebuilding it per input.
var deniedPrefixes = []netip.Prefix{
	netip.MustParsePrefix("0.0.0.0/8"), netip.MustParsePrefix("100.64.0.0/10"), netip.MustParsePrefix("192.0.0.0/24"),
	netip.MustParsePrefix("192.0.2.0/24"), netip.MustParsePrefix("192.88.99.0/24"), netip.MustParsePrefix("198.18.0.0/15"),
	netip.MustParsePrefix("198.51.100.0/24"), netip.MustParsePrefix("203.0.113.0/24"), netip.MustParsePrefix("240.0.0.0/4"),
	netip.MustParsePrefix("64:ff9b::/96"), netip.MustParsePrefix("64:ff9b:1::/48"), netip.MustParsePrefix("100::/64"),
	netip.MustParsePrefix("2001::/23"), netip.MustParsePrefix("2001:db8::/32"), netip.MustParsePrefix("2002::/16"), netip.MustParsePrefix("3fff::/20"),
}

type Options struct {
	Enabled        bool
	AllowLoopback  bool
	Revision       string // GitHub repository input requires an explicit full commit SHA.
	ExpectedSHA256 string // Optional checksum of the downloaded bytes, not the snapshot.
	MaxBytes       int64
	Timeout        time.Duration
	RootCAs        *x509.CertPool // Explicit trust from the API caller; never from an artifact.
}

type Provenance struct {
	Kind                     string `json:"kind"`
	TargetSHA256             string `json:"target_sha256"`
	DownloadURLSHA256        string `json:"download_url_sha256"`
	BytesSHA256              string `json:"bytes_sha256,omitempty"`
	Revision                 string `json:"revision,omitempty"`
	ExpectedChecksumVerified bool   `json:"expected_checksum_verified"`
	Bytes                    int64  `json:"bytes"`
	Status                   string `json:"status"`
}
type Payload struct {
	Name   string
	Data   []byte
	Source Provenance
}
type (
	Target struct{ URL, Name, Kind, Revision string }
	Error  struct{ Code string }
)

func DefaultOptions() Options { return Options{MaxBytes: 32 << 20, Timeout: 30 * time.Second} }

func newClient(o Options) (*http.Client, *http.Transport) {
	tc := &tls.Config{MinVersion: tls.VersionTLS12}
	if o.RootCAs != nil {
		tc.RootCAs = o.RootCAs.Clone()
	}

	dial := &net.Dialer{Timeout: o.Timeout, KeepAlive: 30 * time.Second}
	transport := &http.Transport{Proxy: nil, TLSClientConfig: tc, DisableCompression: true, DisableKeepAlives: true, MaxResponseHeaderBytes: 16 << 10, ResponseHeaderTimeout: o.Timeout, TLSHandshakeTimeout: o.Timeout}
	transport.DialContext = func(c context.Context, network, address string) (net.Conn, error) {
		host, port, e := net.SplitHostPort(address)
		if e != nil {
			return nil, fail("invalid_address")
		}

		var ips []netip.Addr
		if ip, e := netip.ParseAddr(host); e == nil {
			ips = []netip.Addr{ip}
		} else {
			ips, e = net.DefaultResolver.LookupNetIP(c, "ip", host)
			if e != nil {
				return nil, fail("dns_failed")
			}
		}

		if len(ips) == 0 || len(ips) > 64 {
			return nil, fail("dns_failed")
		}

		for _, ip := range ips {
			if !PermittedIP(ip, o.AllowLoopback) {
				return nil, fail("address_not_permitted")
			}
		}

		for _, ip := range ips {
			conn, e := dial.DialContext(c, "tcp", net.JoinHostPort(ip.Unmap().String(), port))
			if e == nil {
				return conn, nil
			}

			if c.Err() != nil {
				return nil, c.Err()
			}
		}

		return nil, fail("connection_failed")
	}
	client := &http.Client{Transport: transport, Timeout: o.Timeout, CheckRedirect: func(*http.Request, []*http.Request) error { return fail("redirect_refused") }}

	return client, transport
}
func IsRemote(s string) bool { return strings.Contains(s, "://") }

// ResolveTarget is pure: GitHub URLs are converted to a commit-pinned codeload
// request. Branch names, tags, marketplace pointers and subpaths are not guessed.
func ResolveTarget(raw string, o Options) (Target, error) {
	if err := o.Validate(); err != nil {
		return Target{}, err
	}

	if !o.Enabled {
		return Target{}, fail("network_permission_required")
	}

	u, err := parseURL(raw, o.AllowLoopback)
	if err != nil {
		return Target{}, err
	}

	t := Target{URL: u.String(), Name: "download.bin", Kind: "https"}
	if strings.EqualFold(u.Hostname(), "github.com") {
		if u.Port() != "" && u.Port() != "443" {
			return Target{}, fail("invalid_github_url")
		}

		parts := strings.Split(strings.Trim(u.Path, "/"), "/")
		if len(parts) != 2 {
			return Target{}, fail("github_requires_repository_root")
		}

		parts[1] = strings.TrimSuffix(parts[1], ".git")
		for _, p := range parts {
			if !repoPart(p) {
				return Target{}, fail("invalid_github_url")
			}
		}

		if o.Revision == "" {
			return Target{}, fail("github_requires_full_commit_sha")
		}

		t.Kind, t.Revision, t.Name = "github-archive", strings.ToLower(o.Revision), "repository.zip"
		t.URL = "https://codeload.github.com/" + parts[0] + "/" + parts[1] + "/zip/" + t.Revision

		return t, nil
	}

	if o.Revision != "" {
		return Target{}, fail("revision_only_for_github")
	}

	name := path.Base(u.Path)
	if safeName(name) {
		t.Name = name
	}

	return t, nil
}

// PermittedIP rejects private, link-local, special-use and IPv4-translation
// ranges. All DNS answers are checked; dialing uses a checked numeric address.
func PermittedIP(a netip.Addr, loopback bool) bool {
	a = a.Unmap()
	if !a.IsValid() || a.Zone() != "" {
		return false
	}

	if a.IsLoopback() {
		return loopback
	}

	if !a.IsGlobalUnicast() || a.IsPrivate() || a.IsLinkLocalUnicast() {
		return false
	}

	for _, p := range deniedPrefixes {
		if p.Contains(a) {
			return false
		}
	}

	return true
}

func Get(ctx context.Context, raw string, o Options) (Payload, error) {
	var out Payload
	if ctx == nil {
		return out, fail("nil_context")
	}

	if err := ctx.Err(); err != nil {
		return out, err
	}

	target, err := ResolveTarget(raw, o)
	if err != nil {
		return out, err
	}

	out.Name = target.Name
	out.Source = Provenance{Kind: target.Kind, TargetSHA256: hash([]byte(raw)), DownloadURLSHA256: hash([]byte(target.URL)), Revision: target.Revision, Status: "failed"}

	client, transport := newClient(o)
	defer transport.CloseIdleConnections()

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, target.URL, nil)
	if err != nil {
		return out, fail("invalid_request")
	}

	req.Header.Set("User-Agent", "scout-offline-first-mvp")
	req.Header.Set("Accept-Encoding", "identity")

	resp, err := client.Do(req)
	if err != nil {
		if ctx.Err() != nil {
			return out, ctx.Err()
		}

		if e, ok := errors.AsType[*Error](err); ok {
			return out, e
		}

		return out, fail("request_failed")
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		return out, fail("http_status")
	}

	if enc := resp.Header.Get("Content-Encoding"); enc != "" && !strings.EqualFold(enc, "identity") {
		return out, fail("content_encoding_refused")
	}

	if resp.ContentLength > o.MaxBytes {
		return out, fail("byte_limit")
	}

	data, err := io.ReadAll(io.LimitReader(resp.Body, o.MaxBytes+1))
	if err != nil {
		if ctx.Err() != nil {
			return out, ctx.Err()
		}

		return out, fail("body_read_failed")
	}

	if int64(len(data)) > o.MaxBytes {
		return out, fail("byte_limit")
	}

	if err := ctx.Err(); err != nil {
		return out, err
	}

	if len(data) == 0 {
		return out, fail("empty_response")
	}

	digest := hash(data)
	if o.ExpectedSHA256 != "" && subtle.ConstantTimeCompare([]byte(digest), []byte(strings.ToLower(o.ExpectedSHA256))) != 1 {
		return out, fail("checksum_mismatch")
	}

	out.Data = data
	out.Source.BytesSHA256, out.Source.Bytes, out.Source.Status = digest, int64(len(data)), "captured"
	out.Source.ExpectedChecksumVerified = o.ExpectedSHA256 != ""

	return out, nil
}

func (o Options) Validate() error {
	if o.MaxBytes < 1 || o.MaxBytes > 128<<20 {
		return fail("invalid_byte_budget")
	}

	if o.Timeout <= 0 || o.Timeout > 2*time.Minute {
		return fail("invalid_timeout")
	}

	if o.Revision != "" && !isHex(o.Revision, 40) {
		return fail("revision_must_be_full_commit_sha")
	}

	if o.ExpectedSHA256 != "" && !isHex(o.ExpectedSHA256, 64) {
		return fail("invalid_expected_checksum")
	}

	if !o.Enabled && (o.AllowLoopback || o.Revision != "" || o.ExpectedSHA256 != "" || o.RootCAs != nil) {
		return fail("network_permission_required")
	}

	return nil
}

func (e *Error) Error() string { return "remote input: " + e.Code }
func fail(code string) error   { return &Error{Code: code} }
func isHex(s string, n int) bool {
	if len(s) != n {
		return false
	}

	_, err := hex.DecodeString(s)

	return err == nil
}
func hash(s []byte) string { h := sha256.Sum256(s); return hex.EncodeToString(h[:]) }
func repoPart(s string) bool {
	if s == "" || s == "." || s == ".." || len(s) > 128 {
		return false
	}

	for _, c := range s {
		if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '-' || c == '_' || c == '.') {
			return false
		}
	}

	return true
}
func safeName(s string) bool { return repoPart(s) && !strings.HasPrefix(s, ".") }
func parseURL(raw string, loopback bool) (*url.URL, error) {
	if len(raw) > 4096 {
		return nil, fail("invalid_url")
	}

	u, err := url.Parse(raw)
	if err != nil || u.Host == "" || u.User != nil || u.Opaque != "" || u.RawQuery != "" || u.ForceQuery || u.Fragment != "" || u.RawFragment != "" || u.RawPath != "" {
		return nil, fail("invalid_url")
	}

	host := u.Hostname()
	if host == "" || strings.ContainsAny(host, "%\\\x00\r\n") {
		return nil, fail("invalid_url")
	}

	ip, iperr := netip.ParseAddr(host)
	if u.Scheme != "https" && !(u.Scheme == "http" && loopback && iperr == nil && ip.Unmap().IsLoopback()) {
		return nil, fail("https_required")
	}

	if iperr == nil && !PermittedIP(ip, loopback) {
		return nil, fail("address_not_permitted")
	}

	if p := u.Port(); p != "" {
		n := 0

		for _, r := range p {
			if r < '0' || r > '9' {
				return nil, fail("invalid_port")
			}

			n = n*10 + int(r-'0')
			if n > 65535 {
				return nil, fail("invalid_port")
			}
		}

		if n == 0 {
			return nil, fail("invalid_port")
		}
	}

	return u, nil
}
