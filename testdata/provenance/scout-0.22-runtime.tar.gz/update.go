package scout

import (
	"context"
	"errors"

	"github.com/skarm/scout/fetch"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/update"
)

type (
	UpdateReport  = model.UpdateReport
	UpdateOptions = model.UpdateOptions
)

func DefaultUpdateOptions() UpdateOptions { return model.DefaultUpdateOptions() }
func UpdateExitCode(r UpdateReport) int   { return update.ExitCode(r) }

// Compare scans two LOCAL targets afresh with this scanner's same policy,
// analyzers and harness profile, then compares the captured evidence. It never
// trusts, imports or suppresses findings from a report or baseline in a package.
// A failure of the old capture does not prevent inspecting the candidate unless
// the caller's context has expired. Both partial reports remain in the result.
// Semantic upload, if enabled in Config, includes both versions with independent
// per-scan budgets. The caller's deadline applies to the complete operation.
func (s *Scanner) Compare(ctx context.Context, previous, candidate string, options UpdateOptions) (UpdateReport, error) {
	if ctx == nil {
		return UpdateReport{}, errors.New("nil context")
	}

	if err := options.Validate(); err != nil {
		return UpdateReport{}, err
	}

	if previous == "" || candidate == "" {
		return UpdateReport{}, errors.New("two explicit local inputs are required")
	}

	if fetch.IsRemote(previous) || fetch.IsRemote(candidate) || s.config.Download.Enabled {
		return UpdateReport{}, errors.New("compare accepts local inputs only; download configuration must be disabled")
	}

	before, oldErr := s.Scan(ctx, previous)
	after, newErr := s.Scan(ctx, candidate)
	r, diffErr := update.Build(ctx, before, after, options)

	return r, errors.Join(oldErr, newErr, diffErr)
}
