package review

import (
	"context"

	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/knowledge"
)

func PromptForMode(mode string) (string, error) { return knowledge.Prompt(mode) }
func PromptDigest(prompt string) string         { return knowledge.Hash([]byte(prompt)) }

// PromptForRequest verifies task/prompt identity before egress. It reads no
// artifact configuration. Content is sent only as the untrusted user message;
// no interpolation of excerpt or manifest text into these trusted instructions.
func PromptForRequest(ctx context.Context, payload []byte) (string, error) {
	if ctx == nil || len(payload) > 128<<10 {
		return "", transportError("invalid_request")
	}

	root, e := jsonconfig.Parse(ctx, string(payload))
	if e != nil || root == nil || root.Kind != "object" {
		return "", transportError("invalid_request")
	}

	schema, sok := root.Get("schema_version").Text()
	version, vok := root.Get("prompt_version").Text()
	mode, mok := root.Get("mode").Text()

	hash, hok := root.Get("prompt_sha256").Text()
	if !sok || !vok || !mok || !hok || schema != ProtocolVersion || version != PromptVersion {
		return "", transportError("request_prompt_identity")
	}

	p, e := knowledge.Prompt(mode)
	if e != nil || PromptDigest(p) != hash {
		return "", transportError("request_prompt_identity")
	}

	return p, nil
}
