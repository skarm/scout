package review

// Shared vocabulary used by this package's protocols and reports.
const (
	valueText    = "text"
	valueBedrock = "bedrock"
	valueRole    = "role"
)
