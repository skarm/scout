package review

import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"mime"
	"net/http"
	"net/url"
	"regexp"
	"sort"
	"strings"
	"time"

	"github.com/skarm/scout/internal/jsonconfig"
)

var (
	awsRegion   = regexp.MustCompile(`^[a-z]{2}(?:-[a-z]+){1,3}-[0-9]$`)
	awsAccessID = regexp.MustCompile(`^[A-Za-z0-9]{8,128}$`)
)

// MessagesOptions selects the native Anthropic Messages protocol or its explicit
// Vertex rawPredict/Bedrock InvokeModel forms. Credentials are caller-owned, not
// discovered from an SDK default chain, metadata service, home or artifact.
type MessagesOptions struct {
	HTTPOptions
	Transport                                          string // anthropic, anthropic-proxy (Vertex), bedrock
	Region, AccessKeyID, SecretAccessKey, SessionToken string
}
type MessagesProvider struct {
	base     *HTTPProvider
	options  MessagesOptions
	identity Identity
}

func NewMessages(o MessagesOptions) (*MessagesProvider, error) {
	if o.Transport == "" {
		o.Transport = valueAnthropic
	}

	switch o.Transport {
	case valueAnthropic, valueAnthropicProxy, valueBedrock:
	default:
		return nil, transportError("unsupported_messages_transport")
	}

	base, e := NewHTTP(o.HTTPOptions)
	if e != nil {
		return nil, e
	}

	if o.Transport == valueBedrock {
		if o.APIKey != "" || !awsRegion.MatchString(o.Region) || !awsAccessID.MatchString(o.AccessKeyID) || len(o.SecretAccessKey) < 8 || len(o.SecretAccessKey) > 8192 || len(o.SessionToken) > 8192 || strings.ContainsAny(o.SecretAccessKey+o.SessionToken, "\r\n\x00") {
			return nil, transportError("invalid_bedrock_credentials")
		}

		u, _ := url.Parse(o.Endpoint)
		if u.Path != "/model/"+o.Model+"/invoke" {
			return nil, transportError("bedrock_model_path_mismatch")
		}
	} else if o.Region != "" || o.AccessKeyID != "" || o.SecretAccessKey != "" || o.SessionToken != "" {
		return nil, transportError("unexpected_aws_credentials")
	}

	id := base.identity
	id.Provider = o.Transport + "-messages-json"
	id.SettingsSHA256 = hashBytes([]byte(id.SettingsSHA256 + "\x00" + o.Transport + "\x00" + o.Region + "\x00messages-envelope-v1"))

	return &MessagesProvider{base: base, options: o, identity: id}, nil
}
func (p *MessagesProvider) Identity() Identity { return p.identity }
func (p *MessagesProvider) Complete(ctx context.Context, payload []byte) (Completion, error) {
	if ctx == nil {
		return Completion{}, transportError("nil_context")
	}

	if ctx.Err() != nil {
		return Completion{}, ctx.Err()
	}

	if len(payload) > 128<<10 || !json.Valid(payload) {
		return Completion{}, transportError("invalid_request")
	}
	// No tool definitions. Native JSON mode availability differs by model, so the
	// protocol schema is in the trusted system message and validated locally.
	// No fence stripping, output repair, model fallback or forced tool invocation.
	system, err := PromptForRequest(ctx, payload)
	if err != nil {
		return Completion{}, err
	}

	system += "\nRequired JSON response schema (trusted protocol):\n" + responseSchema

	body := map[string]any{"max_tokens": p.base.tokens, "system": system, "messages": []any{map[string]any{valueRole: "user", valueContent: []any{map[string]string{"type": valueText, valueText: string(payload)}}}}}
	switch p.options.Transport {
	case valueAnthropic:
		body["model"] = p.base.model
	case valueAnthropicProxy:
		body["anthropic_version"] = "vertex-2023-10-16"
	case valueBedrock:
		body["anthropic_version"] = "bedrock-2023-05-31"
	}

	raw, e := json.Marshal(body)
	if e != nil {
		return Completion{}, transportError("request_encoding_failed")
	}

	req, e := http.NewRequestWithContext(ctx, http.MethodPost, p.base.endpoint, bytes.NewReader(raw))
	if e != nil {
		return Completion{}, transportError("request_failed")
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")

	switch p.options.Transport {
	case valueAnthropic:
		req.Header.Set("Anthropic-Version", "2023-06-01")

		if p.base.key != "" {
			req.Header.Set("X-Api-Key", p.base.key)
		}
	case valueAnthropicProxy:
		if p.base.key != "" {
			req.Header.Set("Authorization", "Bearer "+p.base.key)
		}
	case valueBedrock:
		signBedrock(req, raw, p.options, time.Now())
	}

	raw, e = p.base.readNative(ctx, req)
	if e != nil {
		return Completion{}, e
	}

	return decodeMessagesCompletion(ctx, raw)
}

func decodeMessagesCompletion(ctx context.Context, raw []byte) (Completion, error) {
	root, e := jsonconfig.Parse(ctx, string(raw))
	if e != nil {
		return Completion{}, transportError("invalid_envelope")
	}

	if aliases(root, "type", valueRole, valueContent, "stop_reason", "model", "usage", "error") {
		return Completion{}, transportError("ambiguous_envelope")
	}

	typ, _ := root.Get("type").Text()
	role, _ := root.Get(valueRole).Text()

	stop, _ := root.Get("stop_reason").Text()
	if typ != "message" || role != "assistant" || stop != "end_turn" {
		return Completion{}, transportError("incomplete_response")
	}

	content := root.Get(valueContent)
	if content == nil || content.Kind != "array" || len(content.Elements) == 0 || len(content.Elements) > 16 {
		return Completion{}, transportError("invalid_envelope")
	}

	var output strings.Builder

	for _, n := range content.Elements {
		if aliases(n, "type", valueText) {
			return Completion{}, transportError("ambiguous_envelope")
		}

		t, _ := n.Get("type").Text()

		s, ok := n.Get(valueText).Text()
		if t != valueText || !ok {
			return Completion{}, transportError("tool_call_refused")
		}

		output.WriteString(s)
	}

	model, _ := root.Get("model").Text()
	if len(model) > 256 {
		return Completion{}, transportError("metadata_limit")
	}

	c := Completion{Output: []byte(output.String()), Model: model, InputTokens: -1, OutputTokens: -1}

	if usage := root.Get("usage"); usage != nil {
		if aliases(usage, "input_tokens", "output_tokens") {
			return Completion{}, transportError("ambiguous_envelope")
		}

		var u struct {
			Input  *int64 `json:"input_tokens"`
			Output *int64 `json:"output_tokens"`
		}
		if json.Unmarshal(raw[usage.Span.Start:usage.Span.End], &u) != nil {
			return Completion{}, transportError("invalid_usage")
		}

		if u.Input != nil {
			c.InputTokens = *u.Input
		}

		if u.Output != nil {
			c.OutputTokens = *u.Output
		}

		if c.InputTokens < -1 || c.OutputTokens < -1 || c.InputTokens > 1<<40 || c.OutputTokens > 1<<40 {
			return Completion{}, transportError("invalid_usage")
		}
	}

	return c, ctx.Err()
}

func (p *HTTPProvider) readNative(ctx context.Context, req *http.Request) ([]byte, error) {
	resp, e := p.client.Do(req)
	if e != nil {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}

		if t, ok := errors.AsType[*TransportError](e); ok {
			return nil, t
		}

		return nil, transportError("http_failed")
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != 200 {
		return nil, &TransportError{Code: valueHTTPStatus, Status: resp.StatusCode}
	}

	mt, _, e := mime.ParseMediaType(resp.Header.Get("Content-Type"))
	if e != nil || mt != "application/json" {
		return nil, transportError("content_type")
	}

	if v := resp.Header.Get("Content-Encoding"); v != "" && v != "identity" {
		return nil, transportError("content_encoding")
	}

	if resp.ContentLength > int64(p.maxBytes) {
		return nil, transportError("response_limit")
	}

	raw, e := io.ReadAll(io.LimitReader(resp.Body, int64(p.maxBytes)+1))
	if e != nil {
		return nil, transportError("response_read_failed")
	}

	if len(raw) > p.maxBytes {
		return nil, transportError("response_limit")
	}

	return raw, nil
}

func awsEncode(s string, slash bool) string {
	const digits = "0123456789ABCDEF"

	var b strings.Builder

	for i := 0; i < len(s); i++ {
		c := s[i]
		if c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || strings.ContainsRune("-._~", rune(c)) || slash && c == '/' {
			b.WriteByte(c)
		} else {
			b.WriteByte('%')
			b.WriteByte(digits[c>>4])
			b.WriteByte(digits[c&15])
		}
	}

	return b.String()
}

func hmac256(k []byte, s string) []byte {
	m := hmac.New(sha256.New, k)
	m.Write([]byte(s))

	return m.Sum(nil)
}

// Strict no-query/no-RawPath POST endpoints are validated by NewHTTP. Signing
// supports only regional Bedrock InvokeModel, not generic AWS/S3/SigV4a.
func signBedrock(req *http.Request, payload []byte, o MessagesOptions, now time.Time) {
	stamp := now.UTC().Format("20060102T150405Z")
	date := stamp[:8]
	req.Header.Set("X-Amz-Date", stamp)
	req.Header.Set("X-Amz-Content-Sha256", hashBytes(payload))

	if o.SessionToken != "" {
		req.Header.Set("X-Amz-Security-Token", o.SessionToken)
	}

	headers := map[string]string{"host": req.URL.Host, "content-type": req.Header.Get("Content-Type"), "x-amz-date": stamp, "x-amz-content-sha256": hashBytes(payload)}
	if o.SessionToken != "" {
		headers["x-amz-security-token"] = o.SessionToken
	}

	if v := req.Header.Get("Accept"); v != "" {
		headers["accept"] = v
	}

	keys := make([]string, 0, len(headers))
	for k := range headers {
		keys = append(keys, k)
	}

	sort.Strings(keys)

	var canonical strings.Builder
	for _, k := range keys {
		canonical.WriteString(k + ":" + strings.Join(strings.Fields(headers[k]), " ") + "\n")
	}

	signed := strings.Join(keys, ";")

	uri := awsEncode(req.URL.Path, true)
	if uri == "" {
		uri = "/"
	}

	request := req.Method + "\n" + uri + "\n\n" + canonical.String() + "\n" + signed + "\n" + hashBytes(payload)
	scope := date + "/" + o.Region + "/bedrock/aws4_request"
	text := "AWS4-HMAC-SHA256\n" + stamp + "\n" + scope + "\n" + hashBytes([]byte(request))
	k := hmac256([]byte("AWS4"+o.SecretAccessKey), date)
	k = hmac256(k, o.Region)
	k = hmac256(k, valueBedrock)
	k = hmac256(k, "aws4_request")
	req.Header.Set("Authorization", "AWS4-HMAC-SHA256 Credential="+o.AccessKeyID+"/"+scope+", SignedHeaders="+signed+", Signature="+hex.EncodeToString(hmac256(k, text)))
}
