package review

// Shared vocabulary used by this package's protocols and reports.
const (
	valueAnthropic      = "anthropic"
	valueAnthropicProxy = "anthropic-proxy"
	valueContent        = "content"
	valueHTTPStatus     = "http_status"
)
