// Package review defines the tool-free, opt-in semantic review protocol.
// Source bytes in Request are sensitive. Providers are trusted caller-supplied
// transports, not code discovered inside an artifact. Implementations must be
// concurrency-safe, honor context cancellation and never execute returned code.
package review

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/skarm/scout/knowledge"
)

const (
	ProtocolVersion = "5"
	PromptVersion   = "scout-curated-review-instructions-v4"
	MaxSegments     = 64
	MaxItems        = 16
	MaxEvidence     = 8
)

// SystemPrompt is retained only for source compatibility. Built-in providers use
// PromptForRequest, which binds the stage-specific trusted instruction pack.
//
// Deprecated: use PromptForMode or PromptForRequest.
const SystemPrompt = `Stage-specific security instructions are embedded in scout/knowledge. Use PromptForRequest for the selected task.`

const baseResponseSchema = `{
 "type":"object", "additionalProperties":false,
 "required":["schema_version","request_id","proposals","assessments"],
 "properties":{
  "schema_version":{"type":"string","enum":["5"]},
  "request_id":{"type":"string"},
  "proposals":{"type":"array","maxItems":16,"items":{"type":"object","additionalProperties":false,"required":["reason","severity","evidence"],"properties":{
   "reason":{"type":"string","enum":["tool_description_code_mismatch","instruction_override","secret_transfer","unapproved_execution","persistent_agent_change","reviewer_manipulation","untrusted_dependency","permission_expansion","tool_poisoning","purpose_capability_mismatch","semantic_prompt_injection","paraphrased_attack","natural_language_exfiltration","gradual_deception","description_behavior_mismatch","context_inappropriate_capability","declared_scope_creep","intent_code_divergence","quality_vague_triggers","quality_missing_warnings","quality_language_policy"]},
   "severity":{"type":"string","enum":["low","medium","high","critical"]},"evidence":{"$ref":"#/$defs/evidence"}}}},
  "assessments":{"type":"array","maxItems":16,"items":{"type":"object","additionalProperties":false,"required":["finding_id","verdict","reason","evidence"],"properties":{
   "finding_id":{"type":"string"},"verdict":{"type":"string","enum":["confirmed","disputed","insufficient_context"]},
   "reason":{"type":"string","enum":["supported_by_context","benign_example","legitimate_use","insufficient_context"]},"evidence":{"$ref":"#/$defs/evidence"}}}}
 },
 "$defs":{"evidence":{"type":"array","minItems":1,"maxItems":8,"items":{"type":"object","additionalProperties":false,"required":["excerpt_id","sha256"],"properties":{"excerpt_id":{"type":"string"},"sha256":{"type":"string"}}}}}
}`

//nolint:gochecknoglobals // Immutable lookup data shared by concurrent scans; initialized once to avoid rebuilding it per input.
var responseSchema = compiledResponseSchema()

// Options are operator-owned; no field is loaded from the inspected package.
// Enabled makes every scheduled semantic task required. Zero value is offline.
type Options struct {
	QualityPolicy     bool          `json:"quality_policy"`
	Enabled           bool          `json:"enabled"`
	AllowSourceUpload bool          `json:"allow_source_upload"`
	MaxRequests       int           `json:"max_requests"`
	MaxInputBytes     int           `json:"max_input_bytes"`
	MaxRequestBytes   int           `json:"max_request_bytes"`
	MaxResponseBytes  int           `json:"max_response_bytes"`
	MaxProposals      int           `json:"max_proposals"`
	ChunkBytes        int           `json:"chunk_bytes"`
	Timeout           time.Duration `json:"timeout_ns"`
}

// Identity describes requested configuration, not proof of the model actually
// executing on the remote server. EndpointSHA256 excludes credentials.
type Identity struct {
	Provider       string `json:"provider"`
	Model          string `json:"requested_model"`
	EndpointSHA256 string `json:"endpoint_sha256,omitempty"`
	SettingsSHA256 string `json:"settings_sha256,omitempty"`
}

// Provider receives its own copy of a bounded JSON request. It cannot mutate the
// planner's source evidence or report. No raw provider errors enter scan reports.
type Provider interface {
	Identity() Identity
	Complete(context.Context, []byte) (Completion, error)
}
type Completion struct {
	Output       []byte
	Model        string
	Fingerprint  string
	InputTokens  int64 // -1 means not reported; server supplied, not independently verified
	OutputTokens int64
}

type Request struct {
	PromptSHA256   string      `json:"prompt_sha256"`
	ParentTaskID   string      `json:"parent_task_id,omitempty"`
	ScopeID        string      `json:"scope_id"`
	SchemaVersion  string      `json:"schema_version"`
	PromptVersion  string      `json:"prompt_version"`
	RequestID      string      `json:"request_id"`
	Mode           string      `json:"mode"` // discovery, intent, assessment, proposal_assessment
	SnapshotSHA256 string      `json:"snapshot_sha256"`
	Harness        string      `json:"harness"`
	Excerpts       []Excerpt   `json:"excerpts"`
	Findings       []Finding   `json:"findings"`
	Links          []Link      `json:"links"`
	Components     []Component `json:"components"`
}

// Excerpt holds bounded contiguous original/derived bytes. No normalization or
// fabricated coordinates. IDs bind the exact object, span and content hash.
type Excerpt struct {
	ContentKind  string   `json:"content_kind"` // scanner hint, not proof of runtime role
	ID           string   `json:"id"`
	Path         string   `json:"path"`
	ObjectSHA256 string   `json:"object_sha256"`
	ByteStart    int      `json:"byte_start"`
	ByteEnd      int      `json:"byte_end"`
	SHA256       string   `json:"sha256"`
	Text         string   `json:"text"`
	Components   []string `json:"components"`
}

// Finding is an assessment target, NOT necessarily a deterministic finding.
// Origin distinguishes static evidence from an untrusted semantic hypothesis.
type Finding struct {
	Guidance       *knowledge.Guide `json:"guidance,omitempty"`
	ContextSignals []string         `json:"context_signals,omitempty"`
	Origin         string           `json:"origin"`
	Reason         string           `json:"reason,omitempty"`
	Category       string           `json:"category,omitempty"`
	Method         string           `json:"method,omitempty"`
	Description    string           `json:"description,omitempty"`
	ID             string           `json:"id"`
	RuleID         string           `json:"rule_id"`
	Severity       string           `json:"severity"`
	Evidence       []Citation       `json:"evidence"`
}
type Component struct {
	ID         string `json:"id"`
	Kind       string `json:"kind"`
	Host       string `json:"host"`
	Activation string `json:"activation"`
}

type Link struct {
	ID         string     `json:"id"`
	From       string     `json:"from"`
	To         string     `json:"to"`
	Relation   string     `json:"relation"`
	Activation string     `json:"activation"`
	Evidence   []Citation `json:"evidence"`
}

// Citation can only select a scanner-issued excerpt and copy its digest. Models
// need not compute cryptographic hashes or count UTF-8 bytes to cite evidence.
type Citation struct {
	ExcerptID string `json:"excerpt_id"`
	SHA256    string `json:"sha256"`
}
type Proposal struct {
	Reason   string     `json:"reason"`
	Severity string     `json:"severity"`
	Evidence []Citation `json:"evidence"`
}
type Assessment struct {
	FindingID string     `json:"finding_id"`
	Verdict   string     `json:"verdict"`
	Reason    string     `json:"reason"`
	Evidence  []Citation `json:"evidence"`
}
type Response struct {
	SchemaVersion string       `json:"schema_version"`
	RequestID     string       `json:"request_id"`
	Proposals     []Proposal   `json:"proposals"`
	Assessments   []Assessment `json:"assessments"`
}

func DefaultOptions() Options {
	return Options{
		MaxRequests: 64, MaxInputBytes: 2 << 20, MaxRequestBytes: 32 << 10,
		MaxResponseBytes: 64 << 10, MaxProposals: 128, ChunkBytes: 8 << 10, Timeout: 30 * time.Second,
	}
}

// ResponseSchema is an independent decoded copy suitable for json_schema APIs.
func ResponseSchema() map[string]any {
	var s map[string]any
	if err := json.Unmarshal([]byte(responseSchema), &s); err != nil {
		panic(fmt.Sprintf("invalid compiled protocol schema: %v", err))
	}

	return s
}

func (o Options) Validate() error {
	if !o.Enabled {
		if o.QualityPolicy {
			return errors.New("quality policy requires semantic review")
		}

		return nil
	}

	if !o.AllowSourceUpload {
		return errors.New("semantic review requires explicit consent to send source content, which may contain secrets")
	}

	if o.MaxRequests < 1 || o.MaxRequests > 256 {
		return errors.New("semantic requests must be in 1..256")
	}

	if o.MaxRequestBytes < 2048 || o.MaxRequestBytes > 128<<10 || o.MaxInputBytes < o.MaxRequestBytes || o.MaxInputBytes > 8<<20 {
		return errors.New("invalid semantic request or aggregate input budget")
	}

	if o.MaxResponseBytes < 512 || o.MaxResponseBytes > 128<<10 || o.MaxProposals < 1 || o.MaxProposals > 1024 {
		return errors.New("invalid semantic response or proposal budget")
	}

	if o.ChunkBytes < 256 || o.ChunkBytes > 16<<10 || o.ChunkBytes > o.MaxRequestBytes/2 {
		return errors.New("semantic chunk size must be 256..16384 and at most half the request budget")
	}

	if o.Timeout <= 0 || o.Timeout > 2*time.Minute {
		return errors.New("semantic request timeout must be positive and at most 2m")
	}

	return nil
}

func (i Identity) Validate() error {
	for _, s := range []string{i.Provider, i.Model} {
		if len(s) == 0 || len(s) > 128 {
			return errors.New("provider and requested model must contain 1..128 identifier bytes")
		}

		for _, c := range s {
			if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '-' || c == '_' || c == '.' || c == ':' || c == '/' || c == '@') {
				return errors.New("invalid provider/model identifier")
			}
		}
	}

	for _, s := range []string{i.EndpointSHA256, i.SettingsSHA256} {
		if s == "" {
			continue
		}

		if len(s) != 64 {
			return errors.New("invalid provider configuration digest")
		}

		for _, c := range s {
			if !(c >= 'a' && c <= 'f' || c >= '0' && c <= '9') {
				return errors.New("invalid provider configuration digest")
			}
		}
	}

	return nil
}

func compiledResponseSchema() string {
	var schema map[string]any
	if err := json.Unmarshal([]byte(baseResponseSchema), &schema); err != nil {
		panic("invalid base review schema")
	}

	properties := schemaObject(schema, "properties")
	proposals := schemaObject(schemaObject(properties, "proposals"), "items")
	reason := schemaObject(schemaObject(proposals, "properties"), "reason")

	values, ok := reason["enum"].([]any)
	if !ok {
		panic("invalid base review schema enum")
	}

	for _, value := range knowledge.ReviewReasons() {
		values = append(values, value)
	}

	reason["enum"] = values

	raw, err := json.Marshal(schema)
	if err != nil {
		panic("invalid compiled review schema")
	}

	return string(raw)
}

func schemaObject(parent map[string]any, key string) map[string]any {
	object, ok := parent[key].(map[string]any)
	if !ok {
		panic("invalid base review schema object")
	}

	return object
}
