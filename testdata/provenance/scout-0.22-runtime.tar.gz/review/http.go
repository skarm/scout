package review

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"mime"
	"net"
	"net/http"
	"net/netip"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/knowledge"
)

// HTTPOptions selects one operator-approved Chat Completions compatible endpoint.
// No provider discovery, redirects, ambient proxy, CLI authentication or fallback.
// HTTP is allowed only to literal loopback addresses with explicit AllowLoopback.
// Even a local service may forward data elsewhere; vet the service separately.
type HTTPOptions struct {
	Endpoint         string
	Model            string
	APIKey           string
	AllowLoopback    bool
	Timeout          time.Duration
	MaxOutputTokens  int
	MaxResponseBytes int
	RootCAs          *x509.CertPool // optional explicitly trusted CA pool, cloned by constructor
}
type HTTPProvider struct {
	endpoint string
	key      string
	model    string
	client   *http.Client
	tokens   int
	maxBytes int
	identity Identity
}
type TransportError struct {
	Code   string
	Status int
}

func NewHTTP(o HTTPOptions) (*HTTPProvider, error) {
	u, err := validateHTTPOptions(o)
	if err != nil {
		return nil, err
	}

	return newHTTPProvider(o, u)
}

func validateHTTPOptions(o HTTPOptions) (*url.URL, error) {
	if o.Timeout <= 0 || o.Timeout > 2*time.Minute {
		return nil, transportError("invalid_timeout")
	}

	if o.MaxOutputTokens < 128 || o.MaxOutputTokens > 8192 {
		return nil, transportError("invalid_output_token_budget")
	}

	if o.MaxResponseBytes < 1024 || o.MaxResponseBytes > jsonconfig.MaxBytes {
		return nil, transportError("invalid_response_budget")
	}

	if len(o.Endpoint) > 2048 || len(o.APIKey) > 8192 || strings.ContainsAny(o.APIKey, "\r\n\x00") {
		return nil, transportError("invalid_endpoint_or_authentication")
	}

	u, err := url.Parse(o.Endpoint)
	if err != nil || !validEndpointURL(u) {
		return nil, transportError("invalid_endpoint")
	}

	host := u.Hostname()
	if host == "" {
		return nil, transportError("invalid_endpoint")
	}

	if strings.Contains(host, "%") {
		return nil, transportError("invalid_endpoint")
	}

	literal, iperr := netip.ParseAddr(host)
	if u.Scheme != "https" && !(u.Scheme == "http" && o.AllowLoopback && iperr == nil && literal.Unmap().IsLoopback()) {
		return nil, transportError("https_required")
	}

	if iperr == nil && !permittedIP(literal, o.AllowLoopback) {
		return nil, transportError("address_not_permitted")
	}
	// Validation before a potentially credential-bearing request; a bad port never
	// reaches net/http where an error could otherwise echo the full endpoint.
	if port := u.Port(); port != "" {
		if err := validateEndpointPort(port); err != nil {
			return nil, err
		}
	}

	return u, nil
}

func validEndpointURL(u *url.URL) bool {
	return u.Host != "" && u.User == nil && u.Opaque == "" && u.RawQuery == "" && !u.ForceQuery && u.Fragment == "" && u.RawFragment == "" && u.Path != "" && u.RawPath == ""
}

func newHTTPProvider(o HTTPOptions, u *url.URL) (*HTTPProvider, error) {
	settings, _ := json.Marshal(struct {
		Model, Endpoint, Prompt, Schema string
		Tokens, Bytes                   int
		Loopback                        bool
		Timeout                         time.Duration
	}{o.Model, u.String(), knowledge.Inventory().SHA256, hashBytes([]byte(responseSchema)), o.MaxOutputTokens, o.MaxResponseBytes, o.AllowLoopback, o.Timeout})

	identity := Identity{Provider: "chat-completions-json", Model: o.Model, EndpointSHA256: hashBytes([]byte(u.String())), SettingsSHA256: hashBytes(settings)}
	if err := identity.Validate(); err != nil {
		return nil, err
	}

	tlsConfig := &tls.Config{MinVersion: tls.VersionTLS12}
	if o.RootCAs != nil {
		tlsConfig.RootCAs = o.RootCAs.Clone()
	}

	dialer := &net.Dialer{Timeout: o.Timeout, KeepAlive: 30 * time.Second}
	tr := &http.Transport{
		Proxy: nil, TLSClientConfig: tlsConfig, DisableCompression: true, DisableKeepAlives: true,
		MaxResponseHeaderBytes: 16 << 10, ResponseHeaderTimeout: o.Timeout, TLSHandshakeTimeout: o.Timeout, ForceAttemptHTTP2: false,
	}
	tr.DialContext = (&endpointDialer{dialer: dialer, allowLoopback: o.AllowLoopback}).dial
	client := &http.Client{Timeout: o.Timeout, Transport: tr, CheckRedirect: func(*http.Request, []*http.Request) error { return transportError("redirect_refused") }}

	return &HTTPProvider{endpoint: u.String(), key: o.APIKey, model: o.Model, client: client, tokens: o.MaxOutputTokens, maxBytes: o.MaxResponseBytes, identity: identity}, nil
}

type endpointDialer struct {
	dialer        *net.Dialer
	allowLoopback bool
}

func validateEndpointPort(port string) error {
	n := 0

	for _, c := range port {
		if c < '0' || c > '9' {
			return transportError("invalid_endpoint")
		}

		n = n*10 + int(c-'0')
		if n > 65535 {
			return transportError("invalid_endpoint")
		}
	}

	if n < 1 {
		return transportError("invalid_endpoint")
	}

	return nil
}

func (d *endpointDialer) dial(ctx context.Context, _ string, address string) (net.Conn, error) {
	h, p, err := net.SplitHostPort(address)
	if err != nil {
		return nil, transportError("invalid_address")
	}
	// Every address returned by DNS must satisfy policy. Dial only the resolved
	// numeric address; there is no second resolver step that can be rebound.
	var addresses []netip.Addr
	if a, e := netip.ParseAddr(h); e == nil {
		addresses = append(addresses, a)
	} else {
		ips, e := net.DefaultResolver.LookupNetIP(ctx, "ip", h)
		if e != nil {
			return nil, transportError("dns_failed")
		}

		addresses = ips
	}

	if len(addresses) == 0 || len(addresses) > 64 {
		return nil, transportError("dns_failed")
	}

	for _, a := range addresses {
		if !permittedIP(a, d.allowLoopback) {
			return nil, transportError("address_not_permitted")
		}
	}

	for _, a := range addresses {
		c, e := d.dialer.DialContext(ctx, "tcp", net.JoinHostPort(a.Unmap().String(), p))
		if e == nil {
			return c, nil
		}

		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
	}

	return nil, transportError("connection_failed")
}

// ErrorCode intentionally never returns arbitrary provider or network error text.
func ErrorCode(err error) string {
	if errors.Is(err, context.Canceled) {
		return "cancelled"
	}

	if errors.Is(err, context.DeadlineExceeded) {
		return "timeout"
	}

	if e, ok := errors.AsType[*TransportError](err); ok {
		switch e.Code {
		case valueHTTPStatus:
			if e.Status >= 100 && e.Status <= 599 {
				return "http_status_" + strconv.Itoa(e.Status)
			}
		case "redirect_refused", "http_failed", "dns_failed", "connection_failed", "address_not_permitted", "content_type", "content_encoding", "response_limit", "response_read_failed", "invalid_envelope", "ambiguous_envelope", "provider_error", "unexpected_choices", "incomplete_response", "refused", "tool_call_refused", "metadata_limit", "invalid_usage":
			return "transport_" + e.Code
		}
	}

	return "provider_failed"
}
func (p *HTTPProvider) Identity() Identity { return p.identity }

func (p *HTTPProvider) Complete(ctx context.Context, payload []byte) (Completion, error) {
	if ctx == nil {
		return Completion{}, transportError("nil_context")
	}

	if err := ctx.Err(); err != nil {
		return Completion{}, err
	}

	if len(payload) > 128<<10 || !json.Valid(payload) {
		return Completion{}, transportError("invalid_request")
	}

	system, err := PromptForRequest(ctx, payload)
	if err != nil {
		return Completion{}, err
	}

	body, err := json.Marshal(map[string]any{
		"model": p.model, "store": false, "stream": false, "n": 1, "tools": []any{}, "tool_choice": "none", "max_completion_tokens": p.tokens,
		"messages":        []map[string]string{{valueRole: "system", valueContent: system}, {valueRole: "user", valueContent: string(payload)}},
		"response_format": map[string]any{"type": "json_schema", "json_schema": map[string]any{"name": "scout_review_v4", "strict": true, "schema": ResponseSchema()}},
	})
	if err != nil {
		return Completion{}, transportError("request_encoding_failed")
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, p.endpoint, bytes.NewReader(body))
	if err != nil {
		return Completion{}, transportError("request_failed")
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")

	if p.key != "" {
		req.Header.Set("Authorization", "Bearer "+p.key)
	}

	return p.completeChatRequest(ctx, req)
}

func (p *HTTPProvider) completeChatRequest(ctx context.Context, req *http.Request) (Completion, error) {
	resp, err := p.client.Do(req)
	if err != nil {
		if ctx.Err() != nil {
			return Completion{}, ctx.Err()
		}

		if typed, ok := errors.AsType[*TransportError](err); ok {
			return Completion{}, typed
		}

		if errors.Is(err, context.DeadlineExceeded) {
			return Completion{}, context.DeadlineExceeded
		}

		return Completion{}, transportError("http_failed")
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		return Completion{}, &TransportError{Code: valueHTTPStatus, Status: resp.StatusCode}
	}

	mt, _, e := mime.ParseMediaType(resp.Header.Get("Content-Type"))
	if e != nil || mt != "application/json" {
		return Completion{}, transportError("content_type")
	}

	if enc := resp.Header.Get("Content-Encoding"); enc != "" && enc != "identity" {
		return Completion{}, transportError("content_encoding")
	}

	if resp.ContentLength > int64(p.maxBytes) {
		return Completion{}, transportError("response_limit")
	}

	raw, err := io.ReadAll(io.LimitReader(resp.Body, int64(p.maxBytes)+1))
	if err != nil {
		return Completion{}, transportError("response_read_failed")
	}

	if len(raw) > p.maxBytes {
		return Completion{}, transportError("response_limit")
	}

	return decodeChatCompletion(ctx, raw)
}

func decodeChatCompletion(ctx context.Context, raw []byte) (Completion, error) {
	// Reject duplicate/ambiguous JSON and malformed Unicode in the HTTP envelope.
	root, parseErr := jsonconfig.Parse(ctx, string(raw))
	if parseErr != nil {
		return Completion{}, transportError("invalid_envelope")
	}
	// encoding/json accepts case-insensitive field aliases. Disallow ambiguous
	// protocol fields even when their spellings differ only by case.
	if chatEnvelopeAliases(root) {
		return Completion{}, transportError("ambiguous_envelope")
	}

	var envelope struct {
		Model       string          `json:"model"`
		Fingerprint string          `json:"system_fingerprint"`
		Error       json.RawMessage `json:"error"`
		Choices     []struct {
			Index   int    `json:"index"`
			Finish  string `json:"finish_reason"`
			Message struct {
				Role     string          `json:"role"`
				Content  *string         `json:"content"`
				Refusal  *string         `json:"refusal"`
				Tools    json.RawMessage `json:"tool_calls"`
				Function json.RawMessage `json:"function_call"`
			} `json:"message"`
		} `json:"choices"`
		Usage *struct {
			Input  *int64 `json:"prompt_tokens"`
			Output *int64 `json:"completion_tokens"`
		} `json:"usage"`
	}
	if err := json.Unmarshal(raw, &envelope); err != nil {
		return Completion{}, transportError("invalid_envelope")
	}

	if len(envelope.Error) > 0 && string(envelope.Error) != "null" {
		return Completion{}, transportError("provider_error")
	}

	if len(envelope.Choices) != 1 || envelope.Choices[0].Index != 0 {
		return Completion{}, transportError("unexpected_choices")
	}

	choice := envelope.Choices[0]
	if choice.Finish != "stop" || choice.Message.Role != "assistant" || choice.Message.Content == nil {
		return Completion{}, transportError("incomplete_response")
	}

	if choice.Message.Refusal != nil && *choice.Message.Refusal != "" {
		return Completion{}, transportError("refused")
	}

	for _, v := range []json.RawMessage{choice.Message.Tools, choice.Message.Function} {
		if len(v) > 0 && string(v) != "null" && string(v) != "[]" {
			return Completion{}, transportError("tool_call_refused")
		}
	}

	if len(envelope.Model) > 256 || len(envelope.Fingerprint) > 256 {
		return Completion{}, transportError("metadata_limit")
	}

	c := Completion{Output: []byte(*choice.Message.Content), Model: envelope.Model, Fingerprint: envelope.Fingerprint, InputTokens: -1, OutputTokens: -1}
	if envelope.Usage != nil {
		if envelope.Usage.Input != nil {
			c.InputTokens = *envelope.Usage.Input
		}

		if envelope.Usage.Output != nil {
			c.OutputTokens = *envelope.Usage.Output
		}

		if c.InputTokens < -1 || c.OutputTokens < -1 || c.InputTokens > 1<<40 || c.OutputTokens > 1<<40 {
			return Completion{}, transportError("invalid_usage")
		}
	}

	if err := ctx.Err(); err != nil {
		return Completion{}, err
	}

	return c, nil
}

func chatEnvelopeAliases(root *jsonconfig.Node) bool {
	if aliases(root, "model", "system_fingerprint", "error", "choices", "usage") {
		return true
	}

	if choices := root.Get("choices"); choices != nil {
		for _, choice := range choices.Elements {
			if aliases(choice, "index", "finish_reason", "message") || aliases(choice.Get("message"), valueRole, valueContent, "refusal", "tool_calls", "function_call") {
				return true
			}
		}
	}

	return aliases(root.Get("usage"), "prompt_tokens", "completion_tokens")
}

func (e *TransportError) Error() string { return "semantic transport: " + e.Code }
func transportError(code string) error  { return &TransportError{Code: code} }
func hashBytes(b []byte) string         { h := sha256.Sum256(b); return hex.EncodeToString(h[:]) }

func permittedIP(a netip.Addr, loopback bool) bool {
	a = a.Unmap()
	if !a.IsValid() || a.Zone() != "" {
		return false
	}

	if a.IsLoopback() {
		return loopback
	}

	if !a.IsGlobalUnicast() || a.IsPrivate() || a.IsLinkLocalUnicast() {
		return false
	}
	// Reserved/non-public destinations are never an implicit cloud endpoint.
	for _, s := range []string{"0.0.0.0/8", "100.64.0.0/10", "192.0.0.0/24", "192.0.2.0/24", "198.18.0.0/15", "198.51.100.0/24", "203.0.113.0/24", "240.0.0.0/4", "64:ff9b::/96", "64:ff9b:1::/48", "100::/64", "2001:db8::/32", "2002::/16"} {
		if netip.MustParsePrefix(s).Contains(a) {
			return false
		}
	}

	return true
}

func aliases(n *jsonconfig.Node, keys ...string) bool {
	if n == nil {
		return false
	}

	for _, m := range n.Members {
		for _, k := range keys {
			if m.Key != k && strings.EqualFold(m.Key, k) {
				return true
			}
		}
	}

	return false
}
