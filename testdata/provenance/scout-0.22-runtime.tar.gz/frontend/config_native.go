//go:build !coreonly

package frontend

import (
	"context"
	"fmt"
	"io"
	"sort"
	"strings"
	"time"
	"unicode/utf8"

	toml "github.com/pelletier/go-toml/v2"
	yaml "go.yaml.in/yaml/v3"
)

// yaml.Node has starts, but no end offsets. We report a conservative enclosing
// range from its real start to the end of the unit. We do not invent token ends.
func parseYAML(ctx context.Context, text string) (*ConfigNode, error) {
	d := yaml.NewDecoder(strings.NewReader(text))
	var document yaml.Node
	if err := d.Decode(&document); err == io.EOF {
		return &ConfigNode{Kind: "null"}, nil
	} else if err != nil {
		return nil, &Failure{"invalid"}
	}
	var extra yaml.Node
	if err := d.Decode(&extra); err != io.EOF {
		return nil, &Failure{"multiple_documents"}
	}
	if ctx.Err() != nil {
		return nil, &Failure{"deadline"}
	}
	lines := []int{0}
	for i := range text {
		if text[i] == '\n' {
			lines = append(lines, i+1)
		}
	}
	offset := func(line, column int) (int, error) {
		if line <= 0 || column <= 0 || line > len(lines) {
			return 0, &Failure{codeInvalidTree}
		}
		at := lines[line-1]
		for col := 1; col < column; col++ {
			if at >= len(text) || text[at] == '\n' {
				return 0, &Failure{codeInvalidTree}
			}
			_, n := utf8.DecodeRuneInString(text[at:])
			at += n
		}
		return at, nil
	}
	count := 0
	var convert func(*yaml.Node, int) (*ConfigNode, error)
	convert = func(n *yaml.Node, depth int) (*ConfigNode, error) {
		count++
		if count > MaxNodes || depth > MaxDepth {
			return nil, &Failure{"limit"}
		}
		if ctx.Err() != nil {
			return nil, &Failure{"deadline"}
		}
		if n == nil {
			return nil, &Failure{codeInvalidTree}
		}
		if n.Kind == yaml.DocumentNode {
			if len(n.Content) != 1 {
				return nil, &Failure{codeInvalidTree}
			}
			return convert(n.Content[0], depth)
		}
		start, err := offset(n.Line, n.Column)
		if err != nil {
			return nil, err
		}
		out := &ConfigNode{Start: start, End: len(text)}
		switch n.Kind {
		case yaml.AliasNode:
			return nil, &Failure{"unsupported_alias"}
		case yaml.MappingNode:
			if n.ShortTag() != "!!map" || len(n.Content)%2 != 0 {
				return nil, &Failure{"unsupported_tag"}
			}
			out.Kind = "object"
			seen := map[string]bool{}
			for i := 0; i < len(n.Content); i += 2 {
				k, v := n.Content[i], n.Content[i+1]
				count++
				if count > MaxNodes {
					return nil, &Failure{"limit"}
				}
				if k.Kind != yaml.ScalarNode || k.ShortTag() != "!!str" || k.Value == "<<" || seen[k.Value] {
					return nil, &Failure{"ambiguous_key"}
				}
				seen[k.Value] = true
				a, err := offset(k.Line, k.Column)
				if err != nil {
					return nil, err
				}
				child, err := convert(v, depth+1)
				if err != nil {
					return nil, err
				}
				end := child.Start
				if end < a {
					end = len(text)
				}
				out.Members = append(out.Members, Member{Key: k.Value, Start: a, End: end, Value: child})
			}
		case yaml.SequenceNode:
			if n.ShortTag() != "!!seq" {
				return nil, &Failure{"unsupported_tag"}
			}
			out.Kind = "array"
			for _, x := range n.Content {
				child, err := convert(x, depth+1)
				if err != nil {
					return nil, err
				}
				out.Elements = append(out.Elements, child)
			}
		case yaml.ScalarNode:
			switch n.ShortTag() {
			case "!!str":
				out.Kind, out.Text = "string", n.Value
			case "!!bool":
				if !strings.EqualFold(n.Value, "true") && !strings.EqualFold(n.Value, "false") {
					return nil, &Failure{"unsupported_scalar"}
				}
				out.Kind = "bool"
				out.Bool = strings.EqualFold(n.Value, "true")
			case "!!int", "!!float":
				var scalar any
				if err := n.Decode(&scalar); err != nil {
					return nil, &Failure{"invalid_scalar"}
				}
				out.Kind = "number"
				out.Text = fmt.Sprint(scalar)
			case "!!null":
				var scalar any
				if err := n.Decode(&scalar); err != nil {
					return nil, &Failure{"invalid_scalar"}
				}
				out.Kind = "null"
			default:
				return nil, &Failure{"unsupported_tag"}
			}
		default:
			return nil, &Failure{codeInvalidTree}
		}
		return out, nil
	}
	return convert(&document, 0)
}

// go-toml validates grammar/redefinitions; the stable decoder does not provide
// scalar positions. As in 0.12, TOML evidence conservatively covers the full unit.
func parseTOML(ctx context.Context, text string) (*ConfigNode, error) {
	var values map[string]any
	if err := toml.Unmarshal([]byte(text), &values); err != nil {
		return nil, &Failure{"invalid"}
	}
	count := 0
	var convert func(any, int) (*ConfigNode, error)
	convert = func(value any, depth int) (*ConfigNode, error) {
		count++
		if count > MaxNodes || depth > MaxDepth {
			return nil, &Failure{"limit"}
		}
		if ctx.Err() != nil {
			return nil, &Failure{"deadline"}
		}
		out := &ConfigNode{Start: 0, End: len(text)}
		switch v := value.(type) {
		case map[string]any:
			out.Kind = "object"
			keys := make([]string, 0, len(v))
			for k := range v {
				keys = append(keys, k)
			}
			sort.Strings(keys)
			for _, key := range keys {
				child, err := convert(v[key], depth+1)
				if err != nil {
					return nil, err
				}
				out.Members = append(out.Members, Member{Key: key, Start: 0, End: len(text), Value: child})
			}
		case []any:
			out.Kind = "array"
			for _, x := range v {
				child, err := convert(x, depth+1)
				if err != nil {
					return nil, err
				}
				out.Elements = append(out.Elements, child)
			}
		case string:
			out.Kind, out.Text = "string", v
		case bool:
			out.Kind, out.Bool = "bool", v
		case int64, uint64, float64:
			out.Kind = "number"
			out.Text = fmt.Sprint(v)
		case time.Time:
			out.Kind, out.Text = "string", v.Format(time.RFC3339Nano)
		case toml.LocalDate, toml.LocalTime, toml.LocalDateTime:
			out.Kind, out.Text = "string", fmt.Sprint(v)
		default:
			return nil, &Failure{"unsupported_value"}
		}
		return out, nil
	}
	return convert(values, 0)
}
