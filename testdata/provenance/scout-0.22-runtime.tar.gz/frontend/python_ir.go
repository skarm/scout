package frontend

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"math"
	"slices"
	"strconv"
	"strings"
)

// pythonSyntax is a bounded, byte-addressed copy of Tree-sitter's CST. This is
// only a normalizer input, NOT a hand-written parser or a CPython AST claim.
type pythonSyntax struct {
	Kind, Field string
	Start, End  int
	Named       bool
	Children    []*pythonSyntax
}

type pythonNormalizer struct {
	ctx            context.Context
	text           string
	nodes, encoded int
	partial        bool
	err            error
}

func (n *pythonSyntax) field(key string) *pythonSyntax {
	if n != nil {
		for _, x := range n.Children {
			if x.Field == key {
				return x
			}
		}
	}

	return nil
}

func (n *pythonSyntax) named() []*pythonSyntax {
	var out []*pythonSyntax

	if n != nil {
		for _, x := range n.Children {
			if x.Named && x.Kind != "comment" {
				out = append(out, x)
			}
		}
	}

	return out
}

func (n *pythonSyntax) first() *pythonSyntax {
	for _, x := range n.named() {
		return x
	}

	return nil
}

func (b *pythonNormalizer) textOf(n *pythonSyntax) string {
	if n == nil || n.Start < 0 || n.End < n.Start || n.End > len(b.text) {
		return ""
	}

	return b.text[n.Start:n.End]
}

func (b *pythonNormalizer) make(n *pythonSyntax, typ string) *Node {
	b.nodes++
	if b.nodes > MaxNodes {
		b.err = &Failure{"limit"}
	}

	return &Node{Type: typ, Start: n.Start, End: n.End, Fields: map[string]json.RawMessage{}}
}

func (b *pythonNormalizer) set(n *Node, key string, value any) {
	if b.err != nil || n == nil {
		return
	}

	data, err := json.Marshal(value)
	if err != nil {
		b.err = &Failure{codeInvalidTree}
		return
	}

	b.encoded += len(data)
	if b.encoded > MaxOutput {
		b.err = &Failure{"output_limit"}
		return
	}

	n.Fields[key] = data
}

func (b *pythonNormalizer) list(n *pythonSyntax, depth int) []*Node {
	out := []*Node{}

	for _, x := range n.named() {
		if v := b.node(x, depth+1); v != nil {
			out = append(out, v)
		}
	}

	return out
}

func (b *pythonNormalizer) alias(n *pythonSyntax) *Node {
	out := b.make(n, "alias")

	name, asname := b.textOf(n), ""
	if n.Kind == "aliased_import" {
		name = b.textOf(n.field("name"))
		asname = b.textOf(n.field("alias"))
	}

	if n.Kind == "wildcard_import" {
		name = "*"
	}

	b.set(out, "name", name)
	b.set(out, "asname", asname)

	return out
}

func (b *pythonNormalizer) node(n *pythonSyntax, depth int) *Node {
	if n == nil || b.err != nil {
		return nil
	}

	if depth > MaxDepth || n.Start < 0 || n.End < n.Start || n.End > len(b.text) {
		b.err = &Failure{"limit"}
		return nil
	}

	if b.ctx.Err() != nil {
		b.err = &Failure{"deadline"}
		return nil
	}

	if n.Kind == "comment" {
		return nil
	}

	makeNode := func(typ string) *Node { return b.make(n, typ) }
	child := func(field string) *Node { return b.node(n.field(field), depth+1) }

	switch n.Kind {
	case "module", "block":
		out := makeNode("Module")
		b.set(out, "body", b.list(n, depth))

		return out
	case "expression_statement":
		return b.expressionStatement(n, depth, makeNode)
	case "import_statement", "import_from_statement", "future_import_statement":
		return b.importNode(n)
	case "identifier":
		out := makeNode("Name")
		b.set(out, "id", b.textOf(n))

		return out
	case "attribute":
		out := makeNode("Attribute")
		b.set(out, "value", child("object"))
		b.set(out, "attr", b.textOf(n.field("attribute")))

		return out
	case "call":
		return b.callNode(n, depth)
	case "subscript":
		out := makeNode("Subscript")
		b.set(out, "value", child("value"))
		b.set(out, "slice", child("subscript"))

		return out
	case valueAssignment:
		if n.field("type") != nil {
			out := makeNode("AnnAssign")
			b.set(out, "target", child("left"))
			b.set(out, "annotation", child("type"))
			b.set(out, "value", child("right"))

			return out
		}

		out := makeNode("Assign")
		targets := []*Node{child("left")}

		rhs := n.field("right")
		for rhs != nil && rhs.Kind == valueAssignment {
			targets = append(targets, b.node(rhs.field("left"), depth+1))
			rhs = rhs.field("right")
		}

		b.set(out, "targets", targets)
		b.set(out, "value", b.node(rhs, depth+1))

		return out
	case "augmented_assignment":
		out := makeNode("AugAssign")
		b.set(out, "target", child("left"))
		b.set(out, "value", child("right"))

		return out
	case "named_expression":
		out := makeNode("NamedExpr")
		b.set(out, "target", child("name"))
		b.set(out, "value", child("value"))

		return out
	case "parenthesized_expression", "as_pattern_target":
		return b.node(n.first(), depth+1)
	default:
		return b.literalNode(n, depth)
	}
}

func (b *pythonNormalizer) literalNode(n *pythonSyntax, depth int) *Node {
	makeNode := func(typ string) *Node { return b.make(n, typ) }
	child := func(field string) *Node { return b.node(n.field(field), depth+1) }

	switch n.Kind {
	case "type":
		// Grammar wrapper, not a CPython node. Keep the entire expression,
		// including calls in annotations; do not infer when a host evaluates it.
		if len(n.named()) == 1 {
			return b.node(n.first(), depth+1)
		}

		b.partial = true
		out := makeNode("UnsupportedExpression")
		b.set(out, "body", b.list(n, depth))

		return out
	case "string":
		if value, bytesValue, ok := pythonLiteral(b.textOf(n)); ok {
			out := makeNode("Constant")
			if bytesValue {
				b.set(out, "value", map[string]string{"bytes_hex": hex.EncodeToString([]byte(value))})
			} else {
				b.set(out, "value", value)
			}

			return out
		}

		out := makeNode("JoinedStr")
		values := []*Node{}

		for _, x := range n.named() {
			if x.Kind == "interpolation" {
				values = append(values, b.node(x, depth+1))
			}
		}

		if len(values) == 0 {
			b.partial = true
			out.Type = "UnsupportedExpression"
		}

		b.set(out, "values", values)

		return out
	case "interpolation":
		out := makeNode("FormattedValue")
		b.set(out, "value", child("expression"))
		b.set(out, "format_spec", child("format_specifier"))

		return out
	case "concatenated_string":
		parts := b.list(n, depth)

		var value strings.Builder

		all := true

		for _, p := range parts {
			var s string
			if p == nil || p.Type != "Constant" || json.Unmarshal(p.Fields["value"], &s) != nil {
				all = false
				break
			}

			value.WriteString(s)
		}

		if all {
			out := makeNode("Constant")
			b.set(out, "value", value.String())

			return out
		}

		out := makeNode("JoinedStr")
		b.set(out, "values", parts)

		return out
	case "integer", "float", "true", "false", "none", "ellipsis":
		return b.nodeInteger(makeNode, n)
	default:
		return b.containerNode(n, depth)
	}
}

func (b *pythonNormalizer) containerNode(n *pythonSyntax, depth int) *Node {
	makeNode := func(typ string) *Node { return b.make(n, typ) }
	child := func(field string) *Node { return b.node(n.field(field), depth+1) }

	switch n.Kind {
	case "list", "tuple", "set", "list_pattern", "tuple_pattern", "pattern_list", "expression_list":
		typ := "Tuple"
		if n.Kind == "list" || n.Kind == "list_pattern" {
			typ = "List"
		}

		if n.Kind == "set" {
			typ = "Set"
		}

		out := makeNode(typ)
		b.set(out, "elts", b.list(n, depth))

		return out
	case "dictionary":
		out := makeNode("Dict")
		keys, vals := []*Node{}, []*Node{}

		for _, x := range n.named() {
			if x.Kind == "pair" {
				keys = append(keys, b.node(x.field("key"), depth+1))
				vals = append(vals, b.node(x.field("value"), depth+1))
			} else {
				keys = append(keys, nil)
				vals = append(vals, b.node(x.first(), depth+1))
			}
		}

		b.set(out, "keys", keys)
		b.set(out, "values", vals)

		return out
	case "list_comprehension", "set_comprehension", valueDictionaryComprehension, "generator_expression":
		out := makeNode(map[string]string{"list_comprehension": "ListComp", "set_comprehension": "SetComp", valueDictionaryComprehension: "DictComp", "generator_expression": "GeneratorExp"}[n.Kind])

		generators := []*Node{}
		for _, x := range n.named() {
			if x.Kind == "for_in_clause" {
				g := b.make(x, "comprehension")
				b.set(g, "target", b.node(x.field("left"), depth+1))
				b.set(g, "iter", b.node(x.field("right"), depth+1))
				generators = append(generators, g)
			} else if x.Kind == "if_clause" && len(generators) > 0 {
				g := generators[len(generators)-1]
				b.set(g, "ifs", append(g.List("ifs"), b.node(x.first(), depth+1)))
			}
		}

		b.set(out, "generators", generators)

		if n.Kind == valueDictionaryComprehension {
			b.set(out, "key", b.node(n.field("body").field("key"), depth+1))
			b.set(out, "value", b.node(n.field("body").field("value"), depth+1))
		} else {
			b.set(out, "elt", child("body"))
		}

		return out
	default:
		return b.operatorNode(n, depth)
	}
}

func (b *pythonNormalizer) operatorNode(n *pythonSyntax, depth int) *Node {
	makeNode := func(typ string) *Node { return b.make(n, typ) }
	child := func(field string) *Node { return b.node(n.field(field), depth+1) }

	switch n.Kind {
	case "boolean_operator":
		out := makeNode("BoolOp")
		b.set(out, "values", []*Node{child("left"), child("right")})

		for _, token := range n.Children {
			if token.Kind == "and" {
				b.set(out, "op", "And")
			}

			if token.Kind == "or" {
				b.set(out, "op", "Or")
			}
		}

		return out
	case "conditional_expression":
		parts := n.named()
		if len(parts) == 3 {
			out := makeNode("IfExp")
			b.set(out, "body", b.node(parts[0], depth+1))
			b.set(out, "test", b.node(parts[1], depth+1))
			b.set(out, "orelse", b.node(parts[2], depth+1))

			return out
		}

	case "binary_operator":
		out := makeNode("BinOp")
		b.set(out, "left", child("left"))
		b.set(out, "right", child("right"))

		return out
	case "unary_operator", "not_operator":
		out := makeNode("UnaryOp")
		b.set(out, "operand", child("argument"))
		// Preserve the operator: truthiness must distinguish -1, +0 and not x.
		op := strings.TrimSpace(b.textOf(n))
		switch {
		case strings.HasPrefix(op, "not"):
			b.set(out, "op", "Not")
		case strings.HasPrefix(op, "-"):
			b.set(out, "op", "USub")
		case strings.HasPrefix(op, "+"):
			b.set(out, "op", "UAdd")
		case strings.HasPrefix(op, "~"):
			b.set(out, "op", "Invert")
		}

		return out
	case "list_splat", valueDictionarySplat:
		out := makeNode("Starred")
		b.set(out, "value", b.node(n.first(), depth+1))

		return out
	case "function_definition", "class_definition":
		return b.nodeFunctionDefinition(n, makeNode, depth, child)
	case "decorated_definition":
		out := b.node(n.field("definition"), depth+1)
		dec := []*Node{}

		for _, x := range n.named() {
			if x.Kind == "decorator" {
				dec = append(dec, b.node(x.first(), depth+1))
			}
		}

		b.set(out, "decorator_list", dec)

		return out
	case "lambda":
		out := makeNode("Lambda")
		b.set(out, "args", b.parameters(n.field("parameters"), depth+1))
		b.set(out, "body", child("body"))

		return out
	default:
		return b.statementNode(n, depth)
	}

	return b.unsupportedNode(n, depth)
}

func (b *pythonNormalizer) statementNode(n *pythonSyntax, depth int) *Node {
	makeNode := func(typ string) *Node { return b.make(n, typ) }
	child := func(field string) *Node { return b.node(n.field(field), depth+1) }

	switch n.Kind {
	case "if_statement", "elif_clause":
		out := makeNode("If")
		b.set(out, "test", child("condition"))
		b.set(out, "body", b.list(n.field("consequence"), depth))

		tail := []*Node{}
		alternatives := []*pythonSyntax{}

		for _, x := range n.named() {
			if x.Field == "alternative" {
				alternatives = append(alternatives, x)
			}
		}

		for _, a := range slices.Backward(alternatives) {
			if a.Kind == "else_clause" {
				tail = b.list(a.field("body"), depth)
			} else {
				next := b.node(a, depth+1)
				b.set(next, "orelse", tail)
				tail = []*Node{next}
			}
		}

		b.set(out, "orelse", tail)

		return out
	case "for_statement", "while_statement":
		typ := "For"
		if n.Kind == "while_statement" {
			typ = "While"
		}

		out := makeNode(typ)
		b.set(out, "target", child("left"))
		b.set(out, "iter", child("right"))
		b.set(out, "test", child("condition"))
		b.set(out, "body", b.list(n.field("body"), depth))
		b.set(out, "orelse", b.list(n.field("alternative").field("body"), depth))

		return out
	default:
		return b.terminalStatementNode(n, depth)
	}
}

func (b *pythonNormalizer) terminalStatementNode(n *pythonSyntax, depth int) *Node {
	makeNode := func(typ string) *Node { return b.make(n, typ) }

	switch n.Kind {
	case "with_statement":
		out := makeNode("With")
		items := []*Node{}

		for _, x := range n.named() {
			if x.Kind == "with_clause" {
				for _, item := range x.named() {
					value := item.field("value")

					wi := b.make(item, "withitem")
					if value != nil && value.Kind == "as_pattern" {
						b.set(wi, "context_expr", b.node(value.first(), depth+1))
						b.set(wi, "optional_vars", b.node(value.field("alias"), depth+1))
					} else {
						b.set(wi, "context_expr", b.node(value, depth+1))
					}

					items = append(items, wi)
				}
			}
		}

		b.set(out, "items", items)
		b.set(out, "body", b.list(n.field("body"), depth))

		return out
	case "return_statement", "raise_statement", "assert_statement", "delete_statement":
		typ := map[string]string{"return_statement": "Return", "raise_statement": "Raise", "assert_statement": "Assert", "delete_statement": "Delete"}[n.Kind]
		out := makeNode(typ)
		b.set(out, "value", b.node(n.first(), depth+1))
		b.set(out, "targets", b.list(n, depth))

		return out
	case "pass_statement", "break_statement", "continue_statement":
		return makeNode(map[string]string{"pass_statement": "Pass", "break_statement": "Break", "continue_statement": "Continue"}[n.Kind])
	case "global_statement", "nonlocal_statement":
		out := makeNode(map[string]string{"global_statement": "Global", "nonlocal_statement": "Nonlocal"}[n.Kind])

		names := []string{}
		for _, x := range n.named() {
			names = append(names, b.textOf(x))
		}

		b.set(out, "names", names)

		return out
	}

	return b.unsupportedNode(n, depth)
}

func (b *pythonNormalizer) unsupportedNode(n *pythonSyntax, depth int) *Node {
	// Preserve traversable descendants but explicitly mark projection gaps.
	// Unknown statements are state barriers in the Go security analyzer.
	b.partial = true

	typ := "UnsupportedExpression"
	if strings.HasSuffix(n.Kind, "statement") || strings.HasSuffix(n.Kind, "definition") || n.Kind == "match_statement" {
		typ = "UnsupportedStatement"
	}

	out := b.make(n, typ)
	b.set(out, "body", b.list(n, depth))

	return out
}

func (b *pythonNormalizer) nodeInteger(makeNode func(typ string) *Node, n *pythonSyntax) *Node {
	out := makeNode("Constant")
	b.set(out, "value", nil)

	if n.Kind == "integer" {
		digits := strings.ReplaceAll(b.textOf(n), "_", "")
		if len(digits) > 2 && digits[0] == '0' && strings.ContainsRune("xXoObB", rune(digits[1])) {
			digits = digits[2:]
		}

		b.set(out, "numeric_truth", strings.Trim(digits, "0") != "")
	}

	if n.Kind == "float" {
		v, err := strconv.ParseFloat(strings.ReplaceAll(b.textOf(n), "_", ""), 64)
		if err == nil || math.IsInf(v, 0) {
			b.set(out, "numeric_truth", v != 0)
		} else {
			b.set(out, "numeric_unknown", true)
		}
	}

	if n.Kind == "ellipsis" {
		b.set(out, "numeric_truth", true)
	}

	if n.Kind == "true" {
		b.set(out, "value", true)
	}

	if n.Kind == "false" {
		b.set(out, "value", false)
	}

	return out
}

func (b *pythonNormalizer) nodeFunctionDefinition(n *pythonSyntax, makeNode func(typ string) *Node, depth int, child func(field string) *Node) *Node {
	typ := "FunctionDef"
	if n.Kind == "class_definition" {
		typ = "ClassDef"
	}

	out := makeNode(typ)
	b.set(out, "name", b.textOf(n.field("name")))
	b.set(out, "body", b.list(n.field("body"), depth))
	b.set(out, "decorator_list", []*Node{})

	if typ == "FunctionDef" {
		b.set(out, "args", b.parameters(n.field("parameters"), depth+1))
		b.set(out, "returns", child("return_type"))
	} else {
		bases, keywords := []*Node{}, []*Node{}

		for _, x := range n.field("superclasses").named() {
			if x.Kind == valueKeywordArgument || x.Kind == valueDictionarySplat {
				k := b.make(x, "keyword")
				if x.Kind == valueKeywordArgument {
					b.set(k, "arg", b.textOf(x.field("name")))
					b.set(k, "value", b.node(x.field("value"), depth+1))
				} else {
					b.set(k, "arg", nil)
					b.set(k, "value", b.node(x.first(), depth+1))
				}

				keywords = append(keywords, k)
			} else {
				bases = append(bases, b.node(x, depth+1))
			}
		}

		b.set(out, "bases", bases)
		b.set(out, "keywords", keywords)
	}
	// PEP-695 type parameters require scope semantics not implemented here.
	// Retain expressions for independent observations; never silently omit them.
	if n.field("type_parameters") != nil {
		b.partial = true
		b.set(out, "type_params", b.list(n.field("type_parameters"), depth+1))
	}

	return out
}

func (b *pythonNormalizer) expressionStatement(n *pythonSyntax, depth int, makeNode func(typ string) *Node) *Node {
	xs := n.named()
	if len(xs) == 1 && (xs[0].Kind == valueAssignment || xs[0].Kind == "augmented_assignment") {
		return b.node(xs[0], depth+1)
	}

	out := makeNode("Expr")
	if len(xs) == 1 {
		b.set(out, "value", b.node(xs[0], depth+1))
	} else {
		b.partial = true
		out.Type = "UnsupportedStatement"
		b.set(out, "body", b.list(n, depth))
	}

	return out
}

func (b *pythonNormalizer) parameters(n *pythonSyntax, depth int) *Node {
	if n == nil {
		return nil
	}

	out := b.make(n, "arguments")
	args, defaults, kwonly, kwdefaults := []*Node{}, []*Node{}, []*Node{}, []*Node{}
	posonly := []*Node{}
	keyword := false

	for _, x := range n.named() {
		if x.Kind == "positional_separator" {
			posonly, args = args, []*Node{}
			continue
		}

		if x.Kind == "keyword_separator" {
			keyword = true
			continue
		}

		item := x
		annotation := x.field("type")

		if item.Kind == "typed_parameter" {
			item = item.first()
		}

		if item == nil {
			continue
		}

		typ := item.Kind

		name := b.textOf(item)
		if typ == "default_parameter" || typ == "typed_default_parameter" {
			name = b.textOf(item.field("name"))
		}

		if typ == "list_splat_pattern" || typ == "dictionary_splat_pattern" {
			name = b.textOf(item.first())
		}

		a := b.make(x, "arg")
		b.set(a, "arg", name)
		b.set(a, "annotation", b.node(annotation, depth+1))

		switch typ {
		case "list_splat_pattern":
			b.set(out, "vararg", a)

			keyword = true
		case "dictionary_splat_pattern":
			b.set(out, "kwarg", a)
		case "identifier", "default_parameter", "typed_default_parameter":
			def := b.node(item.field("value"), depth+1)

			if keyword {
				kwonly = append(kwonly, a)
				kwdefaults = append(kwdefaults, def)
			} else {
				args = append(args, a)
				if def != nil {
					defaults = append(defaults, def)
				}
			}
		default:
			b.partial = true
		}
	}

	b.set(out, "args", args)
	b.set(out, "posonlyargs", posonly)
	b.set(out, "kwonlyargs", kwonly)
	b.set(out, "defaults", defaults)
	b.set(out, "kw_defaults", kwdefaults)

	return out
}

func normalizePython(ctx context.Context, text string, root *pythonSyntax) (*Node, error) {
	n := &pythonNormalizer{ctx: ctx, text: text}

	if root == nil || root.Kind != "module" {
		return nil, &Failure{codeInvalidTree}
	}

	ast := n.node(root, 0)
	if n.err != nil {
		return nil, n.err
	}

	if n.partial {
		return ast, &Failure{"unsupported_projection"}
	}

	return ast, nil
}
