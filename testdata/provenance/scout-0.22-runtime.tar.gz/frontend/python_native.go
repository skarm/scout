//go:build !coreonly && cgo

package frontend

import (
	"context"
	"time"

	sitter "github.com/tree-sitter/go-tree-sitter"
	python "github.com/tree-sitter/tree-sitter-python/bindings/go"
)

func pythonAvailable() bool { return true }

func parsePython(ctx context.Context, text string) (*Node, error) {
	parser := sitter.NewParser()
	defer parser.Close()
	if err := parser.SetLanguage(sitter.NewLanguage(python.Language())); err != nil {
		return nil, &Failure{"grammar_abi"}
	}
	deadline, ok := ctx.Deadline()
	if !ok {
		return nil, &Failure{"deadline"}
	}
	left := time.Until(deadline)
	if left < time.Microsecond {
		return nil, &Failure{"deadline"}
	}
	// v0.25's non-nil ParseOptions retain a callback handle (upstream issue #55).
	// Use the pinned native timeout and nil options instead; never a goroutine
	// holding a cancellation pointer past parser.Close. A new parser per call
	// also prevents timed-out parse state being reused for another object.
	parser.SetTimeoutMicros(uint64(left.Microseconds()))
	tree := parser.Parse([]byte(text), nil)
	if tree == nil {
		return nil, &Failure{"deadline"}
	}
	defer tree.Close()
	if ctx.Err() != nil {
		return nil, &Failure{"deadline"}
	}
	root := tree.RootNode()
	if root == nil || root.HasError() {
		return nil, &Failure{"invalid"}
	}
	count := 0
	var capture func(*sitter.Node, int, string) (*pythonSyntax, error)
	capture = func(n *sitter.Node, depth int, field string) (*pythonSyntax, error) {
		count++
		if count > MaxNodes || depth > MaxDepth {
			return nil, &Failure{"limit"}
		}
		if ctx.Err() != nil {
			return nil, &Failure{"deadline"}
		}
		if n == nil || n.IsError() || n.IsMissing() || n.EndByte() > uint(len(text)) || n.StartByte() > n.EndByte() {
			return nil, &Failure{codeInvalidTree}
		}
		out := &pythonSyntax{Kind: n.Kind(), Start: int(n.StartByte()), End: int(n.EndByte()), Field: field, Named: n.IsNamed()}
		for i := uint(0); i < n.ChildCount(); i++ {
			child, err := capture(n.Child(i), depth+1, n.FieldNameForChild(uint32(i)))
			if err != nil {
				return nil, err
			}
			out.Children = append(out.Children, child)
		}
		return out, nil
	}
	syntax, err := capture(root, 0, "")
	if err != nil {
		return nil, err
	}
	return normalizePython(ctx, text, syntax)
}
