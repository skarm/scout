package frontend

import (
	"strconv"
	"strings"
	"unicode/utf8"
)

// pythonLiteral interprets a bounded subset of values of an already parsed
// Tree-sitter string node. It is NOT a Python lexer/parser. Unknown literal
// semantics become an explicit projection gap; they are never guessed.
func pythonLiteral(s string) (string, bool, bool) {
	i := strings.IndexAny(s, "\"'")
	if i < 0 || i > 2 {
		return "", false, false
	}

	prefix := strings.ToLower(s[:i])
	raw, bytesValue := false, false

	switch prefix {
	case "", "u":
	case "r":
		raw = true
	case "b":
		bytesValue = true
	case "br", "rb":
		raw = true
		bytesValue = true
	default:
		return "", false, false
	}

	quote := s[i : i+1]

	n := 1
	if strings.HasPrefix(s[i:], strings.Repeat(quote, 3)) {
		n = 3
	}

	delim := strings.Repeat(quote, n)
	if len(s) < i+2*n || !strings.HasSuffix(s, delim) {
		return "", false, false
	}

	body := s[i+n : len(s)-n]

	body = strings.ReplaceAll(strings.ReplaceAll(body, "\r\n", "\n"), "\r", "\n")
	if bytesValue {
		for _, r := range body {
			if r > 127 {
				return "", false, false
			}
		}
	}

	if raw {
		return body, bytesValue, true
	}

	return decodePythonLiteral(body, bytesValue)
}

func decodePythonLiteral(body string, bytesValue bool) (string, bool, bool) {
	var out strings.Builder
	out.Grow(len(body))

	for j := 0; j < len(body); j++ {
		if body[j] != '\\' {
			out.WriteByte(body[j])
			continue
		}

		j++
		if j >= len(body) {
			return "", false, false
		}

		c := body[j]
		switch c {
		case '\n':
		case '\\', '\'', '"':
			out.WriteByte(c)
		case 'a':
			out.WriteByte('\a')
		case 'b':
			out.WriteByte('\b')
		case 'f':
			out.WriteByte('\f')
		case 'n':
			out.WriteByte('\n')
		case 'r':
			out.WriteByte('\r')
		case 't':
			out.WriteByte('\t')
		case 'v':
			out.WriteByte('\v')
		case 'x', 'u', 'U':
			var ok bool

			j, ok = writePythonHex(&out, body, j, bytesValue)
			if !ok {
				return "", false, false
			}
		case 'N':
			if bytesValue {
				out.WriteString(`\N`)
			} else {
				return "", false, false
			} // no invented Unicode name database
		default:
			var ok bool

			j, ok = writePythonOtherEscape(&out, body, j, bytesValue)
			if !ok {
				return "", false, false
			}
		}
	}

	return out.String(), bytesValue, true
}

func writePythonHex(out *strings.Builder, body string, at int, bytesValue bool) (int, bool) {
	c := body[at]
	if bytesValue && c != 'x' {
		out.WriteByte('\\')
		out.WriteByte(c)

		return at, true
	}

	width := 2

	switch c {
	case 'u':
		width = 4
	case 'U':
		width = 8
	}

	if at+width >= len(body) {
		return at, false
	}

	value, err := strconv.ParseUint(body[at+1:at+1+width], 16, 32)
	if err != nil {
		return at, false
	}

	if bytesValue {
		if value > 255 {
			return at, false
		}

		out.WriteByte(byte(value))
	} else {
		if value > utf8.MaxRune || !utf8.ValidRune(rune(value)) {
			return at, false
		}

		out.WriteRune(rune(value))
	}

	return at + width, true
}

func writePythonOtherEscape(out *strings.Builder, body string, at int, bytesValue bool) (int, bool) {
	c := body[at]
	if c < '0' || c > '7' {
		// Python retains unknown escapes.
		out.WriteByte('\\')
		out.WriteByte(c)

		return at, true
	}

	value := uint32(c - '0')

	for k := 0; k < 2 && at+1 < len(body) && body[at+1] >= '0' && body[at+1] <= '7'; k++ {
		at++
		value = value*8 + uint32(body[at]-'0')
	}

	if bytesValue {
		if value > 255 {
			return at, false
		}

		out.WriteByte(byte(value))
	} else {
		out.WriteRune(rune(value))
	}

	return at, true
}
