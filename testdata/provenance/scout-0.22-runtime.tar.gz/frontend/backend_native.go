//go:build !coreonly

package frontend

func BackendFor(format string) Backend {
	b := Backend{Format: format, Available: true}
	switch format {
	case languagePython:
		b.Name, b.Version = "tree-sitter-python", "0.25.0"
		b.Available = pythonAvailable()
		if !b.Available {
			b.Reason = "Python grammar requires CGO-enabled build"
		}
	case "yaml":
		b.Name, b.Version = "go-yaml", "3.0.5"
	case "toml":
		b.Name, b.Version = "go-toml", "2.4.3"
	default:
		b.Available = false
		b.Reason = "unknown format"
	}
	return b
}
