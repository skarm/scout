package frontend

// Shared vocabulary used by this package's protocols and reports.
const (
	valueAssignment              = "assignment"
	valueDictionaryComprehension = "dictionary_comprehension"
	valueDictionarySplat         = "dictionary_splat"
	codeInvalidTree              = "invalid_tree"
	valueKeywordArgument         = "keyword_argument"
	languagePython               = "python"
	statusUnavailable            = "unavailable"
)
