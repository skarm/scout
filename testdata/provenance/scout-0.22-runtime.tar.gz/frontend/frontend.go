// Package frontend wraps embedded syntax libraries. It never starts Python,
// imports inspected modules, or resolves libraries from the inspected artifact.
package frontend

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"time"
	"unicode/utf8"
)

const (
	MaxBytes  = 256 << 10
	MaxOutput = 2 << 20
	MaxNodes  = 8192
	MaxDepth  = 32
)

// Options enable independent parser capabilities. Deprecated runtime paths are
// retained only to produce a migration error rather than silently ignore them.
type Options struct {
	Python, YAML, TOML bool
	Timeout            time.Duration
	Interpreter        string // Deprecated: Python execution was removed in 0.13.
	YAMLLibrary        string // Deprecated: YAML is compiled into the native build.
}

func DefaultOptions() Options   { return Options{Timeout: 3 * time.Second} }
func (o Options) Enabled() bool { return o.Python || o.YAML || o.TOML }
func (o Options) Validate() error {
	if o.Timeout <= 0 || o.Timeout > 10*time.Second {
		return errors.New("invalid embedded parser timeout")
	}

	if o.Interpreter != "" || o.YAMLLibrary != "" {
		return errors.New("external Python/PyYAML paths are no longer supported; use the embedded build")
	}

	return nil
}

func (o Options) Profile() string {
	if !o.Enabled() {
		return ""
	}

	p := "+embedded-parsers-v5"
	if o.Python {
		p += "-python"
	}

	if o.YAML {
		p += "-yaml"
	}

	if o.TOML {
		p += "-toml"
	}

	return p
}

// Backend identifies the compiled adapter, not a dynamically discovered runtime.
type Backend struct {
	Format    string `json:"format"`
	Name      string `json:"name"`
	Version   string `json:"version"`
	Available bool   `json:"available"`
	Reason    string `json:"reason,omitempty"`
}

func Backends() []Backend {
	return []Backend{BackendFor(languagePython), BackendFor("yaml"), BackendFor("toml")}
}

type Node struct {
	Type   string                     `json:"type"`
	Start  int                        `json:"start"`
	End    int                        `json:"end"`
	Fields map[string]json.RawMessage `json:"fields,omitempty"`
}

func (n *Node) String(key string) string {
	if n == nil {
		return ""
	}

	var s string
	if json.Unmarshal(n.Fields[key], &s) != nil {
		return ""
	}

	return s
}

func (n *Node) Child(key string) *Node {
	if n == nil {
		return nil
	}

	var v Node
	if json.Unmarshal(n.Fields[key], &v) != nil || v.Type == "" {
		return nil
	}

	return &v
}

func (n *Node) List(key string) []*Node {
	if n == nil {
		return nil
	}

	var v []*Node
	if json.Unmarshal(n.Fields[key], &v) != nil {
		return nil
	}

	return v
}

func (n *Node) Children() []*Node {
	if n == nil {
		return nil
	}

	var result []*Node
	// Iteration order is made stable by the caller's AST field list, not a map walk.
	for _, k := range []string{"body", "orelse", "finalbody", "handlers", "value", "values", "targets", "target", "test", "func", "args", "keywords", "elts", "keys", "left", "right", "operand", "comparators", "iter", "generators", "slice", "items", "context_expr", "optional_vars", "decorator_list", "bases", "returns", "format_spec", "pattern", "cases", "elt", "key", "defaults", "kw_defaults", "lower", "upper", "step", "names", "ifs", "exc", "cause", "annotation", "posonlyargs", "kwonlyargs", "vararg", "kwarg", "type_params"} {
		if v := n.Child(k); v != nil {
			result = append(result, v)
		} else {
			for _, v := range n.List(k) {
				if v != nil {
					result = append(result, v)
				}
			}
		}
	}

	return result
}

type ConfigNode struct {
	Kind     string        `json:"kind"`
	Start    int           `json:"start"`
	End      int           `json:"end"`
	Text     string        `json:"text,omitempty"`
	Bool     bool          `json:"bool,omitempty"`
	Members  []Member      `json:"members,omitempty"`
	Elements []*ConfigNode `json:"elements,omitempty"`
}
type Member struct {
	Key   string      `json:"key"`
	Start int         `json:"start"`
	End   int         `json:"end"`
	Value *ConfigNode `json:"value"`
}
type Result struct {
	Protocol int         `json:"protocol"`
	Format   string      `json:"format"`
	Version  string      `json:"version"`
	Status   string      `json:"status"`
	AST      *Node       `json:"ast,omitempty"`
	Config   *ConfigNode `json:"config,omitempty"`
}

func (r Result) RuntimeIdentity() string {
	return fmt.Sprintf("%s-%s-adapter-v5", BackendFor(r.Format).Name, r.Version)
}

type Failure struct{ Category string }

func (e *Failure) Error() string { return "embedded syntax parser: " + e.Category }

func Parse(ctx context.Context, o Options, format, text string) (Result, error) {
	var r Result
	if ctx == nil {
		return r, errors.New("nil parser context")
	}

	if e := o.Validate(); e != nil {
		return r, e
	}

	if !(format == languagePython && o.Python || format == "yaml" && o.YAML || format == "toml" && o.TOML) {
		return r, &Failure{"not_enabled"}
	}

	if len(text) > MaxBytes {
		return r, &Failure{"input_limit"}
	}

	if !utf8.ValidString(text) {
		return r, &Failure{"invalid_utf8"}
	}

	if e := ctx.Err(); e != nil {
		return r, e
	}

	b := BackendFor(format)
	if !b.Available {
		return r, &Failure{statusUnavailable}
	}

	call, cancel := context.WithTimeout(ctx, o.Timeout)
	defer cancel()

	r = Result{Protocol: 2, Format: format, Version: b.Version, Status: "ok"}

	var err error

	switch format {
	case languagePython:
		r.AST, err = parsePython(call, text)
	case "yaml":
		r.Config, err = parseYAML(call, text)
	case "toml":
		r.Config, err = parseTOML(call, text)
	}

	var failure *Failure

	partial := errors.As(err, &failure) && failure.Category == "unsupported_projection" && r.AST != nil
	if err != nil && !partial {
		return Result{}, err
	}

	parseErr := err

	if partial {
		r.Status = "partial"
	}

	if call.Err() != nil {
		return Result{}, &Failure{"deadline"}
	}

	if err = validateTree(r, len(text)); err != nil {
		return Result{}, err
	}

	return r, parseErr
}

// validateTree validates every serialized field, including previously unfamiliar
// Python node fields. Analysis may cover fewer semantics than syntax validation.
func validateTree(r Result, size int) error {
	v := treeValidator{size: size}

	if r.Format != languagePython {
		if r.AST != nil {
			return &Failure{codeInvalidTree}
		}

		return v.config(r.Config, 0)
	}

	if r.AST == nil || r.AST.Type != "Module" || r.Config != nil {
		return &Failure{codeInvalidTree}
	}

	return v.python(r.AST, 0)
}

type treeValidator struct{ size, count int }

func (v *treeValidator) config(n *ConfigNode, depth int) error {
	v.count++
	if n == nil || v.count > MaxNodes || depth > MaxDepth || n.Start < 0 || n.End < n.Start || n.End > v.size {
		return &Failure{codeInvalidTree}
	}

	switch n.Kind {
	case "object":
		seen := make(map[string]bool, len(n.Members))
		for _, m := range n.Members {
			if seen[m.Key] || m.Start < 0 || m.End < m.Start || m.End > v.size {
				return &Failure{"ambiguous_key"}
			}

			seen[m.Key] = true
			if err := v.config(m.Value, depth+1); err != nil {
				return err
			}
		}
	case "array":
		for _, child := range n.Elements {
			if err := v.config(child, depth+1); err != nil {
				return err
			}
		}
	case "string", "bool", "number", "null":
	default:
		return &Failure{codeInvalidTree}
	}

	return nil
}

func (v *treeValidator) python(n *Node, depth int) error {
	v.count++
	if n == nil || depth > MaxDepth || v.count > MaxNodes || n.Start < 0 || n.End < n.Start || n.End > v.size {
		return &Failure{codeInvalidTree}
	}

	for _, raw := range n.Fields {
		if err := v.pythonField(raw, depth+1); err != nil {
			return err
		}
	}

	return nil
}

func (v *treeValidator) pythonField(raw json.RawMessage, depth int) error {
	var child Node
	if json.Unmarshal(raw, &child) == nil && child.Type != "" {
		return v.python(&child, depth)
	}

	var children []*Node
	if json.Unmarshal(raw, &children) == nil {
		for _, child := range children {
			if child == nil {
				continue
			}

			if err := v.python(child, depth); err != nil {
				return err
			}
		}
	}

	return nil
}
