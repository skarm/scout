package frontend

import "strings"

func (b *pythonNormalizer) importNode(n *pythonSyntax) *Node {
	typ := "Import"
	if n.Kind != "import_statement" {
		typ = "ImportFrom"
	}

	out := b.make(n, typ)
	names := []*Node{}

	for _, x := range n.named() {
		if x.Field == "module_name" {
			continue
		}

		if x.Kind == "dotted_name" || x.Kind == "aliased_import" || x.Kind == "wildcard_import" {
			names = append(names, b.alias(x))
		}
	}

	b.set(out, "names", names)

	if typ == "ImportFrom" {
		module := b.textOf(n.field("module_name"))
		if n.Kind == "future_import_statement" {
			module = "__future__"
		}

		level := len(module) - len(strings.TrimLeft(module, "."))
		b.set(out, "module", strings.TrimLeft(module, "."))
		b.set(out, "level", level)
	}

	return out
}

func (b *pythonNormalizer) callNode(n *pythonSyntax, depth int) *Node {
	out := b.make(n, "Call")
	b.set(out, "func", b.node(n.field("function"), depth+1))

	args, keywords := []*Node{}, []*Node{}

	for _, x := range n.field("arguments").named() {
		switch x.Kind {
		case valueKeywordArgument:
			k := b.make(x, "keyword")
			b.set(k, "arg", b.textOf(x.field("name")))
			b.set(k, "value", b.node(x.field("value"), depth+1))
			keywords = append(keywords, k)
		case valueDictionarySplat:
			k := b.make(x, "keyword")
			b.set(k, "arg", nil)
			b.set(k, "value", b.node(x.first(), depth+1))
			keywords = append(keywords, k)
		default:
			args = append(args, b.node(x, depth+1))
		}
	}

	b.set(out, "args", args)
	b.set(out, "keywords", keywords)

	return out
}
