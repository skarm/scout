package scout

import (
	"context"
	"errors"
	"slices"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/model"
)

type BatchReport = model.BatchReport

func BatchExitCode(r BatchReport) int {
	if r.Completeness != model.Complete {
		return 2
	}

	if r.Decision == model.Allow {
		return 0
	}

	return 1
}

// ScanBatch checks up to 32 explicit targets independently. Byte and provider
// budgets apply per target, while context/deadline covers the entire operation.
// It never imports a marketplace's remote entries or approves sibling packages.
func (s *Scanner) ScanBatch(ctx context.Context, targets []string) (BatchReport, error) {
	if ctx == nil || len(targets) == 0 || len(targets) > 32 {
		return BatchReport{}, errors.New("batch requires context and 1..32 explicit targets")
	}

	if slices.Contains(targets, "") {
		return BatchReport{}, errors.New("empty batch target")
	}

	r := BatchReport{SchemaVersion: "1", EngineVersion: Version, Completeness: model.Complete, Decision: model.Allow, Items: make([]model.BatchItem, len(targets)), Limitations: []string{"Explicit per-target scans, not an install-closure or marketplace approval. Capture/analysis/LLM budgets are per input; the caller's deadline covers the batch.", "Input names/URLs are identified by hashes in the outer list. Each report retains its normal evidence. An unavailable input is never treated as a safe empty package."}}
	for i, t := range targets {
		r.Items[i] = model.BatchItem{Index: i, TargetSHA256: artifact.Hash([]byte(t)), Status: "not_run"}
	}

	var allErr error

	for i, t := range targets {
		if ctx.Err() != nil {
			r.Items[i].Status = "cancelled"
			r.Completeness = model.Partial
			allErr = errors.Join(allErr, ctx.Err())

			continue
		}

		report, e := s.Scan(ctx, t)
		r.Items[i].Report = &report

		r.Items[i].Status = "completed"
		if e != nil {
			r.Items[i].Status = "failed"
			allErr = errors.Join(allErr, e)
		}

		if e != nil || report.Coverage.Completeness != model.Complete {
			r.Completeness = model.Partial
		}

		if report.Policy.Decision == model.Block {
			r.Decision = model.Block
		} else if report.Policy.Decision != model.Allow && r.Decision != model.Block {
			r.Decision = model.Review
		}
	}

	if r.Completeness != model.Complete && r.Decision == model.Allow {
		r.Decision = model.Review
	}

	return r, allErr
}
