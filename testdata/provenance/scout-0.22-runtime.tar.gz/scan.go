// Package scout exposes a provisional API for pre-install skill/plugin reviews.
// Local scans are offline; remote input and semantic review each require opt-in.
package scout

import (
	"context"
	"errors"
	"time"

	"github.com/skarm/scout/baseline"
	"github.com/skarm/scout/fetch"
	"github.com/skarm/scout/frontend"
	"github.com/skarm/scout/internal/analyzer"
	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/engine"
	"github.com/skarm/scout/internal/filetype"
	"github.com/skarm/scout/internal/ingest"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/policy"
	"github.com/skarm/scout/internal/semantic"
	"github.com/skarm/scout/review"
	"github.com/skarm/scout/signatures"
	"github.com/skarm/scout/vulnerability"
)

const (
	Info     = model.Info
	Low      = model.Low
	Medium   = model.Medium
	High     = model.High
	Critical = model.Critical
)
const Version = model.EngineVersion

type (
	Report           = model.Report
	Limits           = model.Limits
	ExtractionLimits = model.ExtractionLimits
	HarnessOptions   = model.HarnessOptions
	Policy           = model.Policy
	Severity         = model.Severity
)

type Config struct {
	Profile              string // Optional check preset: basic, extended, semantic. Empty preserves explicit selection.
	Signatures           signatures.Options
	Frontends            frontend.Options
	SkillspectorPatterns bool
	Vulnerabilities      vulnerability.Options
	Baseline             *baseline.Document
	AllowBaselineGlobs   bool
	Download             fetch.Options
	Semantic             review.Options
	Provider             review.Provider
	Harness              HarnessOptions
	ExtractionLimits     ExtractionLimits
	Limits               Limits
	Policy               Policy
	Workers              int
}

type Scanner struct {
	config Config
	engine *engine.Engine
}

func DefaultConfig() Config {
	return Config{Signatures: signatures.DefaultOptions(), Frontends: frontend.DefaultOptions(), Vulnerabilities: vulnerability.DefaultOptions(), Download: fetch.DefaultOptions(), Semantic: review.DefaultOptions(), Harness: HarnessOptions{Host: "auto"}, ExtractionLimits: model.DefaultExtractionLimits(), Limits: model.DefaultLimits(), Policy: Policy{ID: "strict-prototype-v1", BlockAt: model.High}, Workers: 4}
}

func New(c Config) (*Scanner, error) {
	var err error

	c, err = c.ResolveProfile()
	if err != nil {
		return nil, err
	}

	c.Signatures.ExtraRules = append([]byte(nil), c.Signatures.ExtraRules...)

	registry, err := parse.WithFrontends(c.Frontends)
	if err != nil {
		return nil, err
	}

	if err := c.Vulnerabilities.Validate(); err != nil {
		return nil, err
	}

	c.Vulnerabilities.Offline = append([]byte(nil), c.Vulnerabilities.Offline...)
	if c.Vulnerabilities.RootCAs != nil {
		c.Vulnerabilities.RootCAs = c.Vulnerabilities.RootCAs.Clone()
	}

	if c.Baseline != nil {
		b, err := cloneBaseline(*c.Baseline, c.AllowBaselineGlobs)
		if err != nil {
			return nil, err
		}

		c.Baseline = &b
	}

	if err := c.Download.Validate(); err != nil {
		return nil, err
	}

	if c.Download.RootCAs != nil {
		c.Download.RootCAs = c.Download.RootCAs.Clone()
	}

	if err := c.Semantic.Validate(); err != nil {
		return nil, err
	}

	if c.Semantic.Enabled {
		if _, err := semantic.ProviderIdentity(c.Provider); err != nil {
			return nil, err
		}
	} else if c.Provider != nil {
		return nil, errors.New("provider configured but semantic review is disabled")
	}

	if err := c.Harness.Validate(); err != nil {
		return nil, err
	}

	if err := c.ExtractionLimits.Validate(); err != nil {
		return nil, err
	}

	if err := c.Limits.Validate(); err != nil {
		return nil, err
	}

	if err := c.Policy.Validate(); err != nil {
		return nil, err
	}

	rules := analyzer.Builtins()
	if c.Frontends.Python {
		rules = append(rules, analyzer.PythonRules()...)
	}

	if c.SkillspectorPatterns {
		rules = append(rules, analyzer.SkillspectorPatterns()...)
		rules = append(rules, analyzer.PluginSecurityRules()...)
	}

	e, err := engine.NewWithRegistry(rules, c.Workers, registry)
	if err != nil {
		return nil, err
	}

	e, err = e.WithSignatures(c.Signatures)
	if err != nil {
		return nil, err
	}

	return &Scanner{config: c, engine: e}, nil
}

func cloneBaseline(d baseline.Document, allowGlobs bool) (baseline.Document, error) {
	if err := baseline.Validate(d); err != nil {
		return baseline.Document{}, err
	}

	d.Entries = append([]baseline.Entry(nil), d.Entries...)
	if allowGlobs {
		return d, nil
	}

	for _, entry := range d.Entries {
		if entry.Kind == "glob" {
			return baseline.Document{}, errors.New("glob approvals require explicit permission")
		}
	}

	return d, nil
}

func ExitCode(r Report) int { return policy.ExitCode(r) }

// Scan captures local input, or explicitly permitted remote bytes, without executing it.
// A non-nil capture error always
// returns a failed report when configuration was valid. Scanner is safe for
// concurrent Scan calls, with no state or findings shared between scans.
func (s *Scanner) Scan(ctx context.Context, target string) (Report, error) {
	if ctx == nil {
		return Report{}, errors.New("nil context")
	}

	var (
		snapshot   artifact.Snapshot
		err        error
		provenance *fetch.Provenance
	)

	if fetch.IsRemote(target) {
		opts := s.config.Download
		opts.MaxBytes = min(opts.MaxBytes, s.config.Limits.MaxArchiveBytes, s.config.Limits.MaxTotalBytes)
		payload, fetchErr := fetch.Get(ctx, target, opts)
		err = fetchErr

		provenance = &payload.Source
		if provenance.Status == "" {
			provenance.Kind = "remote"
			provenance.Status = "failed"
		}

		if err == nil && int64(len(payload.Data)) > s.config.Limits.MaxFileBytes && filetype.Inspect(payload.Name, string(payload.Data), false).Category != "archive" {
			err = errors.New("remote input exceeds non-archive file byte budget")
			provenance.Status = "rejected_file_budget"
		}

		if err == nil {
			snapshot = artifact.New("remote", []artifact.File{artifact.NewFile(payload.Name, payload.Data, false)}, nil, nil, true)
		}
	} else {
		snapshot, err = ingest.Read(ctx, target, s.config.Limits)
	}

	if err == nil {
		r, runErr := s.runSnapshot(ctx, snapshot)
		r.Source = provenance
		s.finalize(&r)

		return r, runErr
	}
	// Preserve any evidence already captured even when a later read fails.
	r, _ := s.runSnapshot(ctx, snapshot)
	r.Source = provenance
	r.Coverage.Completeness = model.Failed
	r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: "ingest_failed", Message: "Input capture failed or was cancelled; no automatic admission is possible.", AffectsScope: true})
	r.Policy = policy.EvaluateWithSemantic(s.config.Policy, r.Coverage.Completeness, r.Findings, r.Semantic)
	s.finalize(&r)

	return r, err
}

// ScanBytes scans one immutable copy of an operator-supplied file, useful for
// pre-install upload handlers. Names are validated as package-relative paths;
// they never trigger filesystem reads. It uses the same engine as CLI input.
func (s *Scanner) ScanBytes(ctx context.Context, name string, data []byte) (Report, error) {
	if ctx == nil {
		return Report{}, errors.New("nil context")
	}

	if err := ingest.ValidatePath(name, s.config.Limits.MaxPathBytes, s.config.Limits.MaxDepth); err != nil {
		return Report{}, errors.New("invalid input name")
	}
	// Refuse oversized input before inspecting or copying caller-owned bytes.
	maxPossible := min(s.config.Limits.MaxTotalBytes, max(s.config.Limits.MaxFileBytes, s.config.Limits.MaxArchiveBytes))
	if int64(len(data)) > maxPossible {
		return Report{}, errors.New("input exceeds byte budget")
	}

	maxBytes := s.config.Limits.MaxFileBytes
	if filetype.Inspect(name, string(data), false).Category == "archive" {
		maxBytes = min(s.config.Limits.MaxArchiveBytes, s.config.Limits.MaxTotalBytes)
	}

	if int64(len(data)) > maxBytes {
		return Report{}, errors.New("input exceeds byte budget")
	}

	snapshot := artifact.New("memory", []artifact.File{artifact.NewFile(name, data, false)}, nil, nil, true)
	r, err := s.runSnapshot(ctx, snapshot)
	s.finalize(&r)

	return r, err
}

// runSnapshot is the single wiring point shared by local, remote and memory input.
func (s *Scanner) runSnapshot(ctx context.Context, snapshot artifact.Snapshot) (Report, error) {
	return s.engine.Run(ctx, snapshot, engine.RunOptions{
		Limits: s.config.Limits, Policy: s.config.Policy, Extraction: s.config.ExtractionLimits,
		Harness: s.config.Harness, Semantic: s.config.Semantic, Provider: s.config.Provider,
		Vulnerabilities: s.config.Vulnerabilities,
	})
}

// finalize applies only operator-supplied approvals after all evidence is collected.
func (s *Scanner) finalize(r *Report) {
	r.Inspection, _ = s.config.InspectionPlan() // Profile was validated by New.
	for _, check := range r.Inspection.Checks {
		if check.Selected && !check.Available {
			if r.Coverage.Completeness == model.Complete {
				r.Coverage.Completeness = model.Partial
			}

			r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: "inspection_backend_unavailable", Message: "Selected inspection backend is not linked: " + check.ID, AffectsScope: true})
		}
	}

	r.Profile += s.config.Frontends.Profile()
	if s.config.SkillspectorPatterns {
		r.Profile += "+nv-patterns-v1"
	}

	active := r.Findings

	r.Baseline = model.BaselineReport{Status: "disabled", Suppressed: []model.Suppression{}}
	if s.config.Baseline != nil {
		b, a, err := baseline.Apply(*r, *s.config.Baseline, time.Now(), s.config.AllowBaselineGlobs)

		r.Baseline = b
		if err != nil {
			r.Coverage.Completeness = model.Partial
			r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: "baseline_failed", Message: "Operator baseline could not be applied; findings remain active.", AffectsScope: true})
		} else {
			active = a
		}
	}

	r.Policy = policy.EvaluateWithSemantic(s.config.Policy, r.Coverage.Completeness, active, r.Semantic)
	// Retained DB matches still require block even if a finding could not be emitted
	// at the result budget. Only explicit evidence-bound approvals affect findings.
	limitedVulnerabilities := false

	for _, d := range r.Diagnostics {
		if d.Code == "vulnerability_finding_limit" {
			limitedVulnerabilities = true
		}
	}

	if limitedVulnerabilities {
		r.Policy.Decision = model.Block
		r.Policy.Reasons = append(r.Policy.Reasons, "Known database matches exceed the finding budget; no approval is inferred.")
	}

	executable := false

	for _, f := range r.Artifact.Files {
		if f.Executable {
			executable = true
			break
		}
	}

	r.Risk = policy.Score(active, len(r.Baseline.Suppressed), executable)
}
