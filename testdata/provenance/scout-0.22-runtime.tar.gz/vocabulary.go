package scout

// Shared vocabulary used by this package's protocols and reports.
const (
	valueSemantic = "semantic"
)
