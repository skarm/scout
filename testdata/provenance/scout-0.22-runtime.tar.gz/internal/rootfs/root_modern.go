//go:build !linux && !darwin && go1.24

package rootfs

import (
	"fmt"
	"io/fs"
	"os"
	"strings"
)

// Go 1.24's os.Root supplies OS-level traversal resistance. Linux additionally
// uses no-follow opens in its own backend. Only Linux is runtime-tested in the
// initial delivery; the cross-platform CI matrix must verify this backend.
type Root struct{ root *os.Root }

func Open(name string) (*Root, error) {
	r, err := os.OpenRoot(name)
	if err != nil {
		return nil, err
	}
	return &Root{root: r}, nil
}

func (r *Root) Open(name string) (*os.File, error) {
	if !fs.ValidPath(name) || strings.Contains(name, `\`) {
		return nil, fmt.Errorf("invalid root-relative path")
	}
	before, err := r.root.Lstat(name)
	if err != nil {
		return nil, err
	}
	if !before.IsDir() && !before.Mode().IsRegular() {
		return nil, fmt.Errorf("nonregular entry refused")
	}
	f, err := r.root.OpenFile(name, os.O_RDONLY|readFlags, 0)
	if err != nil {
		return nil, err
	}
	after, err := f.Stat()
	if err != nil {
		f.Close()
		return nil, err
	}
	if !os.SameFile(before, after) || (!after.IsDir() && !after.Mode().IsRegular()) {
		f.Close()
		return nil, fmt.Errorf("entry changed during open")
	}
	return f, nil
}
func (r *Root) Close() error { return r.root.Close() }
