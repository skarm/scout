//go:build !linux && !darwin && !go1.24

package rootfs

import (
	"fmt"
	"os"
)

type Root struct{}

func Open(string) (*Root, error) {
	return nil, fmt.Errorf("local scanning on this platform requires Go 1.24+; rebuild with a current Go toolchain")
}

func (*Root) Open(string) (*os.File, error) { return nil, fmt.Errorf("root filesystem unavailable") }
func (*Root) Close() error                  { return nil }
