package extract

import (
	"archive/tar"
	"archive/zip"
	"compress/gzip"
	"io"
	"math"
	"strings"

	"github.com/skarm/scout/internal/archiveutil"
	"github.com/skarm/scout/internal/model"
)

// contextByteReader preserves exact gzip member boundaries while making reads
// cooperative. It is deliberately not a shell, filesystem or network adapter.
type contextByteReader struct {
	ctx interface{ Err() error }
	r   *strings.Reader
}

func (r contextByteReader) Read(p []byte) (int, error) {
	if e := r.ctx.Err(); e != nil {
		return 0, e
	}

	return r.r.Read(p)
}

func (r contextByteReader) ReadByte() (byte, error) {
	if e := r.ctx.Err(); e != nil {
		return 0, e
	}

	return r.r.ReadByte()
}

func extractZIP(o *operation) error {
	o.role = valueArchiveMember
	remaining := o.b.limits.MaxEntries - o.b.result.Report.EntriesVisited

	zr, err := archiveutil.OpenZIPWithBudget(o.b.ctx, []byte(o.parent.file.Content()), remaining, 1024, 32, o.entry)
	if err != nil {
		return err
	}
	// Central-directory order is retained in provenance. Even empty directories
	// consume the scan-wide entry budget; metadata objects consume object budgets.
	for _, entry := range zr.File {
		if err = o.b.ctx.Err(); err != nil {
			return err
		}

		if entry.FileInfo().IsDir() {
			continue
		}

		if o.b.limits.MaxObjectBytes < 0 || entry.UncompressedSize64 > uint64(o.b.limits.MaxObjectBytes) {
			size := int64(math.MaxInt64)
			if entry.UncompressedSize64 <= math.MaxInt64 {
				size = int64(entry.UncompressedSize64)
			}

			o.skipMember(entry.Name, "object_byte_limit", size)
			o.issue("extraction_object_limit", "An archive member exceeds the per-object budget; its prefix is not analyzed as a complete member.")
			o.b.result.Report.Steps[o.step].Status = statusPartial

			continue
		}

		if entry.UncompressedSize64 > math.MaxInt64 {
			return errFormat
		}

		r, e := entry.Open()
		if e != nil {
			return e
		}

		e = o.emit(entry.Name, r, int64(entry.UncompressedSize64), entry.Mode()&0o111 != 0, nil)
		closeErr := r.Close()

		if e != nil {
			return e
		}

		if closeErr != nil {
			return closeErr
		}
	}

	return extractZIPMetadata(o, zr)
}

func extractZIPMetadata(o *operation, zr *zip.Reader) error {
	var err error
	// Raw archive bytes are always analyzed too. These derived fields allow
	// further supported decoding of metadata without replacing the original.
	o.role = "metadata"
	if zr.Comment != "" {
		if err = o.entry(); err != nil {
			return err
		}

		if err = o.text("archive-comment.txt", zr.Comment, nil); err != nil {
			return err
		}
	}

	for _, entry := range zr.File {
		if entry.Comment != "" {
			if err = o.entry(); err != nil {
				return err
			}

			if err = o.text("member-comment.txt", entry.Comment, nil); err != nil {
				return err
			}
		}

		if len(entry.Extra) > 0 {
			if err = o.entry(); err != nil {
				return err
			}

			if err = o.text("zip-extra.bin", string(entry.Extra), nil); err != nil {
				return err
			}
		}
	}

	return nil
}

func extractGZIP(o *operation) error {
	data := o.parent.file.Content()
	reader := strings.NewReader(data)
	stream := 0

	for reader.Len() > 0 {
		if err := o.entry(); err != nil {
			return err
		}

		start := len(data) - reader.Len()

		gz, err := gzip.NewReader(contextByteReader{o.b.ctx, reader})
		if err != nil {
			return err
		}

		gz.Multistream(false)

		name := inheritedName(o.parent.file.Metadata().Path, ".gz")
		if strings.HasSuffix(strings.ToLower(name), ".tgz") {
			name = name[:len(name)-4] + ".tar"
		}

		if gz.Name != "" {
			if err := archiveutil.ValidatePath(gz.Name, 1024, 32); err != nil {
				o.issue("gzip_name_untrusted", "Gzip filename is unsafe or ambiguous; a synthetic name was used.")
			} else {
				name = gz.Name
			}
		}

		comment := gz.Comment
		extra := append([]byte(nil), gz.Extra...)
		err = o.emit(name, gz, -1, false, nil)
		closeErr := gz.Close()

		if err != nil {
			return err
		}

		if closeErr != nil {
			return closeErr
		}

		if reader.Len() >= len(data)-start {
			return errFormat
		}
		// ByteReader prevents gzip read-ahead from swallowing the next member.
		child := &o.b.result.Report.Objects[len(o.b.result.Report.Objects)-1]
		child.ParentRange = &model.ByteRange{Start: start, End: len(data) - reader.Len()}

		if err = extractGZIPMetadata(o, comment, extra); err != nil {
			return err
		}

		stream++
	}

	if stream == 0 {
		return errFormat
	}

	return nil
}

func extractGZIPMetadata(o *operation, comment string, extra []byte) error {
	if comment != "" {
		if err := o.entry(); err != nil {
			return err
		}

		if err := o.text("gzip-comment.txt", comment, nil); err != nil {
			return err
		}
	}

	if len(extra) > 0 {
		if err := o.entry(); err != nil {
			return err
		}

		if err := o.text("gzip-extra.bin", string(extra), nil); err != nil {
			return err
		}
	}

	return nil
}

// TAR support intentionally excludes PAX/GNU/sparse/link records. Inspect each
// raw header before tar.Reader can consume hidden metadata pseudo-entries. The
// raw container stays available for rules even when this narrow profile fails.
func extractTAR(o *operation) error {
	o.role = valueArchiveMember
	data := o.parent.file.Content()
	names := archiveutil.Namespace{MaxNodes: o.b.limits.MaxEntries - o.b.result.Report.EntriesVisited}

	at := 0
	for at < len(data) {
		next, done, err := extractTARMember(o, &names, data, at)
		if err != nil {
			return err
		}

		if done {
			return nil
		}

		at = next
	}
	// Two end blocks are required by this narrow profile.
	return io.ErrUnexpectedEOF
}

func extractTARMember(o *operation, names *archiveutil.Namespace, data string, at int) (int, bool, error) {
	if err := o.entry(); err != nil {
		return at, false, err
	}

	if len(data)-at < 512 {
		return at, false, errFormat
	}

	block := data[at : at+512]
	if strings.Trim(block, "\x00") == "" {
		if len(data)-at < 1024 || strings.Trim(data[at:], "\x00") != "" {
			return at, false, errFormat
		}

		return at, true, nil
	}

	typ := block[156]
	if typ != tar.TypeReg && typ != byte(0) && typ != tar.TypeDir {
		return at, false, errFormat
	}

	tr := tar.NewReader(strings.NewReader(data[at:]))

	hdr, err := tr.Next()
	if err != nil {
		return at, false, err
	}

	if hdr.Format != tar.FormatUSTAR && hdr.Format != tar.FormatUnknown {
		return at, false, errFormat
	}

	if len(hdr.PAXRecords) > 0 || hdr.Linkname != "" || hdr.Size < 0 {
		return at, false, errFormat
	}

	name := strings.TrimSuffix(hdr.Name, "/")
	if err = archiveutil.ValidatePath(name, 1024, 32); err != nil {
		return at, false, err
	}

	directory := typ == tar.TypeDir
	if err = names.Add(name, directory); err != nil {
		return at, false, err
	}

	if directory && hdr.Size != 0 {
		return at, false, errFormat
	}
	// Reject declared expansion before arithmetic or allocation.
	if hdr.Size > int64(len(data)-at-512) {
		return at, false, errFormat
	}

	padded := (hdr.Size + 511) / 512 * 512
	if padded > int64(len(data)-at-512) {
		return at, false, errFormat
	}

	if !directory {
		if hdr.Size > o.b.limits.MaxObjectBytes {
			o.skipMember(name, "object_byte_limit", hdr.Size)
			o.issue("extraction_object_limit", "A TAR member exceeds the object budget; its prefix is not accepted.")
			o.b.result.Report.Steps[o.step].Status = statusPartial
		} else if err = o.emit(name, tr, hdr.Size, hdr.Mode&0o111 != 0, &model.ByteRange{Start: at + 512, End: at + 512 + int(hdr.Size)}); err != nil {
			return at, false, err
		}
	}

	return at + 512 + int(padded), false, nil
}
