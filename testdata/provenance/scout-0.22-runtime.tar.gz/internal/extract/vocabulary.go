package extract

// Shared vocabulary used by this package's protocols and reports.
const (
	valueB64           = ".b64"
	valueArchiveMember = "archive_member"
	valueContentBin    = "content.bin"
	statusPartial      = "partial"
)
