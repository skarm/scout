package extract

// Shared vocabulary used by this package's protocols and reports.
const (
	valueBase64 = ".base64"
)
