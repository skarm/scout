package extract

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"path"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/skarm/scout/internal/model"
)

const MaxJSONDepth = 64

func jsonCandidate(name, data string) bool {
	if strings.EqualFold(path.Ext(name), ".json") {
		return true
	}
	// Conservative content hint, not a promise to find every embedded JSON value.
	s := strings.TrimSpace(data)
	if len(s) < 2 || !utf8.ValidString(s) || strings.ContainsRune(s, 0) {
		return false
	}

	if s[0] != '{' && s[0] != '[' {
		return false
	}

	tail := strings.TrimSpace(s[1:])

	return strings.HasPrefix(tail, "\"") || strings.HasPrefix(tail, "{")
}

// Stream tokens instead of building an unbounded map/interface tree. Both keys
// and values are inspected; field names cannot turn off extraction. Token IDs,
// not actual key/value strings, are used in provenance to avoid secret leakage.
func extractJSON(o *operation) error {
	text := o.parent.file.Content()
	decoder := json.NewDecoder(contextReader{o.b.ctx, strings.NewReader(text)})
	decoder.UseNumber()

	depth := 0
	finished := false
	ordinal := 0

	for {
		if err := o.entry(); err != nil {
			return err
		}

		start := int(decoder.InputOffset())

		token, err := decoder.Token()
		if errors.Is(err, io.EOF) {
			if !finished {
				return errFormat
			}

			return nil
		}

		if err != nil {
			return err
		}

		if finished {
			return errFormat
		} // multiple top-level values are not one JSON document

		end := int(decoder.InputOffset())

		switch value := token.(type) {
		case json.Delim:
			depth, finished, err = jsonDelimiterDepth(value, depth)
			if err != nil {
				return err
			}
		case string:
			if err = extractJSONString(o, value, ordinal, model.ByteRange{Start: start, End: end}, text[start:end]); err != nil {
				return err
			}

			if depth == 0 {
				finished = true
			}
		default:
			if depth == 0 {
				finished = true
			}
		}

		ordinal++
	}
}

func jsonDelimiterDepth(value json.Delim, depth int) (int, bool, error) {
	switch value {
	case '{', '[':
		depth++
		if depth > MaxJSONDepth {
			return depth, false, errBudget
		}
	case '}', ']':
		depth--
		if depth < 0 {
			return depth, false, errFormat
		}

		return depth, depth == 0, nil
	}

	return depth, false, nil
}

func extractJSONString(o *operation, value string, ordinal int, span model.ByteRange, raw string) error {
	// encoding/json substitutes U+FFFD for invalid Unicode. Validate the actual
	// bytes so malformed escapes cannot be mistaken for literal U+FFFD.
	if !validJSONUnicode(raw) {
		return errFormat
	}

	return o.text(fmt.Sprintf("json-string-%d.txt", ordinal), value, &span)
}

func validJSONUnicode(raw string) bool {
	if !utf8.ValidString(raw) {
		return false
	}

	quote := strings.IndexByte(raw, '"')
	if quote < 0 {
		return false
	}

	for at := quote + 1; at < len(raw)-1; {
		if raw[at] != '\\' {
			at++
			continue
		}

		if at+1 >= len(raw) {
			return false
		}

		if raw[at+1] != 'u' {
			at += 2
			continue
		}

		if at+6 > len(raw) {
			return false
		}

		value, err := strconv.ParseUint(raw[at+2:at+6], 16, 16)
		if err != nil {
			return false
		}

		at += 6
		if value >= 0xd800 && value <= 0xdbff {
			if at+6 > len(raw) || raw[at:at+2] != "\\u" {
				return false
			}

			low, err := strconv.ParseUint(raw[at+2:at+6], 16, 16)
			if err != nil || low < 0xdc00 || low > 0xdfff {
				return false
			}

			at += 6
		} else if value >= 0xdc00 && value <= 0xdfff {
			return false
		}
	}

	return true
}
