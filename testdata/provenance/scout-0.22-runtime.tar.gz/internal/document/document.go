// Package document prepares bounded, source-mapped analysis units. Markdown
// support is deliberately a block-envelope subset, NOT a CommonMark/YAML parser.
// Unhandled executable containers and frontmatter prevent automatic admission.
package document

import (
	"context"
	"go/ast"
	"go/token"
	"strings"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/filetype"
	"github.com/skarm/scout/internal/language"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/securitytext"
	"github.com/skarm/scout/internal/source"
)

const (
	MaxRegions        = 512
	MaxGoBytes        = parse.MaxUnitBytes // compatibility name, not a language restriction
	MaxScanGoBytes    = parse.MaxScanBytes
	MaxSourceSegments = 8192
)

type Region struct {
	Kind     string
	Language string // normalized allowlisted label; never untrusted metadata
	Span     source.Span
}

// GoUnit contains a tree and token set owned by the preparation stage. Trusted
// analyzers must not mutate them. They never invoke a compiler or importer.
type GoUnit struct {
	View   source.View
	Tree   *ast.File
	Tokens *token.FileSet
}

// Unit is language-neutral. Unsupported units are retained, rather than being
// silently discarded. A parser tree is private to its matching trusted backend.
type Unit struct {
	Language, Origin, ParserID, ParserVersion, Status string
	Span                                              source.Span
	View                                              source.View
	Tree                                              any
}

// ConfigScope is a non-authoritative structural role attached by harness discovery.
// It grants no exemptions, does not imply activation and always uses physical bytes.
type ConfigScope struct {
	Role string
	Host string
	Span source.Span
}

type File struct {
	securityViews  []source.View
	configScopes   []ConfigScope
	file           artifact.File
	index          source.Index
	regions        []Region
	units          []Unit
	classification filetype.Description
	registry       parse.Registry
	diagnostics    []model.Diagnostic
	budget         *parseBudget
}

type parseBudget struct {
	consumed      map[string]int
	securityBytes int
}

type line struct{ start, end, next int }

// PrepareAll enforces an additional aggregate per-backend parser budget per scan, not
// merely a per-file limit. It shares no cache or mutable state between scans.
func PrepareAll(ctx context.Context, files []artifact.File) []File {
	return PrepareAllWithRegistry(ctx, files, parse.Defaults())
}

// PrepareAllWithRegistry allows future languages without language switches in
// the preparation engine. A registered parser does not imply semantic coverage.
func PrepareAllWithRegistry(ctx context.Context, files []artifact.File, registry parse.Registry) []File {
	budget := parseBudget{consumed: make(map[string]int)}

	documents := make([]File, len(files))
	for i, file := range files {
		documents[i] = prepare(ctx, file, &budget, registry)
	}

	return documents
}

// Prepare retains the raw file even if parsing fails: literal checks must still
// run. Diagnostics contain neither parser errors nor source excerpts.
func Prepare(ctx context.Context, file artifact.File) (out File) {
	return prepare(ctx, file, &parseBudget{consumed: make(map[string]int)}, parse.Defaults())
}

func (f File) WithConfigScopes(scopes []ConfigScope) File {
	f.configScopes = append([]ConfigScope(nil), scopes...)
	return f
}
func (f File) ConfigScopes() []ConfigScope { return append([]ConfigScope(nil), f.configScopes...) }

func (f File) Artifact() artifact.File      { return f.file }
func (f File) SecurityViews() []source.View { return append([]source.View(nil), f.securityViews...) }
func (f File) Index() source.Index          { return f.index }
func (f File) Regions() []Region            { return append([]Region(nil), f.regions...) }
func (f File) Units() []Unit                { return append([]Unit(nil), f.units...) }
func (f File) Classification() filetype.Description {
	d := f.classification
	d.Languages = append([]language.Hint(nil), d.Languages...)

	return d
}

func (f File) GoUnits() []GoUnit {
	var units []GoUnit
	for _, u := range f.units {
		if tree, ok := u.Tree.(parse.GoTree); ok {
			units = append(units, GoUnit{u.View, tree.Tree, tree.Tokens})
		}
	}

	return units
}

// HasParsedUnits is language neutral. A backend result does not establish
// semantic completeness; unit statuses and diagnostics remain authoritative.
func (f File) HasParsedUnits() bool {
	for _, u := range f.units {
		if u.ParserID != "" && u.Tree != nil {
			return true
		}
	}

	return false
}

func (f File) HasGo() bool {
	for _, u := range f.units {
		if _, ok := u.Tree.(parse.GoTree); ok {
			return true
		}
	}

	return false
}

func (f File) Diagnostics() []model.Diagnostic {
	return append([]model.Diagnostic(nil), f.diagnostics...)
}

func (f File) Context(s source.Span) (kind, language string) {
	for _, r := range f.regions {
		if s.Start >= r.Span.Start && s.End <= r.Span.End {
			return r.Kind, r.Language
		}
	}

	for _, u := range f.units {
		if u.Origin == "file" && s.Start >= u.Span.Start && s.End <= u.Span.End {
			return "source-file", u.Language
		}
	}

	return "", ""
}

func (f *File) issue(code, message string) {
	// One diagnostic of a given kind per file bounds large malformed documents.
	for _, d := range f.diagnostics {
		if d.Code == code {
			return
		}
	}

	f.diagnostics = append(f.diagnostics, model.Diagnostic{Code: code, Path: f.file.Metadata().Path, Message: message, AffectsScope: true})
}

func (f *File) region(r Region) bool {
	if len(f.regions) >= MaxRegions {
		f.issue("document_region_limit", "Document region budget exhausted; remaining structure is unknown.")
		return false
	}

	f.regions = append(f.regions, r)

	return true
}

func (f *File) addUnit(ctx context.Context, lang, origin string, span source.Span, v source.View) {
	if len(f.units) >= MaxRegions {
		f.issue("analysis_unit_limit", "Analysis unit budget exhausted; remaining units are unverified.")
		return
	}

	u := Unit{Language: lang, Origin: origin, Span: span, View: v, Status: "unsupported"}
	f.units = append(f.units, u)
	unit := &f.units[len(f.units)-1]

	backend, supported := f.registry.Lookup(lang)
	if !supported {
		code := "structural_analysis_unavailable"
		if origin != "file" {
			code = "embedded_language_unsupported"
		}

		f.issue(code, "No parser is installed for an analysis unit; raw checks still run and its semantics remain unverified.")

		return
	}

	d := backend.Descriptor()
	unit.ParserID = d.ID
	unit.ParserVersion = d.Version
	unit.Status = "not_run"

	f.issue(lang+"_semantics_limited", "A syntax parser and selected rules do not establish complete behavior, variable flow or cross-file semantics.")

	if ctx.Err() != nil {
		f.issue("preparation_cancelled", "Document preparation was cancelled.")
		return
	}

	if len(v.Text()) > d.UnitBytes {
		unit.Status = valueBudgetExceeded

		f.issue(lang+"_source_limit", "Analysis unit exceeds the parser byte budget.")

		return
	}

	if len(v.Text()) > d.ScanBytes-f.budget.consumed[d.ID] {
		unit.Status = valueBudgetExceeded

		f.issue(lang+"_scan_budget", "Aggregate parser byte budget exhausted; this unit was not parsed.")

		return
	}

	f.budget.consumed[d.ID] += len(v.Text())
	unit.Status = "parsing"
	tree, err := backend.Parse(ctx, v)

	unit.Tree = tree
	if identity, ok := tree.(interface{ RuntimeIdentity() string }); ok && identity.RuntimeIdentity() != "" {
		unit.ParserVersion += ":" + identity.RuntimeIdentity()
	}

	if lang == "toml" {
		f.issue("toml_coarse_evidence", "The trusted TOML parser supplies values without token positions; evidence covers the complete unit, not invented per-field locations.")
	}

	unit.Status = "parsed_limited"

	if err != nil {
		category := parse.FailureCategory(err)

		unit.Status = "parse_error"
		if category == "unsupported_syntax" {
			unit.Status = "unsupported_syntax"
		}

		if category == "backend_unavailable" {
			unit.Status = "unavailable"
		}

		if category == "parser_limit" {
			unit.Status = valueBudgetExceeded
		}

		f.issue(lang+"_"+category, "Syntax was not fully parsed; preceding usable syntax is still checked and unparsed content remains unverified.")
	}

	if ctx.Err() != nil {
		f.issue("preparation_cancelled", "Document preparation was cancelled.")
	}
}

func (f *File) markdown(ctx context.Context) {
	text := f.file.Content()
	at := 0
	// UTF-8 BOM is retained in raw source and mapping.
	if strings.HasPrefix(text, "\ufeff") {
		at = len("\ufeff")
	}

	at, proceed := f.markdownFrontmatter(ctx, text, at)
	if !proceed {
		return
	}

	f.markdownBody(ctx, text, at)
}

func (f *File) markdownFrontmatter(ctx context.Context, text string, at int) (int, bool) {
	if at < len(text) {
		first := nextLine(text, at)
		if text[first.start:first.end] == "---" {
			start := at
			at = first.next
			closed := false

			bodyStart, bodyEnd := first.next, len(text)
			for at < len(text) {
				if ctx.Err() != nil {
					f.issue("preparation_cancelled", "Document preparation was cancelled.")
					return at, false
				}

				l := nextLine(text, at)

				at = l.next
				if text[l.start:l.end] == "---" || text[l.start:l.end] == "..." {
					bodyEnd = l.start
					closed = true

					break
				}
			}

			f.region(Region{Kind: "frontmatter", Language: "yaml", Span: source.Span{Start: start, End: at}})

			if _, ok := f.registry.Lookup("yaml"); ok && closed && bodyEnd > bodyStart {
				span := source.Span{Start: bodyStart, End: bodyEnd}

				view, e := source.NewView(text, []source.Span{span})
				if e == nil {
					f.addUnit(ctx, "yaml", "frontmatter", span, view)
				} else {
					f.issue("source_map_error", "Frontmatter mapping failed.")
				}
			} else {
				f.issue("frontmatter_semantics_unavailable", "Frontmatter YAML interpretation is unavailable; raw bytes remain subject to all rules.")
			}

			if !closed {
				f.issue("unterminated_frontmatter", "Frontmatter has no closing delimiter; structure is uncertain.")
			}
		}
	}

	return at, true
}

func (f *File) markdownBody(ctx context.Context, text string, at int) {
	for at < len(text) {
		if ctx.Err() != nil {
			f.issue("preparation_cancelled", "Document preparation was cancelled.")
			return
		}

		l := nextLine(text, at)
		s := text[l.start:l.end]

		indent, ch, width, info, ok := openingFence(s)
		if ok {
			var proceed bool

			at, proceed = f.markdownFence(ctx, text, l, indent, ch, width, info)
			if !proceed {
				return
			}

			continue
		}
		// Conservatively account for constructs requiring full CommonMark parsing.
		trim := strings.TrimLeft(s, " \t")
		if strings.HasPrefix(s, "    ") || strings.HasPrefix(s, "\t") {
			if strings.TrimSpace(s) != "" {
				if !f.region(Region{Kind: "indented-content", Language: "unknown", Span: source.Span{Start: l.start, End: l.next}}) {
					return
				}

				f.issue("markdown_container_unsupported", "Indented content requires a full Markdown/container parser; literal checks still run.")
			}
		}

		if strings.HasPrefix(trim, ">") || strings.HasPrefix(trim, "<") ||
			(strings.Contains(trim, "```") || strings.Contains(trim, "~~~")) {
			f.issue("markdown_container_unsupported", "Nested, inline-fenced or HTML content is outside the block-envelope parser; literal checks still run.")
		}

		at = l.next
	}
}

func (f *File) markdownFence(ctx context.Context, text string, l line, indent int, ch byte, width int, info string) (int, bool) {
	start := l.start
	lang := fenceLanguage(info)
	at := l.next
	spans := []source.Span{}
	closed := false
	hasContent, mappingLimited := false, false
	viewBytes := 0

	for at < len(text) {
		if ctx.Err() != nil {
			f.issue("preparation_cancelled", "Document preparation was cancelled.")
			return at, false
		}

		body := nextLine(text, at)

		at = body.next
		if closingFence(text[body.start:body.end], ch, width) {
			closed = true
			break
		}

		prefix := 0
		for prefix < indent && body.start+prefix < body.end && text[body.start+prefix] == ' ' {
			prefix++
		}

		if strings.TrimSpace(text[body.start:body.end]) != "" {
			hasContent = true
		}
		{
			viewBytes += body.next - body.start - prefix
			if viewBytes > MaxGoBytes {
				mappingLimited = true

				f.issue(lang+"_source_limit", "Embedded analysis unit exceeds the source byte budget.")
			} else if len(spans) >= MaxSourceSegments {
				mappingLimited = true

				f.issue("document_segment_limit", "Embedded source mapping exceeds its segment budget.")
			}

			if !mappingLimited {
				spans = append(spans, source.Span{Start: body.start + prefix, End: body.next})
			}
		}
	}

	if !f.region(Region{Kind: "fenced-code", Language: lang, Span: source.Span{Start: start, End: at}}) {
		return at, false
	}

	if !closed {
		f.issue("unclosed_fence", "A fence extends to end of file; its content is not treated as safe text.")
	}

	if !hasContent || mappingLimited {
		return at, true
	}
	{
		view, err := source.NewView(text, spans)
		if err != nil {
			f.issue("source_map_error", "Embedded source mapping failed.")
			return at, true
		}

		f.addUnit(ctx, lang, "fenced-code", source.Span{Start: start, End: at}, view)
	}

	return at, true
}

func prepare(ctx context.Context, file artifact.File, budget *parseBudget, registry parse.Registry) (out File) {
	out = File{
		file: file, budget: budget, registry: registry,
		classification: filetype.Inspect(file.Metadata().Path, file.Content(), file.Metadata().Executable),
	}
	if file.GeneratedName() {
		// A synthetic .txt label cannot establish filename deception. Keep all
		// detected languages, executable hints and raw/decoded analysis intact.
		out.classification.Conflict = false
	}
	defer func() {
		out.budget = nil
		if recover() != nil {
			for i := range out.units {
				if out.units[i].Status == "parsing" {
					out.units[i].Status = "failed"
				}
			}

			out.issue("parser_panic", "Document preparation failed; raw-text checks remain available.")
		}
	}()

	if ctx == nil || ctx.Err() != nil {
		out.issue("preparation_cancelled", "Document preparation was cancelled.")
		return out
	}

	if file.Metadata().Kind != "text" {
		return out
	}

	out.index = source.NewIndex(file.Content())
	if len(file.Content()) > securitytext.MaxScanBytes-budget.securityBytes {
		out.issue("security_reconstruction_limit", "Aggregate security-text reconstruction budget exhausted; raw checks remain available.")
	} else {
		budget.securityBytes += len(file.Content())

		var limited bool

		out.securityViews, limited = securitytext.Views(ctx, file.Content())
		if limited {
			out.issue("security_reconstruction_limit", "Security-text reconstruction exceeded its source, mapping or runtime budget; raw checks remain available.")
		}
	}

	seen := map[string]bool{}
	for _, h := range out.classification.Languages {
		if !language.Structured(h.Language) || seen[h.Language] {
			continue
		}

		seen[h.Language] = true
		span := source.Span{Start: 0, End: len(file.Content())}

		view, err := source.NewView(file.Content(), []source.Span{span})
		if err != nil {
			out.issue("source_map_error", "Source mapping could not be constructed.")
			continue
		}

		out.addUnit(ctx, h.Language, "file", span, view)
	}
	// Any text file may contain an embedded document, including LICENSE, JSON
	// or source code. This conservative envelope pass never grants trust.
	out.markdown(ctx)

	return out
}

func nextLine(text string, start int) line {
	n := strings.IndexByte(text[start:], '\n')

	end, next := len(text), len(text)
	if n >= 0 {
		end = start + n
		next = end + 1
	}

	if end > start && text[end-1] == '\r' {
		end--
	}

	return line{start: start, end: end, next: next}
}

func openingFence(s string) (indent int, ch byte, width int, info string, ok bool) {
	for indent < len(s) && s[indent] == ' ' {
		indent++
	}

	if indent > 3 || indent >= len(s) || (s[indent] != '`' && s[indent] != '~') {
		return
	}

	ch = s[indent]
	for indent+width < len(s) && s[indent+width] == ch {
		width++
	}

	if width < 3 {
		return
	}

	info = strings.TrimSpace(s[indent+width:])
	if ch == '`' && strings.ContainsRune(info, '`') {
		return
	}

	ok = true

	return
}

func closingFence(s string, ch byte, width int) bool {
	i := 0
	for i < len(s) && s[i] == ' ' {
		i++
	}

	if i > 3 {
		return false
	}

	start := i
	for i < len(s) && s[i] == ch {
		i++
	}

	return i-start >= width && strings.TrimSpace(s[i:]) == ""
}

func fenceLanguage(info string) string {
	fields := strings.Fields(info)
	if len(fields) == 0 {
		return "unknown"
	}

	return language.Normalize(fields[0])
}
