package document

// Shared vocabulary used by this package's protocols and reports.
const (
	valueBudgetExceeded = "budget_exceeded"
)
