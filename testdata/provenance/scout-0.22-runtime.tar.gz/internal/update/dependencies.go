package update

import (
	"sort"

	"github.com/skarm/scout/internal/model"
)

func (b *builder) dependencyGroups(r model.Report, x inventory) map[string][]model.Dependency {
	groups := map[string][]model.Dependency{}

	for _, d := range r.Dependencies.Declarations {
		if !b.step() {
			return groups
		}

		g := key(x.objectKey(d.Source.Path), d.Ecosystem, d.Module)
		groups[g] = append(groups[g], d)
	}

	for _, g := range sortedKeys(groups, nil) {
		sort.Slice(groups[g], func(i, j int) bool { return groups[g][i].Source.ByteStart < groups[g][j].Source.ByteStart })
	}

	return groups
}

func (b *builder) dependencies() {
	oldChecks, newChecks := dependencyChecks(b.r.Before, b.old), dependencyChecks(b.r.After, b.next)

	a, z := b.dependencyGroups(b.r.Before, b.old), b.dependencyGroups(b.r.After, b.next)
	for _, g := range sortedKeys(a, z) {
		if !b.step() {
			return
		}

		left, right := a[g], z[g]
		if dependencySignatures(left) == dependencySignatures(right) {
			continue
		}

		c := model.DependencyChange{GroupID: g, Change: "changed", Before: append([]model.Dependency{}, left...), After: append([]model.Dependency{}, right...)}
		if len(left) == 0 {
			c.Change = valueAdded
			c.ObjectID = b.next.objectKey(right[0].Source.Path)
		} else {
			c.ObjectID = b.old.objectKey(left[0].Source.Path)
		}

		if len(right) == 0 {
			c.Change = valueRemoved
		}

		if (len(left) == 0 && !dependencyAbsenceKnown(c.ObjectID, b.old, oldChecks)) ||
			(len(right) == 0 && !dependencyAbsenceKnown(c.ObjectID, b.next, newChecks)) {
			c.Change = valueUnverified

			b.issue("dependency_absence_unverified")
		}

		b.r.Delta.Counts.DependencyChanges++
		if b.retain() {
			b.r.Delta.Dependencies = append(b.r.Delta.Dependencies, c)
		}
	}
}

func dependencySignature(d model.Dependency) string {
	// The replacement source hash is needed even for local replacement paths,
	// whose sensitive literal values are deliberately not reported.
	replacement := ""
	if d.ReplacementSource != nil {
		replacement = d.ReplacementSource.SpanSHA256
	}

	return digest(struct {
		Ecosystem, Module, Version, Semantics, Replacement, ReplacementModule, ReplacementVersion, ReplacementSHA string
		Indirect                                                                                                  bool
	}{d.Ecosystem, d.Module, d.DeclaredVersion, d.VersionSemantics, d.Replacement, d.ReplacementModule, d.ReplacementVersion, replacement, d.Indirect})
}

func dependencySignatures(ds []model.Dependency) string {
	x := make([]string, 0, len(ds))
	for _, d := range ds {
		x = append(x, dependencySignature(d))
	}

	sort.Strings(x)

	return digest(x)
}

func dependencyChecks(r model.Report, x inventory) map[string]bool {
	out := map[string]bool{}

	for _, m := range r.Dependencies.Manifests {
		id := x.objectKey(m.Path)

		ok := m.Status == valueParsedLimited
		if prior, exists := out[id]; exists {
			ok = ok && prior
		}

		out[id] = ok
	}

	return out
}

func dependencyAbsenceKnown(id string, x inventory, checks map[string]bool) bool {
	o := x.byKey[id]
	if o == nil {
		return x.complete
	}

	return o.file.Status == valueCaptured && checks[id]
}
