// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Modified SkillSpector RP1-RP3: compare both fresh source-bound metadata sets,
// retain hashes/evidence only and align archive members through object addresses.

package update

import "github.com/skarm/scout/internal/model"

func (b *builder) manifests() {
	b.r.Delta.ManifestSignals = []model.ManifestSignal{}
	old := map[string]model.MetadataFile{}

	for _, f := range b.r.Before.Metadata.Files {
		if !b.step() {
			return
		}

		if o := b.old.byPath[f.Path]; o != nil {
			id := key(o.key, f.Format)
			if _, duplicate := old[id]; duplicate {
				b.issue("ambiguous_previous_manifest")
				continue
			}

			old[id] = f
		}
	}

	for _, next := range b.r.After.Metadata.Files {
		if !b.step() {
			return
		}

		o := b.next.byPath[next.Path]
		if o == nil {
			continue
		}

		previous, ok := old[key(o.key, next.Format)]
		if !ok || previous.Status != "parsed_subset" || next.Status != "parsed_subset" {
			continue
		}

		if !b.compareManifestFields(previous, next) {
			return
		}
	}
}

func (b *builder) compareManifestFields(previous, next model.MetadataFile) bool {
	for _, field := range []string{"permissions", "allowed-tools", "triggers", "parameters"} {
		if !b.step() {
			return false
		}

		a, z := lastMetadataField(previous.Fields, field), lastMetadataField(next.Fields, field)
		if a == nil && z == nil {
			continue
		}

		if a != nil && !a.ItemsComplete || z != nil && !z.ItemsComplete {
			b.issue("manifest_declaration_unverified")
			continue
		}

		changes, complete := b.compareManifestItems(a, z)
		if !complete {
			return false
		}

		b.recordManifestSignal(field, a, z, changes)
	}

	return true
}

func lastMetadataField(fields []model.MetadataField, name string) *model.MetadataField {
	var found *model.MetadataField

	for i := range fields {
		if fields[i].Name == name {
			found = &fields[i]
		}
	}

	return found
}

type manifestChanges struct{ added, changed, removed bool }

func metadataItems(field *model.MetadataField) map[string]string {
	out := map[string]string{}

	if field != nil {
		for _, item := range field.Items {
			out[item.NameSHA256] = item.ValueSHA256
		}
	}

	return out
}

func (b *builder) compareManifestItems(a, z *model.MetadataField) (manifestChanges, bool) {
	before, after := metadataItems(a), metadataItems(z)
	changes := manifestChanges{}

	for k, v := range after {
		if !b.step() {
			return changes, false
		}

		if old, ok := before[k]; !ok {
			changes.added = true
		} else if old != v {
			changes.changed = true
		}
	}

	for k := range before {
		if !b.step() {
			return changes, false
		}

		if _, ok := after[k]; !ok {
			changes.removed = true
		}
	}

	return changes, true
}

func (b *builder) recordManifestSignal(field string, a, z *model.MetadataField, changes manifestChanges) {
	rule, severity, kind := "NV-RP1", model.High, "permissions_expanded"

	switch field {
	case "triggers":
		rule, severity, kind = "NV-RP2", model.Medium, "triggers_modified"
	case "parameters":
		rule, severity, kind = "NV-RP3", model.Medium, "parameters_modified"
	}

	if rule == "NV-RP1" && !changes.added {
		return
	}

	if !changes.added && !changes.changed && !changes.removed {
		return
	}

	if !b.retain() {
		return
	}

	signal := model.ManifestSignal{RuleID: rule, Severity: severity, Field: field, Change: kind}

	if a != nil {
		ref := a.Source
		signal.Before = &ref
	}

	if z != nil {
		ref := z.Source
		signal.After = &ref
	}

	b.r.Delta.ManifestSignals = append(b.r.Delta.ManifestSignals, signal)
	b.r.Delta.Counts.ManifestSignals++
}
