package update

// Shared vocabulary used by this package's protocols and reports.
const (
	valueAdded         = "added"
	valueCaptured      = "captured"
	valueParsedLimited = "parsed_limited"
	valueRemoved       = "removed"
	valueUnverified    = "unverified"
)
