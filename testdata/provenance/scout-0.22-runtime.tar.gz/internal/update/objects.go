package update

import (
	"encoding/json"
	"sort"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/model"
)

type object struct {
	key     string
	address model.ObjectAddress
	file    model.File
}
type inventory struct {
	byPath   map[string]*object
	byKey    map[string]*object
	complete bool
}

func (x inventory) objectKey(path string) string {
	if o := x.byPath[path]; o != nil {
		return o.key
	}
	// Never merge an unresolved object with an unrelated valid locator.
	return key("unresolved", path)
}

func (b *builder) inventory(r model.Report, single bool) inventory {
	out := inventory{byPath: map[string]*object{}, byKey: map[string]*object{}, complete: r.Artifact.InventoryComplete}

	put := func(f model.File, a model.ObjectAddress) {
		id := digest(a)
		if out.byKey[id] != nil || out.byPath[f.Path] != nil {
			out.complete = false

			b.issue("ambiguous_object_identity")

			return
		}

		o := &object{id, a, f}

		out.byKey[id], out.byPath[f.Path] = o, o
		if f.Status != valueCaptured || f.SHA256 == "" {
			out.complete = false
		}
	}
	for _, f := range r.Artifact.Files {
		if !b.step() {
			out.complete = false
			return out
		}

		a := model.ObjectAddress{Root: f.Path}
		if single {
			a = model.ObjectAddress{SingleFile: true}
		}

		put(f, a)
	}
	// Extractor output is normally BFS. Sort by depth so content-addressed URI
	// ordering never becomes a hidden parent-before-child assumption.
	derived := append([]model.DerivedObject(nil), r.Extraction.Objects...)
	sort.Slice(derived, func(i, j int) bool {
		if derived[i].Depth != derived[j].Depth {
			return derived[i].Depth < derived[j].Depth
		}

		return derived[i].File.Path < derived[j].File.Path
	})

	for _, d := range derived {
		if !b.step() {
			out.complete = false
			return out
		}

		p := out.byPath[d.ParentPath]
		if p == nil || p.file.SHA256 != d.ParentSHA256 {
			out.complete = false

			b.issue("unresolved_object_provenance")

			continue
		}

		a := model.ObjectAddress{SingleFile: p.address.SingleFile, Root: p.address.Root, Steps: append([]model.ObjectStep(nil), p.address.Steps...)}

		s := model.ObjectStep{Role: d.Role, Extractor: d.ExtractorID, ExtractorVersion: d.ExtractorVersion, Member: d.MemberName, Ordinal: d.Ordinal}
		if d.Role == "archive_member" {
			s.Ordinal = 0
		}

		a.Steps = append(a.Steps, s)
		put(d.File, a)
	}

	if len(r.Extraction.Skipped) > 0 {
		out.complete = false
	}

	for _, s := range r.Extraction.Steps {
		if s.Status != "completed" {
			out.complete = false
		}
	}

	return out
}

func (b *builder) files() {
	for _, id := range sortedKeys(b.old.byKey, b.next.byKey) {
		if !b.step() {
			return
		}

		a, z := b.old.byKey[id], b.next.byKey[id]
		c := model.FileChange{ObjectID: id, Reasons: []string{}}

		if a != nil {
			f := a.file
			c.Before = &f
			c.Address = a.address
		}

		if z != nil {
			f := z.file
			c.After = &f
			c.Address = z.address
		}

		switch {
		case a == nil:
			c.Change = valueAdded
			if !b.old.complete || z.file.Status != valueCaptured {
				c.Change = valueUnverified
			}
		case z == nil:
			c.Change = valueRemoved
			if !b.next.complete || a.file.Status != valueCaptured {
				c.Change = valueUnverified
			}
		case a.file.Status != valueCaptured || z.file.Status != valueCaptured:
			c.Change = valueUnverified
		default:
			c.Reasons = fileChangeReasons(a.file, z.file, c.Address)

			if len(c.Reasons) == 0 {
				b.r.Delta.Counts.UnchangedObjects++
				continue
			}

			c.Change = "modified"
			if len(c.Reasons) == 1 && c.Reasons[0] == "input_name_changed" {
				c.Change = "renamed_input"
			}
		}

		if c.Change == valueUnverified {
			b.issue("object_delta_unverified")

			c.Reasons = append(c.Reasons, "inventory_or_content_unavailable")
		}

		b.r.Delta.Counts.FileChanges++
		if b.retain() {
			b.r.Delta.Files = append(b.r.Delta.Files, c)
		}
	}
}

func fileChangeReasons(before, after model.File, address model.ObjectAddress) []string {
	reasons := []string{}
	if before.SHA256 != after.SHA256 || before.Size != after.Size {
		reasons = append(reasons, "content_changed")
	}

	if before.Executable != after.Executable {
		reasons = append(reasons, "executable_mode_changed")
	}

	if before.Kind != after.Kind {
		reasons = append(reasons, "content_classification_changed")
	}

	if address.SingleFile && len(address.Steps) == 0 && before.Path != after.Path {
		reasons = append(reasons, "input_name_changed")
	}

	return reasons
}

func digest(v any) string {
	b, err := json.Marshal(v)
	if err != nil {
		panic("update identity contains unsupported internal value")
	}

	return artifact.Hash(b)
}
func key(parts ...string) string { return digest(parts) }
func standalone(r model.Report) bool {
	return (r.Artifact.SourceKind == "file" || r.Artifact.SourceKind == "memory") && len(r.Artifact.Files) == 1
}

func sortedKeys[T any](a, b map[string]T) []string {
	set := make(map[string]bool, len(a)+len(b))
	for k := range a {
		set[k] = true
	}

	for k := range b {
		set[k] = true
	}

	keys := make([]string, 0, len(set))
	for k := range set {
		keys = append(keys, k)
	}

	sort.Strings(keys)

	return keys
}

func spanKey(s *model.SourceRef, x inventory) string {
	if s == nil {
		return key("no_source")
	}

	return key(x.objectKey(s.Path), s.SpanSHA256)
}

func locationKey(f model.Finding, x inventory) string {
	trace := make([]string, 0, len(f.Trace))
	for _, t := range f.Trace {
		trace = append(trace, key(t.Role, x.objectKey(t.Location.Path), t.Evidence.SpanSHA256))
	}

	related := make([]string, 0, len(f.RelatedEvidence))
	for _, r := range f.RelatedEvidence {
		related = append(related, key(x.objectKey(r.Path), r.SpanSHA256))
	}

	return key(x.objectKey(f.Location.Path), f.RuleID, f.RuleVersion, string(f.Severity), f.Category, f.Method, f.Evidence.SpanSHA256, digest(trace), digest(related), digest(f.AdvisoryIDs), digest(f.SignatureNames))
}
