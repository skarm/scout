package update

import (
	"slices"
	"sort"
	"strings"

	"github.com/skarm/scout/internal/model"
)

func (b *builder) findingGroups(r model.Report, x inventory) map[string][]model.Finding {
	groups := map[string][]model.Finding{}

	for _, f := range r.Findings {
		if !b.step() {
			return groups
		}

		g := locationKey(f, x)
		groups[g] = append(groups[g], f)
	}

	for _, g := range sortedKeys(groups, nil) {
		sort.Slice(groups[g], func(i, j int) bool {
			a, z := groups[g][i], groups[g][j]
			if a.Location.ByteStart != z.Location.ByteStart {
				return a.Location.ByteStart < z.Location.ByteStart
			}

			if a.Location.ByteEnd != z.Location.ByteEnd {
				return a.Location.ByteEnd < z.Location.ByteEnd
			}

			return a.ID < z.ID
		})
	}

	return groups
}

func (b *builder) findings() {
	a, z := b.findingGroups(b.r.Before, b.old), b.findingGroups(b.r.After, b.next)
	oldChecks := checkIndex(b.r.Before, b.old)

	newChecks := checkIndex(b.r.After, b.next)
	for _, g := range sortedKeys(a, z) {
		if !b.step() {
			return
		}

		left, right := a[g], z[g]

		n := min(len(left), len(right))
		for i := 0; i < max(len(left), len(right)); i++ {
			if !b.step() {
				return
			}

			c := b.findingSides(left, right, i)

			switch {
			case i < n:
				b.r.Delta.Counts.PersistentFindings++
				if b.contextKey(left[i], b.oldComponents) != b.contextKey(right[i], b.newComponents) {
					c.Change = "context_changed"
				} else if c.BeforeLocation.ByteStart != c.AfterLocation.ByteStart || c.BeforeLocation.ByteEnd != c.AfterLocation.ByteEnd {
					c.Change = "relocated"
				} else {
					continue
				}
			case i < len(right):
				c.Change = "introduced"
				if !absenceCheckComplete(right[i], c.ObjectID, b.old, oldChecks) {
					c.Change = valueUnverified

					b.issue("previous_finding_state_unverified")
				} else {
					b.r.Delta.Counts.IntroducedFindings++
				}
			case i < len(left):
				c.Change = "not_observed"

				b.r.Delta.Counts.UnobservedFindings++
				if !absenceCheckComplete(left[i], c.ObjectID, b.next, newChecks) {
					c.Change = valueUnverified

					b.issue("finding_absence_unverified")
				}
			}

			b.r.Delta.Counts.FindingChanges++
			if b.retain() {
				b.r.Delta.Findings = append(b.r.Delta.Findings, c)
			}
		}
	}
}

func (b *builder) findingSides(left, right []model.Finding, index int) model.FindingChange {
	c := model.FindingChange{}

	if index < len(left) {
		f := left[index]
		c.BeforeID = f.ID
		location := f.Location
		c.BeforeLocation = &location
		c.RuleID = f.RuleID
		c.ObjectID = b.old.objectKey(location.Path)
	}

	if index < len(right) {
		f := right[index]
		c.AfterID = f.ID
		location := f.Location
		c.AfterLocation = &location
		c.RuleID = f.RuleID
		c.ObjectID = b.next.objectKey(location.Path)
	}

	return c
}

func checkIndex(r model.Report, x inventory) map[string]model.FileCoverage {
	out := make(map[string]model.FileCoverage, len(r.Coverage.Files))
	for _, f := range r.Coverage.Files {
		out[x.objectKey(f.Path)] = f
	}

	return out
}

func absenceCheckComplete(f model.Finding, objectID string, x inventory, checks map[string]model.FileCoverage) bool {
	o := x.byKey[objectID]
	if o == nil {
		return x.complete
	}

	if o.file.Status != valueCaptured {
		return false
	}

	coverage, ok := checks[objectID]
	if !ok {
		return false
	}

	if slices.Contains(coverage.Gaps, "report_finding_limit") {
		return false
	}

	completed := false

	for _, c := range coverage.Checks {
		if c.AnalyzerID == f.RuleID {
			completed = c.Status == "completed"
		}
	}

	if !completed {
		return false
	}

	language := ""

	switch {
	case strings.HasPrefix(f.Method, "go-ast"):
		language = "go"
	case strings.HasPrefix(f.Method, "shell-"):
		language = "shell"
	case f.Method == "json-configuration":
		language = "json"
	}

	if language != "" {
		found := false

		for _, u := range coverage.Units {
			if u.Language == language {
				found = true

				if u.Status != valueParsedLimited {
					return false
				}
			}
		}

		if !found {
			return false
		}
	}

	return true
}
