// Package update compares fresh scan evidence without trusting an author-supplied
// baseline. A delta explains an update; it never suppresses a candidate finding.
package update

import (
	"context"
	"errors"

	"github.com/skarm/scout/internal/model"
)

const (
	AlgorithmVersion = "2"
	MaxOperations    = 2_000_000
)

type builder struct {
	ctx                          context.Context
	r                            model.UpdateReport
	old, next                    inventory
	oldComponents, newComponents componentIndex
	issues                       map[string]bool
	retained, operations         int
	stopped                      bool
}

func Build(ctx context.Context, before, after model.Report, options model.UpdateOptions) (model.UpdateReport, error) {
	if ctx == nil {
		return model.UpdateReport{}, errors.New("nil comparison context")
	}

	if err := options.Validate(); err != nil {
		return model.UpdateReport{}, err
	}

	b := builder{ctx: ctx, issues: map[string]bool{}, r: model.UpdateReport{
		SchemaVersion: "1", Kind: "fresh-local-update-review", EngineVersion: model.EngineVersion, Options: options, Before: before, After: after,
		Delta: model.UpdateDelta{
			AlgorithmVersion: AlgorithmVersion, Completeness: model.Complete,
			Files: []model.FileChange{}, Components: []model.ComponentChange{}, Dependencies: []model.DependencyChange{}, Findings: []model.FindingChange{}, Issues: []string{},
		},
		Limitations: []string{
			"Both local targets were freshly scanned under the same configured profile. The previous package is not trusted, and no existing finding is suppressed.",
			"Object addresses align relative paths and archive member names. Two standalone file targets align at an operator-selected input slot; their original names and hashes remain visible. No general rename detection is attempted.",
			"Component deltas compare source-bound groups and multisets, not guessed identities of unnamed hooks. Declared links and activation are not runtime behavior.",
			"A finding no longer observed is not proof of remediation. Model outcomes are retained in both reports, not treated as deterministic evidence of a behavioral change.",
			"Dependency changes concern declarations, not installed versions, CVEs, checksums or the remote implementation of MCP servers.",
			"Unknown or skipped content remains unknown. No changes means no observed difference in the captured scope, not a safe update or an install attestation.",
			"Semantic budgets, when enabled, apply independently to each scan; the CLI deadline spans both scans and comparison. Source upload can include both versions.",
		},
	}}
	// These should match because Scanner.Compare owns both scans. Guard against
	// accidental internal misuse rather than silently compare unlike contracts.
	if before.SchemaVersion == "" || after.SchemaVersion == "" ||
		before.SchemaVersion != after.SchemaVersion || before.EngineVersion != after.EngineVersion ||
		before.RulesVersion != after.RulesVersion || before.Profile != after.Profile ||
		before.Components.RequestedHost != after.Components.RequestedHost ||
		before.Policy.BlockAt != after.Policy.BlockAt || before.Policy.ID != after.Policy.ID ||
		digest(before.Limits) != digest(after.Limits) || digest(before.Extraction.Limits) != digest(after.Extraction.Limits) ||
		digest(before.AnalysisLimits) != digest(after.AnalysisLimits) || digest(before.Rules) != digest(after.Rules) ||
		before.Semantic.Enabled != after.Semantic.Enabled || digest(before.Semantic.Options) != digest(after.Semantic.Options) ||
		digest(before.Semantic.Provider) != digest(after.Semantic.Provider) {
		b.issue("comparison_contract_mismatch")
	}

	single := standalone(before) && standalone(after)
	b.old = b.inventory(before, single)

	b.next = b.inventory(after, single)
	if !b.old.complete {
		b.issue("previous_inventory_incomplete")
	}

	if !b.next.complete {
		b.issue("candidate_inventory_incomplete")
	}

	b.r.Delta.SameSnapshot = before.Artifact.InventoryComplete && after.Artifact.InventoryComplete &&
		before.Artifact.SnapshotSHA256 != "" && before.Artifact.SnapshotSHA256 == after.Artifact.SnapshotSHA256
	b.files()
	b.oldComponents = b.components(before, b.old)
	b.newComponents = b.components(after, b.next)
	b.componentChanges()
	b.dependencies()
	b.findings()
	b.manifests()
	b.finalize()

	return b.r, ctx.Err()
}

func ExitCode(r model.UpdateReport) int {
	if r.Completeness != model.Complete {
		return 2
	}

	if r.Policy.Decision != model.Allow {
		return 1
	}

	return 0
}

func (b *builder) issue(code string) {
	if b.issues[code] {
		return
	}

	b.issues[code] = true
	b.r.Delta.Issues = append(b.r.Delta.Issues, code)
	b.r.Delta.Completeness = model.Partial
}

func (b *builder) step() bool {
	if b.stopped {
		return false
	}

	if b.ctx.Err() != nil {
		b.issue("comparison_cancelled")
		b.stopped = true

		return false
	}

	b.operations++
	if b.operations > MaxOperations {
		b.issue("comparison_operation_limit")
		b.stopped = true

		return false
	}

	return true
}

func (b *builder) retain() bool {
	if b.retained >= b.r.Options.MaxChanges {
		b.r.Delta.OmittedChanges++
		b.issue("comparison_change_limit")

		return false
	}

	b.retained++

	return true
}

func (b *builder) finalize() {
	b.r.Completeness = model.Complete
	for _, c := range []model.Completeness{b.r.Before.Coverage.Completeness, b.r.After.Coverage.Completeness, b.r.Delta.Completeness} {
		if c == model.Failed {
			b.r.Completeness = model.Failed
			break
		}

		if c != model.Complete {
			b.r.Completeness = model.Partial
		}
	}

	p := b.r.After.Policy
	p.ID = "update-review-v1/" + p.ID

	p.Reasons = append([]string(nil), p.Reasons...)
	if p.Decision != model.Block && p.Decision != model.Review && p.Decision != model.Allow {
		p.Decision = model.Review
	}

	if b.r.Completeness != model.Complete {
		if p.Decision != model.Block {
			p.Decision = model.Review
		}

		p.Reasons = append(p.Reasons, "One of the fresh scans or the comparison is incomplete; an update cannot be admitted automatically.")
	}

	c := b.r.Delta.Counts
	if !b.r.Delta.SameSnapshot || c.FileChanges+c.ComponentChanges+c.DependencyChanges+c.FindingChanges > 0 {
		if p.Decision == model.Allow {
			p.Decision = model.Review
		}

		p.Reasons = append(p.Reasons, "Captured content or review evidence changed; absence of new findings is not approval of an update.")
	}

	if len(b.r.Before.Semantic.Proposals) > 0 {
		if p.Decision == model.Allow {
			p.Decision = model.Review
		}

		p.Reasons = append(p.Reasons, "Previous semantic hypotheses remain review obligations; a later model response that omits them is not evidence of remediation.")
	}

	p.Reasons = append(p.Reasons, "The candidate policy is evaluated on ALL current findings, including findings already present in the previous package.")
	for _, signal := range b.r.Delta.ManifestSignals {
		if signal.Severity.Rank() >= p.BlockAt.Rank() {
			p.Decision = model.Block
		} else if p.Decision == model.Allow {
			p.Decision = model.Review
		}
	}

	if len(b.r.Delta.ManifestSignals) > 0 {
		p.Reasons = append(p.Reasons, "Captured manifest permission, trigger or parameter declarations changed; review the source-bound rug-pull signals.")
	}

	b.r.Policy = p
}
