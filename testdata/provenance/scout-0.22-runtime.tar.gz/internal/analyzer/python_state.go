package analyzer

import "sort"

type pyValuePair struct {
	xm, ym *pyMapping
	xi, yi *pyInstance
	xs, ys *pyValue
}

// Branch/definition exploration must not mutate shared instance fields. Keep
// aliases inside a fork, then conservatively join both possible field states.
func (s *pyState) fork() *pyState {
	c := pyFork{states: map[*pyState]*pyState{}, seen: map[*pyInstance]*pyInstance{}, sequences: map[*pyValue][]pyValue{}, mappings: map[*pyMapping]*pyMapping{}}
	return c.state(s, 0)
}

type pyFork struct {
	states    map[*pyState]*pyState
	seen      map[*pyInstance]*pyInstance
	sequences map[*pyValue][]pyValue
	mappings  map[*pyMapping]*pyMapping
}

func (c *pyFork) value(v pyValue, depth int) pyValue {
	if depth > 32 {
		return pyValue{origins: v.origins}
	}

	if len(v.elements) > 0 {
		items := v.elements
		if existing := c.sequences[&items[0]]; existing != nil {
			v.elements = existing
		} else {
			v.elements = make([]pyValue, len(items))

			c.sequences[&items[0]] = v.elements
			for i, item := range items {
				v.elements[i] = c.value(item, depth+1)
			}
		}
	}

	if v.instance != nil {
		if instance := c.seen[v.instance]; instance != nil {
			v.instance = instance
		} else {
			original := v.instance
			instance := &pyInstance{class: original.class, fields: map[string]pyValue{}}
			c.seen[original] = instance

			v.instance = instance
			for k, field := range original.fields {
				instance.fields[k] = c.value(field, depth+1)
			}
		}
	}

	if v.mapping != nil {
		if existing := c.mappings[v.mapping]; existing != nil {
			v.mapping = existing
		} else {
			old := v.mapping
			v.mapping = &pyMapping{entries: map[string]pyValue{}}

			c.mappings[old] = v.mapping
			for k, item := range old.entries {
				v.mapping.entries[k] = c.value(item, depth+1)
			}
		}
	}

	if v.bound != nil {
		bound := c.value(*v.bound, depth+1)
		v.bound = &bound
	}

	return v
}

func (c *pyFork) state(old *pyState, depth int) *pyState {
	if old == nil {
		return nil
	}

	if existing := c.states[old]; existing != nil {
		return existing
	}

	r := old.clone()

	c.states[old] = r
	if depth > 32 {
		clear(r.names)
		r.blockedBuiltins = true
		r.parent = nil
		r.global = r

		return r
	}

	r.parent, r.global = c.state(old.parent, depth+1), c.state(old.global, depth+1)
	for k, v := range r.names {
		r.names[k] = c.value(v, 0)
	}

	for original, mapped := range old.forks {
		if c.states[original] == nil {
			c.states[original] = c.state(mapped, depth+1)
		}
	}

	r.forks = c.states

	return r
}

// Containers can be aliased and changed after binding. Refresh their taint
// from current contents, with a depth cap for cyclic mappings.
func pyContents(v pyValue) pyValue {
	seen := map[*pyMapping]bool{}

	var collect func(pyValue, int) pyValue

	collect = func(item pyValue, depth int) pyValue {
		if item.mapping == nil {
			return item
		}

		if depth > 16 || seen[item.mapping] {
			return joinPy(item)
		}

		seen[item.mapping] = true

		out := pyValue{}
		for _, key := range sortedPyKeys(item.mapping.entries) {
			out = joinPy(out, collect(item.mapping.entries[key], depth+1))
		}

		return out
	}
	if v.mapping != nil {
		v.origins = collect(v, 0).origins
	}

	return v
}

// Join branch effects in the current namespace and in explicitly reachable
// global/nonlocal owners. Forks redirect function closures without cloning
// function identities or allowing hypothetical definition scans to write back.
func mergePyBranches(s, a, b *pyState) {
	r := mergePy(a, b)

	visited := map[*pyState]bool{s: true}
	for _, root := range []*pyState{s.parent, s.global} {
		for owner := root; owner != nil && !visited[owner]; owner = owner.parent {
			visited[owner] = true

			x, y := a.forks[owner], b.forks[owner]
			if x == nil {
				x = owner
			}

			if y == nil {
				y = owner
			}

			merged := mergePy(x, y)
			owner.names, owner.blockedBuiltins = merged.names, merged.blockedBuiltins
		}
	}

	r.parent, r.global, r.forks = s.parent, s.global, s.forks
	*s = *r
}

func sortedPyKeys(entries map[string]pyValue) []string {
	keys := make([]string, 0, len(entries))
	for key := range entries {
		keys = append(keys, key)
	}

	sort.Strings(keys)

	return keys
}

func mergePyValue(x, y pyValue, depth int) pyValue {
	return mergePyValueMemo(x, y, depth, map[pyValuePair]pyValue{})
}

func mergePyValueMemo(x, y pyValue, depth int, memo map[pyValuePair]pyValue) pyValue {
	key := pyValuePair{xm: x.mapping, ym: y.mapping, xi: x.instance, yi: y.instance}
	if len(x.elements) > 0 {
		key.xs = &x.elements[0]
	}

	if len(y.elements) > 0 {
		key.ys = &y.elements[0]
	}

	container := key != (pyValuePair{})
	if container {
		if old, ok := memo[key]; ok {
			return old
		}
	}

	z := mergePyScalars(x, y)

	return mergePyContainers(x, y, z, depth, memo, key, container)
}

func mergePyScalars(x, y pyValue) pyValue {
	z := joinPy(x, y)
	if x.truth == y.truth {
		z.truth = x.truth
	}

	if x.name == y.name {
		z.name = x.name
	}

	if x.known && y.known && x.literal == y.literal {
		z.known = true
		z.literal = x.literal
	}

	if x.function == y.function {
		z.function = x.function
	}

	if x.class == y.class {
		z.class = x.class
	}

	if x.bound == y.bound {
		z.bound = x.bound
	}

	return z
}

func mergePyContainers(x, y, z pyValue, depth int, memo map[pyValuePair]pyValue, key pyValuePair, container bool) pyValue {
	if depth < 16 && x.mapping != nil && y.mapping != nil {
		z.mapping = &pyMapping{entries: map[string]pyValue{}}
	}

	if len(x.elements) > 0 && len(x.elements) == len(y.elements) && depth < 16 {
		z.elements = make([]pyValue, len(x.elements))
	}

	if x.instance == y.instance {
		z.instance = x.instance
	} else if depth < 16 && x.instance != nil && y.instance != nil && x.instance.class == y.instance.class {
		z.instance = &pyInstance{class: x.instance.class, fields: map[string]pyValue{}}
	}

	if container {
		memo[key] = z
	}

	if depth < 16 && x.mapping != nil && y.mapping != nil {
		mergePyFields(z.mapping.entries, x.mapping.entries, y.mapping.entries, depth, memo)
	}

	if z.elements != nil {
		for i := range x.elements {
			z.elements[i] = mergePyValueMemo(x.elements[i], y.elements[i], depth+1, memo)
		}
	}

	if x.instance == y.instance {
		z.instance = x.instance
	} else if depth < 16 && x.instance != nil && y.instance != nil && x.instance.class == y.instance.class {
		mergePyFields(z.instance.fields, x.instance.fields, y.instance.fields, depth, memo)
	}

	return z
}

func mergePyFields(out, x, y map[string]pyValue, depth int, memo map[pyValuePair]pyValue) {
	for k, v := range x {
		out[k] = mergePyValueMemo(v, y[k], depth+1, memo)
	}

	for k, v := range y {
		if _, ok := x[k]; !ok {
			out[k] = mergePyValueMemo(pyValue{}, v, depth+1, memo)
		}
	}
}
