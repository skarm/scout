// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Bounded equivalent of MP2's short-phrase backreference (RE2 has no backrefs).

package analyzer

import (
	"context"
	"unicode"
)

func repeatedContext(ctx context.Context, text string, emit func(int, int) bool) bool {
	runes := []rune(text)
	if len(runes) < 42 {
		return false
	}

	offsets := make([]int, 0, len(runes)+1)
	for at := range text {
		offsets = append(offsets, at)
	}

	offsets = append(offsets, len(text))

	for period := 2; period <= 20; period++ {
		start := 0
		flush := func(end int) bool {
			if end-start < period*21 {
				return true
			}

			meaningful := end-start > 256
			for _, r := range runes[start:min(end, start+period)] {
				meaningful = meaningful || unicode.IsLetter(r) || unicode.IsDigit(r)
			}

			return !meaningful || emit(offsets[start], offsets[end])
		}

		for i := period; i < len(runes); i++ {
			if i%4096 == 0 && ctx.Err() != nil {
				return true
			}

			if runes[i] == '\n' || runes[i] != runes[i-period] {
				if !flush(i) {
					return true
				}

				start = i - period + 1
			}
		}

		if !flush(len(runes)) {
			return true
		}
	}

	return false
}
