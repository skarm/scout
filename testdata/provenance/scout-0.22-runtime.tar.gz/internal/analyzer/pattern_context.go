// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Adapted Unicode/SC7 guards from SkillSpector; original byte coordinates,
// explicit candidate caps and no general example-based suppression.

package analyzer

import (
	"regexp"
	"strings"
	"unicode"
	"unicode/utf8"

	"github.com/skarm/scout/internal/promptguard"
)

var credentialNounPrefix = regexp.MustCompile(`(?i)\b(?:validate|verify|refresh|rotate|expire|parse|manage|revoke)\s+$`)

// Adapted from SkillSpector prohibition_context: only an unambiguous bounded
// direct prohibition. Conditional exceptions and a second instruction retain
// detection. Paths, quotation labels and examples never grant an exemption.
var (
	standardSkillMkdir      = regexp.MustCompile(`^mkdir[\t ]+(?:(?:-p|--parents)[\t ]+)?(?:--[\t ]+)?['"]?~/\.(?:claude|codex|gemini)/skills(?:/[A-Za-z0-9][A-Za-z0-9_.-]*)?/?['"]?[\t ]*$`)
	hiddenDirectoryTargets  = regexp.MustCompile(`(?:~/|/home/|/tmp/)\.([a-z_-]+)`)
	directProhibition       = regexp.MustCompile(`(?i)^(?:please[\t ]+)?(?:(?:you|the[\t ]+(?:agent|assistant|model))[\t ]+)?(?:do[\t ]+not|don't|don’t|never|must[\t ]+not|shall[\t ]+not)[\t ]+(?:(?:ever)[\t ]+)?$`)
	prohibitionException    = regexp.MustCompile(`(?i)\b(?:unless|except|until|but|however|instead|if|when|only|otherwise|else)\b`)
	prohibitionUndo         = regexp.MustCompile(`(?i)^[\s.!?;]*(?:(?:instead[, ]+|actually[\t ]+yes[, ]+)(?:do|execute|perform|run)\s+(?:it|that|them)\b|(?:do|execute|perform|run)\s+(?:it|that|them)\s+(?:anyway|instead|remotely)\b)`)
	prohibitionFollowup     = regexp.MustCompile(`(?i)^[\s.!?;]*(?:but|however|instead|unless|except|until|only)\b`)
	prohibitionContinuation = regexp.MustCompile(`(?i)^(?:unless|except|until|if|when|only|in|to|for|as)\b`)
	prohibitionReversal     = regexp.MustCompile(`(?i)\b(?:opposit\w*|invers\w*|invert\w*|revers\w*|contrar\w*|negat\w*|ignore|disregard|override|bypass|suspend|violat\w*)\b`)
	prohibitionSubject      = regexp.MustCompile(`(?i)\b(?:meaning|prohibition|instructions?|rules?|assistant|agent|negation)\b`)
	negatedReversal         = regexp.MustCompile(`(?i)(?:do[\t ]+not|don't|don’t|never|must[\t ]+not)[\t ]+$`)
)

func familyVersion(id string) string {
	switch id {
	case valueSC2:
		return "7"
	case "P2", "P6", "P8", "PE2", valuePE3, "PE4", "EA1", "EA3", valueEA5, "E5", valueOH1, valueTM1, "TM3", "TM4", "RA1", valueRA2, valueAS3:
		return "6"
	case "E1", valueEA2:
		return "5"
	case valueMP2, valueMP3, "P7", "P9":
		return "4"
	case "P3", "P4", "P5", "E2", "SC1", "SC3", valueSC7:
		return "3"
	}

	return "2"
}

func patternExempt(id, text string, start, end int) bool {
	if (id == valueEA2 || id == valueRA2 || id == valueMP3 || id == valuePE3 || id == valueAS3) && directlyProhibited(text, start, end) {
		return true
	}

	if (id == "P6" || id == "P7" || id == "P8") && (directlyProhibited(text, start, end) || promptguard.Prohibited(text, start, end)) {
		return true
	}

	switch id {
	case valueRA2:
		return protectedDirectoryExample(text, start, end)
	case valueSC7:
		matched := strings.ToLower(text[start:end])
		if matched == "--disable-content-trust" {
			rest := strings.ToLower(text[end:])
			if strings.HasPrefix(rest, "=false") && (len(rest) == 6 || strings.ContainsRune(" \t\r\n;|&)", rune(rest[6]))) {
				return true
			}
		}
	case "P2":
		r, _ := utf8.DecodeRuneInString(text[start:end])
		if r == 0x200d && end-start == 3 {
			return emojiBefore(text, start) && emojiAfter(text, end)
		}
	case valuePE3:
		if strings.HasPrefix(strings.ToLower(text[start:end]), "access ") && credentialNounPrefix.MatchString(text[max(0, start-64):start]) {
			return true
		}
	}

	return false
}

func protectedDirectoryExample(text string, start, end int) bool {
	matched := text[start:end]
	if strings.HasPrefix(matched, "mkdir") || strings.HasPrefix(matched, "create") || strings.HasPrefix(matched, "write") {
		paths := hiddenDirectoryTargets.FindAllStringSubmatch(matched, 32)
		if len(paths) > 0 {
			unprotected := false

			for _, p := range paths {
				v := strings.ToLower(p[1])
				unprotected = unprotected || !(strings.HasPrefix(v, "git") || strings.HasPrefix(v, "ssh") || strings.HasPrefix(v, "aws"))
			}

			if !unprotected {
				return true
			}
		}
	}

	left := strings.LastIndex(text[:start], "\n") + 1

	right := len(text)
	if i := strings.IndexByte(text[end:], '\n'); i >= 0 {
		right = end + i
	}

	line := strings.TrimSpace(text[left:right])
	if standardSkillMkdir.MatchString(line) && strings.Count(line, "'")%2 == 0 && strings.Count(line, `"`)%2 == 0 {
		return true
	}

	return false
}

func directlyProhibited(text string, start, end int) bool {
	if start < 0 || end < start || end > len(text) {
		return false
	}
	// A nearby instruction to invert/disregard the prohibition prevents a
	// scanner-authored exemption. Stay within a bounded paragraph/window.
	contextStart, contextEnd := max(0, start-512), min(len(text), end+512)
	if boundaries := paragraphBoundaries(text[contextStart:start]); len(boundaries) > 0 {
		contextStart += boundaries[len(boundaries)-1][1]
	}

	if boundaries := paragraphBoundaries(text[end:contextEnd]); len(boundaries) > 0 {
		contextEnd = end + boundaries[0][0]
	}

	if openInstructionQuote(text[contextStart:start]) {
		return false
	}

	window := text[contextStart:contextEnd]
	if prohibitionSubject.MatchString(window) {
		for _, at := range prohibitionReversal.FindAllStringIndex(window, -1) {
			if !negatedReversal.MatchString(window[max(0, at[0]-64):at[0]]) {
				return false
			}
		}
	}

	left := max(0, start-512)
	for i := start - 1; i >= left; i-- {
		if strings.ContainsRune("\r\n.!?;", rune(text[i])) {
			left = i + 1
			break
		}
	}

	prefix := strings.TrimLeft(text[left:start], " \t-+*")

	prefix = strings.NewReplacer("`", "", "*", "", "_", "").Replace(prefix)
	if !directProhibition.MatchString(prefix) {
		return false
	}

	right := min(len(text), end+512)
	for i := end; i < right; i++ {
		if strings.ContainsRune("\r\n.!?;", rune(text[i])) {
			right = i
			break
		}
	}

	if right < len(text) && (prohibitionUndo.MatchString(text[right:min(len(text), right+160)]) || prohibitionFollowup.MatchString(text[right:min(len(text), right+160)])) {
		return false
	}

	tail := strings.TrimSpace(text[end:right])
	if !prohibitionContinuesSafely(text, right) {
		return false
	}

	if prohibitionException.MatchString(tail) || prohibitionException.MatchString(text[start:end]) || strings.Contains(strings.ToLower(text[start:end]), " then ") {
		return false
	}

	return strings.Trim(tail, " \t`*_\"'") == ""
}

func prohibitionContinuesSafely(text string, right int) bool {
	if right < len(text) {
		next := text[right:min(len(text), right+128)]
		// A sentence terminator before the line break does not make an
		// immediately following list qualifier a separate safe prohibition.
		if at := strings.IndexByte(next, '\n'); at >= 0 && strings.Trim(next[:at], " \t\r.!?;") == "" && !strings.HasPrefix(next[at+1:], "\n") {
			next = next[at+1:]
		}

		continuation := strings.TrimLeft(next, " \t\r\n-*+>0123456789.)")
		if prohibitionContinuation.MatchString(continuation) {
			return false
		}

		if strings.HasPrefix(continuation, "#") {
			if _, after, ok := strings.Cut(continuation, "\n"); ok {
				following := strings.TrimLeft(after, " \t\r\n-*+>0123456789.)")
				if prohibitionContinuation.MatchString(following) {
					return false
				}
			}
		}
	}

	return true
}

func emojiBase(r rune) bool {
	return r >= 0x1f000 && r <= 0x1faff || r >= 0x2600 && r <= 0x27bf || r == 0x00a9 || r == 0x00ae || r == 0x203c || r == 0x2049 || r == 0x2122 || r == 0x2139 || r == 0x3030 || r == 0x303d
}
func emojiModifier(r rune) bool { return r >= 0x1f3fb && r <= 0x1f3ff }
func variation(r rune) bool     { return r == 0xfe0e || r == 0xfe0f }
func emojiBefore(s string, at int) bool {
	for count := 0; at > 0 && count < 8; count++ {
		r, n := utf8.DecodeLastRuneInString(s[:at])
		at -= n

		if variation(r) || emojiModifier(r) {
			continue
		}

		return emojiBase(r)
	}

	return false
}

func emojiAfter(s string, at int) bool {
	for count := 0; at < len(s) && count < 8; count++ {
		r, n := utf8.DecodeRuneInString(s[at:])
		at += n

		if variation(r) || emojiModifier(r) {
			continue
		}

		return emojiBase(r)
	}

	return false
}

// safeFlagEnd recognizes only the three known subdivision sequences, a stricter
// exception than upstream's generic 2..6 lower-case/digit tag allowance. A black
// flag around an arbitrary short instruction is not an exemption.
func safeFlagEnd(s string, at int) int {
	r, n := utf8.DecodeRuneInString(s[at:])
	if r != 0x1f3f4 {
		return at
	}

	pos := at + n

	var code [6]byte

	count := 0
	for pos < len(s) && count < len(code) {
		r, n = utf8.DecodeRuneInString(s[pos:])
		if r == 0xe007f {
			v := string(code[:count])
			if v == "gbeng" || v == "gbsct" || v == "gbwls" {
				return pos + n
			}

			return at
		}

		if r < 0xe0020 || r > 0xe007e {
			return at
		}

		code[count] = byte(r - 0xe0000)
		count++
		pos += n
	}

	return at
}

// An unmatched quotation from earlier in the paragraph makes a prohibition
// referential/ambiguous. Apostrophes inside words are not quotation delimiters.
func openInstructionQuote(text string) bool {
	quote := rune(0)

	runes := []rune(text)
	for i, r := range runes {
		if r != '\'' && r != '"' && r != '‘' && r != '’' && r != '“' && r != '”' {
			continue
		}

		if (r == '\'' || r == '’') && i > 0 && i+1 < len(runes) && unicode.IsLetter(runes[i-1]) && unicode.IsLetter(runes[i+1]) {
			continue
		}

		if quote == 0 {
			quote = r
			continue
		}

		if r == quote || quote == '‘' && r == '’' || quote == '“' && r == '”' {
			quote = 0
		}
	}

	return quote != 0
}
