package analyzer

import (
	"context"
	"go/ast"
	"go/token"
	"maps"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/model"
)

const (
	MaxGoFlowOperations = 20000
	MaxGoFlowBindings   = 1024
)

type goFlow struct{}

type flowValue struct {
	trace []Trace
	bound bool
}
type (
	//nolint:staticcheck // SA1019: parser object identity provides bounded lexical bindings without resolving inspected imports.
	flowState  map[*ast.Object]flowValue
	flowWalker struct {
		ctx       context.Context
		unit      document.GoUnit
		imports   map[string]string
		remaining *int
		out       *Result
		budget    int
	}
)

func (goFlow) Rule() model.Rule {
	return model.Rule{
		ID: "GO004", Version: "1", Title: "Credential values may flow through local variables to an HTTP API", Description: "A bounded local source/assignment/HTTP-argument chain was found.", Severity: model.High, Category: valueCredentialEgress, Method: "go-ast-local-flow",
		Limitation: "Intrafunction local variables, selected pure wrappers and conservative if branches only; unknown calls/control flow invalidate tracked bindings. No type checking, cross-file/call graph, general alias analysis or proof of transmission or malicious intent. Legitimate authentication may match.",
	}
}
func (goFlow) AppliesTo(f artifact.File) bool         { return f.Metadata().Kind == formatText }
func (goFlow) AppliesToDocument(f document.File) bool { return f.HasGo() }
func (a goFlow) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	return a.FindDocument(ctx, document.Prepare(ctx, f), budget)
}

func (a goFlow) FindDocument(ctx context.Context, f document.File, budget int) (Result, error) {
	out := Result{}
	if err := ctx.Err(); err != nil {
		return out, err
	}

	ops := MaxGoFlowOperations

	for _, unit := range f.GoUnits() {
		if unit.Tree == nil {
			continue
		}

		a := flowWalker{ctx: ctx, unit: unit, imports: importNames(unit.Tree), remaining: &ops, out: &out, budget: budget}
		for _, decl := range unit.Tree.Decls {
			if fd, ok := decl.(*ast.FuncDecl); ok && fd.Body != nil {
				a.block(fd.Body.List, make(flowState), 0)
			}

			if out.Truncated || ctx.Err() != nil {
				break
			}
		}

		if out.Truncated || ctx.Err() != nil {
			break
		}
	}

	return out, ctx.Err()
}

func (a *flowWalker) charge() bool {
	(*a.remaining)--
	if *a.remaining < 0 {
		a.out.Truncated = true
	}

	return !a.out.Truncated && a.ctx.Err() == nil
}

func (a *flowWalker) trace(v flowValue, node ast.Node, role string) flowValue {
	if len(v.trace) >= 7 {
		a.out.Truncated = true
		return flowValue{}
	}

	span, ok := nodeSpan(a.unit, node)
	if !ok {
		return flowValue{}
	}

	v.trace = append(append([]Trace(nil), v.trace...), Trace{Role: role, Start: span.Start, End: span.End})

	return v
}

func (a *flowWalker) expr(e ast.Expr, s flowState, depth int) flowValue {
	if e == nil || !a.charge() {
		return flowValue{}
	}

	if depth > 32 {
		a.out.Truncated = true
		return flowValue{}
	}

	switch x := e.(type) {
	case *ast.Ident:
		if v, ok := s[x.Obj]; ok {
			v.bound = true
			return v
		}
	case *ast.ParenExpr:
		return a.expr(x.X, s, depth+1)
	case *ast.BinaryExpr:
		left := a.expr(x.X, s, depth+1)

		right := a.expr(x.Y, s, depth+1)
		if x.Op == token.ADD {
			return firstFlow(left, right)
		}
	case *ast.CallExpr:
		return a.callExpr(x, s, depth)
	case *ast.SelectorExpr:
		a.expr(x.X, s, depth+1)
	case *ast.IndexExpr:
		a.expr(x.X, s, depth+1)
		a.expr(x.Index, s, depth+1)
	case *ast.SliceExpr:
		a.expr(x.X, s, depth+1)
		a.expr(x.Low, s, depth+1)
		a.expr(x.High, s, depth+1)
		a.expr(x.Max, s, depth+1)
	case *ast.TypeAssertExpr:
		a.expr(x.X, s, depth+1)
	case *ast.UnaryExpr:
		a.expr(x.X, s, depth+1)
	case *ast.CompositeLit:
		return a.compositeExpr(x, s, depth)
	}

	return flowValue{}
}

func (a *flowWalker) callExpr(x *ast.CallExpr, s flowState, depth int) flowValue {
	if !completeCall(a.unit, x) {
		return flowValue{}
	}

	args := make([]flowValue, len(x.Args))
	for i, e := range x.Args {
		args[i] = a.expr(e, s, depth+1)
	}

	pkg, method := qualified(x.Fun, a.imports)
	if pkg == "os" && (method == valueGetenv || method == "LookupEnv") && len(x.Args) == 1 {
		key, known := constantString(x.Args[0], a.imports)
		if known && sensitiveName(key) {
			return a.trace(flowValue{}, x, valueSource)
		}

		return flowValue{}
	}

	if (pkg == "os" || pkg == valueIoIoutil) && method == valueReadFile && len(x.Args) == 1 {
		name, known := constantString(x.Args[0], a.imports)
		if known && sensitivePath(name) {
			return a.trace(flowValue{}, x, valueSource)
		}

		return flowValue{}
	}

	if pkg == "net/http" && a.httpSink(x, method, args) {
		return flowValue{}
	}

	return a.wrapperCall(x, s, args, pkg, method)
}

func (a *flowWalker) httpSink(x *ast.CallExpr, method string, args []flowValue) bool {
	indexes := []int{}

	switch method {
	case "Get", "Head":
		indexes = []int{0}
	case "Post":
		indexes = []int{0, 2}
	case "PostForm":
		indexes = []int{0, 1}
	case "NewRequest":
		indexes = []int{1, 2}
	case "NewRequestWithContext":
		indexes = []int{2, 3}
	}

	for _, i := range indexes {
		if i < len(args) && args[i].bound && len(args[i].trace) > 0 {
			a.sink(x, args[i])
			break
		}
	}

	return len(indexes) > 0
}

func (a *flowWalker) wrapperCall(x *ast.CallExpr, s flowState, args []flowValue, pkg, method string) flowValue {
	pure := (pkg == "strings" && method == valueNewReader) || (pkg == valueBytes && (method == "NewBuffer" || method == "NewBufferString" || method == valueNewReader)) || (pkg == "io" && method == "NopCloser")
	if id, ok := x.Fun.(*ast.Ident); ok && id.Obj == nil && id.Name == kindString {
		pure = true
	}

	if typ, ok := x.Fun.(*ast.ArrayType); ok && typ.Len == nil {
		if id, ok := typ.Elt.(*ast.Ident); ok && id.Obj == nil && id.Name == "byte" {
			pure = true
		}
	}

	if pure && len(args) == 1 {
		return args[0]
	}
	// Unknown calls may invoke closures or modify aliased data. Never preserve a
	// stale taint chain by guessing that user functions are pure/sanitizers.
	clearState(s)

	return flowValue{}
}

func (a *flowWalker) compositeExpr(x *ast.CompositeLit, s flowState, depth int) flowValue {
	var first flowValue
	// Support url.Values and untyped elements of it, not arbitrary object methods.
	pkg, name := qualified(x.Type, a.imports)

	valid := x.Type == nil || (pkg == "net/url" && name == "Values")
	for _, el := range x.Elts {
		if kv, ok := el.(*ast.KeyValueExpr); ok {
			el = kv.Value
		}

		v := a.expr(el, s, depth+1)
		if valid {
			first = firstFlow(first, v)
		}
	}

	return first
}

func (a *flowWalker) sink(call *ast.CallExpr, v flowValue) {
	if len(a.out.Matches) >= a.budget {
		a.out.Truncated = true
		return
	}

	span, ok := nodeSpan(a.unit, call)
	if !ok {
		return
	}
	// One result per sink even when multiple arguments carry the same source.
	for _, m := range a.out.Matches {
		if m.Start == span.Start && m.End == span.End {
			return
		}
	}

	if len(v.trace) > 7 {
		a.out.Truncated = true
		return
	}

	tr := append(append([]Trace(nil), v.trace...), Trace{Role: valueSink, Start: span.Start, End: span.End})
	a.out.Matches = append(a.out.Matches, Match{Start: span.Start, End: span.End, Trace: tr})
}

func (a *flowWalker) bind(s flowState, id *ast.Ident, v flowValue) {
	if id == nil || id.Name == "_" || id.Obj == nil {
		return
	}

	if len(v.trace) == 0 {
		delete(s, id.Obj)
		return
	}

	if len(s) >= MaxGoFlowBindings {
		a.out.Truncated = true

		clearState(s)

		return
	}

	v = a.trace(v, id, "transform")
	if len(v.trace) > 0 {
		s[id.Obj] = v
	}
}

func (a *flowWalker) assign(lhs []ast.Expr, rhs []ast.Expr, tok token.Token, s flowState) {
	vs := make([]flowValue, len(rhs))
	for i, e := range rhs {
		vs[i] = a.expr(e, s, 0)
	}

	for i, e := range lhs {
		id, ok := e.(*ast.Ident)
		if !ok {
			clearState(s)
			continue
		}

		v := flowValue{}
		if len(lhs) == len(rhs) {
			v = vs[i]
		} else if i == 0 && len(rhs) == 1 && tupleSource(rhs[0], a.imports) {
			v = vs[0]
		}

		if tok == token.ADD_ASSIGN {
			v = firstFlow(s[id.Obj], v)
		} else if tok != token.ASSIGN && tok != token.DEFINE {
			v = flowValue{}
		}

		a.bind(s, id, v)
	}
}

// block returns false when execution unconditionally leaves this block.
func (a *flowWalker) block(stmts []ast.Stmt, s flowState, depth int) bool {
	if depth > 32 {
		a.out.Truncated = true
		return false
	}

	for _, st := range stmts {
		if !a.charge() {
			return false
		}

		switch x := st.(type) {
		case *ast.AssignStmt:
			a.assign(x.Lhs, x.Rhs, x.Tok, s)
		case *ast.ExprStmt:
			a.expr(x.X, s, 0)
		case *ast.DeclStmt:
			a.declaration(x, s)
		case *ast.ReturnStmt:
			for _, e := range x.Results {
				a.expr(e, s, 0)
			}

			return false
		case *ast.BlockStmt:
			if !a.block(x.List, s, depth+1) {
				return false
			}
		case *ast.IfStmt:
			if !a.ifStatement(x, s, depth) {
				return false
			}
		case *ast.GoStmt:
			a.expr(x.Call, s, 0)
			clearState(s)
		case *ast.DeferStmt:
			a.expr(x.Call, s, 0)
			clearState(s)
		case *ast.EmptyStmt:
		default:
			clearState(s)
		}
	}

	return true
}

func (a *flowWalker) declaration(x *ast.DeclStmt, s flowState) {
	g, ok := x.Decl.(*ast.GenDecl)
	if !ok {
		clearState(s)
		return
	}

	for _, sp := range g.Specs {
		if v, ok := sp.(*ast.ValueSpec); ok {
			left := make([]ast.Expr, len(v.Names))
			for i, id := range v.Names {
				left[i] = id
			}

			a.assign(left, v.Values, token.ASSIGN, s)
		}
	}
}

func (a *flowWalker) ifStatement(x *ast.IfStmt, s flowState, depth int) bool {
	if x.Init != nil {
		a.block([]ast.Stmt{x.Init}, s, depth+1)
	}

	a.expr(x.Cond, s, 0)
	left, right := cloneState(s), cloneState(s)
	lok := a.block(x.Body.List, left, depth+1)

	rok := true
	if x.Else != nil {
		rok = a.block([]ast.Stmt{x.Else}, right, depth+1)
	}

	clearState(s)

	if lok {
		maps.Copy(s, left)
	}

	if rok {
		for k, v := range right {
			if len(s[k].trace) == 0 {
				s[k] = v
			}
		}
	}

	if len(s) > MaxGoFlowBindings {
		a.out.Truncated = true

		clearState(s)

		return false
	}

	if !lok && !rok {
		return false
	}

	return true
}

func cloneState(s flowState) flowState {
	out := make(flowState, len(s))
	maps.Copy(out, s)

	return out
}
func clearState(s flowState) { clear(s) }
func firstFlow(vs ...flowValue) flowValue {
	for _, v := range vs {
		if len(v.trace) > 0 {
			return v
		}
	}

	return flowValue{}
}

func tupleSource(call ast.Expr, imports map[string]string) bool {
	c, ok := call.(*ast.CallExpr)
	if !ok {
		return false
	}

	pkg, m := qualified(c.Fun, imports)

	return (pkg == "os" && (m == "LookupEnv" || m == valueReadFile)) || (pkg == valueIoIoutil && m == valueReadFile)
}
