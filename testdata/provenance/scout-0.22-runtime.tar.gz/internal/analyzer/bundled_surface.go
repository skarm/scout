// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Modified Go implementation of SkillSpector BH1-BH4 declaration/transfer checks.

package analyzer

import (
	"context"
	"errors"
	"net"
	"net/url"
	"path"
	"strings"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/hookpolicy"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/shellsyntax"
	"github.com/skarm/scout/internal/source"
)

//nolint:gochecknoglobals // These hook vocabularies are initialized once and only read by concurrent scans.
var (
	hookEvents      = hookpolicy.Events
	sensitiveEvents = stringSet("UserPromptSubmit UserPromptExpansion MessageDisplay PreToolUse PermissionRequest PermissionDenied PostToolUse PostToolUseFailure PostToolBatch SubagentStop TaskCreated TaskCompleted Stop StopFailure PreCompact PostCompact Elicitation ElicitationResult")
)

type bundledSurface struct {
	id    string
	hooks hookpolicy.Policy
}

func (a bundledSurface) Rule() model.Rule {
	title := map[string]string{"BH1": "Bundled non-command lifecycle handler declaration", valueBH2: "Bundled hook transfers sensitive content remotely", valueBH3: "Bundled permission or execution/traffic setting requires review", "BH4": "Bundled settings declare automatic command execution"}[a.id]

	severity := model.Medium
	if a.id == valueBH2 {
		severity = model.Critical
	}

	if a.id == valueBH3 {
		severity = model.Critical
	}

	return model.Rule{ID: "NV-" + a.id, Version: "3", Title: title, Description: title, Severity: severity, Category: "bundled-execution-surface", Method: "bounded-hook-settings-analysis", Limitation: "Conditional declarations, not proven host activation. Closed captured settings.local-before-settings disable semantics within a namespace/project; external settings and host trust remain unknown. BH2 requires a remote HTTP event body or direct literal or symbolic-HOME upload command. BH3 descriptor severity is a maximum; acceptEdits is medium and project-ignored auto is low."}
}

func (bundledSurface) AppliesTo(f artifact.File) bool       { return f.Metadata().Kind == formatText }
func (bundledSurface) AppliesToDocument(document.File) bool { return true }
func (a bundledSurface) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	return a.FindDocument(ctx, document.Prepare(ctx, f), budget)
}

func (a bundledSurface) FindDocument(ctx context.Context, d document.File, budget int) (Result, error) {
	out := Result{}
	seen := map[source.Span]bool{}
	partial := false

	for _, u := range d.Units() {
		tree, ok := u.Tree.(parse.JSONTree)
		if !ok || tree.Root == nil {
			continue
		}

		emit := a.surfaceEmitter(u, &out, &partial, seen, budget)
		name := strings.ToLower(path.Base(d.Artifact().Metadata().Path))
		settings := name == "settings.json" || name == "settings.local.json"
		state := a.surfaceHookState(d, u, tree.Root, settings)

		partial = partial || state.Uncertain
		if settings || name == "hooks.json" {
			a.inspectSurface(ctx, tree.Root, settings, state.Disabled, emit, &partial)
		}

		for _, scope := range d.ConfigScopes() {
			if scope.Role != "hook_config" {
				continue
			}

			if n := scopedNode(tree.Root, scope.Span); n != nil {
				a.inspectSurface(ctx, n, false, state.Disabled, emit, &partial)
			}
		}
	}

	if ctx.Err() != nil {
		return out, ctx.Err()
	}

	if partial {
		return out, errors.New("bundled hook/settings shape or event semantics incomplete")
	}

	return out, nil
}

func (a bundledSurface) surfaceEmitter(u document.Unit, out *Result, partial *bool, seen map[source.Span]bool, budget int) func(*jsonconfig.Node, ...model.Severity) {
	return func(n *jsonconfig.Node, severity ...model.Severity) {
		if n == nil || out.Truncated {
			return
		}

		at, e := u.View.Original(n.Span)
		if e != nil {
			*partial = true
			return
		}

		if seen[at] {
			return
		}

		seen[at] = true

		if len(out.Matches) >= budget {
			out.Truncated = true
			return
		}

		m := Match{Start: at.Start, End: at.End}
		if len(severity) > 0 {
			m.Severity = severity[0]
		} else if a.id == valueBH3 {
			m.Severity = model.High
		}

		m.InactiveForSurface = a.id == valueBH3 && m.Severity == model.Low
		out.Matches = append(out.Matches, m)
	}
}

func (a bundledSurface) surfaceHookState(d document.File, u document.Unit, root *jsonconfig.Node, settings bool) hookpolicy.State {
	state := a.hooks[d.Artifact().Metadata().Path]
	if a.hooks == nil && settings && u.Origin == "file" {
		state = hookpolicy.Local(root)
	}

	if u.Origin != "file" {
		state.Disabled = false
	}

	if !settings {
		for _, scope := range d.ConfigScopes() {
			if scope.Role == "hook_config" && scope.Host != "" && scope.Host != "claude-code" {
				state.Disabled = false
			}
		}
	}

	return state
}

func (a bundledSurface) inspectSurface(ctx context.Context, root *jsonconfig.Node, settings, disabled bool, emit func(*jsonconfig.Node, ...model.Severity), partial *bool) {
	if root == nil || root.Kind != kindObject {
		*partial = true
		return
	}

	if n := root.Get("disableAllHooks"); settings && n != nil && n.Kind != "bool" {
		*partial = true
	}

	hooks := root.Get("hooks")
	if hooks == nil && !settings {
		hooks = root
	}

	if hooks != nil && !disabled {
		if hooks.Kind != kindObject {
			*partial = true
		} else if !a.inspectHookEvents(ctx, hooks, emit, partial) {
			return
		}
	}

	if settings {
		a.inspectSettings(root, disabled, emit, partial)
	}
}

func (a bundledSurface) inspectHookEvents(ctx context.Context, hooks *jsonconfig.Node, emit func(*jsonconfig.Node, ...model.Severity), partial *bool) bool {
	for _, event := range hooks.Members {
		if ctx.Err() != nil {
			return false
		}

		if !hookEvents[event.Key] {
			*partial = true
		}

		if event.Value.Kind != kindArray {
			*partial = true
			continue
		}

		for _, group := range event.Value.Elements {
			handlers := group.Get("hooks")
			if handlers == nil || handlers.Kind != kindArray {
				*partial = true
				continue
			}

			for _, h := range handlers.Elements {
				if ctx.Err() != nil {
					return false
				}

				a.inspectHookHandler(ctx, event.Key, h, emit, partial)
			}
		}
	}

	return true
}

func (a bundledSurface) inspectHookHandler(ctx context.Context, event string, h *jsonconfig.Node, emit func(*jsonconfig.Node, ...model.Severity), partial *bool) {
	kind, _ := h.Get("type").Text()

	var valid bool

	switch kind {
	case valueCommand:
		text, ok := h.Get(valueCommand).Text()
		valid = ok && strings.TrimSpace(text) != ""
	case schemeHTTP:
		text, ok := h.Get("url").Text()
		u, e := url.Parse(text)
		valid = ok && e == nil && u.Hostname() != "" && (u.Scheme == schemeHTTP || u.Scheme == "https")
	case "prompt", "agent":
		text, ok := h.Get("prompt").Text()
		valid = ok && strings.TrimSpace(text) != ""
	case "mcp_tool":
		text, ok := h.Get("server").Text()
		tool, yes := h.Get("tool").Text()
		valid = ok && yes && text != "" && tool != ""
	default:
		valid = false
	}

	if !valid {
		*partial = true
	}
	// AC003 already represents command declarations. Preserve its
	// identity without charging the same declaration twice.
	if a.id == "BH1" && kind != valueCommand {
		emit(h)
	}

	if a.id == valueBH2 && valid {
		if kind == schemeHTTP {
			text, _ := h.Get("url").Text()
			if sensitiveEvents[event] && externalHTTP(text) {
				emit(h)
			}
		}

		if kind == valueCommand && directHookUpload(ctx, event, h) {
			emit(h)
		}
	}
}

func (a bundledSurface) inspectSettings(root *jsonconfig.Node, disabled bool, emit func(*jsonconfig.Node, ...model.Severity), partial *bool) {
	if a.id == "BH4" {
		inspectAutomaticCommands(root, disabled, emit, partial)
	}

	if a.id == valueBH3 {
		inspectPermissionSettings(root, emit)
		inspectEnvironmentSettings(root, emit, partial)
	}
}

func inspectAutomaticCommands(root *jsonconfig.Node, disabled bool, emit func(*jsonconfig.Node, ...model.Severity), partial *bool) {
	for key := range strings.FieldsSeq("apiKeyHelper awsAuthRefresh awsCredentialExport gcpAuthRefresh otelHeadersHelper statusLine fileSuggestion") {
		n := root.Get(key)
		if n == nil {
			continue
		}

		if disabled && (key == "statusLine" || key == "fileSuggestion") {
			continue
		}

		if key == "statusLine" || key == "fileSuggestion" {
			kind, ok := n.Get("type").Text()
			if !ok {
				*partial = true
				continue
			}

			if kind != valueCommand {
				continue
			}

			n = n.Get(valueCommand)
		}

		inspectAutomaticCommand(n, emit, partial)
	}
}

func inspectAutomaticCommand(n *jsonconfig.Node, emit func(*jsonconfig.Node, ...model.Severity), partial *bool) {
	if text, ok := n.Text(); ok {
		if strings.TrimSpace(text) != "" {
			emit(n)
		}
	} else if n != nil && n.Kind == kindArray {
		for _, part := range n.Elements {
			if _, ok := part.Text(); !ok {
				*partial = true
			}
		}

		if len(n.Elements) > 0 {
			emit(n)
		}
	} else {
		*partial = true
	}
}

func inspectPermissionSettings(root *jsonconfig.Node, emit func(*jsonconfig.Node, ...model.Severity)) {
	permissions := root.Get("permissions")
	if mode, ok := permissions.Get("defaultMode").Text(); ok {
		switch mode {
		case "bypassPermissions":
			if disabledMode, _ := permissions.Get("disableBypassPermissionsMode").Text(); disabledMode != "disable" {
				emit(permissions.Get("defaultMode"), model.Critical)
			}
		case "acceptEdits":
			emit(permissions.Get("defaultMode"), model.Medium)
		case "auto":
			emit(permissions.Get("defaultMode"), model.Low)
		}
	}

	for _, n := range permissions.GetOrEmpty("allow").Elements {
		if text, ok := n.Text(); ok {
			if severity := permissionGrantSeverity(text); severity != "" {
				emit(n, severity)
			}
		}
	}

	for _, n := range permissions.GetOrEmpty("additionalDirectories").Elements {
		if text, ok := n.Text(); ok && rootOrHome(text) {
			emit(n, model.Critical)
		}
	}

	if nodeBool(root.Get("enableAllProjectMcpServers")) {
		emit(root.Get("enableAllProjectMcpServers"))
	}

	if n := root.Get("enabledMcpjsonServers"); n != nil && len(n.Elements) > 0 {
		emit(n)
	}
}

func inspectEnvironmentSettings(root *jsonconfig.Node, emit func(*jsonconfig.Node, ...model.Severity), partial *bool) {
	for _, m := range root.GetOrEmpty(valueEnv).Members {
		text, ok := m.Value.Text()
		if !ok {
			*partial = true
			continue
		}

		text = strings.TrimSpace(text)
		if text == "" {
			continue
		}

		switch m.Key {
		case "CLAUDE_CODE_SHELL_PREFIX", "LD_PRELOAD", "DYLD_INSERT_LIBRARIES", "GIT_SSH_COMMAND":
			emit(m.Value)
		case "ANTHROPIC_BASE_URL", "ANTHROPIC_BEDROCK_BASE_URL", "ANTHROPIC_VERTEX_BASE_URL":
			if strings.TrimRight(strings.ToLower(text), "/") != "https://api.anthropic.com" {
				emit(m.Value)
			}
		case "HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy":
			if externalHTTP(text) {
				emit(m.Value)
			}
		case "NODE_OPTIONS":
			for token := range strings.FieldsSeq(text) {
				for _, flag := range []string{"-r", "--require", "--import", "--loader", "--experimental-loader"} {
					if token == flag || strings.HasPrefix(token, flag+"=") {
						emit(m.Value)
					}
				}
			}
		}
	}
}

func stringSet(text string) map[string]bool {
	m := map[string]bool{}
	for s := range strings.FieldsSeq(text) {
		m[s] = true
	}

	return m
}
func nodeBool(n *jsonconfig.Node) bool { return n != nil && n.Kind == "bool" && n.Bool }
func rootOrHome(s string) bool {
	if strings.HasPrefix(s, "/") {
		return path.Clean(s) == "/"
	}

	if s == "~" {
		return true
	}

	return strings.HasPrefix(s, "~/") && path.Clean(strings.TrimPrefix(s, "~/")) == "."
}

func permissionGrantSeverity(s string) model.Severity {
	switch s {
	case "Bash", "Bash(*)", "PowerShell", "PowerShell(*)", "Read", "Edit", "Write":
		return model.Critical
	}

	for _, tool := range []string{"Read", "Edit"} {
		if strings.HasPrefix(s, tool+"(") && strings.HasSuffix(s, ")") {
			v := s[len(tool)+1 : len(s)-1]
			if v == "//" || v == "//**" || v == "~" || v == "~/**" {
				return model.Critical
			}

			if strings.HasPrefix(v, "~/") && (strings.HasPrefix(v, "~/.ssh/") || v == "~/.aws/credentials" || v == "~/.npmrc" || v == "~/.pypirc" || v == "~/.docker/config.json") {
				return model.High
			}
		}
	}

	if broadTool(s) {
		return model.High
	}

	return ""
}

func externalHTTP(text string) bool {
	u, e := url.Parse(text)
	return e == nil && (u.Scheme == schemeHTTP || u.Scheme == "https") && closedRemoteHost(u.Hostname())
}

func closedRemoteHost(host string) bool {
	if host == "" || loopbackHost(host) {
		return false
	}

	if ip := net.ParseIP(host); ip != nil {
		return !ip.IsLoopback()
	}

	if strings.Contains(host, ":") || strings.HasPrefix(strings.ToLower(host), "0x") {
		return false
	}

	if strings.Trim(host, "0123456789.") == "" {
		return false
	}

	return true
}

// Closed direct-command proof only: one simple curl invocation, one remote
// destination, and a literal stdin/sensitive file upload. No shell expansion.
func directHookUpload(ctx context.Context, event string, h *jsonconfig.Node) bool {
	if shell := h.Get("shell"); shell != nil {
		if value, ok := shell.Text(); !ok || value != "bash" {
			return false
		}
	}

	command, _ := h.Get(valueCommand).Text()
	argv := []string{}

	if args := h.Get("args"); args != nil {
		if args.Kind != kindArray {
			return false
		}

		argv = append(argv, command)

		for _, n := range args.Elements {
			s, ok := n.Text()
			if !ok {
				return false
			}

			argv = append(argv, s)
		}
	} else {
		tree, e := shellsyntax.Parse(ctx, command)
		if e != nil || len(tree.Statements) != 1 {
			return false
		}

		stmt := tree.Statements[0]
		if len(stmt.Commands) != 1 {
			return false
		}

		c := stmt.Commands[0]
		if len(c.Assignments) > 0 || len(c.Redirects) > 0 || c.Subshell != nil {
			return false
		}

		for _, word := range c.Words {
			s, ok := hookUploadWord(word)
			if !ok {
				return false
			}

			argv = append(argv, s)
		}
	}

	return directUploadArguments(event, argv)
}

// An abstract HOME anchor models the package's declared home-relative operand;
// it does not read the scanner's environment or evaluate arbitrary expansion.
func hookUploadWord(word *shellsyntax.Word) (string, bool) {
	if v, ok := word.Literal(); ok {
		return v, true
	}

	var b strings.Builder

	home := false

	for _, p := range word.Parts {
		switch p.Kind {
		case valueLiteral:
			b.WriteString(p.Text)
		case valueParameter:
			if p.Text != "HOME" || home || (b.String() != "" && b.String() != "@") {
				return "", false
			}

			home = true

			b.WriteString("/home/scout-symbolic-home")
		default:
			return "", false
		}
	}

	v := b.String()

	return v, home && sensitiveAbsoluteFile(strings.TrimPrefix(v, "@"))
}
