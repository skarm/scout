package analyzer

import (
	"context"
	"errors"
	"maps"
	"path"
	"strings"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/shellsyntax"
	"github.com/skarm/scout/internal/source"
)

const (
	MaxShellOperations = 65536
	MaxShellBindings   = 256
	MaxShellTraceSteps = 6
)

type shellCheck struct{ kind string }

type shellOrigin struct {
	source source.Span
	via    []source.Span
}
type shellValue struct {
	text                 string
	known                bool
	credential, download *shellOrigin
}
type shellState struct {
	vars      map[string]shellValue
	functions map[string]*shellsyntax.File
	ambient   bool
}

type shellWalk struct {
	ctx               context.Context
	view              source.View
	kind              string
	limit, operations int
	result            Result
	err               error
	activeFunctions   map[*shellsyntax.File]bool
}

func newShellState() *shellState {
	return &shellState{vars: map[string]shellValue{}, functions: map[string]*shellsyntax.File{}, ambient: true}
}

func (a shellCheck) Rule() model.Rule {
	r := model.Rule{
		ID: a.kind, Version: "2", Method: "shell-subset-ast", Severity: model.Medium,
		Limitation: "Bounded native shell subset, not full POSIX/Bash. Command names are syntactic candidates, not resolved executables. Selected straight-line assignments/stdio and constant words only; no general control flow, functions, aliases, field splitting or external-file semantics. A flow is not proof of execution or malicious intent.",
	}
	switch a.kind {
	case "SH001":
		r.Title, r.Category, r.Severity = "Downloaded bytes reach a shell execution input", "remote-execution", model.High
	case "SH002":
		r.Title, r.Category, r.Severity = "Sensitive data reaches a supported curl request argument", "credential-egress", model.High
	case "SH003":
		r.Title, r.Category = "Shell evaluates text or sources a file", "dynamic-execution"
	case "SH004":
		r.Title, r.Category = "Shell command reads a sensitive credential path", "credential-access"
	}

	r.Description = r.Title

	return r
}
func (shellCheck) AppliesTo(f artifact.File) bool { return f.Metadata().Kind == formatText }
func (shellCheck) AppliesToDocument(f document.File) bool {
	for _, u := range f.Units() {
		if t, ok := u.Tree.(parse.ShellTree); ok && t.Tree != nil {
			return true
		}
	}

	return false
}

func (a shellCheck) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	return a.FindDocument(ctx, document.Prepare(ctx, f), budget)
}

func (a shellCheck) FindDocument(ctx context.Context, f document.File, limit int) (Result, error) {
	if ctx == nil {
		return Result{}, errors.New("nil shell analysis context")
	}

	walk := shellWalk{ctx: ctx, kind: a.kind, limit: limit}

	for _, u := range f.Units() {
		t, ok := u.Tree.(parse.ShellTree)
		if !ok || t.Tree == nil {
			continue
		}

		walk.view = u.View
		walk.list(t.Tree, newShellState())

		if walk.err != nil || walk.result.Truncated {
			break
		}
	}

	return walk.result, errors.Join(walk.err, ctx.Err())
}

func (s *shellState) clone() *shellState {
	n := &shellState{vars: make(map[string]shellValue, len(s.vars)), functions: map[string]*shellsyntax.File{}, ambient: s.ambient}
	maps.Copy(n.vars, s.vars)

	maps.Copy(n.functions, s.functions)

	return n
}
func (s *shellState) barrier() { clear(s.vars); s.ambient = false }

func (a *shellWalk) step() bool {
	if a.err != nil || a.result.Truncated {
		return false
	}

	if err := a.ctx.Err(); err != nil {
		a.err = err
		return false
	}

	a.operations++
	if a.operations > MaxShellOperations {
		a.err = errors.New("shell analysis operation budget exceeded")
		return false
	}

	return true
}

func (a *shellWalk) emit(kind string, s source.Span, origin *shellOrigin) {
	if kind != a.kind || !a.step() {
		return
	}

	if len(a.result.Matches) >= a.limit {
		a.result.Truncated = true
		return
	}

	m, err := a.view.Original(s)
	if err != nil {
		a.err = errors.New("shell source mapping failed")
		return
	}

	match := Match{Start: m.Start, End: m.End}

	if origin != nil {
		trace := append([]source.Span{origin.source}, origin.via...)

		trace = append(trace, s)
		for i, span := range trace {
			x, e := a.view.Original(span)
			if e != nil {
				a.err = errors.New("shell trace mapping failed")
				return
			}

			role := "transform"
			if i == 0 {
				role = valueSource
			} else if i == len(trace)-1 {
				role = "sink"
			}

			match.Trace = append(match.Trace, Trace{Role: role, Start: x.Start, End: x.End})
		}
	}

	a.result.Matches = append(a.result.Matches, match)
}

func (a *shellWalk) via(o *shellOrigin, s source.Span) *shellOrigin {
	if o == nil {
		return nil
	}

	if len(o.via) >= MaxShellTraceSteps {
		a.err = errors.New("shell trace budget exceeded")
		return nil
	}

	n := &shellOrigin{source: o.source, via: append([]source.Span(nil), o.via...)}
	if s.End > s.Start {
		n.via = append(n.via, s)
	}

	return n
}

func (a *shellWalk) word(w *shellsyntax.Word, s *shellState) shellValue {
	if w == nil || !a.step() {
		return shellValue{}
	}

	v := shellValue{known: !w.Expands}
	for _, part := range w.Parts {
		if !a.step() {
			return v
		}

		x := shellValue{known: true}

		switch part.Kind {
		case valueLiteral:
			x.text = part.Text
		case valueParameter:
			var ok bool

			x, ok = s.vars[part.Text]
			if !ok {
				if part.Text == "HOME" && s.ambient {
					x = shellValue{text: "$HOME", known: true}
				} // symbolic, not a host lookup

				if sensitiveName(part.Text) && s.ambient {
					x.credential = &shellOrigin{source: part.Span}
				}
			}
		case "substitution":
			x = a.list(part.Tree, s.clone())
			x.known = false
		}
		// Unquoted known expansions can split/glob into multiple arguments.
		// Do not reinterpret a value such as "echo /bin/curl" as one executable.
		if part.Kind != valueLiteral && !part.Quoted && x.known && strings.ContainsAny(x.text, " \t\n*?[") {
			x.known = false
		}

		v = mergeShellValue(v, x)
		if !x.known || len(x.text) > MaxStaticStringBytes-len(v.text) {
			v.known = false
		} else if v.known {
			v.text += x.text
		}
	}

	if !v.known {
		v.text = ""
	}

	return v
}

func (a *shellWalk) bind(s *shellState, b shellsyntax.Assignment) {
	if !a.step() {
		return
	}

	v := a.word(b.Value, s)
	v.credential = a.via(v.credential, b.Span)

	v.download = a.via(v.download, b.Span)
	if _, ok := s.vars[b.Name]; !ok && len(s.vars) >= MaxShellBindings {
		a.err = errors.New("shell binding budget exceeded")
		return
	}

	s.vars[b.Name] = v
}

func (a *shellWalk) list(f *shellsyntax.File, s *shellState) shellValue {
	return a.listInput(f, s, shellValue{})
}

func (a *shellWalk) listInput(f *shellsyntax.File, s *shellState, incoming shellValue) shellValue {
	var out shellValue
	if f == nil {
		return out
	}

	conditional := false

	for _, st := range f.Statements {
		if !a.step() {
			break
		}

		branch := conditional || st.Next == "&&" || st.Next == "||" || st.Next == "&"
		if branch {
			s.barrier()
		}

		input := incoming

		for _, cmd := range st.Commands {
			state := s
			if len(st.Commands) > 1 || st.Next == "&" {
				state = s.clone()
			}

			input = a.command(cmd, state, input)
		}

		out = mergeShellValue(out, input)

		if branch {
			s.barrier()
		}

		conditional = st.Next == "&&" || st.Next == "||"
	}

	return out
}

func (a *shellWalk) command(c *shellsyntax.Command, s *shellState, input shellValue) shellValue {
	if !a.step() {
		return shellValue{}
	}

	if c.FunctionName != "" {
		s.functions[c.FunctionName] = c.FunctionBody
		a.function(c.FunctionBody, s.clone(), shellValue{})

		return shellValue{}
	}

	if c.Group != nil || len(c.Alternatives) > 0 {
		input, redirected := a.redirects(c, s, input)

		out := shellValue{}
		if c.Group != nil {
			out = a.listInput(c.Group, s, input)
		} else {
			a.list(c.Prelude, s)

			for _, branch := range c.Alternatives {
				out = mergeShellValue(out, a.listInput(branch, s.clone(), input))
			}

			s.barrier()
		}

		if redirected {
			return shellValue{}
		}

		return out
	}

	if len(c.Words) == 0 && c.Subshell == nil {
		for _, b := range c.Assignments {
			a.bind(s, b)
		}

		a.redirects(c, s, input)

		return shellValue{}
	}
	// Prefix assignments do not change parameter expansion of the command's
	// argument words: TOKEN=x curl --data "$TOKEN" uses the previous TOKEN.
	for _, b := range c.Assignments {
		a.word(b.Value, s)
	}

	values := make([]shellValue, len(c.Words))
	for i, w := range c.Words {
		values[i] = a.word(w, s)
	}

	input, outputRedirect := a.redirects(c, s, input)
	if c.Subshell != nil {
		out := a.list(c.Subshell, s.clone())

		if outputRedirect {
			return shellValue{}
		}

		return out
	}

	name, args, ok := shellInvocation(values)
	if !ok {
		s.barrier()
		return shellValue{}
	}

	if body := s.functions[name]; body != nil {
		return a.function(body, s, input)
	}

	out := a.invokeCommand(c, s, input, name, args)

	if outputRedirect {
		return shellValue{}
	}

	return out
}

func (a *shellWalk) invokeCommand(c *shellsyntax.Command, s *shellState, input shellValue, name string, args []shellValue) shellValue {
	var out shellValue

	switch name {
	case "curl":
		return a.curlCommand(c, input, args)
	case "wget":
		if wgetStdout(args) {
			out.download = &shellOrigin{source: c.Span}
		}
	case valueCat:
		return a.catCommand(c, input, args)
	case valueEcho:
		for _, v := range args {
			out = mergeShellValue(out, v)
		}
	case valuePrintf:
		if len(args) > 0 && args[0].known && printfStringFormat(args[0].text) {
			for _, v := range args[1:] {
				out = mergeShellValue(out, v)
			}
		}
	default:
		a.executionCommand(c, s, input, name, args)
	}

	return out
}

func (a *shellWalk) curlCommand(c *shellsyntax.Command, input shellValue, args []shellValue) shellValue {
	var out shellValue

	request := curlArguments(args)
	if request.valid && request.remote {
		for _, body := range request.bodies {
			v := body.value
			if body.file && v.known {
				file := v.text
				if body.at {
					file = strings.TrimPrefix(file, "@")
				}

				if file == "-" {
					v = mergeShellValue(v, input)
				} else if sensitivePath(file) {
					v.credential = &shellOrigin{source: c.Span}
					a.emit("SH004", c.Span, nil)
				}
			}

			if v.credential != nil {
				a.emit("SH002", c.Span, v.credential)
			}
		}

		if request.stdout {
			out.download = &shellOrigin{source: c.Span}
		}
	}

	return out
}

func (a *shellWalk) catCommand(c *shellsyntax.Command, input shellValue, args []shellValue) shellValue {
	var out shellValue

	files, readsInput, valid := catArguments(args)
	if valid {
		if readsInput {
			out = input
		}

		for _, v := range files {
			if v.known && sensitivePath(v.text) {
				out.credential = &shellOrigin{source: c.Span}
				a.emit("SH004", c.Span, nil)
			}
		}
	}

	return out
}

func (a *shellWalk) executionCommand(c *shellsyntax.Command, s *shellState, input shellValue, name string, args []shellValue) {
	switch name {
	case "eval":
		a.emit("SH003", c.Span, nil)

		for _, v := range args {
			if v.download != nil {
				a.emit("SH001", c.Span, v.download)
			}
		}

		s.barrier()
	case valueSource, ".":
		a.emit("SH003", c.Span, nil)
		s.barrier()
	case "sh", "bash", "dash", "zsh", "ksh":
		commandText, readsInput := shellExecution(args)
		if commandText >= 0 {
			a.emit("SH003", c.Span, nil)

			if args[commandText].download != nil {
				a.emit("SH001", c.Span, args[commandText].download)
			}
		}

		if readsInput && input.download != nil {
			a.emit("SH001", c.Span, input.download)
		}
	case "true", "false", ":":
	default:
		s.barrier() // unknown builtins/functions can mutate shell state
	}
}

func (a *shellWalk) function(body *shellsyntax.File, s *shellState, input shellValue) shellValue {
	if a.activeFunctions == nil {
		a.activeFunctions = map[*shellsyntax.File]bool{}
	}

	if body == nil || a.activeFunctions[body] || len(a.activeFunctions) >= 16 {
		s.barrier()
		return shellValue{}
	}

	a.activeFunctions[body] = true
	defer delete(a.activeFunctions, body)

	return a.listInput(body, s, input)
}

func (a *shellWalk) redirects(c *shellsyntax.Command, s *shellState, input shellValue) (shellValue, bool) {
	out := false

	for _, r := range c.Redirects {
		v := a.word(r.Target, s)

		fd := r.FD
		switch r.Op {
		case "<", "<>":
			if fd == "" || fd == "0" {
				input = shellValue{}
				if v.known && sensitivePath(v.text) {
					input.credential = &shellOrigin{source: r.Span}
					a.emit("SH004", r.Span, nil)
				}
			}
		case "<<<":
			if fd == "" || fd == "0" {
				input = v
			}
		case "<<", "<<-":
			body := a.word(r.Body, s)
			if fd == "" || fd == "0" {
				input = body
			}
		case "<&":
			if fd == "" || fd == "0" {
				input = shellValue{}
			}
		case ">", ">>", ">|", ">&":
			if fd == "" || fd == "1" {
				out = true
			}
		case "&>", "&>>":
			out = true
		}
	}

	return input, out
}

func mergeShellValue(x, y shellValue) shellValue {
	if x.credential == nil {
		x.credential = y.credential
	}

	if x.download == nil {
		x.download = y.download
	}

	return x
}

func shellInvocation(v []shellValue) (string, []shellValue, bool) {
	for layers := 0; len(v) > 0 && layers < 4; layers++ {
		if !v[0].known || v[0].text == "" {
			return "", nil, false
		}

		name := path.Base(v[0].text)
		v = v[1:]

		switch name {
		case "builtin":
			return shellBuiltin(v)
		case valueCommand:
			if len(v) > 0 && v[0].known && v[0].text == "--" {
				v = v[1:]
			} else if len(v) > 0 && v[0].known && strings.HasPrefix(v[0].text, "-") {
				return "", nil, false
			}
		case valueEnv:
			// Environment options/assignments change semantics; only a bare env
			// wrapper or -- is supported, not guessed through.
			if len(v) > 0 && v[0].known && v[0].text == "--" {
				v = v[1:]
			}

			if len(v) > 0 && (!v[0].known || strings.HasPrefix(v[0].text, "-") || strings.Contains(v[0].text, "=")) {
				return "", nil, false
			}
		case valueSudo:
			var ok bool

			v, ok = sudoArguments(v)
			if !ok {
				return "", nil, false
			}
		default:
			return name, v, true
		}
	}

	return "", nil, false
}

func shellBuiltin(v []shellValue) (string, []shellValue, bool) {
	if len(v) > 0 && v[0].known && v[0].text == "--" {
		v = v[1:]
	}

	if len(v) == 0 || !v[0].known {
		return "", nil, false
	}

	switch v[0].text {
	case "eval", valueSource, ".", valueEcho, valuePrintf, "true", "false", ":":
		return v[0].text, v[1:], true
	}

	return "", nil, false
}

func sudoArguments(v []shellValue) ([]shellValue, bool) {
	for len(v) > 0 && v[0].known && strings.HasPrefix(v[0].text, "-") {
		flag := v[0].text
		v = v[1:]

		if flag == "--" {
			break
		}

		if flag == "-u" || flag == "-g" {
			if len(v) == 0 || !v[0].known {
				return nil, false
			}

			v = v[1:]
		} else if flag != "-E" && flag != "-n" {
			return nil, false
		}
	}

	return v, true
}

func shellExecution(args []shellValue) (int, bool) {
	stdin, noexec := false, false

	for i := range args {
		v := args[i]
		if !v.known {
			return -1, false
		}

		if v.text == "--" {
			return -1, !noexec && (stdin || i == len(args)-1)
		}

		if strings.HasPrefix(v.text, "--") {
			if v.text == "--noprofile" || v.text == "--norc" {
				continue
			}

			return -1, false
		}

		if strings.HasPrefix(v.text, "-") && len(v.text) > 1 {
			command, valid := shellExecutionFlags(v.text[1:], &stdin, &noexec)
			if !valid {
				return -1, false
			}

			if command {
				if noexec || i+1 >= len(args) {
					return -1, false
				}

				return i + 1, false
			}

			continue
		}

		return -1, stdin && !noexec // with -s, operands are positional parameters
	}

	return -1, !noexec
}

func shellExecutionFlags(flags string, stdin, noexec *bool) (bool, bool) {
	command := false

	for _, flag := range flags {
		switch flag {
		case 'n', 'D':
			*noexec = true
		case 'c':
			command = true
		case 's':
			*stdin = true
		case 'e', 'u', 'f', 'x', 'v', 'l', 'p':
		default:
			return false, false
		}
	}

	return command, true
}

// cat reads stdin only with no file operands or an explicit "-". File operands
// replace, rather than preserve, the incoming pipeline's data.
func catArguments(args []shellValue) ([]shellValue, bool, bool) {
	var files []shellValue

	options := true
	for _, v := range args {
		if v.known && options && v.text == "--" {
			options = false
			continue
		}

		if v.known && options && strings.HasPrefix(v.text, "-") && v.text != "-" {
			if strings.HasPrefix(v.text, "--") {
				return nil, false, false
			}

			for _, flag := range v.text[1:] {
				if !strings.ContainsRune("AbEenstTuv", flag) {
					return nil, false, false
				}
			}

			continue
		}

		files = append(files, v)
	}

	input := len(files) == 0
	for _, v := range files {
		if v.known && v.text == "-" {
			input = true
		}
	}

	return files, input, true
}

func printfStringFormat(s string) bool {
	uses := false

	for i := 0; i < len(s); i++ {
		if s[i] != '%' {
			continue
		}

		i++
		if i == len(s) {
			return false
		}

		switch s[i] {
		case 's':
			uses = true
		case '%':
		default:
			return false
		}
	}

	return uses
}
