// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Modified SC9: Scout inventories excluded directories too; this signal is
// source-bound to a local declaration whose implementation was not captured.

package analyzer

import (
	"context"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/model"
)

type uninspectedReference struct{ records map[string][]Match }

func BindGraph(checks []Analyzer, docs []document.File, g model.ComponentGraph) []Analyzer {
	records := map[string][]Match{}

	byPath := map[string]artifact.File{}
	for _, d := range docs {
		byPath[d.Artifact().Metadata().Path] = d.Artifact()
	}

	for _, r := range g.References {
		if r.Source == nil || r.Status != "unresolved" || (r.Reason != "handler_not_captured" && r.Reason != "component_not_captured") {
			continue
		}

		s := r.Source

		f, ok := byPath[s.Path]
		if !ok || f.Metadata().SHA256 != s.SHA256 {
			continue
		}

		records[s.Path] = append(records[s.Path], Match{Start: s.ByteStart, End: s.ByteEnd})
	}

	out := append([]Analyzer(nil), checks...)
	for i, a := range out {
		if _, ok := a.(uninspectedReference); ok {
			out[i] = uninspectedReference{records: records}
		}
	}

	return out
}

func (uninspectedReference) Rule() model.Rule {
	return model.Rule{ID: "NV-SC9", Version: "1", Title: "Declared local component was not inspected", Description: "A captured configuration refers to a local component or handler unavailable to inspection.", Severity: model.High, Category: valueSupplyChain, Method: "source-bound-component-coverage", Limitation: "Selected harness local references only. Missing, excluded and unreadable targets cannot be distinguished universally; this is an inspection obligation, not proof of malicious code. All captured directories remain inspected without path exemptions."}
}

func (a uninspectedReference) AppliesTo(f artifact.File) bool {
	return len(a.records[f.Metadata().Path]) > 0
}

func (a uninspectedReference) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	out := Result{}

	for _, m := range a.records[f.Metadata().Path] {
		if ctx.Err() != nil {
			return out, ctx.Err()
		}

		if len(out.Matches) >= budget {
			out.Truncated = true
			break
		}

		out.Matches = append(out.Matches, m)
	}

	return out, nil
}
