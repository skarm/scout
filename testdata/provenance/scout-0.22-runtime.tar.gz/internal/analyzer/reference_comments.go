package analyzer

import (
	"context"
	"regexp"
	"strings"
)

var (
	referenceOpener          = regexp.MustCompile(`(?m)(?:^|[\r\n])[\t ]{0,3}\[//\]:`)
	referenceKeyword         = regexp.MustCompile(`(?i)(?:^|[^A-Za-z0-9])(?:system|instructions?|ignore|post|get|send|transmit|upload|execute|override)(?:$|[^A-Za-z0-9])`)
	referenceCamelBoundary   = regexp.MustCompile(`([a-z])([A-Z])`)
	referenceAcronymBoundary = regexp.MustCompile(`([A-Z])([A-Z][a-z])`)
	referenceAction          = regexp.MustCompile(`(?i)\b(?:ignoring|transmitting|uploading|sending)\b|ignorepreviousinstructions|transmitconversationto(?:attacker|external)|systemprompt|postrequestto`)
)

func referenceHasKeyword(text string) bool {
	words := referenceCamelBoundary.ReplaceAllString(text, "$1 $2")
	words = referenceAcronymBoundary.ReplaceAllString(words, "$1 $2")

	return referenceKeyword.MatchString(words) || referenceAction.MatchString(words)
}

// Inspect only the destination and optional title of this comment convention.
// A bounded continuation may cross one logical line, never a blank paragraph.
func referenceCommentSignals(ctx context.Context, text string, emit func(int, int) bool) bool {
	openers := referenceOpener.FindAllStringIndex(text, 65537)
	if len(openers) > 65536 {
		return true
	}

	for _, at := range openers {
		if ctx.Err() != nil {
			return true
		}

		if inspectReferenceComment(text, at[0], at[1], emit) {
			return true
		}
	}

	return false
}

func inspectReferenceComment(text string, start, cursor int, emit func(int, int) bool) bool {
	for start < len(text) && (text[start] == '\r' || text[start] == '\n') {
		start++
	}

	bound := min(len(text), cursor+2048)

	cursor = skipReferenceSpace(text, cursor, bound)
	if cursor >= bound || text[cursor] == '\r' || text[cursor] == '\n' || text[cursor] != '#' {
		return false
	}

	destination := cursor
	cursor = referenceDestinationEnd(text, cursor, bound)
	found := referenceHasKeyword(text[destination:cursor])
	end := cursor

	cursor = skipReferenceSpace(text, cursor, bound)
	if cursor < bound && text[cursor] != '\r' && text[cursor] != '\n' && strings.ContainsRune("(\"'", rune(text[cursor])) {
		title := cursor + 1
		cursor = referenceTitleEnd(text, cursor, bound)
		found = found || referenceHasKeyword(text[title:cursor])
		end = cursor
	}

	if found && !emit(start, end) {
		return true
	}

	return cursor == bound && bound < len(text)
}

func skipReferenceSpace(text string, cursor, bound int) int {
	for cursor < bound && (text[cursor] == ' ' || text[cursor] == '\t') {
		cursor++
	}

	if cursor < bound && (text[cursor] == '\r' || text[cursor] == '\n') {
		if text[cursor] == '\r' && cursor+1 < bound && text[cursor+1] == '\n' {
			cursor++
		}

		cursor++
		for cursor < bound && (text[cursor] == ' ' || text[cursor] == '\t') {
			cursor++
		}
	}

	return cursor
}

func referenceDestinationEnd(text string, cursor, bound int) int {
	depth := 0

	for cursor < bound {
		c := text[cursor]
		if c == '\\' && cursor+1 < bound {
			cursor += 2
			continue
		}

		if c == '\r' || c == '\n' || c == ' ' || c == '\t' {
			break
		}

		if c == '(' {
			depth++
		}

		if c == ')' {
			depth--
			if depth < 0 {
				break
			}
		}

		cursor++
	}

	return cursor
}

func referenceTitleEnd(text string, cursor, bound int) int {
	closing := text[cursor]
	if closing == '(' {
		closing = ')'
	}

	cursor++
	lines := 0

	for cursor < bound {
		c := text[cursor]
		if c == '\\' && cursor+1 < bound {
			cursor += 2
			continue
		}

		if c == closing {
			break
		}

		if c == '\r' || c == '\n' {
			lines++
			if lines > 1 {
				break
			}

			if c == '\r' && cursor+1 < bound && text[cursor+1] == '\n' {
				cursor++
			}

			following := cursor + 1
			for following < bound && (text[following] == ' ' || text[following] == '\t') {
				following++
			}

			if following == bound || text[following] == '\r' || text[following] == '\n' {
				break
			}
		}

		cursor++
	}

	return cursor
}
