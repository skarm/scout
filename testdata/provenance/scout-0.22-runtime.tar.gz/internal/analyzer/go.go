package analyzer

import (
	"context"
	"errors"
	"go/ast"
	"go/token"
	"path"
	"strconv"
	"strings"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/source"
)

const (
	goShell goKind = iota
	goSensitiveRead
	goDirectHTTP
)

const (
	MaxStaticStringBytes  = 4096
	MaxConstantOperations = 256
)

type goKind uint8

type goCheck struct{ kind goKind }

func (a goCheck) Rule() model.Rule {
	r := model.Rule{
		Version: "1", Method: "go-ast", Severity: model.Medium,
		Limitation: "Go syntax only, not type checking or proof of execution. Resolves literal strings, constant concatenation and selected library calls; mutable-variable flow and cross-file resolution are not supported.",
	}

	switch a.kind {
	case goShell:
		r.ID, r.Title, r.Category = "GO001", "Go constructs a shell command", "process-execution"
	case goSensitiveRead:
		r.ID, r.Title, r.Category = "GO002", "Go file API references a sensitive credential path", valueCredentialAccess
	case goDirectHTTP:
		r.ID, r.Title, r.Category = "GO003", "Credential material flows directly into an HTTP body API", valueCredentialEgress
		r.Severity, r.Method = model.High, "go-ast-direct-flow"
		r.Limitation += " Direct nested expressions only; legitimate credential exchange can also match. Request construction does not prove transmission or malicious intent."
	}

	r.Description = r.Title

	return r
}

func (goCheck) AppliesTo(f artifact.File) bool {
	return f.Metadata().Kind == formatText
}
func (goCheck) AppliesToDocument(f document.File) bool { return f.HasGo() }
func (a goCheck) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	return a.FindDocument(ctx, document.Prepare(ctx, f), budget)
}

func (a goCheck) FindDocument(ctx context.Context, f document.File, budget int) (Result, error) {
	var (
		result     Result
		mappingErr error
	)

	if err := ctx.Err(); err != nil {
		return result, err
	}

	for _, unit := range f.GoUnits() {
		if unit.Tree == nil {
			continue
		}

		imports := importNames(unit.Tree)
		ast.Inspect(unit.Tree, func(n ast.Node) bool {
			if n == nil || result.Truncated || mappingErr != nil || ctx.Err() != nil {
				return false
			}

			call, ok := n.(*ast.CallExpr)
			if !ok {
				return true
			}
			// A recovered AST can contain a synthesized delimiter at EOF or at
			// a different token. Verify actual delimiters, not only IsValid().
			// Complete neighboring/child calls remain independently inspectable.
			if !completeCall(unit, call) {
				return true
			}

			origin, matched := a.matchCall(call, imports)
			if !matched {
				return true
			}

			return appendGoMatch(unit, call, origin, budget, &result, &mappingErr)
		})

		if result.Truncated || mappingErr != nil || ctx.Err() != nil {
			break
		}
	}

	return result, errors.Join(mappingErr, ctx.Err())
}

func (a goCheck) matchCall(call *ast.CallExpr, imports map[string]string) (ast.Expr, bool) {
	pkg, method := qualified(call.Fun, imports)

	var origin ast.Expr

	matched := false

	switch a.kind {
	case goShell:
		index := 0
		if method == "CommandContext" {
			index = 1
		}

		if pkg == "os/exec" && (method == "Command" || method == "CommandContext") && len(call.Args) > index {
			name, known := constantString(call.Args[index], imports)
			matched = known && isShell(name)
		}
	case goSensitiveRead:
		if ((pkg == "os" && (method == valueReadFile || method == "Open" || method == "OpenFile")) ||
			(pkg == valueIoIoutil && method == valueReadFile)) && len(call.Args) > 0 {
			name, known := constantString(call.Args[0], imports)
			matched = known && sensitivePath(name)
		}
	case goDirectHTTP:
		index := -1

		if pkg == "net/http" {
			switch method {
			case "Post", "NewRequest":
				index = 2
			case "NewRequestWithContext":
				index = 3
			case "PostForm":
				index = 1
			}
		}

		if index >= 0 && len(call.Args) > index {
			origin = sensitiveExpression(call.Args[index], imports, 0)
			matched = origin != nil
		}
	}

	return origin, matched
}

func appendGoMatch(unit document.GoUnit, call *ast.CallExpr, origin ast.Expr, budget int, result *Result, mappingErr *error) bool {
	span, ok := nodeSpan(unit, call)
	if !ok {
		*mappingErr = errors.New("go AST source mapping failed")
		return false
	}

	if len(result.Matches) >= budget {
		result.Truncated = true
		return false
	}

	m := Match{Start: span.Start, End: span.End}

	if origin != nil {
		if src, valid := nodeSpan(unit, origin); valid {
			m.Trace = []Trace{{Role: valueSource, Start: src.Start, End: src.End}, {Role: valueSink, Start: span.Start, End: span.End}}
		} else {
			*mappingErr = errors.New("go AST trace mapping failed")
			return false
		}
	}

	result.Matches = append(result.Matches, m)

	return true
}

func completeCall(unit document.GoUnit, call *ast.CallExpr) bool {
	file := unit.Tokens.File(call.Pos())
	if file == nil || !call.Lparen.IsValid() || !call.Rparen.IsValid() {
		return false
	}

	left, right := int(call.Lparen)-file.Base(), int(call.Rparen)-file.Base()
	text := unit.View.Text()

	return left >= 0 && right > left && right < len(text) && text[left] == '(' && text[right] == ')'
}

func nodeSpan(unit document.GoUnit, n ast.Node) (source.Span, bool) {
	file := unit.Tokens.File(n.Pos())
	if file == nil || n.End() < n.Pos() || n.End() > token.Pos(file.Base()+file.Size()) {
		return source.Span{}, false
	}

	s, err := unit.View.Original(source.Span{Start: file.Offset(n.Pos()), End: file.Offset(n.End())})

	return s, err == nil
}

func importNames(f *ast.File) map[string]string {
	m := make(map[string]string, len(f.Imports))
	for _, spec := range f.Imports {
		p, err := strconv.Unquote(spec.Path.Value)
		if err != nil {
			continue
		}

		name := path.Base(p)
		if spec.Name != nil {
			name = spec.Name.Name
		}

		if name != "." && name != "_" {
			m[name] = p
		}
	}

	return m
}

func qualified(expr ast.Expr, imports map[string]string) (pkg, name string) {
	selector, ok := expr.(*ast.SelectorExpr)
	if !ok {
		return "", ""
	}

	id, ok := selector.X.(*ast.Ident)
	// go/parser resolves local/package declarations. A shadowed import is not
	// the standard-library package and must not produce a package-API match.
	if !ok || id.Obj != nil {
		return "", ""
	}

	return imports[id.Name], selector.Sel.Name
}

func constantString(e ast.Expr, imports map[string]string) (string, bool) {
	remaining := MaxConstantOperations
	return evalString(e, imports, 0, &remaining)
}

func evalString(e ast.Expr, imports map[string]string, depth int, remaining *int) (string, bool) {
	if depth > 16 || *remaining <= 0 {
		return "", false
	}

	*remaining--

	switch x := e.(type) {
	case *ast.BasicLit:
		if x.Kind != token.STRING || len(x.Value) > 6*MaxStaticStringBytes+2 {
			return "", false
		}

		s, err := strconv.Unquote(x.Value)

		return s, err == nil && len(s) <= MaxStaticStringBytes
	case *ast.ParenExpr:
		return evalString(x.X, imports, depth+1, remaining)
	case *ast.BinaryExpr:
		if x.Op != token.ADD {
			return "", false
		}

		left, a := evalString(x.X, imports, depth+1, remaining)

		right, b := evalString(x.Y, imports, depth+1, remaining)
		if !a || !b || len(left)+len(right) > MaxStaticStringBytes {
			return "", false
		}

		return left + right, true
	case *ast.Ident:
		if x.Obj == nil || x.Obj.Kind != ast.Con {
			return "", false
		}

		spec, ok := x.Obj.Decl.(*ast.ValueSpec)
		if !ok || len(spec.Names) != len(spec.Values) {
			return "", false
		}

		for i, n := range spec.Names {
			if n.Name == x.Name {
				return evalString(spec.Values[i], imports, depth+1, remaining)
			}
		}
	case *ast.CallExpr:
		return evalStringCall(x, imports, depth, remaining)
	}

	return "", false
}

func evalStringCall(x *ast.CallExpr, imports map[string]string, depth int, remaining *int) (string, bool) {
	pkg, method := qualified(x.Fun, imports)
	if pkg == "os" && method == valueGetenv && len(x.Args) == 1 {
		s, ok := evalString(x.Args[0], imports, depth+1, remaining)
		if ok && s == valueHOME {
			return "$HOME", true
		} // symbolic, never host lookup
	}

	if (pkg == "path" || pkg == "path/filepath") && method == "Join" && len(x.Args) > 0 && len(x.Args) <= 32 {
		parts := make([]string, 0, len(x.Args))
		total := 0

		for _, arg := range x.Args {
			s, ok := evalString(arg, imports, depth+1, remaining)
			// Windows filepath semantics are outside this first profile.
			if !ok || strings.ContainsRune(s, '\\') {
				return "", false
			}

			total += len(s)
			if total > MaxStaticStringBytes {
				return "", false
			}

			parts = append(parts, s)
		}

		return path.Join(parts...), true
	}

	return "", false
}

func isShell(s string) bool {
	switch path.Base(strings.ReplaceAll(s, "\\", "/")) {
	case "sh", valueBash, "dash", "zsh", "ksh", "fish", "cmd", "cmd.exe", "powershell", "powershell.exe", "pwsh", "pwsh.exe":
		return true
	}

	return false
}

func sensitivePath(s string) bool {
	s = path.Clean(s)
	if s == "/etc/shadow" {
		return true
	}

	for _, tail := range []string{".ssh/id_rsa", ".ssh/id_ed25519", ".aws/credentials"} {
		if s == tail || strings.HasSuffix(s, "/"+tail) {
			return true
		}
	}

	return false
}

func sensitiveName(s string) bool {
	s = strings.ToUpper(s)
	for _, token := range []string{"TOKEN", "SECRET", "PASSWORD", "PASSWD", "API_KEY", "ACCESS_KEY", "PRIVATE_KEY"} {
		if s == token || strings.HasSuffix(s, "_"+token) || strings.HasPrefix(s, token+"_") || strings.Contains(s, "_"+token+"_") {
			return true
		}
	}

	return false
}

// sensitiveExpression follows only selected direct value-preserving wrappers.
// It does not treat arbitrary function calls as taint propagation and never
// reads environment variables or files. Recursion has an independent ceiling.
func sensitiveExpression(expr ast.Expr, imports map[string]string, depth int) ast.Expr {
	if depth > 24 {
		return nil
	}

	switch x := expr.(type) {
	case *ast.ParenExpr:
		return sensitiveExpression(x.X, imports, depth+1)
	case *ast.BinaryExpr:
		if x.Op != token.ADD {
			return nil
		}

		if s := sensitiveExpression(x.X, imports, depth+1); s != nil {
			return s
		}

		return sensitiveExpression(x.Y, imports, depth+1)
	case *ast.CompositeLit:
		pkg, name := qualified(x.Type, imports)
		if x.Type != nil && (pkg != "net/url" || name != "Values") {
			return nil
		}

		for _, el := range x.Elts {
			if kv, ok := el.(*ast.KeyValueExpr); ok {
				el = kv.Value
			}

			if s := sensitiveExpression(el, imports, depth+1); s != nil {
				return s
			}
		}
	case *ast.CallExpr:
		return sensitiveCall(x, imports, depth)
	}

	return nil
}

func sensitiveCall(x *ast.CallExpr, imports map[string]string, depth int) ast.Expr {
	pkg, method := qualified(x.Fun, imports)
	if pkg == "os" && method == valueGetenv && len(x.Args) == 1 {
		if s, ok := constantString(x.Args[0], imports); ok && sensitiveName(s) {
			return x
		}

		return nil
	}

	known := (pkg == "strings" && method == valueNewReader) ||
		(pkg == valueBytes && (method == valueNewReader || method == "NewBufferString" || method == "NewBuffer")) ||
		(pkg == "fmt" && (method == "Sprint" || method == "Sprintf" || method == "Sprintln")) ||
		(pkg == "io" && method == "NopCloser")
	if id, ok := x.Fun.(*ast.Ident); ok && id.Obj == nil && id.Name == kindString {
		known = true
	}

	if array, ok := x.Fun.(*ast.ArrayType); ok && array.Len == nil {
		if id, ok := array.Elt.(*ast.Ident); ok && id.Obj == nil && id.Name == "byte" {
			known = true
		}
	}

	if !known {
		return nil
	}

	for _, arg := range x.Args {
		if s := sensitiveExpression(arg, imports, depth+1); s != nil {
			return s
		}
	}

	return nil
}
