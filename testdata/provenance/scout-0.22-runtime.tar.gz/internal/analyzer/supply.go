package analyzer

import (
	"context"
	"errors"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/source"
)

type moduleCheck struct{ id string }

func (a moduleCheck) Rule() model.Rule {
	r := model.Rule{
		ID: a.id, Version: "1", Severity: model.Medium, Category: valueSupplyChain, Method: "go-mod-structure",
		Limitation: "Declarations only. No dependency download, checksum verification, vulnerability database or proof of execution. A legitimate local replacement may require review.",
	}
	switch a.id {
	case valueSC002:
		r.Title = "Go module uses a local replacement outside module checksum verification"
	case valueSC003:
		r.Title = "Go module dependency identity is redirected to a different module"
	}

	r.Description = r.Title

	return r
}
func (moduleCheck) AppliesTo(f artifact.File) bool { return f.Metadata().Kind == formatText }
func (moduleCheck) AppliesToDocument(f document.File) bool {
	for _, u := range f.Units() {
		if _, ok := u.Tree.(parse.GoModTree); ok {
			return true
		}
	}

	return false
}

func (a moduleCheck) Find(ctx context.Context, f artifact.File, n int) (Result, error) {
	return a.FindDocument(ctx, document.Prepare(ctx, f), n)
}

func (a moduleCheck) FindDocument(ctx context.Context, f document.File, budget int) (Result, error) {
	var out Result
	if err := ctx.Err(); err != nil {
		return out, err
	}

	for _, u := range f.Units() {
		tree, ok := u.Tree.(parse.GoModTree)
		if !ok || tree.File == nil {
			continue
		}

		for _, r := range tree.File.Replace {
			if err := ctx.Err(); err != nil {
				return out, err
			}

			match := a.id == valueSC002 && r.New.Version == "" || a.id == valueSC003 && r.New.Version != "" && r.Old.Path != r.New.Path
			if !match {
				continue
			}

			if len(out.Matches) >= budget {
				out.Truncated = true
				return out, nil
			}

			start, end := r.Syntax.Span()

			at, err := u.View.Original(source.Span{Start: start.Byte, End: end.Byte})
			if err != nil {
				return out, errors.New("go.mod source mapping failed")
			}

			out.Matches = append(out.Matches, Match{Start: at.Start, End: at.End})
		}
	}

	return out, nil
}
