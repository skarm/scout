package analyzer

import "strings"

type shellBody struct {
	value    shellValue
	file, at bool
}
type curlRequest struct {
	valid, remote, stdout bool
	bodies                []shellBody
}

// This is a finite option model, not execution or a complete curl CLI parser.
// Unknown options invalidate the model rather than shifting argument positions.
func curlArguments(args []shellValue) curlRequest {
	r := curlRequest{valid: true, stdout: true}
	options := true

	for i := 0; i < len(args); i++ {
		v := args[i]
		if !v.known {
			r.valid = false
			continue
		}

		s := v.text
		if options && s == "--" {
			options = false
			continue
		}

		if !options || !strings.HasPrefix(s, "-") || s == "-" {
			r.remote = r.remote || httpURL(s)
			continue
		}

		key, value, attached := "", shellValue{}, false
		if strings.HasPrefix(s, "--") {
			key = s
			if before, after, ok := strings.Cut(s, "="); ok {
				key = before
				value = v
				value.text = after
				attached = true
			}
		} else {
			key, value, attached = r.shortOption(v)
			if key == "" {
				continue
			}
		}

		if !r.valueOption(key, attached) {
			continue
		}

		if !attached {
			i++
			if i >= len(args) {
				r.valid = false
				break
			}

			value = args[i]
		}

		r.applyOption(key, value)
	}

	return r
}

func (r *curlRequest) shortOption(v shellValue) (key string, value shellValue, attached bool) {
	flags := v.text[1:]
	for j := 0; j < len(flags); j++ {
		c := flags[j]
		if strings.ContainsRune("doTHuAX", rune(c)) {
			key = "-" + string(c)

			if j+1 < len(flags) {
				value = v
				value.text = flags[j+1:]
				attached = true
			}

			break
		}

		if c == 'O' {
			r.stdout = false
		} else if c == 'I' {
			r.stdout = false
		} else if !strings.ContainsRune("fsSLkigNq012346", rune(c)) {
			r.valid = false
		}
	}

	return key, value, attached
}

func (r *curlRequest) valueOption(key string, attached bool) bool {
	switch key {
	case "--silent", "--show-error", "--fail", "--location", "--insecure", "--compressed", "--globoff", "--no-buffer", "--disable":
		if attached {
			r.valid = false
		}

		return false
	case "--remote-name", "--remote-name-all", "--head", "--out-null":
		r.stdout = false
		if attached {
			r.valid = false
		}

		return false
	case "-d", valueData, valueDataASCII, valueDataBinary, "--data-raw", "--data-urlencode", "--json", "-T", valueUploadFile, "-H", "--header", "-u", "--user", "-o", "--output", valueURL, "-A", "--user-agent", "-X", "--request", "--connect-timeout", "--max-time", "--retry":
	default:
		r.valid = false
		return false
	}

	return true
}

func (r *curlRequest) applyOption(key string, value shellValue) {
	switch key {
	case "-o", "--output":
		if !value.known || value.text != "-" {
			r.stdout = false
		}
	case valueURL:
		if value.known {
			r.remote = r.remote || httpURL(value.text)
		}
	case "-d", valueData, valueDataASCII, valueDataBinary, "--json", "--data-urlencode":
		r.bodies = append(r.bodies, shellBody{value: value, file: value.known && strings.HasPrefix(value.text, "@"), at: true})
	case "-T", valueUploadFile:
		r.bodies = append(r.bodies, shellBody{value: value, file: true})
	case "--data-raw", "-H", "--header", "-u", "--user":
		r.bodies = append(r.bodies, shellBody{value: value})
	}
}

func httpURL(s string) bool {
	return strings.HasPrefix(s, "https://") || strings.HasPrefix(s, "http://")
}

func wgetStdout(args []shellValue) bool {
	stdout, remote := false, false

	for i := 0; i < len(args); i++ {
		v := args[i]
		if !v.known {
			return false
		}

		s := v.text
		switch {
		case s == "-O" || s == "--output-document":
			i++
			if i == len(args) || !args[i].known {
				return false
			}

			stdout = args[i].text == "-"
		case strings.HasPrefix(s, "--output-document="):
			stdout = strings.TrimPrefix(s, "--output-document=") == "-"
		case s == "--quiet" || s == "--no-check-certificate":
		case strings.HasPrefix(s, "-") && !strings.HasPrefix(s, "--"):
			var ok bool

			stdout, i, ok = wgetShortOptions(s[1:], args, i, stdout)
			if !ok {
				return false
			}
		case strings.HasPrefix(s, "-"):
			return false
		default:
			remote = remote || httpURL(s)
		}
	}

	return stdout && remote
}

func wgetShortOptions(flags string, args []shellValue, i int, stdout bool) (bool, int, bool) {
	for j := 0; j < len(flags); j++ {
		if flags[j] == 'O' {
			if j+1 < len(flags) {
				stdout = flags[j+1:] == "-"
			} else {
				i++
				if i == len(args) || !args[i].known {
					return false, i, false
				}

				stdout = args[i].text == "-"
			}

			break
		}

		if !strings.ContainsRune("qnv", rune(flags[j])) {
			return false, i, false
		}
	}

	return stdout, i, true
}
