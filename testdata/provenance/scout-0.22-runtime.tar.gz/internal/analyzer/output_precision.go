// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Selected output-handling guards adapted to bounded Go syntax inspection.

package analyzer

import (
	"strings"
	"unicode"
	"unicode/utf8"

	"github.com/skarm/scout/frontend"
	"github.com/skarm/scout/internal/document"
)

func pythonOutputArgument(name string, call *frontend.Node) bool {
	arguments := call.List(valueArgs)
	if len(arguments) > 1 {
		arguments = arguments[:1]
	}

	allowed := map[string]bool{valueArgs: true, "executable": true}
	if name == "subprocess.getoutput" || name == "subprocess.getstatusoutput" {
		allowed = map[string]bool{"cmd": true}
	}

	if name == "subprocess.run" || name == "subprocess.check_output" {
		allowed["input"] = true
	}

	for _, k := range call.List("keywords") {
		if strings.HasPrefix(name, "subprocess.") && allowed[k.String("arg")] {
			arguments = append(arguments, k.Child("value"))
		}
	}

	count := 0

	var hasName func(*frontend.Node, int) bool

	hasName = func(n *frontend.Node, depth int) bool {
		count++
		if n == nil || depth > 32 || count > 8192 {
			return false
		}

		if n.Type == valueName {
			switch n.String("id") {
			case "response", "output", "result", "answer", "completion", "reply", "generated":
				return true
			}
		}

		for _, c := range n.Children() {
			if hasName(c, depth+1) {
				return true
			}
		}

		return false
	}
	for _, a := range arguments {
		if hasName(a, 0) {
			return true
		}
	}

	return false
}

// Recognize only a complete, ordinary single-line regexp operand. Ambiguous
// division, comments, templates and truncated lookback retain the review signal.
func regexpLiteralExec(d document.File, m Match) bool {
	javascript := false
	for _, hint := range d.Classification().Languages {
		javascript = javascript || hint.Language == languageJavaScript || hint.Language == valueTypescript
	}

	text := d.Artifact().Content()
	if !javascript || !strings.HasPrefix(text[m.Start:m.End], valueExec) {
		return false
	}

	floor := max(0, m.Start-4096)

	start := strings.LastIndexAny(text[floor:m.Start], "\r\n")
	if start < 0 && floor > 0 {
		return false
	}

	start += floor + 1

	prefix := strings.TrimRightFunc(text[start:m.Start], unicode.IsSpace)
	if !strings.HasSuffix(prefix, ".") {
		return false
	}

	prefix = strings.TrimRightFunc(strings.TrimSuffix(prefix, "."), unicode.IsSpace)
	prefix = strings.TrimRightFunc(strings.TrimSuffix(prefix, "?"), unicode.IsSpace)

	closing := len(prefix)
	for closing > 0 && strings.ContainsRune("dgimsuvy", rune(prefix[closing-1])) {
		closing--
	}

	if closing == 0 || prefix[closing-1] != '/' {
		return false
	}

	closing--

	return completeRegexpPrefix(prefix, closing, start)
}

func completeRegexpPrefix(prefix string, closing, start int) bool {
	inClass := false

	for opening := closing - 1; opening >= 0; opening-- {
		b := prefix[opening]
		if b != '/' && b != '[' && b != ']' {
			continue
		}

		escaped := 0
		for at := opening - 1; at >= 0 && prefix[at] == '\\'; at-- {
			escaped++
		}

		if escaped%2 != 0 {
			continue
		}

		if b == ']' {
			inClass = true
		}

		if b == '[' {
			inClass = false
		}

		if b != '/' || inClass {
			continue
		}

		if opening+1 == closing {
			return false
		}

		before := strings.TrimSpace(prefix[:opening])

		return regexpAllowedPrefix(before, start)
	}

	return false
}

func regexpAllowedPrefix(before string, start int) bool {
	// Require the whole prefix to be free of other slash/comment/template
	// syntax; this intentionally recognizes less than a JavaScript parser.
	if strings.ContainsAny(before, "/`\\") || strings.Contains(before, "<!--") || strings.Contains(before, "-->") {
		return false
	}

	quote := rune(0)
	for _, r := range before {
		if quote == 0 && (r == '\'' || r == '"') {
			quote = r
		} else if r == quote {
			quote = 0
		}
	}

	if quote != 0 {
		return false
	}

	if before == "" {
		return start == 0
	}

	last, _ := utf8.DecodeLastRuneInString(before)
	if strings.ContainsRune("=([{,:;?&|*%^~", last) {
		return true
	}

	for _, word := range []string{"return", "throw", "case"} {
		if before0, ok := strings.CutSuffix(before, word); ok {
			left := before0
			if left == "" {
				return true
			}

			r, _ := utf8.DecodeLastRuneInString(left)

			return !identifierContinuation(r) && r != '.' && r != '#'
		}
	}

	return false
}
