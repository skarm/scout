// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Bounded reflective module dictionary/string handling adapted from SkillSpector.

package analyzer

import (
	"strings"

	"github.com/skarm/scout/frontend"
)

func (w *pyWalker) moduleDictionary(n *frontend.Node, s *pyState) string {
	name := w.name(n, s, 1)
	for _, base := range []string{"os", valueBuiltins} {
		if name == base+".__dict__" {
			return base
		}
	}

	return ""
}

func pyDangerousAttribute(key string) bool {
	switch key {
	case valueExec, valueEval, valueSystem, valuePopen, valueImport:
		return true
	}

	return false
}

func pyDictionaryRead(name string) bool {
	return name == "get" || name == "pop" || name == "setdefault"
}

func pyReflectiveString(n *frontend.Node, depth int) (string, bool) {
	if n == nil || depth > 16 {
		return "", false
	}

	if v, ok := nodeLiteral(n); ok {
		return v, true
	}

	if n.Type != valueCall || len(n.List(valueArgs)) != 1 {
		return "", false
	}

	fn := n.Child("func")
	if fn == nil || fn.Type != valueAttribute || fn.String("attr") != "join" {
		return "", false
	}

	separator, ok := nodeLiteral(fn.Child("value"))
	if !ok || len(separator) > 10 {
		return "", false
	}

	arg := n.List(valueArgs)[0]
	if arg.Type != valueList && arg.Type != valueTuple {
		return "", false
	}

	nodes := arg.List("elts")
	if len(nodes) > 32 {
		return "", false
	}

	parts := make([]string, 0, len(nodes))
	size := 0

	for _, node := range nodes {
		p, ok := pyReflectiveString(node, depth+1)
		if !ok {
			return "", false
		}

		size += len(p)
		if len(parts) > 0 {
			size += len(separator)
		}

		if size > 10 {
			return "", false
		}

		parts = append(parts, p)
	}

	return strings.Join(parts, separator), true
}
