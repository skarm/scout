// Package analyzer implements non-executing literal and selected Go/Shell AST checks.
// The checks do not establish malicious intent or full semantic coverage.
package analyzer

import (
	"context"
	"path"
	"regexp"
	"strings"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/filetype"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/promptguard"
	"github.com/skarm/scout/internal/source"
)

// Match refers to original file bytes. Bounds are half-open. No source text is
// returned, preventing accidental credential disclosure through reports.
type Match struct {
	Start, End int
	Trace      []Trace
	Related    []model.SourceRef
	// A trusted analyzer may lower severity from its descriptor's maximum.
	Severity           model.Severity
	InactiveForSurface bool
	// Scanner-owned context labels, validated by the report boundary.
	ContextSignals []string
}
type Trace struct {
	Role       string
	Start, End int
}
type Result struct {
	// Valid matches remain usable even when Find also returns an error.
	Matches   []Match
	Truncated bool
}

// Analyzer implementations are trusted scanner code, NOT sandboxed plugins.
// They must be immutable, concurrency-safe and cooperate with cancellation.
type Analyzer interface {
	Rule() model.Rule
	AppliesTo(artifact.File) bool
	Find(context.Context, artifact.File, int) (Result, error)
}

// DocumentAnalyzer reuses the single preparation pass. Only trusted, read-only
// analyzers receive parsed ASTs; this is not a plugin security boundary.
type DocumentAnalyzer interface {
	Analyzer
	AppliesToDocument(document.File) bool
	FindDocument(context.Context, document.File, int) (Result, error)
}

type literal struct {
	rule       model.Rule
	expression *regexp.Regexp
}

type opaque struct{}

func newLiteral(id, title, expression string, severity model.Severity, category, limitation string) Analyzer {
	return literal{
		rule: model.Rule{
			ID: id, Version: "2", Title: title, Description: title,
			Severity: severity, Category: category, Method: "literal-heuristic", Limitation: limitation,
		},
		expression: regexp.MustCompile(expression),
	}
}

// Builtins returns a new registry. Fences, tests, LICENSE and hidden directories
// do not disable rules. Findings describe matched text, not proven intent.
func Builtins() []Analyzer {
	rules := append([]Analyzer{
		newLiteral("PI001", "Instruction-hierarchy override phrase", `(?i)\b(?:ignore|disregard|override)[\t ]+(?:all[\t ]+)?(?:previous|prior|system)[\t ]+(?:instructions?|prompts?|rules?)\b|(?i:игнорируй(?:те)?|проигнорируй(?:те)?)[\t ]+(?:все[\t ]+)?(?:предыдущие|системные)[\t ]+инструкции`, model.Medium, "prompt-injection", "Literal English/Russian phrases only; negation, quotation and intent require review. No automatic suppression in examples."),
		newLiteral("EX001", "Download piped to a shell", `(?im)\b(?:curl|wget)\b[^\r\n|]+\|[\t ]*(?:(?:sudo|env)[\t ]+)?(?:ba|da|z|k)?sh\b`, model.High, "remote-execution", "Single-line literal pipeline only; aliases, constructed commands and shell grammar are not analyzed. A match may be an example."),
		newLiteral("SE001", "Private-key PEM marker", `-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----`, model.High, "credential-material", "Marker only; not proof of a valid or live key. Values and source excerpts are never included in reports."),
		newLiteral("FS001", "Sensitive credential-path reference", `(?:~|\$HOME|\$\{HOME\})/\.ssh/(?:id_rsa|id_ed25519)\b|/etc/shadow\b|(?:~|\$HOME|\$\{HOME\})/\.aws/credentials\b`, model.Medium, valueCredentialAccess, "Literal path reference only, not a confirmed read or data-flow. Constructed paths require future AST analysis."),
		opaque{},
		moduleCheck{id: valueSC002},
		moduleCheck{id: valueSC003},
		goCheck{kind: goShell},
		goCheck{kind: goSensitiveRead},
		goCheck{kind: goDirectHTTP},
		goFlow{},
		shellCheck{kind: valueSH001},
		shellCheck{kind: "SH002"},
		shellCheck{kind: "SH003"},
		shellCheck{kind: "SH004"},
	}, agentRules()...)
	rules = append(rules, instructionRules()...)

	return append(rules, artifactIntegrityRules()...)
}

func IsOpaqueExecutable(f artifact.File) bool {
	return filetype.Inspect(f.Metadata().Path, f.Content(), f.Metadata().Executable).Executable
}

// Surface is a non-authoritative display hint, never a trust or suppression
// decision. A malicious author can name a file tests/payload or LICENSE.
func Surface(name string) string {
	if strings.EqualFold(path.Base(name), "SKILL.md") || strings.EqualFold(path.Base(name), "AGENTS.md") || strings.EqualFold(path.Base(name), "CLAUDE.md") {
		return valueInstructions
	}

	for part := range strings.SplitSeq(name, "/") {
		switch strings.ToLower(part) {
		case "tests", "test", "testdata", "fixtures", "evals":
			return "tests"
		}
	}

	if strings.HasPrefix(strings.ToUpper(path.Base(name)), "LICENSE") {
		return "license"
	}

	switch strings.ToLower(path.Ext(name)) {
	case ".sh", ".bash", ".py", ".go", ".js", ".ts", ".jsx", ".tsx", ".ps1", ".rb", ".pl", ".bat", ".cmd":
		return "code"
	case ".json", ".yaml", ".yml", ".toml", ".ini":
		return valueConfig
	case ".md", ".txt", ".rst":
		return "docs"
	}

	if strings.HasPrefix(strings.ToUpper(path.Base(name)), "LICENSE") {
		return "license"
	}

	return "other"
}

// NeedsStructuralAnalysis prevents literal-only inspection of code/config from
// being presented as complete executable/configuration analysis.
func NeedsStructuralAnalysis(f artifact.File) bool {
	return filetype.Inspect(f.Metadata().Path, f.Content(), f.Metadata().Executable).Structured
}

func (a literal) Rule() model.Rule { return a.rule }

// Scan every captured byte stream, including binary files. A NUL byte, invalid
// UTF-8, or image suffix must not disable basic literal checks. This does not
// decode encodings or compressed/embedded objects.
func (a literal) AppliesTo(f artifact.File) bool { return true }

func (a literal) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	if err := ctx.Err(); err != nil {
		return Result{}, err
	}
	// RE2 matching is bounded by the captured-file and finding budgets. Match
	// against ORIGINAL bytes; case folding/Unicode must not shift evidence.
	matches := a.expression.FindAllStringIndex(f.Content(), budget+1)

	if err := ctx.Err(); err != nil {
		return Result{}, err
	}

	truncated := len(matches) > budget
	if truncated {
		matches = matches[:budget]
	}

	result := Result{Matches: make([]Match, 0, len(matches)), Truncated: truncated}
	for _, m := range matches {
		if (a.rule.ID == "PL001") && (directlyProhibited(f.Content(), m[0], m[1]) || promptguard.Prohibited(f.Content(), m[0], m[1])) {
			continue
		}

		result.Matches = append(result.Matches, Match{Start: m[0], End: m[1]})
	}

	return result, nil
}

func (a literal) AppliesToDocument(document.File) bool { return true }
func (a literal) FindDocument(ctx context.Context, d document.File, budget int) (Result, error) {
	out, err := a.Find(ctx, d.Artifact(), budget)
	if err != nil || out.Truncated {
		return out, err
	}

	seen := map[source.Span]bool{}
	for _, m := range out.Matches {
		seen[source.Span{Start: m.Start, End: m.End}] = true
	}

	for _, v := range d.SecurityViews() {
		if ctx.Err() != nil {
			return out, ctx.Err()
		}

		matches := a.expression.FindAllStringIndex(v.Text(), budget+1)
		for _, loc := range matches {
			if a.rule.ID == "PL001" && (directlyProhibited(v.Text(), loc[0], loc[1]) || promptguard.Prohibited(v.Text(), loc[0], loc[1])) {
				continue
			}

			span, e := v.Original(source.Span{Start: loc[0], End: loc[1]})
			if e != nil {
				return out, e
			}

			if seen[span] {
				continue
			}

			if len(out.Matches) >= budget {
				out.Truncated = true
				return out, nil
			}

			seen[span] = true
			out.Matches = append(out.Matches, Match{Start: span.Start, End: span.End})
		}
	}

	return out, nil
}

func (opaque) Rule() model.Rule {
	return model.Rule{ID: "BI001", Version: "2", Title: "Opaque executable payload requires dedicated analysis", Description: "Compiled, executable or bytecode payload is present; this profile cannot inspect its behavior.", Severity: model.High, Category: "unverified-executable", Method: "file-classification", Limitation: "A suffix/signature is a candidate, not proof of type or maliciousness; the default policy refuses unverified executable payloads."}
}
func (opaque) AppliesTo(f artifact.File) bool { return IsOpaqueExecutable(f) }
func (opaque) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	if err := ctx.Err(); err != nil {
		return Result{}, err
	}

	if budget < 1 {
		return Result{Truncated: true}, nil
	}

	return Result{Matches: []Match{{Start: 0, End: len(f.Content())}}}, nil
}
