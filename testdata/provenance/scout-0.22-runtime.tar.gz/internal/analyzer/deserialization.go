// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Modified Go implementation of SkillSpector DS1-DS4. Fenced units retain
// original source spans; language hints are candidates, never trust boundaries.

package analyzer

import (
	"context"
	"regexp"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/source"
)

type deserialization struct {
	id, title, language string
	patterns            []*regexp.Regexp
}

func DeserializationRules() []Analyzer {
	makeRule := func(id, title, language string, expressions ...string) Analyzer {
		a := deserialization{id: id, title: title, language: language}
		for _, e := range expressions {
			a.patterns = append(a.patterns, regexp.MustCompile("(?i)"+e))
		}

		return a
	}

	return []Analyzer{
		makeRule("DS1", "PHP object deserialization", "php", `\bunserialize\s*\(`),
		makeRule("DS2", "Ruby Marshal deserialization", "ruby", `\bMarshal\s*\.\s*(?:load|restore)\b`),
		makeRule("DS3", "Unsafe Ruby YAML/Oj deserialization", "ruby", `\b(?:YAML|Psych|Oj)\s*\.\s*load\s*\(`),
		makeRule("DS4", "Unsafe JavaScript deserialization", languageJavaScript, `require\(\s*['"](?:node-serialize|serialize-to-js)['"]\s*\)`, `\bfuncster\b`, `\.unserialize\s*\(`),
	}
}

func (a deserialization) Rule() model.Rule {
	severity := model.High
	if a.id == "DS3" {
		severity = model.Medium
	}

	return model.Rule{ID: "NV-" + a.id, Version: "1", Title: a.title, Description: a.title, Severity: severity, Category: "insecure-deserialization", Method: "language-gated-pattern", Limitation: "Adapted SkillSpector DS1-DS4 signatures on candidate language units; not proof of untrusted input, exploitability or runtime execution. Quoted/commented code can match. No general PHP/Ruby/JS data flow."}
}

func (deserialization) AppliesTo(f artifact.File) bool       { return f.Metadata().Kind == formatText }
func (deserialization) AppliesToDocument(document.File) bool { return true }
func (a deserialization) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	return a.FindDocument(ctx, document.Prepare(ctx, f), budget)
}

func (a deserialization) FindDocument(ctx context.Context, d document.File, budget int) (Result, error) {
	out := Result{}
	seen := map[source.Span]bool{}

	for _, u := range d.Units() {
		if u.Language != a.language && !(a.language == languageJavaScript && u.Language == valueTypescript) {
			continue
		}

		for _, p := range a.patterns {
			if ctx.Err() != nil {
				return out, ctx.Err()
			}

			for _, loc := range p.FindAllStringIndex(u.View.Text(), budget+1) {
				at, e := u.View.Original(source.Span{Start: loc[0], End: loc[1]})
				if e != nil {
					return out, e
				}

				if seen[at] {
					continue
				}

				seen[at] = true

				if len(out.Matches) >= budget {
					out.Truncated = true
					return out, nil
				}

				out.Matches = append(out.Matches, Match{Start: at.Start, End: at.End})
			}
		}
	}

	return out, ctx.Err()
}
