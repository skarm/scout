// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Adapted detector concepts from SkillSpector mcp_tool_poisoning and
// mcp_least_privilege. Modified bounded parser/evidence implementation.

package analyzer

import (
	"context"
	"encoding/base64"
	"errors"
	"regexp"
	"slices"
	"strings"
	"unicode"
	"unicode/utf8"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/dependencies"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/source"
)

var (
	hiddenMetadata  = regexp.MustCompile(`(?is)<\\?!-{2}.*?-{2}>|\[//\]:\s*#\s*\([^\r\n]*\)|data:text/[^;,\s]{1,80};base64,`)
	base64Metadata  = regexp.MustCompile(`[A-Za-z0-9+/]{50,}={0,2}`)
	poisonParameter = regexp.MustCompile(`(?i)\b(?:ignore|override)\b.{0,80}\b(?:instructions?|system|rules?)\b|\bsystem\s*:|\b(?:send|upload|transmit)\b.{0,80}\b(?:credentials?|token|secret|conversation)\b|\b(?:curl|wget|eval|exec)\s*\(?`)
)

//nolint:gochecknoglobals // Immutable package-name dictionaries shared by concurrent scans.
var (
	popularPython    = strings.Fields("requests numpy pandas flask django pytest sqlalchemy pillow cryptography boto3 pyyaml beautifulsoup4 scipy matplotlib setuptools urllib3 certifi click fastapi pydantic aiohttp httpx rich typer openai anthropic langchain transformers torch tensorflow")
	popularNPM       = strings.Fields("express react lodash axios chalk commander debug dotenv moment typescript webpack eslint prettier next vite zod uuid ws yargs minimist glob semver async underscore bluebird mongoose mongodb redis socket.io nodemon jest mocha chai")
	historicalPython = map[string]bool{"pycrypto": true, "nose": true, "distribute": true}
	historicalNPM    = map[string]bool{"request": true, "nomnom": true, "optimist": true, "npm-conf": true}
)

type pluginCheck struct{ id string }

type dependencySignal struct{ id string }

func PluginSecurityRules() []Analyzer {
	out := append([]Analyzer{
		pluginCheck{"NV-TP1"},
		pluginCheck{valueNVTP2},
		pluginCheck{valueNVTP3},
		permissionCheck{id: "NV-LP1"},
		permissionCheck{id: "NV-LP2"},
		permissionCheck{id: "NV-LP3"},
		permissionCheck{id: "NV-LP4"},
		uninspectedReference{},
		dependencySignal{"NV-SC5"},
		dependencySignal{"NV-SC6"},
		sourceRedirection{},
		triggerCheck{"NV-TR1M"},
		triggerCheck{"NV-TR2M"},
		triggerCheck{"NV-TR3M"},
	}, DeserializationRules()...)

	return append(out, RegistryRules()...)
}

func (a pluginCheck) Rule() model.Rule {
	title := "Suspicious hidden content in tool metadata"
	if a.id == valueNVTP2 {
		title = "Confusable or invisible tool identifier"
	}

	if a.id == valueNVTP3 {
		title = "Suspicious parameter description or default"
	}

	return model.Rule{ID: a.id, Version: "2", Title: title, Description: title, Severity: model.Medium, Category: "tool-poisoning", Method: "structured-metadata-heuristic", Limitation: "Adapted TP1-TP3. Parsed metadata only; hidden text, confusables and long descriptions are review signals, not proof of malice. Legitimate defaults can match. Unknown schemas/Unicode scripts remain unverified."}
}

func (a pluginCheck) AppliesTo(f artifact.File) bool { return f.Metadata().Kind == formatText }

func (a pluginCheck) AppliesToDocument(f document.File) bool {
	for _, u := range f.Units() {
		if _, ok := u.Tree.(parse.JSONTree); ok {
			return true
		}
	}

	return false
}

func (a pluginCheck) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	return a.FindDocument(ctx, document.Prepare(ctx, f), budget)
}

func (a pluginCheck) FindDocument(ctx context.Context, f document.File, budget int) (Result, error) {
	var out Result

	seen := map[source.Span]bool{}
	ops := 0

	for _, u := range f.Units() {
		t, ok := u.Tree.(parse.JSONTree)
		if !ok || t.Root == nil {
			continue
		}

		emit := pluginEmitter(u, &out, seen, budget)
		check := a.pluginTextCheck(emit)
		a.walkMetadata(ctx, t.Root, 0, &ops, &out, check, emit)
	}

	if ops >= 32768 {
		return out, errors.New("metadata operation limit")
	}

	return out, ctx.Err()
}

func pluginEmitter(u document.Unit, out *Result, seen map[source.Span]bool, budget int) func(*jsonconfig.Node) {
	return func(n *jsonconfig.Node) {
		if n == nil {
			return
		}

		p, e := u.View.Original(n.Span)
		if e != nil {
			return
		}

		if seen[p] {
			return
		}

		seen[p] = true

		if len(out.Matches) >= budget {
			out.Truncated = true
			return
		}

		out.Matches = append(out.Matches, Match{Start: p.Start, End: p.End})
	}
}

func (a pluginCheck) pluginTextCheck(emit func(*jsonconfig.Node)) func(*jsonconfig.Node, bool, bool) {
	return func(n *jsonconfig.Node, identifier, param bool) {
		s, ok := n.Text()
		if !ok {
			return
		}

		switch a.id {
		case "NV-TP1":
			if hiddenText(s) {
				emit(n)
			}
		case valueNVTP2:
			if identifier && confusingIdentifier(s) {
				emit(n)
			}
		case valueNVTP3:
			if param && (poisonParameter.MatchString(s) || len([]rune(s)) > 500) {
				emit(n)
			}
		}
	}
}

func (a pluginCheck) walkMetadata(ctx context.Context, n *jsonconfig.Node, depth int, ops *int, out *Result, check func(*jsonconfig.Node, bool, bool), emit func(*jsonconfig.Node)) {
	if n == nil || ctx.Err() != nil || out.Truncated || *ops >= 32768 {
		return
	}

	*ops++

	if depth > 32 {
		return
	}

	switch n.Kind {
	case kindObject:
		check(n.Get("name"), true, false)
		check(n.Get("description"), false, false)

		for _, v := range n.GetOrEmpty("triggers").Elements {
			check(v, true, false)
		}

		for _, v := range n.GetOrEmpty("parameters").Elements {
			check(v.Get("name"), true, true)
			check(v.Get("description"), false, true)
			check(v.Get("default"), false, true)
		}

		a.checkToolProperties(n, check, emit)

		for _, m := range n.Members {
			a.walkMetadata(ctx, m.Value, depth+1, ops, out, check, emit)
		}
	case kindArray:
		for _, v := range n.Elements {
			a.walkMetadata(ctx, v, depth+1, ops, out, check, emit)
		}
	}
}

func (a pluginCheck) checkToolProperties(n *jsonconfig.Node, check func(*jsonconfig.Node, bool, bool), emit func(*jsonconfig.Node)) {
	props := n.Get("inputSchema").Get("properties")
	if props == nil {
		props = n.Get("input_schema").Get("properties")
	}

	if props != nil {
		for _, m := range props.Members {
			key := &jsonconfig.Node{Kind: "string", String: m.Key, Span: m.KeySpan}
			check(key, true, false)
			check(m.Value.Get("description"), false, true)
			d := m.Value.Get("default")
			check(d, false, true)

			if a.id == valueNVTP3 {
				if s, ok := d.Text(); ok && strings.HasPrefix(strings.ToLower(s), "http://") {
					emit(d)
				}
			}
		}
	}
}

func (a dependencySignal) Rule() model.Rule {
	title := "Dependency name matches a historical maintenance concern list"
	limit := "Small historical list adapted from upstream; not a current maintainer-status database or proof of vulnerability."

	if a.id == "NV-SC6" {
		title = "Dependency name resembles a popular package"
		limit = "Selected popular-package lexicon and bounded edit distance. Similarity is not proof of typosquatting or compromise."
	}

	return model.Rule{ID: a.id, Version: "1", Title: title, Description: title, Severity: model.Medium, Category: "supply-chain", Method: "parsed-dependency-name-heuristic", Limitation: limit}
}

func (a dependencySignal) AppliesTo(f artifact.File) bool { return f.Metadata().Kind == formatText }

func (a dependencySignal) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	return a.FindDocument(ctx, document.Prepare(ctx, f), budget)
}

func (a dependencySignal) AppliesToDocument(f document.File) bool { return true }

func (a dependencySignal) FindDocument(ctx context.Context, f document.File, budget int) (Result, error) {
	inv := dependencies.Collect(ctx, []document.File{f})
	out := Result{}
	seen := map[source.Span]bool{}

	for _, d := range inv.Declarations {
		if ctx.Err() != nil {
			return out, ctx.Err()
		}

		match := false
		if a.id == "NV-SC5" {
			match = d.Ecosystem == valuePyPI && historicalPython[d.Module] || d.Ecosystem == valueNpm && historicalNPM[d.Module]
		} else {
			list := popularPython
			if d.Ecosystem == valueNpm {
				list = popularNPM
			} else if d.Ecosystem != valuePyPI {
				continue
			}

			known := slices.Contains(list, d.Module)

			if known {
				continue
			}

			for _, p := range list {
				n := editDistance(d.Module, p)
				if n > 0 && n <= 2 && n*3 <= min(len(d.Module), len(p)) {
					match = true
					break
				}
			}
		}

		at := source.Span{Start: d.Source.ByteStart, End: d.Source.ByteEnd}
		if match && !seen[at] {
			seen[at] = true

			if len(out.Matches) >= budget {
				out.Truncated = true
				break
			}

			out.Matches = append(out.Matches, Match{Start: at.Start, End: at.End})
		}
	}

	return out, nil
}

func invisibleMetadata(s string) bool {
	for _, r := range s {
		if r == 0x200b || r == 0x200c || r == 0x200d || r == 0xfeff || r >= 0x202a && r <= 0x202e || r >= 0x2066 && r <= 0x2069 {
			return true
		}
	}

	return false
}

func confusingIdentifier(s string) bool {
	if invisibleMetadata(s) {
		return true
	}

	latin, other := false, false

	for _, r := range s {
		if unicode.In(r, unicode.Latin) {
			latin = true
		}

		if unicode.In(r, unicode.Cyrillic, unicode.Greek) {
			other = true
		}
	}

	return latin && other // Natural-language non-Latin descriptions are not identifiers.
}

func hiddenText(s string) bool {
	if hiddenMetadata.MatchString(s) || invisibleMetadata(s) {
		return true
	}

	for _, candidate := range base64Metadata.FindAllString(s, 8) {
		b, e := base64.StdEncoding.DecodeString(candidate + strings.Repeat("=", (4-len(candidate)%4)%4))
		if e == nil && len(b) > 0 && utf8.Valid(b) {
			return true
		}
	}

	return false
}

func editDistance(a, b string) int {
	if len(a) > 64 || len(b) > 64 {
		return 65
	}

	prev := make([]int, len(b)+1)
	for i := range prev {
		prev[i] = i
	}

	for i := 1; i <= len(a); i++ {
		next := make([]int, len(b)+1)
		next[0] = i

		for j := 1; j <= len(b); j++ {
			c := 0
			if a[i-1] != b[j-1] {
				c = 1
			}

			next[j] = min(next[j-1]+1, prev[j]+1, prev[j-1]+c)
		}

		prev = next
	}

	return prev[len(b)]
}
