// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Adapted from static_patterns_supply_chain.py: _analyze_triggers and its
// constants. Uses decoded structured fields, bounded work and physical evidence.

package analyzer

import (
	"context"
	"regexp"
	"strings"
	"unicode/utf8"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/source"
)

var (

	//nolint:gochecknoglobals // Immutable lookup data shared by concurrent scans; initialized once to avoid rebuilding it per input.
	builtinTriggers = wordSet("help search find run test build deploy install create delete update list show get set open close start stop restart status log debug commit push pull merge branch checkout rebase diff blame stash tag release version lint format fix refactor review explain chat ask edit write read save load copy move")

	//nolint:gochecknoglobals // Immutable lookup data shared by concurrent scans; initialized once to avoid rebuilding it per input.
	broadTriggers = wordSet("the a an is it do go make thing stuff code file data text work good bad yes no ok please thanks hi hello hey")

	//nolint:gochecknoglobals // Immutable lookup data shared by concurrent scans; initialized once to avoid rebuilding it per input.
	baitingTriggers = []*regexp.Regexp{
		regexp.MustCompile(`^(?:anything|everything|whatever|always|any\s+(?:question|request|task|input))$`),
		regexp.MustCompile(`^(?:when(?:ever)?|if|every\s+time)\s+(?:the\s+)?user\s+(?:says?|asks?|types?|sends?)\s+(?:anything|something|a\s+message)$`),
		regexp.MustCompile(`^(?:all|any|every)\s+(?:messages?|inputs?|requests?|queries?|questions?)$`),
	}
)

type triggerCheck struct{ id string }

func (a triggerCheck) Rule() model.Rule {
	titles := map[string]string{valueNVTR1M: "Overly broad declared trigger", valueNVTR2M: "Declared trigger shadows a common command", valueNVTR3M: "Generic baiting trigger declaration"}
	return model.Rule{ID: a.id, Version: "1", Title: titles[a.id], Description: titles[a.id], Severity: model.Medium, Category: valueTriggerAbuse, Method: "structured-trigger-analysis", Limitation: "Adapted upstream TR1-TR3 for root decoded triggers arrays. Declaration or a configuration example does not prove activation by any harness. Short legitimate triggers may match; aliases, nested schemas and unparsed metadata are not inferred."}
}
func (a triggerCheck) AppliesTo(f artifact.File) bool { return f.Metadata().Kind == formatText }
func (a triggerCheck) AppliesToDocument(f document.File) bool {
	for _, u := range f.Units() {
		if t, ok := u.Tree.(parse.JSONTree); ok && t.Root != nil && t.Root.Get("triggers") != nil {
			return true
		}
	}

	return false
}

func (a triggerCheck) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	return a.FindDocument(ctx, document.Prepare(ctx, f), budget)
}

func (a triggerCheck) FindDocument(ctx context.Context, f document.File, budget int) (Result, error) {
	out := Result{}
	seen := map[source.Span]bool{}
	ops := 0

	for _, u := range f.Units() {
		t, ok := u.Tree.(parse.JSONTree)
		if !ok || t.Root == nil {
			continue
		}

		list := t.Root.Get("triggers")
		if list == nil || list.Kind != kindArray {
			continue
		}

		for _, n := range list.Elements {
			if err := ctx.Err(); err != nil {
				return out, err
			}

			ops++
			if ops > 32768 {
				out.Truncated = true
				return out, nil
			}

			text, ok := n.Text()
			if !ok {
				continue
			}

			text = strings.ToLower(strings.TrimSpace(text))
			if !a.matchesTrigger(text) {
				continue
			}

			span, err := u.View.Original(n.Span)
			if err != nil || seen[span] {
				continue
			}

			seen[span] = true

			if len(out.Matches) >= budget {
				out.Truncated = true
				return out, nil
			}

			out.Matches = append(out.Matches, Match{Start: span.Start, End: span.End})
		}
	}

	return out, ctx.Err()
}

func (a triggerCheck) matchesTrigger(text string) bool {
	if text == "" {
		return false
	}

	words := strings.Fields(text)

	switch a.id {
	case valueNVTR1M:
		return len(words) == 1 && broadTriggers[text] || utf8.RuneCountInString(text) <= 2
	case valueNVTR2M:
		return builtinTriggers[text] || len(words) > 0 && len(words) <= 2 && builtinTriggers[words[0]]
	case valueNVTR3M:
		for _, p := range baitingTriggers {
			if p.MatchString(text) {
				return true
			}
		}
	}

	return false
}

func wordSet(s string) map[string]bool {
	out := map[string]bool{}
	for w := range strings.FieldsSeq(s) {
		out[w] = true
	}

	return out
}
