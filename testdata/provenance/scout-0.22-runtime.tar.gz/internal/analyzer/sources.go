// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// SC10 concept adapted to supported parsed sources. No source is contacted.

package analyzer

import (
	"context"
	"net/url"
	"path"
	"strings"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/source"
)

type sourceRedirection struct{}

func (sourceRedirection) Rule() model.Rule {
	return model.Rule{ID: "NV-SC10", Version: "4", Title: "Dependency source added, redirected or unresolved", Description: "A supported declaration references a nondefault package source, local path or source override.", Severity: model.Medium, Category: valueSupplyChain, Method: "structured-package-source", Limitation: "Selected npm/PyPI JSON/TOML/requirements/npmrc and parsed shell registry/env declarations, including cargo index environment keys; selected Yarn, pip INI, Cargo, Maven and NuGet configurations. Alternate sources may be legitimate. No repository is contacted, no package manager is run and credentials are not copied into reports."}
}
func (sourceRedirection) AppliesTo(artifact.File) bool { return true }
func (a sourceRedirection) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	return a.FindDocument(ctx, document.Prepare(ctx, f), budget)
}
func (sourceRedirection) AppliesToDocument(document.File) bool { return true }
func (sourceRedirection) FindDocument(ctx context.Context, f document.File, budget int) (Result, error) {
	out := Result{}
	seen := map[source.Span]bool{}
	emit := func(at source.Span) {
		if seen[at] {
			return
		}

		seen[at] = true

		if len(out.Matches) >= budget {
			out.Truncated = true
			return
		}

		out.Matches = append(out.Matches, Match{Start: at.Start, End: at.End})
	}
	shellSourceDeclarations(ctx, f, emit)

	name := strings.ToLower(path.Base(f.Artifact().Metadata().Path))
	if unescaped, e := url.PathUnescape(name); e == nil {
		name = strings.ToLower(path.Base(unescaped))
	}

	out.Truncated = directSourceConfig(ctx, name, f.Artifact().Content(), emit) || out.Truncated
	if err := sourceTextDeclarations(ctx, name, f.Artifact().Content(), emit); err != nil {
		return out, err
	}

	for _, u := range f.Units() {
		tree, ok := u.Tree.(parse.JSONTree)
		if !ok || tree.Root == nil {
			continue
		}

		mark := func(n *jsonconfig.Node) {
			if n != nil {
				if at, err := u.View.Original(n.Span); err == nil {
					emit(at)
				}
			}
		}
		inspectSourceTree(ctx, name, f.Artifact().Metadata().Path, tree.Root, mark)
	}

	return out, ctx.Err()
}

func sourceTextDeclarations(ctx context.Context, name, text string, emit func(source.Span)) error {
	if name == valueNpmrc || name == "requirements.txt" || strings.HasPrefix(name, "requirements-") {
		offset := 0

		for _, line := range strings.SplitAfter(text, "\n") {
			if ctx.Err() != nil {
				return ctx.Err()
			}

			trim := strings.TrimSpace(line)
			if !strings.HasPrefix(trim, "#") && !strings.HasPrefix(trim, ";") {
				if name == valueNpmrc {
					parts := strings.SplitN(trim, "=", 2)
					if len(parts) == 2 && (strings.TrimSpace(parts[0]) == valueRegistry || strings.HasSuffix(strings.TrimSpace(parts[0]), ":registry")) {
						if !defaultSource(strings.TrimSpace(parts[1]), valueNpm) {
							emit(source.Span{Start: offset, End: offset + len(line)})
						}
					}
				} else if strings.Contains(trim, "--index-url") || strings.Contains(trim, "--extra-index-url") || strings.Contains(trim, "--find-links") || strings.HasPrefix(trim, "-i ") || strings.HasPrefix(trim, "-f ") {
					emit(source.Span{Start: offset, End: offset + len(line)})
				}
			}

			offset += len(line)
		}
	}

	return nil
}

func inspectSourceTree(ctx context.Context, name, filePath string, root *jsonconfig.Node, mark func(*jsonconfig.Node)) {
	switch name {
	case ".yarnrc.yml", ".yarnrc.yaml":
		checkYarnSources(ctx, root, 0, mark)
	case valueConfigToml:
		if strings.Contains(strings.ToLower(filePath), ".cargo/") {
			checkCargoSources(root, mark)
		}
	case "package.json":
		checkPackageSources(root, mark)
	case "package-lock.json", "npm-shrinkwrap.json":
		checkResolvedSources(ctx, root, 0, mark)
	case "pyproject.toml":
		checkPyprojectSources(root, mark)
	case "pipfile", "pipfile.lock":
		checkPipfileSources(root, mark)
	case "uv.lock", "poetry.lock":
		checkPythonLockSources(root, mark)
	}
}

func checkYarnSources(ctx context.Context, n *jsonconfig.Node, depth int, mark func(*jsonconfig.Node)) {
	if n == nil || depth > 32 || ctx.Err() != nil {
		return
	}

	for _, m := range n.Members {
		if m.Key == "npmRegistryServer" {
			if v, ok := m.Value.Text(); !ok || !defaultSource(v, valueNpm) {
				mark(m.Value)
			}
		}

		checkYarnSources(ctx, m.Value, depth+1, mark)
	}
}

func checkCargoSources(root *jsonconfig.Node, mark func(*jsonconfig.Node)) {
	sources := root.Get(valueSource)
	if sources != nil {
		for _, m := range sources.Members {
			if n := m.Value.Get("replace-with"); n != nil {
				mark(n)
			}

			for _, key := range []string{valueRegistry, "git", "directory", "local-registry"} {
				if n := m.Value.Get(key); n != nil {
					if v, ok := n.Text(); key != valueRegistry || !ok || !defaultShellSource(v, "cargo") {
						mark(n)
					}
				}
			}
		}
	}

	registries := root.Get("registries")
	if registries != nil {
		for _, m := range registries.Members {
			if n := m.Value.Get("index"); n != nil {
				if v, ok := n.Text(); !ok || !defaultShellSource(v, "cargo") {
					mark(n)
				}
			}
		}
	}
}

func checkPackageSources(root *jsonconfig.Node, mark func(*jsonconfig.Node)) {
	for _, field := range []string{"dependencies", "devDependencies", "optionalDependencies", "peerDependencies", "overrides", "resolutions"} {
		n := root.Get(field)
		if n == nil {
			continue
		}

		for _, m := range n.Members {
			v, ok := m.Value.Text()
			if ok && (strings.HasPrefix(v, "npm:") || strings.HasPrefix(v, "file:") || strings.HasPrefix(v, "git") || strings.HasPrefix(v, schemeHTTP) || strings.HasPrefix(v, "link:")) {
				mark(m.Value)
			}
		}
	}
}

func checkResolvedSources(ctx context.Context, n *jsonconfig.Node, depth int, mark func(*jsonconfig.Node)) {
	if n == nil || depth > 32 || ctx.Err() != nil {
		return
	}

	if v, ok := n.Get("resolved").Text(); ok && !defaultSource(v, valueNpm) {
		mark(n.Get("resolved"))
	}

	for _, m := range n.Members {
		checkResolvedSources(ctx, m.Value, depth+1, mark)
	}

	for _, v := range n.Elements {
		checkResolvedSources(ctx, v, depth+1, mark)
	}
}

func checkPyprojectSources(root *jsonconfig.Node, mark func(*jsonconfig.Node)) {
	for _, n := range []*jsonconfig.Node{root.Get("tool").Get("poetry").Get(valueSource), root.Get("tool").Get("uv").Get("index")} {
		if n == nil {
			continue
		}

		items := n.Elements
		if n.Kind == kindObject {
			items = []*jsonconfig.Node{n}
		}

		for _, item := range items {
			url := item.Get("url")
			if value, ok := url.Text(); url != nil && (!ok || !defaultSource(value, valuePyPI)) {
				mark(url)
			}
		}
	}

	if n := root.Get("tool").Get("uv").Get("sources"); n != nil {
		mark(n)
	}
}

func checkPipfileSources(root *jsonconfig.Node, mark func(*jsonconfig.Node)) {
	n := root.Get(valueSource)
	if n == nil {
		n = root.Get("_meta").Get("sources")
	}

	if n != nil {
		for _, v := range n.Elements {
			if s, ok := v.Get("url").Text(); ok && !defaultSource(s, valuePyPI) {
				mark(v)
			}
		}
	}
}

func checkPythonLockSources(root *jsonconfig.Node, mark func(*jsonconfig.Node)) {
	n := root.Get("package")
	if n != nil {
		for _, p := range n.Elements {
			src := p.Get(valueSource)
			if src == nil {
				continue
			}

			v, ok := src.Get(valueRegistry).Text()
			if !ok {
				v, ok = src.Get("url").Text()
			}

			if !ok || !defaultSource(v, valuePyPI) {
				mark(src)
			}
		}
	}
}

func defaultSource(s, eco string) bool {
	u, e := url.Parse(s)
	if e != nil || u.Scheme != schemeHTTPS || u.User != nil || u.RawQuery != "" || u.Fragment != "" {
		return false
	}

	if eco == valueNpm {
		return u.Host == "registry.npmjs.org"
	}

	return u.Host == "pypi.org" || u.Host == "files.pythonhosted.org"
}
