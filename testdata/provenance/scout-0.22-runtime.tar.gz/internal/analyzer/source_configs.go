// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Selected additional SC10 direct configuration surfaces; never resolved online.

package analyzer

import (
	"context"
	"encoding/xml"
	"errors"
	"io"
	"strings"

	"github.com/skarm/scout/internal/source"
)

func directSourceConfig(ctx context.Context, name, text string, emit func(source.Span)) bool {
	switch name {
	case "pip.conf", "pip.ini", ".pypirc", valueYarnrc, valueNpmrc:
		return directLineSourceConfig(ctx, name, text, emit)
	case "settings.xml", "pom.xml", valueNugetConfig:
		return directXMLSourceConfig(ctx, name, text, emit)
	}

	return false
}

func directLineSourceConfig(ctx context.Context, name, text string, emit func(source.Span)) bool {
	offset := 0

	for _, line := range strings.SplitAfter(text, "\n") {
		if ctx.Err() != nil {
			return true
		}

		trim := strings.TrimSpace(line)
		if !strings.HasPrefix(trim, "#") && !strings.HasPrefix(trim, ";") {
			key, value, ok := strings.Cut(trim, "=")
			if name == valueYarnrc && !ok {
				parts := strings.Fields(trim)
				if len(parts) == 2 {
					key, value, ok = parts[0], parts[1], true
				}
			}

			if ok {
				key = strings.TrimSpace(key)
				value = strings.Trim(strings.TrimSpace(value), `"'`)

				kind := valuePyPI
				if name == valueYarnrc || name == valueNpmrc {
					kind = valueNpm
				}

				if (key == valueRegistry || key == "index-url" || key == "extra-index-url" || key == "find-links" || key == "repository") && !defaultSource(value, kind) {
					emit(source.Span{Start: offset, End: offset + len(line)})
				}
			}
		}

		offset += len(line)
	}

	return false
}

func directXMLSourceConfig(ctx context.Context, name, text string, emit func(source.Span)) bool {
	dec := xml.NewDecoder(strings.NewReader(text))
	stack := []string{}
	operations := 0

	for {
		if ctx.Err() != nil {
			return true
		}

		before := int(dec.InputOffset())

		tok, e := dec.Token()
		if errors.Is(e, io.EOF) {
			break
		}

		if e != nil {
			return true
		}

		operations++
		if operations > 8192 {
			return true
		}

		switch node := tok.(type) {
		case xml.StartElement:
			stack = append(stack, node.Name.Local)
			if len(stack) > 64 {
				return true
			}

			inspectNugetSource(name, node, stack, source.Span{Start: before, End: int(dec.InputOffset())}, emit)
		case xml.EndElement:
			if len(stack) > 0 {
				stack = stack[:len(stack)-1]
			}
		case xml.CharData:
			inspectMavenSource(name, node, stack, source.Span{Start: before, End: int(dec.InputOffset())}, emit)
		}
	}

	return false
}

func inspectNugetSource(name string, node xml.StartElement, stack []string, span source.Span, emit func(source.Span)) {
	if name == valueNugetConfig && node.Name.Local == "add" && len(stack) > 1 && stack[len(stack)-2] == "packageSources" {
		for _, a := range node.Attr {
			if a.Name.Local == "value" && strings.TrimSpace(a.Value) != "https://api.nuget.org/v3/index.json" {
				emit(span)
			}
		}
	}
}

func inspectMavenSource(name string, node xml.CharData, stack []string, span source.Span, emit func(source.Span)) {
	if name != valueNugetConfig && len(stack) > 1 && stack[len(stack)-1] == "url" {
		parent := stack[len(stack)-2]
		if parent == "mirror" || parent == "repository" || parent == "pluginRepository" {
			v := strings.TrimSpace(string(node))
			if v != "" && v != "https://repo.maven.apache.org/maven2" && v != "https://repo1.maven.org/maven2" {
				emit(span)
			}
		}
	}
}
