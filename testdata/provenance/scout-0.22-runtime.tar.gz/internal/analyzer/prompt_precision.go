package analyzer

import (
	"regexp"
	"strings"
	"unicode"
	"unicode/utf8"

	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/language"
)

var (
	formatRulesHeading      = regexp.MustCompile(`(?i)^[\t ]{0,3}#{1,6}[\t ]+(?:(?:json|html|markdown|csv|xml|yaml|report)[\t ]+)?output[\t ]+(?:rules|instructions)(?:[\t ]+\((?:both[\t ]+modes|offline[- ]safe|formatting|report)\))?[\t ]*#*[\t ]*$`)
	rawPromptTarget         = regexp.MustCompile(`(?i)\b(?:prompts|prompt|instructions|instruction|rules|rule|guidelines|guideline|directives|directive)\b`)
	privilegedPromptRequest = regexp.MustCompile(`(?i)\b(?:your\s+(?:full\s+)?|(?:system|developer|internal|secret|hidden)\s+)`)
	headingFormat           = regexp.MustCompile(`(?i)\b(?:json|html|markdown|csv|xml|yaml|report)\s+output|\(both\s+modes\)`)
	forwardProcedure        = regexp.MustCompile(`(?i)follow\s+the\s+steps\s+below|do\s+(?:the\s+)?following`)
	headingDirective        = regexp.MustCompile(`(?i)\b(?:commands?|verbatim|execute|recite|reproduce)\b|\b(?:repeat|reveal|disclose|print|show)\b[^\r\n]{0,80}\b(?:them|rules|instructions|prompt)\b|\brules\s+means\b|\b(?:use|follow|repeat)[^\r\n]{0,80}\b(?:instructions|rules|commands)[^\r\n]{0,40}\b(?:without\s+changes|exactly)\b`)
)

func promptPrecision(d document.File, m Match) bool {
	text := d.Artifact().Content()
	start := strings.LastIndexByte(text[:m.Start], '\n') + 1

	end := len(text)
	if at := strings.IndexByte(text[m.End:], '\n'); at >= 0 {
		end = m.End + at
	}

	markdown := false
	for _, hint := range d.Classification().Languages {
		markdown = markdown || hint.Language == formatMarkdown
	}

	if markdown && !strings.HasPrefix(text[start:end], "\t") && formatRulesHeading.MatchString(text[start:end]) && headingFormat.MatchString(text[start:end]) && len(text) <= 16384 {
		context := strings.NewReplacer("*", "", "_", "", "`", "", "\u200b", "", "<br>", " ").Replace(text)
		// An explicit command/referent prevents this narrow formatting exemption.
		if !headingDirective.MatchString(context) && !forwardProcedure.MatchString(text[:start]) && !strings.ContainsAny(context, "<>") {
			return true
		}
	}

	code := false

	for _, hint := range d.Classification().Languages {
		if language.Structured(hint.Language) && hint.Language != formatJSON && hint.Language != "yaml" && hint.Language != "toml" {
			code = true
		}
	}

	if !code {
		return false
	}

	if privilegedPromptRequest.MatchString(text[m.Start:m.End]) {
		return false
	}
	// Some Unicode identifier suffixes normalize to a space plus a letter.
	// Inspect the physical token as well as the mapped match boundary.
	for _, at := range rawPromptTarget.FindAllStringIndex(text[m.Start:m.End], -1) {
		if end := m.Start + at[1]; end < len(text) {
			r, _ := utf8.DecodeRuneInString(text[end:])
			if identifierContinuation(r) {
				return true
			}
		}
	}

	if m.End < len(text) {
		r, _ := utf8.DecodeRuneInString(text[m.End:])
		if identifierContinuation(r) {
			return true
		}
	}

	if m.End > m.Start {
		r, _ := utf8.DecodeLastRuneInString(text[m.Start:m.End])
		if unicode.IsMark(r) || unicode.Is(unicode.Cf, r) {
			return true
		}
	}

	return false
}

func identifierContinuation(r rune) bool {
	return unicode.IsLetter(r) || unicode.IsDigit(r) || unicode.IsMark(r) || unicode.Is(unicode.Pc, r) || unicode.Is(unicode.Cf, r) || r == '$'
}
