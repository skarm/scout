// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
//
// Modified implementation: published SkillSpector AST/TT categories and supported
// call sets are reimplemented in Go over a real, optional Python AST frontend.
// Scope/overwrites and source spans differ; this is not exact upstream parity.

package analyzer

import (
	"context"
	"encoding/json"
	"errors"
	"maps"
	"strings"

	"github.com/skarm/scout/frontend"
	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/source"
)

type pythonCheck struct{ id string }

type pyOrigin struct {
	kind       string
	start, end int
	steps      []source.Span
}
type pyValue struct {
	literal  string
	known    bool
	truth    uint8
	name     string
	origins  []pyOrigin
	function *pyFunction
	class    *pyClass
	instance *pyInstance
	bound    *pyValue
	elements []pyValue // bounded literal sequence, captured before assignment
	mapping  *pyMapping
	super    *pySuper
}
type (
	pyMapping struct{ entries map[string]pyValue }
	pyState   struct {
		names           map[string]pyValue
		blockedBuiltins bool
		parent, global  *pyState
		locals          map[string]bool
		declarations    map[string]string
		forks           map[*pyState]*pyState
	}
)

type pyWalker struct {
	ctx         context.Context
	rule        string
	budget, ops int
	unit        document.Unit
	out         *Result
	err         error
	seen        map[[2]int]bool
	frames      []*pyFrame
	active      map[*pyFunction]bool
	calls       int
	limited     bool
}

func newPyState() *pyState {
	s := &pyState{names: map[string]pyValue{}, locals: map[string]bool{}, declarations: map[string]string{}}
	s.global = s

	return s
}

func PythonRules() []Analyzer {
	pythonRuleIDs := [...]string{valueAST1, valueAST2, valueAST3, valueAST4, valueAST5, valueAST6, valueAST7, valueAST8, valueAST9, valueAST10, valueTT1, valueTT2, valueTT3, valueTT4, valueTT5, valueTT6}

	out := make([]Analyzer, 0, len(pythonRuleIDs))
	for _, id := range pythonRuleIDs {
		out = append(out, pythonCheck{id})
	}

	return out
}

func (a pythonCheck) Rule() model.Rule {
	title := map[string]string{valueAST1: "Python exec call", valueAST2: "Python eval call", valueAST3: "Python dynamic import", valueAST4: "Python subprocess call", valueAST5: "Python OS execution call", valueAST6: "Python compile call", valueAST7: "Python dynamic attribute lookup", valueAST8: "Python nested decoding/import/execution chain", valueAST9: "Python reflective execution handle", valueTT1: "Python direct source-to-sink flow", valueTT2: "Python source-to-sink flow through variables", valueTT3: "Python environment data reaches network output", valueTT4: "Python file data reaches network output", valueTT5: "Python external input reaches code execution"}[a.id]
	if a.id == valueAST10 {
		title = "Python unsafe deserialization"
	}

	if a.id == valueTT6 {
		title = "Python external or file input reaches unsafe deserialization"
	}

	sev := model.Medium

	switch a.id {
	case valueAST1, valueAST2, valueAST5, valueAST8, valueAST9, valueTT1, valueTT3, valueTT4, valueTT5, valueTT6:
		sev = model.High
	case valueAST7:
		sev = model.Low
	}

	return model.Rule{ID: "PY-" + a.id, Version: "8", Title: title, Description: title, Severity: sev, Category: "python-execution-and-dataflow", Method: "python-ast-go-analysis", Limitation: "Embedded Tree-sitter Python CST projected into bounded Go IR; not CPython AST. Selected aliases, assignments, branches, same-file functions, methods, instance fields and C3 inheritance are modeled. No execution, cross-file/general type inference or proof of intent. Recursive/dynamic calls and complex control flow remain incomplete. Environment values need not be secrets; annotation evaluation timing is unknown."}
}
func (pythonCheck) AppliesTo(f artifact.File) bool { return f.Metadata().Kind == formatText }
func (pythonCheck) AppliesToDocument(f document.File) bool {
	for _, u := range f.Units() {
		if _, ok := u.Tree.(parse.PythonTree); ok {
			return true
		}
	}

	return false
}

func (a pythonCheck) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	if e := ctx.Err(); e != nil {
		return Result{}, e
	}

	return a.FindDocument(ctx, document.Prepare(ctx, f), budget)
}

func (a pythonCheck) FindDocument(ctx context.Context, f document.File, budget int) (Result, error) {
	var out Result

	limited := false

	for _, u := range f.Units() {
		tree, ok := u.Tree.(parse.PythonTree)
		if !ok || tree.Root == nil {
			continue
		}

		w := pyWalker{ctx: ctx, rule: a.id, budget: budget, unit: u, out: &out, seen: map[[2]int]bool{}}
		w.block(tree.Root.List("body"), newPyState(), 0)

		limited = limited || w.limited
		if w.err != nil {
			return out, w.err
		}

		if out.Truncated {
			return out, nil
		}
	}

	out.Truncated = out.Truncated || limited

	return out, ctx.Err()
}

func (s *pyState) clone() *pyState {
	r := newPyState()
	r.blockedBuiltins = s.blockedBuiltins

	r.parent, r.global, r.forks = s.parent, s.global, s.forks
	maps.Copy(r.locals, s.locals)

	maps.Copy(r.declarations, s.declarations)

	maps.Copy(r.names, s.names)

	return r
}

func (s *pyState) scope() *pyState {
	r := newPyState()
	r.parent, r.global, r.forks = s, s.global, s.forks
	r.blockedBuiltins = s.blockedBuiltins

	return r
}

func (s *pyState) owner(name string) *pyState {
	if s.declarations[name] == "global" {
		return s.global
	}

	if s.declarations[name] == "nonlocal" {
		for p := s.parent; p != nil && p.parent != nil; p = p.parent {
			if p.locals[name] && p.declarations[name] == "" {
				return p
			}
		}
	}

	if s.parent != nil && !s.locals[name] {
		return s.parent.owner(name)
	}

	return s
}

func (s *pyState) lookup(name string) (pyValue, bool) {
	v, ok := s.owner(name).names[name]
	return v, ok
}

func (s *pyState) set(name string, v pyValue) {
	if s.declarations[name] == "" {
		s.locals[name] = true
	}

	s.owner(name).names[name] = v
}

func (s *pyState) resolve(name string) string {
	if v, ok := s.lookup(name); ok {
		return v.name
	}

	if s.blockedBuiltins || s.owner(name).blockedBuiltins {
		return ""
	}

	switch name {
	case valueExec, valueEval, valueCompile, valueImport, valueGetattr, valueVars, valueInput, "open", "str", valueBytes, "bytearray", "repr", "dict", "list", "tuple", valueSet, "len", "print", valueStaticmethod, valueClassmethod, kindObject, "super":
		return name
	}

	return ""
}

func (w *pyWalker) charge(depth int) bool {
	w.ops++
	if w.ctx.Err() != nil {
		w.err = w.ctx.Err()
		return false
	}

	if w.ops > 100000 || depth > 64 {
		w.out.Truncated = true
		return false
	}

	return w.err == nil && !w.out.Truncated
}

func (w *pyWalker) emit(id string, n *frontend.Node, o *pyOrigin) {
	if id != w.rule || n == nil || n.Start >= n.End {
		return
	}

	k := [2]int{n.Start, n.End}
	if w.seen[k] {
		return
	}

	if len(w.out.Matches) >= w.budget {
		w.out.Truncated = true
		return
	}

	main, e := w.unit.View.Original(source.Span{Start: n.Start, End: n.End})
	if e != nil {
		w.err = errors.New("python source mapping failed")
		return
	}

	m := Match{Start: main.Start, End: main.End}

	if o != nil {
		add := func(role string, s source.Span) {
			v, e := w.unit.View.Original(s)
			if e != nil {
				w.err = errors.New("python trace mapping failed")
				return
			}

			if v.Start < v.End {
				m.Trace = append(m.Trace, Trace{Role: role, Start: v.Start, End: v.End})
			}
		}
		add(valueSource, source.Span{Start: o.start, End: o.end})

		for _, s := range o.steps {
			add("transform", s)
		}

		add(valueSink, source.Span{Start: n.Start, End: n.End})
	}

	if w.err == nil {
		w.seen[k] = true
		w.out.Matches = append(w.out.Matches, m)
	}
}

func (w *pyWalker) flow(n *frontend.Node, v pyValue, sink string) {
	for i := range v.origins {
		o := v.origins[i]

		id := valueTT1
		if len(o.steps) > 0 {
			id = valueTT2
		}

		if sink == valueNetwork && o.kind == "environment" {
			id = valueTT3
		}

		if sink == valueNetwork && o.kind == kindFile {
			id = valueTT4
		}

		if sink == valueExec && (o.kind == valueNetwork || o.kind == valueInput) {
			id = valueTT5
		}

		if sink == "deserialization" && (o.kind == valueNetwork || o.kind == valueInput || o.kind == kindFile) {
			id = valueTT6
		}

		w.emit(id, n, &o)
	}
}

func (w *pyWalker) name(n *frontend.Node, s *pyState, depth int) string {
	if n == nil || depth > 32 || !w.charge(depth) {
		return ""
	}

	switch n.Type {
	case valueName:
		return s.resolve(n.String("id"))
	case valueAttribute:
		b := w.name(n.Child("value"), s, depth+1)
		if b != "" {
			return b + "." + n.String("attr")
		}
	case valueSubscript:
		if base := w.moduleDictionary(n.Child("value"), s); base != "" {
			if key, ok := pyReflectiveString(n.Child("slice"), 0); ok {
				return base + "." + key
			}
		}
	case valueCall:
		return w.callName(n, s, depth)
	}

	return ""
}

func (w *pyWalker) callName(n *frontend.Node, s *pyState, depth int) string {
	f := w.name(n.Child("func"), s, depth+1)

	args := n.List(valueArgs)
	if (f == valueImport || f == "importlib.import_module") && len(args) > 0 {
		v, ok := nodeLiteral(args[0])
		if ok && len(v) <= 256 {
			return v
		}
	}

	if f == "pathlib.Path" || f == "socket.socket" || f == "requests.Session" || f == "httpx.Client" || f == "httpx.AsyncClient" {
		return f
	}

	if f == "urllib.request.build_opener" || f == valueUrllibRequestOpenerDirector {
		return valueUrllibRequestOpenerDirector
	}

	if f == valueVars && len(args) == 1 {
		base := w.name(args[0], s, depth+1)
		if base == "os" || base == valueBuiltins {
			return base + ".__dict__"
		}
	}

	if fn := n.Child("func"); fn != nil && fn.Type == valueAttribute && pyDictionaryRead(fn.String("attr")) && len(args) > 0 {
		if base := w.moduleDictionary(fn.Child("value"), s); base != "" {
			if key, ok := pyReflectiveString(args[0], 0); ok {
				return base + "." + key
			}
		}
	}

	if f == valueGetattr && len(args) >= 2 {
		b := w.name(args[0], s, depth+1)

		v, ok := pyReflectiveString(args[1], 0)
		if b != "" && ok {
			return b + "." + v
		}
	}

	return ""
}

func (w *pyWalker) nestedSource(n *frontend.Node, s *pyState, depth int) bool {
	if n == nil || depth > 32 {
		return false
	}

	if n.Type == valueCall {
		name := canonPy(w.name(n.Child("func"), s, 0))
		if name == valueCompile || name == valueImport {
			return true
		}

		for _, prefix := range []string{"subprocess.", "os.", "base64.", "codecs.", "marshal.", "urllib.", "requests.", "httpx."} {
			if strings.HasPrefix(name, prefix) {
				return true
			}
		}
	}

	for _, child := range n.Children() {
		if w.nestedSource(child, s, depth+1) {
			return true
		}
	}

	return false
}

func (w *pyWalker) expr(n *frontend.Node, s *pyState, depth int) pyValue {
	if n == nil || !w.charge(depth) {
		return pyValue{}
	}

	switch n.Type {
	case "UnsupportedExpression", "UnsupportedStatement":
		// Retain independent visible calls, but infer no value through unknown
		// syntax and do not let speculative child effects change caller state.
		child := s.fork()
		for _, x := range n.Children() {
			w.expr(x, child, depth+1)
		}

		return pyValue{}
	case valueConstant:
		v, ok := nodeLiteral(n)
		return pyValue{literal: v, known: ok, truth: pyTruth(n, s, 0)}
	case valueName:
		if v, ok := s.lookup(n.String("id")); ok {
			return pyContents(v)
		}

		return pyValue{name: s.resolve(n.String("id"))}
	case valueTuple, valueList:
		return w.sequenceExpr(n, s, depth)
	case "Dict":
		return w.dictionaryExpr(n, s, depth)
	case "ListComp", "SetComp", "DictComp", "GeneratorExp":
		return w.comprehensionExpr(n, s, depth)
	case "BoolOp":
		return w.booleanExpr(n, s, depth)
	case "IfExp":
		return w.conditionalExpr(n, s, depth)
	case valueAttribute:
		return w.attributeExpr(n, s, depth)
	case valueSubscript:
		return w.subscriptExpr(n, s, depth)
	case valueCall:
		return w.callExpression(n, s, depth)
	case "NamedExpr":
		v := w.expr(n.Child("value"), s, depth+1)
		w.assign(n.Child("target"), v, s, n)

		return v
	case "Lambda":
		return w.lambdaExpr(n, s, depth)
	default:
		vs := []pyValue{}
		for _, child := range n.Children() {
			vs = append(vs, w.expr(child, s, depth+1))
		}

		v := transformed(joinPy(vs...), n)
		v.truth = pyTruth(n, s, 0)

		return v
	}
}

func (w *pyWalker) sequenceExpr(n *frontend.Node, s *pyState, depth int) pyValue {
	items := n.List("elts")
	values := make([]pyValue, 0, min(len(items), 64))

	complete := len(items) <= 64
	for _, item := range items {
		v := w.expr(item, s, depth+1)
		if len(values) < 64 {
			values = append(values, v)
		}

		complete = complete && item.Type != valueStarred
	}

	v := transformed(joinPy(values...), n)

	v.truth = pyTruth(n, s, 0)
	if complete {
		v.elements = values
	} else {
		w.limited = true
	}

	return v
}

func (w *pyWalker) dictionaryExpr(n *frontend.Node, s *pyState, depth int) pyValue {
	keys, values := n.List("keys"), n.List("values")
	entries := map[string]pyValue{}
	vs := []pyValue{}

	complete := len(keys) <= 64 && len(keys) == len(values)
	for i, key := range keys {
		if i >= len(values) {
			break
		}

		v := w.expr(values[i], s, depth+1)

		vs = append(vs, v)
		if key == nil && v.mapping != nil {
			maps.Copy(entries, v.mapping.entries)
		} else if k, ok := nodeLiteral(key); ok {
			entries[k] = v
		} else {
			complete = false

			w.expr(key, s, depth+1)
		}

		if len(entries) > 64 {
			complete = false
		}
	}

	v := transformed(joinPy(vs...), n)
	if complete {
		v.mapping = &pyMapping{entries: entries}
		v = pyContents(v)
	} else {
		w.limited = true
	}

	return v
}

func (w *pyWalker) comprehensionExpr(n *frontend.Node, s *pyState, depth int) pyValue {
	child := s.fork()
	for _, g := range n.List("generators") {
		// The first iterable is read before binding the comprehension target.
		iter := w.expr(g.Child("iter"), child, depth+1)
		w.assign(g.Child("target"), iter, child, g)

		for _, condition := range g.List("ifs") {
			if w.expr(condition, child, depth+1).truth == 1 {
				return pyValue{}
			}
		}
	}

	if n.Type == "DictComp" {
		return transformed(joinPy(w.expr(n.Child("key"), child, depth+1), w.expr(n.Child("value"), child, depth+1)), n)
	}

	return transformed(w.expr(n.Child("elt"), child, depth+1), n)
}

func (w *pyWalker) booleanExpr(n *frontend.Node, s *pyState, depth int) pyValue {
	values := n.List("values")
	if len(values) == 0 {
		return pyValue{}
	}

	v := w.expr(values[0], s, depth+1)
	for _, item := range values[1:] {
		if n.String("op") == "And" && v.truth == 1 || n.String("op") == "Or" && v.truth == 2 {
			return v
		}

		if v.truth == 0 {
			branch := s.fork()
			next := w.expr(item, branch, depth+1)
			mergePyBranches(s, s, branch)

			v = mergePyValue(v, next, 0)
		} else {
			v = w.expr(item, s, depth+1)
		}
	}

	return v
}

func (w *pyWalker) conditionalExpr(n *frontend.Node, s *pyState, depth int) pyValue {
	test := w.expr(n.Child("test"), s, depth+1)
	if test.truth == 2 {
		return w.expr(n.Child("body"), s, depth+1)
	}

	if test.truth == 1 {
		return w.expr(n.Child("orelse"), s, depth+1)
	}

	a, b := s.fork(), s.fork()
	x, y := w.expr(n.Child("body"), a, depth+1), w.expr(n.Child("orelse"), b, depth+1)
	mergePyBranches(s, a, b)

	return mergePyValue(x, y, 0)
}

func (w *pyWalker) attributeExpr(n *frontend.Node, s *pyState, depth int) pyValue {
	name := canonPy(w.name(n, s, 0))
	if name == "os.environ" {
		v := origin("environment", n)
		v.name = name

		return v
	}

	v := w.expr(n.Child("value"), s, depth+1)
	if member, ok := pyMember(v, n.String("attr")); ok {
		return member
	}

	v.function = nil
	v.class = nil
	v.instance = nil
	v.bound = nil
	v.name = name

	return v
}

func (w *pyWalker) subscriptExpr(n *frontend.Node, s *pyState, depth int) pyValue {
	if base := w.moduleDictionary(n.Child("value"), s); base != "" {
		w.expr(n.Child("value"), s, depth+1)
		w.expr(n.Child("slice"), s, depth+1)

		if key, ok := pyReflectiveString(n.Child("slice"), 0); ok {
			if pyDangerousAttribute(key) {
				w.emit(valueAST9, n, nil)
			}

			return pyValue{name: base + "." + key}
		}

		w.emit(valueAST7, n, nil)

		return pyValue{}
	}

	v := w.expr(n.Child("value"), s, depth+1)
	w.expr(n.Child("slice"), s, depth+1)

	if key, ok := nodeLiteral(n.Child("slice")); ok && v.mapping != nil {
		return transformed(pyContents(v.mapping.entries[key]), n)
	}

	v.name = ""
	v.known = false

	return v
}

func (w *pyWalker) callExpression(n *frontend.Node, s *pyState, depth int) pyValue {
	name := canonPy(w.name(n.Child("func"), s, 0))
	args := n.List(valueArgs)
	vals, positional, keywords := w.callArguments(n, s, depth)
	all := joinPy(vals...)
	fn := n.Child("func")
	callable := w.expr(fn, s, depth+1)

	receiver := pyValue{}
	if fn != nil && fn.Type == valueAttribute {
		receiver = callable
	}

	if value, handled := w.resolveCallable(n, s, depth, name, args, positional, keywords, callable); handled {
		return value
	}

	if value, handled := w.observeBuiltinCall(name, n, args, s); handled {
		return value
	}

	all = w.observeCallEffects(name, n, args, keywords, s, all, receiver)

	return w.callResult(name, n, args, vals, all, receiver, fn, s)
}

func (w *pyWalker) callArguments(n *frontend.Node, s *pyState, depth int) ([]pyValue, []pyValue, map[string]pyValue) {
	args := n.List(valueArgs)
	vals := []pyValue{}
	positional := []pyValue{}
	keywords := map[string]pyValue{}

	for _, a := range args {
		if a.Type == valueStarred {
			v := w.expr(a.Child("value"), s, depth+1)

			vals = append(vals, v)
			if v.elements != nil {
				positional = append(positional, v.elements...)
			} else {
				w.limited = true
			}

			continue
		}

		v := w.expr(a, s, depth+1)
		vals = append(vals, v)
		positional = append(positional, v)
	}

	for _, k := range n.List("keywords") {
		value := k.Child("value")
		v := w.expr(value, s, depth+1)

		vals = append(vals, v)
		if k.String("arg") == "" {
			if v.mapping != nil {
				for key, item := range v.mapping.entries {
					keywords[key] = pyContents(item)
				}
			} else {
				w.limited = true
			}
		} else {
			keywords[k.String("arg")] = v
		}
	}

	return vals, positional, keywords
}

func (w *pyWalker) resolveCallable(n *frontend.Node, s *pyState, depth int, name string, args []*frontend.Node, positional []pyValue, keywords map[string]pyValue, callable pyValue) (pyValue, bool) {
	fn := n.Child("func")
	if fn != nil && fn.Type == valueAttribute && pyDictionaryRead(fn.String("attr")) && len(args) > 0 {
		if base := w.moduleDictionary(fn.Child("value"), s); base != "" {
			if key, ok := pyReflectiveString(args[0], 0); ok {
				if pyDangerousAttribute(key) {
					w.emit(valueAST9, n, nil)
				}

				return pyValue{name: base + "." + key}, true
			}

			w.emit(valueAST7, n, nil)

			return pyValue{}, true
		}
	}

	if name == "super" {
		if len(positional) == 2 && positional[0].class != nil {
			return pyValue{super: &pySuper{owner: positional[0].class, receiver: positional[1]}}, true
		}

		if len(positional) == 0 && len(w.frames) > 0 {
			frame := w.frames[len(w.frames)-1]
			if frame.owner != nil {
				return pyValue{super: &pySuper{owner: frame.owner, receiver: frame.receiver}}, true
			}
		}

		w.limited = true

		return pyValue{}, true
	}

	if callable.function != nil {
		return w.invoke(callable, n, positional, keywords, s, depth+1), true
	}

	if callable.class != nil {
		if constructor, ok := pyMember(callable, "__new__"); ok && constructor.function != nil {
			w.invoke(constructor, n, append([]pyValue{{class: callable.class}}, positional...), keywords, s, depth+1)
		}

		instance := pyValue{instance: &pyInstance{class: callable.class, fields: map[string]pyValue{}}}
		if init, ok := pyMember(instance, "__init__"); ok && init.function != nil {
			w.invoke(init, n, positional, keywords, s, depth+1)
		}

		return instance, true
	}

	return pyValue{}, false
}

func (w *pyWalker) observeBuiltinCall(name string, n *frontend.Node, args []*frontend.Node, s *pyState) (pyValue, bool) {
	switch name {
	case valueExec:
		w.emit(valueAST1, n, nil)
	case valueEval:
		w.emit(valueAST2, n, nil)
	case valueImport:
		w.emit(valueAST3, n, nil)
	case valueCompile:
		w.emit(valueAST6, n, nil)
	case valueGetattr:
		if len(args) >= 2 {
			if v, ok := pyReflectiveString(args[1], 0); !ok {
				w.emit(valueAST7, n, nil)
			} else {
				switch v {
				case valueExec, valueEval, valueSystem, valuePopen, valueImport:
					w.emit(valueAST9, n, nil)
				}
			}

			if key, ok := pyReflectiveString(args[1], 0); ok {
				if base := w.name(args[0], s, 0); base != "" {
					return pyValue{name: base + "." + key}, true
				}
			}
		}
	}

	return pyValue{}, false
}

func (w *pyWalker) observeCallEffects(name string, n *frontend.Node, args []*frontend.Node, keywords map[string]pyValue, s *pyState, all, receiver pyValue) pyValue {
	if name == valueExec || name == valueEval {
		if len(args) > 0 && w.nestedSource(args[0], s, 0) {
			w.emit(valueAST8, n, nil)
		}
	}

	if strings.HasPrefix(name, "subprocess.") {
		if pyExec(name) && keywords[valueShell].truth == 2 {
			w.emit(valueTM1, n, nil)
		}

		switch strings.TrimPrefix(name, "subprocess.") {
		case "call", valueRun, "Popen", "check_output", "check_call", "getoutput", "getstatusoutput":
			w.emit(valueAST4, n, nil)
		}
	}

	if after, ok := strings.CutPrefix(name, "os."); ok {
		tail := after
		if tail == valueSystem || tail == valuePopen || strings.HasPrefix(tail, valueExec) || strings.HasPrefix(tail, "spawn") || tail == "posix_spawn" || tail == "posix_spawnp" {
			w.emit(valueAST5, n, nil)
		}
	}

	if pyExec(name) {
		w.flow(n, all, valueExec)

		if pythonOutputArgument(name, n) {
			w.emit(valueOH1, n, nil)
		}
	}

	if w.unsafeDeserialization(name, n, s) {
		w.emit(valueAST10, n, nil)
		w.flow(n, all, "deserialization")
	}

	if pyNetwork(name) {
		if name == valueUrllibRequestUrlopen {
			all = joinPy(all, receiver)
		}

		w.flow(n, all, valueNetwork)
	}

	if pyHTTPBody(name, n) {
		w.emit("E1", n, nil)
	}

	if name == "pathlib.Path.write_text" || name == "pathlib.Path.write_bytes" || name == "file-write.write" {
		w.flow(n, all, kindFile)
	}

	return all
}

func (w *pyWalker) callResult(name string, n *frontend.Node, args []*frontend.Node, vals []pyValue, all, receiver pyValue, fn *frontend.Node, s *pyState) pyValue {
	switch name {
	case valueVars:
		if len(args) == 1 {
			base := w.name(args[0], s, 0)
			if base == "os" || base == valueBuiltins {
				return pyValue{name: base + ".__dict__"}
			}
		}
	case "urllib.request.build_opener", valueUrllibRequestOpenerDirector:
		v := joinPy(vals...)
		for _, arg := range vals {
			v = joinPy(v, pyHandlerOrigins(arg, 0, map[*pyInstance]bool{}))
		}

		v.name = valueUrllibRequestOpenerDirector

		return v
	case "urllib.request.Request":
		v := transformed(all, n)
		v.name = "urllib.request.Request"

		return v
	case "os.getenv", "os.environ.get":
		return origin("environment", n)
	case valueInput, "sys.stdin.read", "sys.stdin.readline":
		return origin(valueInput, n)
	case "open":
		return pythonOpenResult(n, args)
	case "pathlib.Path.read_text", "pathlib.Path.read_bytes":
		return origin(kindFile, n)
	case "pathlib.Path", "socket.socket", "requests.Session", "httpx.Client", "httpx.AsyncClient":
		return pyValue{name: name}
	}

	return w.wrapperResult(name, n, args, all, receiver, fn)
}

func pythonOpenResult(n *frontend.Node, args []*frontend.Node) pyValue {
	mode := "r"

	if len(args) > 1 {
		if v, ok := nodeLiteral(args[1]); ok {
			mode = v
		} else {
			return pyValue{}
		}
	}

	for _, k := range n.List("keywords") {
		if k.String("arg") == "mode" {
			if v, ok := nodeLiteral(k.Child("value")); ok {
				mode = v
			} else {
				return pyValue{}
			}
		}
	}

	if strings.ContainsAny(mode, "wax+") {
		return pyValue{name: "file-write"}
	}

	v := origin(kindFile, n)
	v.name = "file-read"

	return v
}

func (w *pyWalker) wrapperResult(name string, n *frontend.Node, args []*frontend.Node, all, receiver pyValue, fn *frontend.Node) pyValue {
	if pyIncoming(name) {
		return origin(valueNetwork, n)
	}

	if name == "file-read.read" || name == "file-read.readline" || name == "file-read.readlines" {
		receiver.name = ""
		return transformed(receiver, n)
	}

	switch name {
	case "str", valueBytes, "bytearray", "repr", "dict", "list", "tuple", valueSet, "json.dumps", "urllib.parse.urlencode", "base64.b64encode", "base64.b64decode", "base64.decodebytes", "codecs.decode", "marshal.loads":
		return transformed(all, n)
	}

	if fn != nil && fn.Type == valueAttribute {
		switch fn.String("attr") {
		case "read", "readline", "readlines", formatJSON:
			if len(receiver.origins) > 0 {
				return transformed(receiver, n)
			}
		case "encode", "decode", "strip", "format", "replace", "join", "split", "rsplit", "splitlines":
			v := joinPy(receiver, all)
			return transformed(v, n)
		}
	}

	if name == valueImport || name == "importlib.import_module" {
		if len(args) > 0 {
			if v, ok := nodeLiteral(args[0]); ok {
				return pyValue{name: v}
			}
		}
	}

	return pyValue{}
}

func (w *pyWalker) lambdaExpr(n *frontend.Node, s *pyState, depth int) pyValue {
	w.definitionInputs(n.Child(valueArgs), nil, s, depth+1)
	f := w.defineFunction(n, s, depth+1)
	child := s.fork().scope()
	w.bindArgs(n.Child(valueArgs), child)

	maps.Copy(child.names, f.defaults)

	w.expr(n.Child("body"), child, depth+1)
	// Defining a function does not evaluate its body or return its value.
	// Inspect the body for independent observations, not caller taint.
	return pyValue{function: f}
}

func (w *pyWalker) assign(target *frontend.Node, v pyValue, s *pyState, statement *frontend.Node) {
	if target == nil {
		return
	}

	if target.Type == valueName {
		s.set(target.String("id"), transformed(v, statement))
		return
	}

	if target.Type == valueAttribute {
		base := w.expr(target.Child("value"), s, 0)
		if base.instance != nil {
			base.instance.fields[target.String("attr")] = transformed(v, statement)
		}

		if base.class != nil {
			base.class.attrs[target.String("attr")] = transformed(v, statement)
		}

		return
	}

	if target.Type == valueSubscript {
		base := w.expr(target.Child("value"), s, 0)
		if base.mapping != nil {
			if key, ok := nodeLiteral(target.Child("slice")); ok && len(base.mapping.entries) < 64 {
				base.mapping.entries[key] = transformed(v, statement)
			} else {
				w.limited = true
			}
		}

		return
	}

	if target.Type == valueTuple || target.Type == valueList {
		items := target.List("elts")
		for i, n := range items {
			item := pyValue{}
			if len(items) == len(v.elements) && len(items) <= 64 {
				item = v.elements[i]
			} else {
				w.limited = true
			}

			w.assign(n, item, s, statement)
		}
	}
}

// definitionInputs inspects annotation expressions as potentially evaluated
// syntax. Their side effects/values do not become caller state: Python versions,
// future imports and annotation consumers determine evaluation timing.
func (w *pyWalker) definitionInputs(args, returns *frontend.Node, s *pyState, depth int) {
	if args != nil {
		for _, key := range []string{"defaults", "kw_defaults"} {
			for _, d := range args.List(key) {
				w.expr(d, s, depth+1)
			}
		}

		for _, key := range []string{"posonlyargs", valueArgs, "kwonlyargs"} {
			for _, a := range args.List(key) {
				w.expr(a.Child("annotation"), s.clone(), depth+1)
			}
		}

		for _, key := range []string{"vararg", "kwarg"} {
			w.expr(args.Child(key).Child("annotation"), s.clone(), depth+1)
		}
	}

	w.expr(returns, s.clone(), depth+1)
}

func (w *pyWalker) bindArgs(args *frontend.Node, s *pyState) {
	if args == nil {
		return
	}

	for _, k := range []string{"posonlyargs", valueArgs, "kwonlyargs"} {
		for _, arg := range args.List(k) {
			s.set(arg.String("arg"), pyValue{})
		}
	}

	for _, k := range []string{"vararg", "kwarg"} {
		if n := args.Child(k); n != nil {
			s.set(n.String("arg"), pyValue{})
		}
	}
}

// Python local declarations shadow outer bindings throughout their scope, even
// before their first assignment. This prevents treating a local exec as builtins.exec.
func (w *pyWalker) prebind(nodes []*frontend.Node, s *pyState) {
	w.prebindDeclarations(nodes, s)
	w.prebindNames(nodes, s)
}

func (w *pyWalker) prebindDeclarations(nodes []*frontend.Node, s *pyState) {
	for _, n := range nodes {
		if n == nil {
			continue
		}

		if n.Type == valueFunctionDef || n.Type == valueAsyncFunctionDef || n.Type == valueClassDef {
			continue
		}

		if n.Type == "Global" || n.Type == "Nonlocal" {
			var names []string
			if json.Unmarshal(n.Fields["names"], &names) != nil {
				w.limited = true
				continue
			}

			for _, name := range names {
				s.declarations[name] = strings.ToLower(n.Type)
			}
		}

		w.prebindDeclarations(n.List("body"), s)
		w.prebindDeclarations(n.List("orelse"), s)
		w.prebindDeclarations(n.List("finalbody"), s)

		for _, h := range n.List("handlers") {
			w.prebindDeclarations(h.List("body"), s)
		}
	}
}

func (w *pyWalker) prebindNames(nodes []*frontend.Node, s *pyState) {
	for _, n := range nodes {
		if n == nil {
			continue
		}

		switch n.Type {
		case valueFunctionDef, valueAsyncFunctionDef, valueClassDef:
			if s.declarations[n.String("name")] == "" {
				s.set(n.String("name"), pyValue{})
			}

			continue
		case valueAssign:
			for _, v := range n.List("targets") {
				w.prebindTarget(v, s)
			}
		case valueAnnAssign, "AugAssign", "For", "AsyncFor":
			w.prebindTarget(n.Child("target"), s)
		case "Import", "ImportFrom":
			for _, alias := range n.List("names") {
				name := alias.String("asname")
				if name == "" {
					name = strings.Split(alias.String("name"), ".")[0]
				}

				if s.declarations[name] == "" {
					s.set(name, pyValue{})
				}
			}
		}

		w.prebind(n.List("body"), s)
		w.prebind(n.List("orelse"), s)
		w.prebind(n.List("finalbody"), s)

		for _, h := range n.List("handlers") {
			w.prebind(h.List("body"), s)
		}
	}
}

func (w *pyWalker) prebindTarget(n *frontend.Node, s *pyState) {
	if n == nil {
		return
	}

	if n.Type == valueName {
		if s.declarations[n.String("id")] == "" {
			s.set(n.String("id"), pyValue{})
		}

		return
	}

	if n.Type == valueTuple || n.Type == valueList {
		for _, x := range n.List("elts") {
			w.prebindTarget(x, s)
		}
	}
}

func (w *pyWalker) block(nodes []*frontend.Node, s *pyState, depth int) {
	for _, n := range nodes {
		if n == nil || !w.charge(depth) {
			return
		}

		switch n.Type {
		case "Global", "Nonlocal":
			// Declarations were collected for the entire function before binding.
		case "UnsupportedStatement":
			child := s.fork()
			w.block(n.List("body"), child, depth+1)

			for name := range s.names {
				s.names[name] = pyValue{}
			}

			s.blockedBuiltins = true
		case "Import":
			for _, a := range n.List("names") {
				name := a.String("name")

				key := a.String("asname")
				if key == "" {
					key = strings.Split(name, ".")[0]
					name = key
				}

				s.set(key, pyValue{name: name})
			}
		case "ImportFrom":
			w.importFrom(n, s)
		case valueAssign:
			v := w.expr(n.Child("value"), s, depth+1)
			for _, t := range n.List("targets") {
				w.assign(t, v, s, n)
			}
		case valueAnnAssign:
			w.expr(n.Child("annotation"), s.clone(), depth+1)
			v := w.expr(n.Child("value"), s, depth+1)
			w.assign(n.Child("target"), v, s, n)
		case "AugAssign":
			v := joinPy(w.expr(n.Child("target"), s, depth+1), w.expr(n.Child("value"), s, depth+1))
			w.assign(n.Child("target"), v, s, n)
		case valueFunctionDef, valueAsyncFunctionDef:
			w.functionStatement(n, s, depth)
		case valueClassDef:
			w.classStatement(n, s, depth)
		default:
			if !w.controlStatement(n, s, depth) {
				return
			}
		}
	}
}

func (w *pyWalker) importFrom(n *frontend.Node, s *pyState) {
	var level int
	if json.Unmarshal(n.Fields["level"], &level) != nil {
		w.limited = true
		return
	}

	for _, a := range n.List("names") {
		name := a.String("name")

		key := a.String("asname")
		if key == "" {
			key = name
		}

		if name == "*" {
			s.blockedBuiltins = true
			for k := range s.names {
				s.names[k] = pyValue{}
			}

			continue
		}

		if level != 0 {
			s.set(key, pyValue{})
		} else {
			s.set(key, pyValue{name: n.String("module") + "." + name})
		}
	}
}

func (w *pyWalker) functionStatement(n *frontend.Node, s *pyState, depth int) {
	for _, d := range n.List("decorator_list") {
		w.expr(d, s, depth+1)
	}

	args := n.Child(valueArgs)
	w.definitionInputs(args, n.Child("returns"), s, depth+1)
	function := w.defineFunction(n, s, depth+1)
	s.set(n.String("name"), pyValue{function: function})

	for _, tp := range n.List("type_params") {
		w.expr(tp, s.clone(), depth+1)
	}

	child := s.fork().scope()
	w.prebind(n.List("body"), child)
	w.bindArgs(args, child)

	maps.Copy(child.names, function.defaults)

	w.frames = append(w.frames, &pyFrame{})
	w.block(n.List("body"), child, depth+1)
	w.frames = w.frames[:len(w.frames)-1]
}

func (w *pyWalker) classStatement(n *frontend.Node, s *pyState, depth int) {
	for _, d := range n.List("decorator_list") {
		w.expr(d, s, depth+1)
	}

	for _, b := range n.List("bases") {
		w.expr(b, s, depth+1)
	}

	for _, k := range n.List("keywords") {
		w.expr(k.Child("value"), s, depth+1)
	}

	for _, tp := range n.List("type_params") {
		w.expr(tp, s.clone(), depth+1)
	}

	w.defineClass(n, s, depth+1)
}

func (w *pyWalker) controlStatement(n *frontend.Node, s *pyState, depth int) bool {
	switch n.Type {
	case "Return":
		v := w.expr(n.Child("value"), s, depth+1)
		if len(w.frames) > 0 {
			frame := w.frames[len(w.frames)-1]
			frame.values = append(frame.values, v)
		}

		return false
	case "If":
		w.expr(n.Child("test"), s, depth+1)
		a, b := s.fork(), s.fork()
		w.block(n.List("body"), a, depth+1)
		w.block(n.List("orelse"), b, depth+1)
		mergePyBranches(s, a, b)
	case "With", "AsyncWith":
		for _, i := range n.List("items") {
			v := w.expr(i.Child("context_expr"), s, depth+1)
			w.assign(i.Child("optional_vars"), v, s, i.Child("context_expr"))
		}

		w.block(n.List("body"), s, depth+1)
	case "For", "AsyncFor", "While":
		w.expr(n.Child("iter"), s, depth+1)
		w.expr(n.Child("test"), s, depth+1)
		a := s.fork()
		w.assign(n.Child("target"), pyValue{}, a, n)
		w.block(n.List("body"), a, depth+1)
		// Explore a second possible iteration so loop-carried sources can
		// reach earlier sinks. The parser still reports limited loop semantics.
		w.block(n.List("body"), a, depth+1)
		mergePyBranches(s, s, a)
		w.block(n.List("orelse"), s, depth+1)
	case "Try", "TryStar":
		w.tryStatement(n, s, depth)
	case "Delete":
		for _, t := range n.List("targets") {
			w.assign(t, pyValue{}, s, n)
		}
	default:
		w.expr(n, s, depth+1)
	}

	return true
}

func (w *pyWalker) tryStatement(n *frontend.Node, s *pyState, depth int) {
	a := s.fork()
	w.block(n.List("body"), a, depth+1)
	w.block(n.List("orelse"), a, depth+1)
	merged := a

	for _, h := range n.List("handlers") {
		b := s.fork()
		if h.String("name") != "" {
			b.names[h.String("name")] = pyValue{}
		}

		w.block(h.List("body"), b, depth+1)
		merged = mergePy(merged, b)
	}

	mergePyBranches(s, s, merged)
	w.block(n.List("finalbody"), s, depth+1)
}

func mergePy(a, b *pyState) *pyState {
	r := a.clone()

	r.blockedBuiltins = a.blockedBuiltins || b.blockedBuiltins
	for k, x := range a.names {
		y, ok := b.names[k]
		if !ok {
			y = pyValue{}
		}

		z := mergePyValue(x, y, 0)
		r.names[k] = z
	}

	for k, y := range b.names {
		if _, ok := r.names[k]; !ok {
			r.names[k] = joinPy(pyValue{}, y)
		}
	}

	return r
}

func joinPy(vs ...pyValue) pyValue {
	r := pyValue{}
	seen := map[[2]int]bool{}

	for _, v := range vs {
		for _, o := range v.origins {
			k := [2]int{o.start, o.end}
			if seen[k] {
				continue
			}

			seen[k] = true

			if len(r.origins) < 4 {
				r.origins = append(r.origins, o)
			}
		}
	}

	return r
}

func transformed(v pyValue, n *frontend.Node) pyValue {
	if n == nil {
		return v
	}

	r := v

	r.origins = append([]pyOrigin(nil), v.origins...)
	for i := range r.origins {
		p := r.origins[i]

		p.steps = append([]source.Span(nil), p.steps...)
		if len(p.steps) < 5 {
			p.steps = append(p.steps, source.Span{Start: n.Start, End: n.End})
		}

		r.origins[i] = p
	}

	return r
}

func origin(kind string, n *frontend.Node) pyValue {
	return pyValue{origins: []pyOrigin{{kind: kind, start: n.Start, end: n.End}}}
}

func nodeLiteral(n *frontend.Node) (string, bool) {
	if n == nil || n.Type != valueConstant {
		return "", false
	}

	var s string
	if json.Unmarshal(n.Fields["value"], &s) != nil {
		return "", false
	}

	return s, true
}

func canonPy(n string) string {
	n = strings.TrimPrefix(n, "builtins.")
	for _, prefix := range []string{"requests.Session.", "httpx.Client.", "httpx.AsyncClient."} {
		if after, ok := strings.CutPrefix(n, prefix); ok {
			n = strings.Split(prefix, ".")[0] + "." + after
		}
	}

	if n == "urllib.request.OpenerDirector.open" {
		return valueUrllibRequestUrlopen
	}

	return n
}

func pyExec(n string) bool {
	switch n {
	case valueExec, valueEval, valueCompile, "os.system", "os.popen", "subprocess.run", "subprocess.call", "subprocess.check_output", "subprocess.check_call", "subprocess.Popen", "subprocess.getoutput", "subprocess.getstatusoutput":
		return true
	}

	return false
}

// A parsed outgoing HTTP body is an observable transmission construct even
// without a tainted source. Resolve imports/aliases/shadowing just as TT does.
func pyHTTPBody(name string, n *frontend.Node) bool {
	if !pyNetwork(name) {
		return false
	}

	for _, k := range n.List("keywords") {
		if k.String("arg") == "data" || k.String("arg") == formatJSON || k.String("arg") == "content" || k.String("arg") == "files" {
			return true
		}
	}

	return (strings.HasSuffix(name, ".post") || strings.HasSuffix(name, ".put") || strings.HasSuffix(name, ".patch")) && len(n.List(valueArgs)) > 1
}

func pyNetwork(n string) bool {
	switch n {
	case "requests.get", "requests.post", "requests.put", "requests.patch", "requests.delete", "httpx.get", "httpx.post", "httpx.put", "httpx.patch", "httpx.delete", valueUrllibRequestUrlopen, "socket.socket.send", "socket.socket.sendall", "socket.socket.sendto":
		return true
	}

	return false
}

func pyIncoming(n string) bool {
	return strings.HasPrefix(n, "requests.") && pyNetwork(n) || strings.HasPrefix(n, "httpx.") && pyNetwork(n) || n == valueUrllibRequestUrlopen || n == "urllib.request.urlretrieve" || n == "socket.socket.recv" || n == "socket.socket.recvfrom"
}
