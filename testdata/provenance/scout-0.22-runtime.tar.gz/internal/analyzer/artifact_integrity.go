// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Modified SkillSpector artifact integrity/SC8 signals with bounded Go views.

package analyzer

import (
	"context"
	"path"
	"regexp"
	"slices"
	"strings"
	"unicode"
	"unicode/utf8"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/model"
)

//nolint:gochecknoglobals // Immutable lookup data shared by concurrent scans; initialized once to avoid rebuilding it per input.
var separatedInstruction = func() *regexp.Regexp {
	parts := make([]string, 0, 19)

	for _, word := range []string{"ignore", "bypass", "reveal", valueSystem, "send", "upload", "transmit", valueNever, "warn", "always", "forget", "previous", "you", "conversation", valueInstructions, "prompt", "execute", "delete", "steal"} {
		letters := strings.Split(word, "")
		parts = append(parts, strings.Join(letters, `[\s\p{Z}\x{85}._*·\p{M}\p{Nd}-]+`))
	}

	return regexp.MustCompile(`(?i)\b(?:` + strings.Join(parts, "|") + `)\b`)
}()

type integrityCheck struct{ id string }

func (a integrityCheck) Rule() model.Rule {
	title := map[string]string{valueAE2: "Artifact content conflicts with filename/language hints", valueAE3: "Instruction-capable text contains embedded NUL bytes", valueAE4: "Suspicious Unicode controls or mixed-script token", valueAE5: "Instruction text exceeds security reconstruction limits", valueAE6: "Security instruction uses inter-character separators", valueSC8: "Bundled Python bytecode or cache artifact"}[a.id]

	severity := model.Medium
	if a.id == valueAE3 || a.id == valueAE5 || a.id == valueAE6 || a.id == valueSC8 {
		severity = model.High
	}

	version := "2"
	if a.id == valueAE2 || a.id == valueAE6 {
		version = "3"
	}

	return model.Rule{ID: "NV-" + a.id, Version: version, Title: title, Description: title, Severity: severity, Category: "artifact-integrity", Method: "bounded-artifact-integrity", Limitation: "Adapted artifact signals, not proof of evasion or malicious intent. Unicode density and mixed-token scripts can have legitimate uses. Author filename/type hints are candidates; scanner-generated JSON labels are not author filename claims. No opaque payload is executed, decompiled or declared safe."}
}
func (integrityCheck) AppliesTo(artifact.File) bool         { return true }
func (integrityCheck) AppliesToDocument(document.File) bool { return true }
func (a integrityCheck) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	return a.FindDocument(ctx, document.Prepare(ctx, f), budget)
}

func (a integrityCheck) FindDocument(ctx context.Context, d document.File, budget int) (Result, error) {
	if ctx.Err() != nil {
		return Result{}, ctx.Err()
	}

	f := d.Artifact()
	text := f.Content()
	name := strings.ToLower(f.Metadata().Path)
	hit := false
	start, end := 0, len(text)

	switch a.id {
	case valueAE2:
		hit = d.Classification().Conflict
	case valueAE3:
		at := strings.IndexByte(text, 0)

		hit = at >= 0 && utf8.ValidString(text) && d.Classification().Basis != "signature"
		if hit {
			start, end = at, at+1
		}
	case valueAE4:
		if f.Metadata().Kind == formatText {
			var err error

			hit, err = suspiciousUnicode(ctx, text)
			if err != nil {
				return Result{}, err
			}
		}
	case valueAE5:
		hit = reconstructionLimited(name, d)
	case valueAE6:
		if f.Metadata().Kind == formatText {
			if loc := separatedInstruction.FindStringIndex(text); loc != nil {
				hit = true
				start, end = loc[0], loc[1]
			}
		}
	case valueSC8:
		hit = strings.HasSuffix(name, ".pyc") || strings.HasSuffix(name, ".pyo")
		for part := range strings.SplitSeq(name, "/") {
			hit = hit || part == "__pycache__"
		}
	}

	if !hit || start >= end {
		return Result{}, nil
	}

	if budget < 1 {
		return Result{Truncated: true}, nil
	}

	return Result{Matches: []Match{{Start: start, End: end}}}, ctx.Err()
}

func reconstructionLimited(name string, d document.File) bool {
	if ext := path.Ext(name); ext == ".md" || ext == ".markdown" || ext == ".txt" {
		for _, diag := range d.Diagnostics() {
			if diag.Code == "security_reconstruction_limit" {
				return true
			}
		}
	}

	return false
}

func suspiciousUnicode(ctx context.Context, text string) (bool, error) {
	controls, total := 0, 0

	for at, r := range text {
		if at%1024 == 0 && ctx.Err() != nil {
			return false, ctx.Err()
		}

		total++

		if unicode.Is(unicode.Cf, r) && !(r == 0x200d && emojiBefore(text, at) && emojiAfter(text, at+utf8.RuneLen(r))) {
			controls++
		}
	}

	if total > 0 && controls*100 >= total {
		return true, nil
	}

	return slices.ContainsFunc(strings.FieldsFunc(text, func(r rune) bool { return !unicode.IsLetter(r) }), confusingIdentifier), nil
}

func artifactIntegrityRules() []Analyzer {
	return []Analyzer{integrityCheck{valueAE2}, integrityCheck{valueAE3}, integrityCheck{valueAE4}, integrityCheck{valueAE5}, integrityCheck{valueAE6}, integrityCheck{valueSC8}}
}
