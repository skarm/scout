package analyzer

import (
	"encoding/json"
	"sort"

	"github.com/skarm/scout/frontend"
)

// 0 unknown, 1 definitely false, 2 definitely true. No Python code is evaluated.
func pyTruth(n *frontend.Node, s *pyState, depth int) uint8 {
	if n == nil || depth > 32 {
		return 0
	}

	switch n.Type {
	case valueName:
		v, _ := s.lookup(n.String("id"))
		return v.truth
	case valueConstant:
		return pyConstantTruth(n)
	case valueList, valueTuple, "Set":
		nodes := n.List("elts")
		for _, v := range nodes {
			if v.Type == valueStarred {
				return 0
			}
		}

		if len(nodes) > 0 {
			return 2
		}

		return 1
	case "Dict":
		keys := n.List("keys")
		for _, v := range keys {
			if v == nil {
				return 0
			}
		}

		if len(keys) > 0 {
			return 2
		}

		return 1
	case "UnaryOp":
		v := pyTruth(n.Child("operand"), s, depth+1)
		switch n.String("op") {
		case "Not":
			if v == 1 {
				return 2
			}

			if v == 2 {
				return 1
			}
		case "USub", "UAdd":
			return v
		}
	}

	return 0
}

func pyConstantTruth(n *frontend.Node) uint8 {
	var numeric bool
	if json.Unmarshal(n.Fields["numeric_truth"], &numeric) == nil {
		if numeric {
			return 2
		}

		return 1
	}

	if json.Unmarshal(n.Fields["numeric_unknown"], &numeric) == nil && numeric {
		return 0
	}

	var v any
	if json.Unmarshal(n.Fields["value"], &v) != nil {
		return 0
	}

	yes := false

	switch x := v.(type) {
	case nil:
	case bool:
		yes = x
	case string:
		yes = x != ""
	case float64:
		yes = x != 0
	default:
		return 0
	}

	if yes {
		return 2
	}

	return 1
}

// A handler object may retain credentials in constructor-assigned fields.
// Only captured fields of this bounded same-file instance are considered.
func pyHandlerOrigins(v pyValue, depth int, seen map[*pyInstance]bool) pyValue {
	out := joinPy(v)
	if depth > 8 || v.instance == nil || seen[v.instance] {
		return out
	}

	seen[v.instance] = true

	keys := make([]string, 0, len(v.instance.fields))
	for key := range v.instance.fields {
		keys = append(keys, key)
	}

	sort.Strings(keys)

	for _, key := range keys {
		out = joinPy(out, pyHandlerOrigins(v.instance.fields[key], depth+1, seen))
	}

	return out
}
