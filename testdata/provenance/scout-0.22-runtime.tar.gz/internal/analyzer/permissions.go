// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Adapted LP1-LP4 concepts; immutable, namespace-scoped observations with
// captured evidence. Permission strings are declarations, never enforcement.

package analyzer

import (
	"context"
	"errors"
	"path"
	"regexp"
	"sort"
	"strings"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/hookpolicy"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/source"
)

//nolint:gochecknoglobals // Immutable lookup data shared by concurrent scans; initialized once to avoid rebuilding it per input.
var capPatterns = []struct {
	name string
	rx   *regexp.Regexp
}{
	{valueShell, regexp.MustCompile(`(?i)subprocess|\bPopen\b|os\.(?:system|popen|exec)|exec\.Command|\b(?:curl|wget|chmod)\b`)},
	{valueNetwork, regexp.MustCompile(`(?i)\b(?:httpx|requests|urllib|aiohttp)\b|socket\.connect|\bfetch\s*\(|XMLHttpRequest|http\.(?:Get|Post|NewRequest)|\.Do\s*\(`)},
	{valueFileRead, regexp.MustCompile(`(?i)open\s*\([^\r\n)]{0,256},\s*['"][^'"\r\n]{0,8}r|\.(?:read_text|read_bytes)\s*\(|os\.(?:ReadFile|listdir|walk)|glob\.glob`)},
	{valueFileWrite, regexp.MustCompile(`(?i)open\s*\([^\r\n)]{0,256},\s*['"][^'"\r\n]{0,8}[wa]|\.(?:write_text|write_bytes)\s*\(|shutil\.copy|os\.(?:WriteFile|Create|rename|mkdir)`)},
	{valueEnv, regexp.MustCompile(`(?i)os\.(?:environ|getenv|LookupEnv)|process\.env|\bdotenv\b`)},
	{valueMcp, regexp.MustCompile(`(?i)create_session|MCPClient|mcp\.client`)},
}

//nolint:gochecknoglobals // Immutable permission vocabulary shared by concurrent scans.
var (
	permissionWords      = regexp.MustCompile(`[A-Za-z_]+|\*`)
	permissionCategories = map[string]string{valueBash: valueShell, valueShell: valueShell, "execute": valueShell, "terminal": valueShell, valueCommand: valueShell, valueNetwork: valueNetwork, "webfetch": valueNetwork, "websearch": valueNetwork, schemeHTTP: valueNetwork, "fetch": valueNetwork, "api": valueNetwork, "read": valueFileRead, "glob": valueFileRead, "ls": valueFileRead, "fs_read": valueFileRead, valueFileRead: valueFileRead, "write": valueFileWrite, "edit": valueFileWrite, "multiedit": valueFileWrite, "fs_write": valueFileWrite, valueFileWrite: valueFileWrite, valueEnv: valueEnv, "environment": valueEnv, valueMcp: valueMcp, "tools": valueMcp, "tool_use": valueMcp}
)

type permissionCheck struct {
	id      string
	records map[string]permissionRecord
	failure bool
}
type permissionRecord struct {
	span                source.Span
	present, wild, code bool
	declared            map[string]bool
	observed            map[string]model.SourceRef
}

// BindContexts supplies only immutable captured scope facts, not filesystem or
// network access. The four LP rules share one bounded discovery pass per scan.
func BindContexts(ctx context.Context, checks []Analyzer, docs []document.File, extraction model.ExtractionReport) []Analyzer {
	hooks := hookpolicy.Bind(ctx, docs, extraction)

	checks = append([]Analyzer(nil), checks...)
	for i, a := range checks {
		switch v := a.(type) {
		case agentConfigCheck:
			v.hooks = hooks
			checks[i] = v
		case bundledSurface:
			v.hooks = hooks
			checks[i] = v
		}
	}

	needed := false

	for _, a := range checks {
		if _, ok := a.(permissionCheck); ok {
			needed = true
			break
		}
	}

	if !needed {
		return checks
	}

	records, failed := permissionRecords(ctx, docs, extraction)

	out := append([]Analyzer(nil), checks...)
	for i, a := range out {
		if p, ok := a.(permissionCheck); ok {
			p.records, p.failure = records, failed
			out[i] = p
		}
	}

	return out
}

func (a permissionCheck) Rule() model.Rule {
	title := map[string]string{valueNVLP1: "Code capability hint lacks a matching permission declaration", valueNVLP2: "Permission declaration contains a wildcard", valueNVLP3: "Code capability hints have no permission declaration", valueNVLP4: "Declared capability has no observed use in the captured scope"}[a.id]

	severity := model.Medium
	if a.id == valueNVLP4 {
		severity = model.Low
	}

	return model.Rule{ID: a.id, Version: "1", Title: title, Description: title, Severity: severity, Category: "least-privilege", Method: "scoped-declaration-capability-heuristic", Limitation: "Captured same-namespace nearest-skill/plugin scope only. Capabilities are lexical hints, not verified execution; absence of a hint does not prove unused permission. External code, host enforcement and unknown tool names remain unverified. Related evidence contains bounded observations."}
}

func (a permissionCheck) AppliesTo(f artifact.File) bool {
	_, ok := a.records[f.Metadata().Path]
	return ok || a.failure
}

func (a permissionCheck) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	if ctx.Err() != nil {
		return Result{}, ctx.Err()
	}

	if a.failure {
		return Result{}, errors.New("permission scope discovery limited")
	}

	r, ok := a.records[f.Metadata().Path]
	if !ok || !r.code {
		return Result{}, nil
	}

	match := false

	switch a.id {
	case valueNVLP1:
		if r.present && !r.wild {
			for c := range r.observed {
				if !r.declared[c] {
					match = true
					break
				}
			}
		}
	case valueNVLP2:
		match = r.wild
	case valueNVLP3:
		match = !r.present && len(r.observed) > 0
	case valueNVLP4:
		if r.present && !r.wild {
			for c := range r.declared {
				if _, ok := r.observed[c]; !ok {
					match = true
					break
				}
			}
		}
	}

	if !match {
		return Result{}, nil
	}

	if budget < 1 {
		return Result{Truncated: true}, nil
	}

	m := Match{Start: r.span.Start, End: r.span.End}

	keys := make([]string, 0, len(r.observed))
	for c := range r.observed {
		keys = append(keys, c)
	}

	sort.Strings(keys)

	for _, c := range keys {
		m.Related = append(m.Related, r.observed[c])
	}

	return Result{Matches: []Match{m}}, nil
}

type (
	permissionAddress struct{ ns, name string }
	permissionScope   struct {
		file, ns, root string
		r              permissionRecord
	}
)

func permissionRecords(ctx context.Context, docs []document.File, extraction model.ExtractionReport) (map[string]permissionRecord, bool) {
	addresses := map[string]permissionAddress{}

	for _, d := range docs {
		p := d.Artifact().Metadata().Path
		if !strings.HasPrefix(p, "scout-object://") {
			addresses[p] = permissionAddress{"snapshot", p}
		}
	}

	for _, o := range extraction.Objects {
		if o.Role == "archive_member" {
			addresses[o.File.Path] = permissionAddress{o.ParentPath, o.MemberName}
		}
	}

	scopes := []permissionScope{}

	for _, d := range docs {
		if ctx.Err() != nil {
			return nil, true
		}

		p := d.Artifact().Metadata().Path

		addr, ok := addresses[p]
		if !ok {
			continue
		}

		isSkill := path.Base(addr.name) == "SKILL.md"

		isPlugin := strings.HasSuffix(addr.name, ".claude-plugin/plugin.json") || strings.HasSuffix(addr.name, ".codex-plugin/plugin.json")
		if !isSkill && !isPlugin {
			continue
		}

		if len(scopes) >= 1024 {
			return nil, true
		}

		record := declaredPermissionRecord(d, isSkill, isPlugin)
		if record == nil {
			continue
		}

		root := path.Dir(addr.name)
		if isPlugin {
			root = path.Dir(root)
		}

		if root == "." {
			root = ""
		}

		scopes = append(scopes, permissionScope{p, addr.ns, root, *record})
	}

	sort.Slice(scopes, func(i, j int) bool {
		if len(scopes[i].root) != len(scopes[j].root) {
			return len(scopes[i].root) > len(scopes[j].root)
		}

		return scopes[i].file < scopes[j].file
	})

	if !observePermissionScopes(ctx, docs, addresses, scopes) {
		return nil, true
	}

	out := map[string]permissionRecord{}
	for _, s := range scopes {
		out[s.file] = s.r
	}

	return out, false
}

func observePermissionScopes(ctx context.Context, docs []document.File, addresses map[string]permissionAddress, scopes []permissionScope) bool {
	ops := 0

	for _, d := range docs {
		if ctx.Err() != nil {
			return false
		}

		p := d.Artifact().Metadata().Path

		addr, ok := addresses[p]
		if !ok || !permissionCode(d) {
			continue
		}

		for i := range scopes {
			ops++
			if ops > 500000 {
				return false
			}

			s := &scopes[i]
			if s.ns != addr.ns || s.root != "" && addr.name != s.root && !strings.HasPrefix(addr.name, s.root+"/") {
				continue
			}

			observePermissions(d, &s.r)

			break
		}
	}

	return true
}

func declaredPermissionRecord(d document.File, isSkill, isPlugin bool) *permissionRecord {
	for _, u := range d.Units() {
		if isSkill && u.Origin != "frontmatter" || isPlugin && u.Origin != kindFile {
			continue
		}

		tree, ok := u.Tree.(parse.JSONTree)
		if !ok || tree.Root == nil {
			continue
		}

		at, e := u.View.Original(tree.Root.Span)
		if e != nil {
			continue
		}

		r := permissionRecord{span: at, declared: map[string]bool{}, observed: map[string]model.SourceRef{}}

		collectPermissionDeclarations(tree.Root, &r)

		return &r
	}

	return nil
}

func collectPermissionDeclarations(root *jsonconfig.Node, r *permissionRecord) {
	for _, key := range []string{"permissions", "allowed-tools"} {
		n := root.Get(key)
		if n == nil {
			continue
		}

		r.present = true

		values := []string{}
		if s, ok := n.Text(); ok {
			values = append(values, s)
		}

		for _, v := range n.Elements {
			if s, ok := v.Text(); ok {
				values = append(values, s)
			}
		}

		for _, v := range values {
			for _, word := range permissionWords.FindAllString(strings.ToLower(v), 128) {
				if word == "*" || word == "all" || word == "full" || word == "any" {
					r.wild = true
				}

				if c, ok := permissionCategories[word]; ok {
					r.declared[c] = true
				}
			}
		}
	}
}

func permissionCode(d document.File) bool {
	for _, u := range d.Units() {
		switch u.Language {
		case "go", "python", valueShell, languageJavaScript, valueTypescript, "powershell", "ruby", "php", "perl", "lua", "rust", "c", "cpp", "java":
			return true
		}
	}

	return false
}

func observePermissions(d document.File, r *permissionRecord) {
	r.code = true
	for _, c := range capPatterns {
		if _, ok := r.observed[c.name]; ok {
			continue
		}

		m := c.rx.FindStringIndex(d.Artifact().Content())
		if m == nil {
			continue
		}

		meta := d.Artifact().Metadata()
		r.observed[c.name] = model.SourceRef{Path: meta.Path, SHA256: meta.SHA256, ByteStart: m[0], ByteEnd: m[1], SpanSHA256: artifact.Hash([]byte(d.Artifact().Content()[m[0]:m[1]]))}
	}
}
