// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Adapted offline MCP Registry posture checks. Captured-byte evidence, bounded
// JSON parsing and static integration are Scout-specific; no acquisition/trust.

package analyzer

import (
	"context"
	"errors"
	"regexp"
	"strings"
	"unicode"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/source"
)

var (
	registrySHA        = regexp.MustCompile(`^[a-f0-9]{64}$`)
	registryNPMVersion = regexp.MustCompile(`^v?[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$`)
	registryWildcard   = regexp.MustCompile(`(?:^|\.)[xX*](?:\.|$)`)

	//nolint:gochecknoglobals // Immutable lookup data shared by concurrent scans; initialized once to avoid rebuilding it per input.
	mutableRegistryVersions = stringSet("latest next beta alpha stable canary edge main master dev nightly preview")
)

type registryCheck struct{ id string }

func RegistryRules() []Analyzer {
	out := make([]Analyzer, 0, 5)
	for _, id := range []string{"MCP-PACKAGE-VERSION", valueMCPPACKAGESHA256, valueMCPRepository, valueMCPOFFICIALSTATUS, valueMCPPlainHTTP} {
		out = append(out, registryCheck{id})
	}

	return out
}

func (a registryCheck) Rule() model.Rule {
	title := map[string]string{
		"MCP-PACKAGE-VERSION":  "Registry package version requires review",
		valueMCPPACKAGESHA256:  "Registry package content digest requires review",
		valueMCPRepository:     "Registry repository reference is unavailable",
		valueMCPOFFICIALSTATUS: "Registry status is unavailable or not active",
		valueMCPPlainHTTP:      "Registry record declares a plaintext HTTP endpoint",
	}[a.id]

	severity := model.High
	if a.id == valueMCPRepository {
		severity = model.Info
	}

	if a.id == valueMCPOFFICIALSTATUS {
		severity = model.Medium
	}

	return model.Rule{ID: a.id, Version: "1", Title: title, Description: title, Severity: severity, Category: "registry-posture", Method: "captured-registry-record-analysis", Limitation: "Bounded registry-shaped JSON servers envelopes only. Fields are untrusted registry assertions, not verified ownership, integrity or service behavior. Missing/wrong-typed optional facts are info/unavailable; malformed record/collection shapes remain incomplete. Selected upstream version grammar; no registry access, package install, signature verification or history comparison. Descriptor severity is a maximum."}
}

func (registryCheck) AppliesTo(f artifact.File) bool       { return f.Metadata().Kind == formatText }
func (registryCheck) AppliesToDocument(document.File) bool { return true }
func (a registryCheck) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	return a.FindDocument(ctx, document.Prepare(ctx, f), budget)
}

func (a registryCheck) FindDocument(ctx context.Context, d document.File, budget int) (Result, error) {
	out := Result{}
	seen := map[source.Span]bool{}
	partial := false
	operations := 0

	for _, u := range d.Units() {
		if ctx.Err() != nil {
			return out, ctx.Err()
		}

		t, ok := u.Tree.(parse.JSONTree)
		if !ok || u.Language != formatJSON || t.Root == nil || t.Root.Kind != kindObject {
			continue
		}

		records := t.Root.Get("servers")
		// Candidate grammar, never a trust decision. Generic mcpServers maps and
		// unrelated endpoint objects cannot be mistaken for registry records.
		if records == nil || records.Kind != kindArray {
			continue
		}

		emit := registryEmitter(u, &out, &partial, seen, budget)

		for _, entry := range records.Elements {
			if ctx.Err() != nil {
				return out, ctx.Err()
			}

			operations++
			if operations > 8192 {
				return out, errors.New("registry record budget exceeded")
			}

			record := entry.Get("server")
			if !registryCollectionsValid(record) {
				partial = true
				continue
			}

			if err := a.inspectRegistryRecord(entry, record, &operations, emit); err != nil {
				return out, err
			}
		}
	}

	if partial {
		return out, errors.New("registry candidate shape incomplete")
	}

	return out, ctx.Err()
}

func registryEmitter(u document.Unit, out *Result, partial *bool, seen map[source.Span]bool, budget int) func(*jsonconfig.Node, model.Severity, bool) {
	return func(n *jsonconfig.Node, severity model.Severity, unavailable bool) {
		if n == nil || out.Truncated {
			return
		}

		at, e := u.View.Original(n.Span)
		if e != nil {
			*partial = true
			return
		}

		if seen[at] {
			return
		}

		seen[at] = true

		if len(out.Matches) >= budget {
			out.Truncated = true
			return
		}

		signal := "registry_assertion"
		if unavailable {
			signal = "evidence_unavailable"
		}

		out.Matches = append(out.Matches, Match{Start: at.Start, End: at.End, Severity: severity, ContextSignals: []string{signal}})
	}
}

func (a registryCheck) inspectRegistryRecord(entry, record *jsonconfig.Node, operations *int, emit func(*jsonconfig.Node, model.Severity, bool)) error {
	switch a.id {
	case valueMCPRepository:
		repo := record.Get("repository")

		value, ok := repo.Get("url").Text()
		if !ok || value == "" {
			if repo == nil {
				repo = record
			}

			emit(repo, model.Info, true)
		}
	case valueMCPOFFICIALSTATUS:
		n := entry.Get("_meta").Get("io.modelcontextprotocol.registry/official").Get("status")

		value, ok := n.Text()
		if !ok {
			emit(entry, model.Info, true)
		} else if value != "active" {
			emit(n, model.Medium, false)
		}
	case valueMCPPlainHTTP:
		for _, remote := range record.GetOrEmpty("remotes").Elements {
			if n := remote.Get("url"); n != nil {
				if value, ok := n.Text(); ok && strings.HasPrefix(strings.ToLower(value), "http://") {
					emit(n, model.High, false)
				}
			}
		}
	default:
		return a.inspectRegistryPackages(record, operations, emit)
	}

	return nil
}

func (a registryCheck) inspectRegistryPackages(record *jsonconfig.Node, operations *int, emit func(*jsonconfig.Node, model.Severity, bool)) error {
	for _, p := range record.GetOrEmpty("packages").Elements {
		*operations++
		if *operations > 8192 {
			return errors.New("registry record budget exceeded")
		}

		key := "version"
		if a.id == valueMCPPACKAGESHA256 {
			key = "fileSha256"
		}

		n := p.Get(key)

		value, ok := n.Text()
		if !ok {
			emit(p, model.Info, true)
			continue
		}

		kind, _ := p.Get("registryType").Text()

		valid := specificRegistryVersion(kind, value)
		if a.id == valueMCPPACKAGESHA256 {
			valid = registrySHA.MatchString(value)
		}

		if !valid {
			emit(n, model.High, false)
		}
	}

	return nil
}

func specificRegistryVersion(kind, value string) bool {
	if mutableRegistryVersions[strings.ToLower(value)] {
		return false
	}

	digit := false
	for _, r := range value {
		digit = digit || unicode.IsDigit(r)
		if unicode.IsSpace(r) || strings.ContainsRune("^~*><=|", r) {
			return false
		}
	}

	if !digit || registryWildcard.MatchString(value) {
		return false
	}

	return kind != valueNpm || registryNPMVersion.MatchString(value)
}

func registryCollectionsValid(record *jsonconfig.Node) bool {
	if record == nil || record.Kind != kindObject {
		return false
	}

	name, ok := record.Get("name").Text()
	if !ok || name == "" {
		return false
	}

	if n := record.Get("repository"); n != nil && n.Kind != "null" && n.Kind != kindObject {
		return false
	}

	for _, key := range []string{"packages", "remotes"} {
		if n := record.Get(key); n != nil {
			if n.Kind != kindArray {
				return false
			}

			for _, v := range n.Elements {
				if v.Kind != kindObject {
					return false
				}
			}
		}
	}

	return true
}
