package analyzer

import (
	"context"
	"encoding/hex"
	"errors"
	"net"
	"net/url"
	"path"
	"regexp"
	"strings"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/hookpolicy"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/source"
)

var environmentReference = regexp.MustCompile(`\$\{[A-Za-z_][A-Za-z0-9_]*\}|\$[A-Za-z_][A-Za-z0-9_]*`)

var npmPackageName = regexp.MustCompile(`^(?:@[a-z0-9._-]+/)?[a-z0-9._-]+$`)

var exactPackageVersion = regexp.MustCompile(`^[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$`)

type agentConfigCheck struct {
	id    string
	hooks hookpolicy.Policy
}

func (a agentConfigCheck) Rule() model.Rule {
	r := model.Rule{
		ID: a.id, Version: "1", Severity: model.Medium, Method: "json-configuration",
		Limitation: "Strict bounded JSON and supported field shapes only. A declaration is not proof of runtime activation, compromise or effective host permissions. Hook disables use a closed captured Claude settings.local-before-settings subset; external settings and other precedence remain unknown. YAML/TOML require an explicitly selected trusted parser; TOML positions cover the whole unit.",
	}
	switch a.id {
	case valueAC001:
		r.Title, r.Category, r.Severity = "Agent configuration requests permission bypass", "approval-bypass", model.High
	case valueAC002:
		r.Title, r.Category = "Agent configuration declares a broad tool approval", "excessive-permissions"
	case valueAC003:
		r.Title, r.Category = "Agent lifecycle hook declares command execution", "lifecycle-execution"
	case valueSC001:
		r.Title, r.Category = "MCP launcher package is not pinned to an exact version", valueSupplyChain
		r.Limitation += " Selected direct npx/npm-exec/go-run/uvx/uv-tool/pip/docker/podman argv forms only. Container tags are mutable; only a syntactic SHA256 digest counts as pinned. Exact version text is not package integrity, authenticity or a vulnerability check. Wrappers and arbitrary package managers are not resolved."
	case valueMC001:
		r.Title, r.Category = "MCP endpoint declares non-loopback plaintext HTTP", "insecure-transport"
		r.Limitation += " URL text only; no DNS, redirects or endpoint access. Loopback exemption is syntactic, not authentication or host trust."
	case valueMC002:
		r.Title, r.Category = "MCP configuration embeds a credential-like literal", "credential-material"
		r.Limitation += " Selected env/header names and URL userinfo; literals are not proven live secrets. Runtime interpolation is not evaluated."
	case valueMC003:
		r.Title, r.Category = "MCP tool schema requests highly sensitive input", "sensitive-data-request"
		r.Limitation += " Selected inputSchema property names; legitimate auth tools can also match. readOnlyHint is not treated as a safety guarantee."
	}

	if a.id == valueAC003 || a.id == valueSC001 || a.id == valueMC001 || a.id == valueMC002 {
		r.Version = "2"
		r.Limitation += " Includes harness-linked inline/custom-path config objects without assuming activation."
	}

	r.Description = r.Title
	r.Version = "4"

	return r
}
func (agentConfigCheck) AppliesTo(f artifact.File) bool { return f.Metadata().Kind == formatText }
func (agentConfigCheck) AppliesToDocument(f document.File) bool {
	for _, u := range f.Units() {
		if _, ok := u.Tree.(parse.JSONTree); ok {
			return true
		}
	}

	return false
}

func (a agentConfigCheck) Find(ctx context.Context, f artifact.File, budget int) (Result, error) {
	if err := ctx.Err(); err != nil {
		return Result{}, err
	}

	return a.FindDocument(ctx, document.Prepare(ctx, f), budget)
}

func (a agentConfigCheck) FindDocument(ctx context.Context, f document.File, budget int) (Result, error) {
	var (
		out        Result
		mappingErr error
	)

	seen := make(map[source.Span]bool)

	if err := ctx.Err(); err != nil {
		return out, err
	}

	for _, u := range f.Units() {
		tree, ok := u.Tree.(parse.JSONTree)
		if !ok || tree.Root == nil {
			continue
		}

		emit := configEmitter(u, &out, &mappingErr, seen, budget)
		state := a.hookState(f, u, tree.Root)

		actualHook := u.Origin == kindFile && (hookpolicy.IsSettings(f.Artifact().Metadata().Path) || path.Base(f.Artifact().Metadata().Path) == "hooks.json")
		if a.id != valueAC003 || !state.Disabled || !actualHook {
			a.inspect(ctx, tree.Root, emit)
		}

		if a.id == valueAC003 && state.Uncertain {
			mappingErr = errors.New("hook disable semantics incomplete")
		}

		a.inspectConfigScopes(ctx, f, u, tree.Root, state, &out, emit)

		if out.Truncated || mappingErr != nil || ctx.Err() != nil {
			break
		}
	}

	return out, errors.Join(mappingErr, ctx.Err())
}

func configEmitter(u document.Unit, out *Result, mappingErr *error, seen map[source.Span]bool, budget int) func(source.Span) {
	return func(span source.Span) {
		if out.Truncated || *mappingErr != nil {
			return
		}

		at, err := u.View.Original(span)
		if err != nil {
			*mappingErr = errors.New("configuration evidence mapping failed")
			return
		}

		if seen[at] {
			return
		}

		if len(out.Matches) >= budget {
			out.Truncated = true
			return
		}

		seen[at] = true
		out.Matches = append(out.Matches, Match{Start: at.Start, End: at.End})
	}
}

func (a agentConfigCheck) hookState(f document.File, u document.Unit, root *jsonconfig.Node) hookpolicy.State {
	state := a.hooks[f.Artifact().Metadata().Path]
	if a.hooks == nil && u.Origin == kindFile && hookpolicy.IsSettings(f.Artifact().Metadata().Path) {
		state = hookpolicy.Local(root)
	}

	if !hookpolicy.IsSettings(f.Artifact().Metadata().Path) {
		for _, scope := range f.ConfigScopes() {
			if scope.Role == valueHookConfig && scope.Host != "" && scope.Host != "claude-code" {
				state.Disabled = false
			}
		}
	}

	return state
}

func (a agentConfigCheck) inspectConfigScopes(ctx context.Context, f document.File, u document.Unit, root *jsonconfig.Node, state hookpolicy.State, out *Result, emit func(source.Span)) {
	if u.Origin == kindFile {
		for _, scope := range f.ConfigScopes() {
			if out.Truncated || ctx.Err() != nil {
				break
			}

			n := scopedNode(root, scope.Span)
			if scope.Span.Start == 0 && scope.Span.End == len(f.Artifact().Content()) {
				n = root
			}

			if n != nil && !(a.id == valueAC003 && scope.Role == valueHookConfig && state.Disabled) {
				a.inspectScope(ctx, n, scope.Role, emit)
			}
		}
	}
}

func (a agentConfigCheck) inspect(ctx context.Context, root *jsonconfig.Node, emit func(source.Span)) {
	if root.Kind != kindObject {
		return
	}

	switch a.id {
	case valueAC001:
		for _, key := range []string{"approval_policy", "sandbox_mode"} {
			n := root.Get(key)
			if text, ok := n.Text(); ok && (key == "approval_policy" && text == valueNever || key == "sandbox_mode" && text == "danger-full-access") {
				emit(n.Span)
			}
		}

		n := root.Get("permissions").Get("defaultMode")

		disabledMode, _ := root.Get("permissions").Get("disableBypassPermissionsMode").Text()
		if text, ok := n.Text(); ok && text == "bypassPermissions" && disabledMode != "disable" {
			emit(n.Span)
		}
	case valueAC002:
		inspectBroadTools(root, emit)
	case valueAC003:
		inspectCommandHooks(ctx, root.Get("hooks"), emit)
	case valueMC003:
		inspectSensitiveToolParameters(ctx, root, emit)
	default:
		a.inspectServers(ctx, root, emit)
	}
}

func inspectBroadTools(root *jsonconfig.Node, emit func(source.Span)) {
	for _, key := range []string{"allowed-tools", "permissions"} {
		n := root.Get(key)
		if text, ok := n.Text(); ok && broadTool(text) {
			emit(n.Span)
		}

		if n != nil {
			for _, v := range n.Elements {
				if text, ok := v.Text(); ok && broadTool(text) {
					emit(v.Span)
				}
			}
		}
	}

	allow := root.Get("permissions").Get("allow")
	if allow != nil {
		for _, n := range allow.Elements {
			if text, ok := n.Text(); ok && broadTool(text) {
				emit(n.Span)
			}
		}
	}
}

func inspectCommandHooks(ctx context.Context, hooks *jsonconfig.Node, emit func(source.Span)) {
	if hooks == nil {
		return
	}

	for _, event := range hooks.Members {
		if ctx.Err() != nil {
			return
		}

		for _, matcher := range event.Value.Elements {
			group := matcher.Get("hooks")
			if group == nil {
				continue
			}

			for _, hook := range group.Elements {
				kind, _ := hook.Get("type").Text()

				command := hook.Get(valueCommand)
				if text, ok := command.Text(); kind == valueCommand && ok && strings.TrimSpace(text) != "" {
					emit(command.Span)
				}
			}
		}
	}
}

func inspectSensitiveToolParameters(ctx context.Context, root *jsonconfig.Node, emit func(source.Span)) {
	tools := root.Get("tools")
	if tools == nil {
		tools = root.Get("result").Get("tools")
	}

	if tools == nil {
		return
	}

	for _, tool := range tools.Elements {
		if ctx.Err() != nil {
			return
		}

		props := tool.Get("inputSchema").Get("properties")
		if props == nil {
			continue
		}

		for _, m := range props.Members {
			if highlySensitiveParameter(m.Key) {
				emit(m.KeySpan)
			}
		}
	}
}

func (a agentConfigCheck) inspectServers(ctx context.Context, root *jsonconfig.Node, emit func(source.Span)) {
	servers := root.Get("mcpServers")
	if servers == nil {
		servers = root.Get("mcp_servers")
	}

	if servers == nil {
		return
	}

	for _, member := range servers.Members {
		if ctx.Err() != nil {
			return
		}

		a.server(member.Value, emit)
	}
}

func (a agentConfigCheck) server(server *jsonconfig.Node, emit func(source.Span)) {
	if server == nil || server.Kind != kindObject {
		return
	}

	switch a.id {
	case valueSC001:
		command, ok := server.Get(valueCommand).Text()

		args := server.Get(valueArgs)
		if !ok || args == nil || args.Kind != kindArray {
			return
		}

		for _, arg := range args.Elements {
			if arg.Kind != kindString {
				return
			}
		}

		for _, n := range unpinnedLauncher(command, args.Elements) {
			emit(n.Span)
		}
	case valueMC001:
		n := server.Get("url")
		if text, ok := n.Text(); ok {
			u, err := url.Parse(text)
			if err == nil && strings.EqualFold(u.Scheme, schemeHTTP) && u.Hostname() != "" && !loopbackHost(u.Hostname()) {
				emit(n.Span)
			}
		}
	case valueMC002:
		inspectServerCredentials(server, emit)
	}
}

func inspectServerCredentials(server *jsonconfig.Node, emit func(source.Span)) {
	for _, field := range []string{valueEnv, "headers", "http_headers"} {
		container := server.Get(field)
		if container == nil || container.Kind != kindObject {
			continue
		}

		for _, m := range container.Members {
			key := strings.ToUpper(strings.ReplaceAll(m.Key, "-", "_"))
			if !sensitiveName(key) && key != "AUTHORIZATION" && key != "PROXY_AUTHORIZATION" {
				continue
			}

			if text, ok := m.Value.Text(); ok && credentialLiteral(text) {
				emit(m.Value.Span)
			}
		}
	}

	n := server.Get("url")
	if text, ok := n.Text(); ok {
		u, err := url.Parse(text)
		if err == nil && u.User != nil {
			if p, yes := u.User.Password(); yes && credentialLiteral(p) {
				emit(n.Span)
			}
		}
	}
}

// Scoped trees retain ORIGINAL source spans; only a wrapper role is supplied by
// discovery. This is not execution or trust in configuration field contents.
func (a agentConfigCheck) inspectScope(ctx context.Context, n *jsonconfig.Node, role string, emit func(source.Span)) {
	if n.Kind != kindObject {
		return
	}

	if role == "mcp_config" && (a.id == valueSC001 || a.id == valueMC001 || a.id == valueMC002) {
		maps := []*jsonconfig.Node{}
		if v := n.Get("mcpServers"); v != nil {
			maps = append(maps, v)
		}

		if v := n.Get("mcp_servers"); v != nil {
			maps = append(maps, v)
		}

		if len(maps) == 0 {
			maps = append(maps, n)
		}

		for _, servers := range maps {
			for _, m := range servers.Members {
				if ctx.Err() != nil {
					return
				}

				a.server(m.Value, emit)
			}
		}
	}

	if role == valueHookConfig && a.id == valueAC003 {
		if n.Get("hooks") != nil {
			a.inspect(ctx, n, emit)
			return
		}

		wrapper := &jsonconfig.Node{Kind: kindObject, Members: []jsonconfig.Member{{Key: "hooks", Value: n}}}
		a.inspect(ctx, wrapper, emit)
	}
}

// Agent checks focus on installable instructions/configuration rather than
// generic language quality. Config declarations are NOT effective permissions:
// trust, precedence and external host policy remain outside this offline scan.
func agentRules() []Analyzer {
	return []Analyzer{
		agentSignal("PI002", "Instruction to conceal actions from the user", `(?i)\b(?:do not|don't|never)[\t ]+(?:tell|inform|notify)[\t ]+(?:the[\t ]+)?user\b|(?i:не)[\t ]+(?:сообщай(?:те)?|рассказывай(?:те)?|уведомляй(?:те)?)[\t ]+пользовател(?:ю|я)`, "prompt-injection", "Narrow English/Russian concealment wording only; quotation, legitimate privacy instructions and negation require review."),
		agentSignal("AG001", "Agent approval or sandbox bypass flag is referenced", `(?:--dangerously-skip-permissions|--dangerously-bypass-approvals-and-sandbox)\b`, "approval-bypass", "A literal flag reference, not proof of invocation. A prohibition or example can match; host restrictions are not evaluated."),
		agentSignal("AG002", "Claude-style dynamic context command marker", "(?m)(?:^|[\\t ])!`[^`\\r\\n]+`", "preprocessing-execution", "Recognizes a single-line marker, not all Claude preprocessing forms. It can be an example, is not executed, and is not classified as malicious by itself."),
		agentConfigCheck{id: valueAC001},
		agentConfigCheck{id: valueAC002},
		agentConfigCheck{id: valueAC003},
		agentConfigCheck{id: valueSC001},
		agentConfigCheck{id: valueMC001},
		agentConfigCheck{id: valueMC002},
		agentConfigCheck{id: valueMC003},
		bundledSurface{id: valueBH1},
		bundledSurface{id: valueBH2},
		bundledSurface{id: valueBH3},
		bundledSurface{id: valueBH4},
	}
}

func agentSignal(id, title, expression, category, limitation string) Analyzer {
	return literal{
		rule: model.Rule{
			ID: id, Version: "1", Title: title, Description: title,
			Severity: model.Medium, Category: category, Method: "literal-agent-signal", Limitation: limitation,
		},
		expression: regexp.MustCompile(expression),
	}
}

func broadTool(s string) bool {
	s = strings.TrimSpace(s)
	return s == "*" || s == "Bash" || s == "Bash(*)" || s == "Bash:*" || s == "mcp__*"
}

func loopbackHost(host string) bool {
	if strings.EqualFold(host, "localhost") || strings.EqualFold(host, "localhost.") {
		return true
	}

	ip := net.ParseIP(host)

	return ip != nil && ip.IsLoopback()
}

func credentialLiteral(value string) bool {
	s := strings.TrimSpace(value)
	if s == "" {
		return false
	}
	// Remove references, not entire strings containing one: ${TOKEN}-literal
	// still embeds a literal. Lowercase env values remain allowed by this hint.
	s = strings.TrimSpace(environmentReference.ReplaceAllString(s, ""))

	return s != "" && !strings.EqualFold(s, "Bearer") && !strings.EqualFold(s, "Basic")
}

func highlySensitiveParameter(name string) bool {
	s := strings.ToLower(strings.NewReplacer("_", "", "-", "").Replace(name))
	switch s {
	case "password", "apikey", "privatekey", "sshprivatekey", "systemprompt", "conversationhistory", "chathistory", "accesstoken", "refreshtoken":
		return true
	}

	return false
}

// A small explicit argv model; does not run package managers or resolve PATH.
// Unknown flags/wrappers are outside this check, never guessed as package names.
func unpinnedLauncher(command string, args []*jsonconfig.Node) []*jsonconfig.Node {
	base := strings.ToLower(path.Base(strings.ReplaceAll(command, "\\", "/")))

	base = strings.TrimSuffix(strings.TrimSuffix(base, ".exe"), ".cmd")
	if base == "go" {
		if len(args) < 2 || args[0].String != valueRun || strings.HasPrefix(args[1].String, "-") {
			return nil
		}

		n := args[1]

		at := strings.LastIndexByte(n.String, '@')
		if at < 1 {
			return nil
		} // local/unchecked-module launches are not claimed pinned

		if !exactPackageVersion.MatchString(strings.TrimPrefix(n.String[at+1:], "v")) {
			return []*jsonconfig.Node{n}
		}

		return nil
	}

	if base == "uvx" || base == "uv" || base == valuePip || base == valuePip3 {
		return unpinnedPythonLauncher(base, args)
	}

	if base == "docker" || base == "podman" {
		return unpinnedContainerLauncher(args)
	}

	return unpinnedNodeLauncher(base, args)
}

func unpinnedPythonLauncher(base string, args []*jsonconfig.Node) []*jsonconfig.Node {
	if base == "uv" {
		if len(args) < 3 || args[0].String != "tool" || args[1].String != valueRun {
			return nil
		}

		args = args[2:]
	}

	if base == valuePip || base == valuePip3 {
		if len(args) < 2 || args[0].String != valueInstall {
			return nil
		}

		args = args[1:]
	}

	for _, n := range args {
		v := n.String
		if v == "--no-cache" || v == "--quiet" || v == "-q" {
			continue
		}

		if strings.HasPrefix(v, "-") {
			return nil
		}

		at := strings.Index(v, "==")
		if at < 1 || strings.ContainsAny(v[at+2:], "*<>=!~, ;/\\") || v[at+2:] == "" {
			return []*jsonconfig.Node{n}
		}

		return nil
	}

	return nil
}

func unpinnedContainerLauncher(args []*jsonconfig.Node) []*jsonconfig.Node {
	if len(args) < 2 || (args[0].String != valueRun && args[0].String != "pull" && args[0].String != "create") {
		return nil
	}

	for _, n := range args[1:] {
		v := n.String
		if v == "--rm" || v == "-i" || v == "-t" || v == "-it" {
			continue
		}

		if strings.HasPrefix(v, "-") {
			return nil
		}

		if at := strings.LastIndex(v, "@sha256:"); at > 0 && len(v[at+8:]) == 64 {
			if _, e := hex.DecodeString(v[at+8:]); e == nil {
				return nil
			}
		}

		return []*jsonconfig.Node{n}
	}

	return nil
}

func unpinnedNodeLauncher(base string, args []*jsonconfig.Node) []*jsonconfig.Node {
	npmMode := base == valueNpm
	if npmMode {
		if len(args) == 0 || args[0].String != valueExec {
			return nil
		}

		args = args[1:]
	} else if base != "npx" {
		return nil
	}

	return unpinnedNodeArguments(args, npmMode)
}

func unpinnedNodeArguments(args []*jsonconfig.Node, npmMode bool) []*jsonconfig.Node {
	var bad []*jsonconfig.Node

	packages := false

	for i := 0; i < len(args); i++ {
		n := args[i]

		s := n.String
		switch {
		case s == "-y" || s == "--yes" || s == "--no":
			continue
		case s == "-p" || s == "--package":
			if npmMode && s == "-p" {
				return bad
			} // npm -p means --parseable, not --package

			i++
			if i >= len(args) {
				return bad
			}

			n = args[i]
			s = n.String
			packages = true
		case strings.HasPrefix(s, "--package="):
			s = strings.TrimPrefix(s, "--package=")
			packages = true
		case s == "--":
			if packages {
				return bad
			}

			i++
			if i >= len(args) {
				return bad
			}

			n = args[i]
			s = n.String
		case strings.HasPrefix(s, "-"):
			return bad
		default:
			if packages || npmMode {
				return bad
			}
		}

		if !pinnedNPM(s) {
			bad = append(bad, n)
		}

		if !packages {
			return bad
		}
	}

	return bad
}

func pinnedNPM(s string) bool {
	at := strings.LastIndexByte(s, '@')
	if at < 1 || !npmPackageName.MatchString(s[:at]) {
		return false
	}

	return exactPackageVersion.MatchString(s[at+1:])
}

func scopedNode(n *jsonconfig.Node, span source.Span) *jsonconfig.Node {
	if n == nil || span.Start > n.Span.End || span.End < n.Span.Start {
		return nil
	}
	// Config file nodes use the whole-file range including whitespace; inline
	// nodes use exact token spans. Never match an arbitrary containing object.
	if n.Span == span {
		return n
	}

	for _, m := range n.Members {
		if child := scopedNode(m.Value, span); child != nil {
			return child
		}
	}

	for _, e := range n.Elements {
		if child := scopedNode(e, span); child != nil {
			return child
		}
	}

	return nil
}
