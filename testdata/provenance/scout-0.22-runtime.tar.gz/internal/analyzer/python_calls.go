// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Modified bounded same-file call/method propagation, based on SkillSpector
// behavioral_taint_tracking. This is static inference, never Python execution.

package analyzer

import (
	"maps"
	"slices"
	"sort"

	"github.com/skarm/scout/frontend"
)

type pyFunction struct {
	node     *frontend.Node
	lexical  *pyState
	defaults map[string]pyValue
	kind     string
	dynamic  bool
	owner    *pyClass
}
type pyClass struct {
	attrs map[string]pyValue
	mro   []*pyClass
}
type pyInstance struct {
	class  *pyClass
	fields map[string]pyValue
}
type pyFrame struct {
	values   []pyValue
	owner    *pyClass
	receiver pyValue
}
type pySuper struct {
	owner    *pyClass
	receiver pyValue
}

func (w *pyWalker) defineFunction(n *frontend.Node, s *pyState, depth int) *pyFunction {
	f := &pyFunction{node: n, lexical: s, defaults: map[string]pyValue{}}
	for _, d := range n.List("decorator_list") {
		name := w.name(d, s, 0)
		if name == valueStaticmethod || name == valueClassmethod {
			f.kind = name
		} else {
			f.dynamic = true
		}
	}

	args := n.Child(valueArgs)
	if args == nil {
		return f
	}

	pos := append(append([]*frontend.Node{}, args.List("posonlyargs")...), args.List(valueArgs)...)

	defaults := args.List("defaults")
	for i, d := range defaults {
		j := len(pos) - len(defaults) + i
		if j >= 0 {
			f.defaults[pos[j].String("arg")] = w.expr(d, s, depth+1)
		}
	}

	kw := args.List("kwonlyargs")
	for i, d := range args.List("kw_defaults") {
		if d != nil && i < len(kw) {
			f.defaults[kw[i].String("arg")] = w.expr(d, s, depth+1)
		}
	}

	return f
}

func (w *pyWalker) invoke(value pyValue, call *frontend.Node, pos []pyValue, kw map[string]pyValue, caller *pyState, depth int) pyValue {
	f := value.function
	if f == nil || !w.charge(depth) {
		return pyValue{}
	}

	w.calls++
	if w.active == nil {
		w.active = map[*pyFunction]bool{}
	}

	if f.dynamic || w.active[f] || len(w.frames) > 16 || w.calls > 4096 {
		w.limited = true
		return pyValue{}
	}

	w.active[f] = true
	defer delete(w.active, f)

	lexical := f.lexical
	if mapped := caller.forks[lexical]; mapped != nil {
		lexical = mapped
	}

	s := lexical.scope()
	w.prebind(f.node.List("body"), s)
	args := f.node.Child(valueArgs)
	w.bindArgs(args, s)

	if value.bound != nil {
		pos = append([]pyValue{*value.bound}, pos...)
	}

	maps.Copy(s.names, f.defaults)
	w.bindInvocation(f, call, args, pos, kw, s)

	frame := &pyFrame{owner: f.owner}
	if value.bound != nil {
		frame.receiver = *value.bound
	} else if f.owner != nil && len(pos) > 0 {
		frame.receiver = pos[0]
	}

	w.frames = append(w.frames, frame)
	if f.node.Type == "Lambda" {
		frame.values = append(frame.values, w.expr(f.node.Child("body"), s, depth+1))
	} else {
		w.block(f.node.List("body"), s, depth+1)
	}

	w.frames = w.frames[:len(w.frames)-1]
	if len(frame.values) == 1 {
		return transformed(frame.values[0], call)
	}

	return transformed(joinPy(frame.values...), call)
}

func (w *pyWalker) bindInvocation(f *pyFunction, call, args *frontend.Node, pos []pyValue, kw map[string]pyValue, s *pyState) {
	used := map[string]bool{}

	keywordNames := make([]string, 0, len(kw))
	for key := range kw {
		keywordNames = append(keywordNames, key)
	}

	sort.Strings(keywordNames)

	if args != nil {
		posonly := map[string]bool{}
		for _, p := range args.List("posonlyargs") {
			posonly[p.String("arg")] = true
		}

		parameters := append(append([]*frontend.Node{}, args.List("posonlyargs")...), args.List(valueArgs)...)
		for i, p := range parameters {
			if i < len(pos) {
				key := p.String("arg")
				s.names[key] = transformed(pos[i], call)
				used[key] = true
			}
		}

		for _, key := range keywordNames {
			w.bindKeyword(args, key, kw[key], used, posonly, s, call)
		}

		w.bindVariadicAndDefaults(f, call, args, pos, kw, s, used, posonly, parameters, keywordNames)
	}
}

func (w *pyWalker) bindKeyword(args *frontend.Node, key string, v pyValue, used, posonly map[string]bool, s *pyState, call *frontend.Node) {
	if used[key] && !posonly[key] {
		w.limited = true
		return
	}

	matched := false

	for _, p := range append(append([]*frontend.Node{}, args.List(valueArgs)...), args.List("kwonlyargs")...) {
		if p.String("arg") == key {
			s.names[key] = transformed(v, call)
			used[key] = true
			matched = true

			break
		}
	}

	if !matched && args.Child("kwarg") == nil {
		w.limited = true
	}
}

func (w *pyWalker) bindVariadicAndDefaults(f *pyFunction, call, args *frontend.Node, pos []pyValue, kw map[string]pyValue, s *pyState, used, posonly map[string]bool, parameters []*frontend.Node, keywordNames []string) {
	for _, p := range append(parameters, args.List("kwonlyargs")...) {
		key := p.String("arg")
		if !used[key] {
			if _, ok := f.defaults[key]; !ok {
				w.limited = true
			}
		}
	}

	if extra := args.Child("vararg"); extra != nil {
		tail := pos[min(len(pos), len(parameters)):]
		v := transformed(joinPy(tail...), call)
		v.elements = append([]pyValue{}, tail...)
		s.names[extra.String("arg")] = v
	} else if len(pos) > len(parameters) {
		w.limited = true
	}

	if extra := args.Child("kwarg"); extra != nil {
		vs := []pyValue{}
		entries := map[string]pyValue{}

		for _, key := range keywordNames {
			v := kw[key]
			if !used[key] || posonly[key] {
				vs = append(vs, v)
				entries[key] = v
			}
		}

		v := transformed(joinPy(vs...), call)
		v.mapping = &pyMapping{entries: entries}
		s.names[extra.String("arg")] = v
	}
}

func (w *pyWalker) defineClass(n *frontend.Node, s *pyState, depth int) {
	c := &pyClass{attrs: map[string]pyValue{}}
	bases := []*pyClass{}

	for _, base := range n.List("bases") {
		v := w.expr(base, s, depth+1)
		if v.class != nil {
			bases = append(bases, v.class)
		} else if w.name(base, s, 0) != kindObject {
			w.limited = true
		}
	}

	c.mro = pyMRO(c, bases)
	if c.mro == nil {
		w.limited = true
		c.mro = []*pyClass{c}
	}

	s.names[n.String("name")] = pyValue{class: c}
	// Class attributes live in a separate namespace. Methods capture the outer
	// lexical scope, not arbitrary class-local names as Python function globals.
	local := s.scope()
	w.block(n.List("body"), local, depth+1)
	bindClassAttributes(c, n, local, s)
	w.inspectClassMethods(c, n, s, depth)
}

func bindClassAttributes(c *pyClass, n *frontend.Node, local, s *pyState) {
	for _, item := range n.List("body") {
		key := item.String("name")
		if item.Type == valueFunctionDef || item.Type == valueAsyncFunctionDef {
			v := local.names[key]
			if v.function != nil {
				v.function.lexical = s
				v.function.owner = c
			}

			c.attrs[key] = v
		} else if item.Type == valueAssign {
			for _, target := range item.List("targets") {
				if target.Type == valueName {
					key = target.String("id")
					c.attrs[key] = local.names[key]
				}
			}
		} else if item.Type == valueAnnAssign && item.Child("value") != nil {
			if target := item.Child("target"); target != nil && target.Type == valueName {
				key = target.String("id")
				c.attrs[key] = local.names[key]
			}
		}
	}
}

func (w *pyWalker) inspectClassMethods(c *pyClass, n *frontend.Node, s *pyState, depth int) {
	// Inspect potential method capabilities in an isolated receiver. A method
	// need not be called by the module to contain an observable source/sink.
	receiver := pyValue{instance: &pyInstance{class: c, fields: map[string]pyValue{}}}
	if init, ok := pyMember(receiver, "__init__"); ok && init.function != nil {
		w.invoke(init, n, nil, nil, s.fork(), depth+1)
	}

	keys := make([]string, 0, len(c.attrs))
	for key := range c.attrs {
		if key != "__init__" && key != "__new__" {
			keys = append(keys, key)
		}
	}

	sort.Strings(keys)

	for _, key := range keys {
		isolated := s.fork()
		isolated.names["__scout_receiver__"] = receiver

		isolated = isolated.fork()
		if method, ok := pyMember(isolated.names["__scout_receiver__"], key); ok && method.function != nil {
			w.invoke(method, n, nil, nil, isolated, depth+1)
		}
	}
}

func pyMember(base pyValue, name string) (pyValue, bool) {
	var after *pyClass
	if base.super != nil {
		after = base.super.owner
		base = base.super.receiver
	}

	class := base.class
	if base.instance != nil {
		if v, ok := base.instance.fields[name]; ok {
			return v, true
		}

		class = base.instance.class
	}

	if class == nil {
		return pyValue{}, false
	}

	started := after == nil
	for _, c := range class.mro {
		if !started {
			if c == after {
				started = true
			}

			continue
		}

		if v, ok := c.attrs[name]; ok {
			if v.function != nil {
				if v.function.kind == valueClassmethod {
					bound := pyValue{class: class}
					v.bound = &bound
				} else if v.function.kind != valueStaticmethod && base.instance != nil {
					bound := base
					v.bound = &bound
				}
			}

			return v, true
		}
	}

	return pyValue{}, false
}

// C3 merge preserves Python's diamond inheritance order. An inconsistent or
// resource-limited hierarchy is unknown, never flattened to a guessed base.
func pyMRO(c *pyClass, bases []*pyClass) []*pyClass {
	if len(bases) > 32 {
		return nil
	}

	seqs := [][]*pyClass{}
	for _, b := range bases {
		seqs = append(seqs, append([]*pyClass(nil), b.mro...))
	}

	seqs = append(seqs, append([]*pyClass(nil), bases...))

	out := []*pyClass{c}
	for len(out) < 128 {
		remaining := false

		var candidate *pyClass

		for _, seq := range seqs {
			if len(seq) == 0 {
				continue
			}

			remaining = true

			head := seq[0]
			if validMROHead(head, seqs) {
				candidate = head
				break
			}
		}

		if !remaining {
			return out
		}

		if candidate == nil {
			return nil
		}

		out = append(out, candidate)
		for i, seq := range seqs {
			if len(seq) > 0 && seq[0] == candidate {
				seqs[i] = seq[1:]
			}
		}
	}

	return nil
}

func validMROHead(head *pyClass, seqs [][]*pyClass) bool {
	for _, other := range seqs {
		if len(other) == 0 {
			continue
		}

		if slices.Contains(other[1:], head) {
			return false
		}
	}

	return true
}
