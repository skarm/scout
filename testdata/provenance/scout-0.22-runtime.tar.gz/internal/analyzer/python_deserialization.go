// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Modified from SkillSpector behavioral_ast AST10 and taint TT6 call sets.

package analyzer

import (
	"encoding/json"

	"github.com/skarm/scout/frontend"
)

func (w *pyWalker) unsafeDeserialization(name string, n *frontend.Node, s *pyState) bool {
	switch name {
	case "pickle.load", "pickle.loads", "cPickle.load", "cPickle.loads", "_pickle.load", "_pickle.loads", "marshal.load", "marshal.loads", "dill.load", "dill.loads", "jsonpickle.decode", "pandas.read_pickle", "joblib.load", "yaml.unsafe_load":
		return true
	case "yaml.load":
		var loader *frontend.Node

		args := n.List(valueArgs)
		if len(args) > 1 {
			loader = args[1]
		}

		for _, k := range n.List("keywords") {
			if k.String("arg") == "Loader" {
				loader = k.Child("value")
			}
		}

		resolved := w.name(loader, s, 0)

		return resolved != "yaml.SafeLoader" && resolved != "yaml.CSafeLoader" && resolved != "yaml.BaseLoader"
	case "torch.load":
		for _, k := range n.List("keywords") {
			if k.String("arg") == "weights_only" && pyTrue(k.Child("value")) {
				return false
			}
		}

		return true
	case "numpy.load":
		for _, k := range n.List("keywords") {
			if k.String("arg") == "allow_pickle" && pyTrue(k.Child("value")) {
				return true
			}
		}

		args := n.List(valueArgs)

		return len(args) > 2 && pyTrue(args[2])
	}

	return false
}

func pyTrue(n *frontend.Node) bool {
	if n == nil || n.Type != valueConstant {
		return false
	}

	var b bool

	return json.Unmarshal(n.Fields["value"], &b) == nil && b
}
