package analyzer

import (
	"context"
	"regexp"
	"strings"

	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/shellsyntax"
	"github.com/skarm/scout/internal/source"
)

var (
	proseShellStart    = regexp.MustCompile("^[\\t ]*(?:[-*+][\\t ]+)?(?:['\"]?(?:curl|wget|r['\"]?m|chmod|git|cp|mv|install|env|command|sudo|bash|sh|echo|printf)\\b|cu\\\\|wg\\\\|\\$\\(|`)")
	proseCompoundStart = regexp.MustCompile(`^[\t ]*(?:if|for|while|until|case|time|function)\b|^[\t ]*[{(]|^[\t ]*[A-Za-z_][A-Za-z0-9_]*\(\)`)
)

// Parsed command words handle quote concatenation and physical line wrapping.
// The command is never resolved or executed; unknown words remain unknown.
func (a familyAnalyzer) shellPatterns(ctx context.Context, d document.File, budget int) (Result, error) {
	p := shellPatternWalker{analyzer: a, ctx: ctx, budget: budget, seen: map[source.Span]bool{}}

	for _, u := range d.Units() {
		if t, ok := u.Tree.(parse.ShellTree); ok {
			tree := t.Tree

			if a.spec.id == valueSC2 {
				if parsed, err := shellsyntax.ParseDeclarations(ctx, u.View.Text()); err == nil {
					tree = parsed
				}
			}

			p.walk(tree, u.View, 0)
		}
	}

	prose := true

	for _, h := range d.Classification().Languages {
		switch h.Language {
		case formatText, "markdown", "shell":
		default:
			prose = false
		}
	}

	if prose {
		p.prose(d.Artifact().Content())
	}

	return p.out, ctx.Err()
}

type shellPatternWalker struct {
	analyzer    familyAnalyzer
	ctx         context.Context
	budget, ops int
	out         Result
	seen        map[source.Span]bool
}

func (p *shellPatternWalker) walk(tree *shellsyntax.File, view source.View, depth int) {
	a, ctx := p.analyzer, p.ctx
	out := &p.out

	if tree == nil {
		return
	}

	if depth > 32 {
		out.Truncated = true
		return
	}

	if a.spec.id == valueSC2 {
		p.downloadPatterns(tree, view)
		return
	}

	for _, statement := range tree.Statements {
		for _, command := range statement.Commands {
			p.ops++
			if p.ops > 8192 || ctx.Err() != nil {
				out.Truncated = true
				return
			}

			if !p.command(command, view) {
				return
			}

			p.walk(command.Subshell, view, depth+1)

			for _, word := range command.Words {
				for _, part := range word.Parts {
					if part.Kind == "substitution" {
						p.walk(part.Tree, view, depth+1)
					}
				}
			}
		}
	}
}

func (p *shellPatternWalker) downloadPatterns(tree *shellsyntax.File, view source.View) {
	ctx, budget, out, seen := p.ctx, p.budget, &p.out, p.seen
	// Reuse the bounded download-to-execution analysis, including shell
	// continuations, quote concatenation, wrappers and stdio ownership.
	// Markdown candidates have their own mapped view; no flattened text
	// or fabricated offsets are needed.
	w := shellWalk{ctx: ctx, kind: "SH001", limit: budget + 1, view: view}
	w.list(tree, newShellState())

	out.Truncated = out.Truncated || w.result.Truncated || w.err != nil
	for _, m := range w.result.Matches {
		at := source.Span{Start: m.Start, End: m.End}
		if !seen[at] {
			if len(out.Matches) >= budget {
				out.Truncated = true
				return
			}

			seen[at] = true

			out.Matches = append(out.Matches, m)
		}
	}
}

func shellPatternWords(command *shellsyntax.Command, rule string) []string {
	words := make([]string, 0, len(command.Words))

	for _, word := range command.Words {
		v, ok := word.Literal()
		if !ok && rule == "RA2" {
			var literal strings.Builder

			ok = true

			for _, part := range word.Parts {
				if part.Kind != valueLiteral {
					ok = false
					break
				}

				literal.WriteString(part.Text)
			}

			v = literal.String()
		}

		if !ok {
			v = "__scout_unknown_word__"
		}

		if len(words) > 0 {
			v = strings.NewReplacer("\r", "__scout_word_break__", "\n", "__scout_word_break__").Replace(v)
		}

		words = append(words, v)
	}

	return words
}

func (p *shellPatternWalker) command(command *shellsyntax.Command, view source.View) bool {
	a, ctx, out, seen, budget := p.analyzer, p.ctx, &p.out, p.seen, p.budget

	words := shellPatternWords(command, a.spec.id)
	if len(words) > 0 {
		switch words[0] {
		case "curl", "wget", "rm", "chmod", "git", "cp", "mv", "install":
			r, _ := a.findText(ctx, strings.Join(words, " "), 1)
			if a.spec.id == "TM1" && words[0] == "rm" {
				r.Matches = nil
			}

			if len(r.Matches) > 0 || a.spec.id == "TM1" && unsafeRemoval(command) || a.spec.id == "RA2" && persistentCopy(words) {
				at, e := view.Original(command.Span)
				if e == nil && !seen[at] {
					seen[at] = true

					if len(out.Matches) >= budget {
						out.Truncated = true
						return false
					}

					out.Matches = append(out.Matches, Match{Start: at.Start, End: at.End})
				}
			}
		}
	}

	return true
}

func (p *shellPatternWalker) prose(text string) {
	a, ctx := p.analyzer, p.ctx

	offset := 0
	for offset < len(text) {
		if ctx.Err() != nil {
			return
		}

		lineEnd := len(text)
		if p := strings.IndexByte(text[offset:], '\n'); p >= 0 {
			lineEnd = offset + p + 1
		}

		end := lineEnd
		if proseShellStart.MatchString(text[offset:lineEnd]) || a.spec.id == valueSC2 && proseCompoundStart.MatchString(text[offset:lineEnd]) {
			p.proseSegment(text, offset, end)
		}

		offset = lineEnd
	}
}

func (p *shellPatternWalker) proseSegment(text string, offset, end int) {
	a, ctx := p.analyzer, p.ctx

	for range 8 {
		segment := text[offset:end]

		tree, err := shellsyntax.Parse(ctx, segment)
		if a.spec.id == valueSC2 {
			if parsed, e := shellsyntax.ParseDeclarations(ctx, segment); e == nil {
				tree, err = parsed, nil
			}
		}

		continued := end < len(text) && strings.HasSuffix(strings.TrimRight(segment, "\r\n"), `\`)
		if err == nil && !continued {
			view, e := source.NewView(text, []source.Span{{Start: offset, End: end}})
			if e == nil {
				p.walk(tree, view, 0)
			}

			break
		}

		if end == len(text) || end-offset > 8192 {
			break
		}

		p := strings.IndexByte(text[end:], '\n')
		if p < 0 {
			end = len(text)
		} else {
			end += p + 1
		}
	}
}

func persistentCopy(words []string) bool {
	if len(words) < 3 || (words[0] != "cp" && words[0] != "mv" && words[0] != "install") {
		return false
	}

	destination := words[len(words)-1]
	for _, root := range []string{"/.claude/skills/", "/.codex/skills/", "/.gemini/skills/", "/Library/LaunchAgents/", "/.config/autostart/"} {
		if strings.Contains(destination, root) {
			return true
		}
	}

	return false
}

func unsafeRemoval(command *shellsyntax.Command) bool {
	if len(command.Words) == 0 {
		return false
	}

	name, ok := command.Words[0].Literal()
	if !ok {
		return false
	}

	switch name {
	case "rm", "/bin/rm", "/usr/bin/rm", "del", "erase":
	default:
		return false
	}

	recursive, force, target, options := false, false, false, true

	for _, word := range command.Words[1:] {
		value, literal := word.Literal()
		if !literal {
			var plain bool

			value, plain = shellRemovalWord(word)
			if !plain {
				continue
			}
		}

		if options && literal && strings.HasPrefix(value, "-") {
			if value == "--" {
				options = false
				continue
			}

			if value == "--recursive" {
				recursive = true
				continue
			}

			if value == "--force" {
				force = true
				continue
			}

			if strings.HasPrefix(value, "--") {
				continue
			}

			recursive = recursive || strings.ContainsAny(value, "rR")
			force = force || strings.Contains(value, "f")

			continue
		}

		target = target || value == "/" || !word.Quoted && (value == "*" || value == "/*" || value == "~" || strings.HasPrefix(value, "~/"))
	}

	return recursive && force && target
}

func shellRemovalWord(word *shellsyntax.Word) (string, bool) {
	var b strings.Builder

	for _, p := range word.Parts {
		if p.Kind != valueLiteral {
			return "", false
		}

		b.WriteString(p.Text)
	}

	return b.String(), true
}
