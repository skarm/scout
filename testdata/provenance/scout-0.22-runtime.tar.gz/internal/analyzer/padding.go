// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Adapted P9 padding thresholds/guards; all offsets remain original UTF-8 bytes.

package analyzer

import (
	"context"
	"path"
	"regexp"
	"strings"
	"unicode"
	"unicode/utf8"
)

var (
	paddingLineBreak = regexp.MustCompile(`\r\n|[\r\n\x{85}\x{2028}\x{2029}]`)
	paddingDelimiter = regexp.MustCompile(`^[\t ]*:?-+:?[\t ]*$`)
)

type paddingLine struct {
	text       string
	start, end int
}

func paddingChar(r rune) bool {
	return r == ' ' || strings.ContainsRune("\t\n\r\v\f\u200b\u200c\u200d\u2060\ufeff\u0085\u180e", r) || unicode.In(r, unicode.Zs, unicode.Zl, unicode.Zp)
}

func paddingOnly(s string) bool {
	for _, r := range s {
		if !paddingChar(r) {
			return false
		}
	}

	return true
}

func paddingTablePipes(s string) ([]int, bool) {
	sTrim := strings.TrimSpace(s)
	if !strings.HasPrefix(sTrim, "|") || !strings.HasSuffix(sTrim, "|") {
		return nil, false
	}

	var out []int

	column := 0

	for _, r := range s {
		if r == '|' {
			out = append(out, column)
		}

		column++
	}

	return out, true
}

func paddingMatches(ctx context.Context, name, text string, budget int) (Result, error) {
	out := Result{}

	if budget < 1 {
		return Result{Truncated: true}, nil
	}

	name = path.Base(strings.ReplaceAll(name, "\\", "/"))
	for _, glob := range []string{"*.min.js", "*.min.css", "*.lock", "package-lock.json", "yarn.lock", "*.svg", "*.map"} {
		if ok, _ := path.Match(glob, name); ok {
			return out, nil
		}
	}

	chars := utf8.RuneCountInString(text)
	if chars == 0 || strings.Count(text, "\ufffd")*10 > chars*3 {
		return out, nil
	}

	emit := paddingEmitter(&out, budget)

	lines := paddingLines(text)
	if err := paddingLineRuns(ctx, lines, emit); err != nil {
		return out, err
	}

	markdown := strings.EqualFold(path.Ext(name), ".md") || strings.EqualFold(path.Ext(name), ".markdown")

	aligned := map[int]map[int]bool{}
	if markdown {
		aligned = paddingTableAlignment(lines)
	}

	if err := paddingColumns(ctx, lines, markdown, aligned, emit); err != nil {
		return out, err
	}

	if err := paddingRuneRuns(ctx, text, emit); err != nil {
		return out, err
	}

	for i := 0; i < len(lines); {
		j := i + 1
		for j < len(lines) && lines[j].text == lines[i].text && strings.TrimSpace(lines[i].text) != "" {
			j++
		}

		if j-i >= 64 {
			emit(lines[i].start, lines[j-1].end)
		}

		i = j
	}

	return out, ctx.Err()
}

func paddingEmitter(out *Result, budget int) func(int, int) {
	return func(start, end int) {
		if start >= end {
			return
		}

		for _, m := range out.Matches {
			if start < m.End && end > m.Start {
				return
			}
		}

		if len(out.Matches) >= budget {
			out.Truncated = true
			return
		}

		out.Matches = append(out.Matches, Match{Start: start, End: end})
	}
}

func paddingLines(text string) []paddingLine {
	breaks := paddingLineBreak.FindAllStringIndex(text, -1)
	lines := make([]paddingLine, 0, len(breaks)+1)

	start := 0
	for _, p := range breaks {
		lines = append(lines, paddingLine{text[start:p[0]], start, p[1]})
		start = p[1]
	}

	lines = append(lines, paddingLine{text[start:], start, len(text)})

	return lines
}

func paddingLineRuns(ctx context.Context, lines []paddingLine, emit func(int, int)) error {
	for i := 0; i < len(lines); {
		if ctx.Err() != nil {
			return ctx.Err()
		}

		if !paddingOnly(lines[i].text) {
			i++
			continue
		}

		j := i + 1
		for j < len(lines) && paddingOnly(lines[j].text) {
			j++
		}

		if j-i >= 20 {
			emit(lines[i].start, lines[j-1].end)
		}

		i = j
	}

	return nil
}

func paddingTableAlignment(lines []paddingLine) map[int]map[int]bool {
	aligned := map[int]map[int]bool{}

	for i := 0; i+1 < len(lines); i++ {
		hp, ok := paddingTablePipes(lines[i].text)

		dp, dok := paddingTablePipes(lines[i+1].text)
		if !ok || !dok || len(hp) != len(dp) {
			continue
		}

		cells := strings.Split(strings.TrimSpace(lines[i+1].text), "|")
		valid := true

		for _, c := range cells[1 : len(cells)-1] {
			if !paddingDelimiter.MatchString(c) {
				valid = false
				break
			}
		}

		if !valid {
			continue
		}

		set := func(row int, pipes []int) {
			aligned[row] = map[int]bool{}

			for k, p := range pipes {
				if p == dp[k] {
					aligned[row][p] = true
				}
			}
		}
		set(i, hp)

		j := i + 2
		for j < len(lines) {
			p, ok := paddingTablePipes(lines[j].text)
			if !ok || len(p) != len(dp) {
				break
			}

			set(j, p)
			j++
		}

		i = j - 1
	}

	return aligned
}

func paddingColumns(ctx context.Context, lines []paddingLine, markdown bool, aligned map[int]map[int]bool, emit func(int, int)) error {
	fence := byte(0)
	fenceWidth := 0

	for i, line := range lines {
		if ctx.Err() != nil {
			return ctx.Err()
		}

		trim := strings.TrimSpace(line.text)
		fenced := fence != 0

		if markdown && len(trim) >= 3 && (trim[0] == '`' || trim[0] == '~') {
			n := 0
			for n < len(trim) && trim[n] == trim[0] {
				n++
			}

			if n >= 3 {
				fenced = true

				if fence == 0 {
					fence = trim[0]
					fenceWidth = n
				} else if fence == trim[0] && n >= fenceWidth {
					fence = 0
				}
			}
		}

		if markdown && fenced {
			continue
		}

		paddingColumnRuns(line, aligned[i], emit)
	}

	return nil
}

func paddingColumnRuns(line paddingLine, aligned map[int]bool, emit func(int, int)) {
	runStart, count, column := -1, 0, 0
	onlySpaces := true

	flush := func(at int) {
		if count >= 80 && !(onlySpaces && aligned[column]) {
			emit(line.start+runStart, line.start+at)
		}

		runStart = -1
		count = 0
		onlySpaces = true
	}
	for at, r := range line.text {
		if paddingChar(r) {
			if runStart < 0 {
				runStart = at
			}

			count++
			onlySpaces = onlySpaces && r == ' '
		} else {
			flush(at)
		}

		column++
	}

	flush(len(line.text))
}

func paddingRuneRuns(ctx context.Context, text string, emit func(int, int)) error {
	runStart, runBytes, paddingBytes := -1, 0, 0
	repeatedStart, repeatedCount := 0, 0
	last := rune(-1)

	for at, r := range text {
		if at%4096 == 0 && ctx.Err() != nil {
			return ctx.Err()
		}

		size := utf8.RuneLen(r)
		if paddingChar(r) {
			paddingBytes += size

			if runStart < 0 {
				runStart = at
			}

			runBytes += size
		} else {
			if runBytes > 2048 {
				emit(runStart, at)
			}

			runStart = -1
			runBytes = 0
		}

		if r != last {
			if repeatedCount >= 512 && !paddingChar(last) {
				emit(repeatedStart, at)
			}

			repeatedStart = at
			repeatedCount = 0
		}

		repeatedCount++
		last = r
	}

	if runBytes > 2048 {
		emit(runStart, len(text))
	}

	if repeatedCount >= 512 && !paddingChar(last) {
		emit(repeatedStart, len(text))
	}

	if len(text) > 4096 && paddingBytes*10 > len(text)*9 {
		emit(0, len(text))
	}

	return nil
}
