// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Modified direct curl/wget/scp/rsync BH2 argument proofs.

package analyzer

import (
	"path"
	"regexp"
	"slices"
	"strings"
)

var (
	absoluteHome   = regexp.MustCompile(`^/(?:Users/[^/]+|home/[^/]+|root)(/.*)$`)
	sshDestination = regexp.MustCompile(`^(?:[A-Za-z0-9._-]+@)?(\[[0-9A-Fa-f:.]+\]|[A-Za-z0-9.-]+):[^\s]+$`)
)

func sensitiveAbsoluteFile(name string) bool {
	if strings.ContainsAny(name, "\x00\r\n$*?[]{}!\\") {
		return false
	}

	m := absoluteHome.FindStringSubmatch(path.Clean(name))
	if m == nil {
		return false
	}

	suffix := m[1]
	for _, dir := range []string{"/.ssh", "/.aws", "/.kube", "/.config/gcloud"} {
		if suffix == dir || strings.HasPrefix(suffix, dir+"/") {
			return true
		}
	}

	return slices.Contains([]string{"/.claude/settings.json", "/.claude/settings.local.json", "/.claude/.credentials.json", "/.docker/config.json", "/.netrc", "/.npmrc"}, suffix)
}

func directUploadArguments(event string, argv []string) bool {
	if len(argv) < 2 {
		return false
	}

	command := path.Base(argv[0])

	args := argv[1:]
	if command == "scp" || command == "rsync" {
		if len(args) != 2 || !sensitiveAbsoluteFile(args[0]) || strings.HasPrefix(args[1], "-") {
			return false
		}

		match := sshDestination.FindStringSubmatch(args[1])

		return match != nil && closedRemoteHost(strings.Trim(match[1], "[]"))
	}

	if command != valueCurl && command != valueWget {
		return false
	}

	proof := uploadProof{event: event, command: command}
	for i := 0; i < len(args); i++ {
		next, ok := proof.argument(args, i)
		if !ok {
			return false
		}

		i = next
	}

	return proof.sensitive && proof.remote == 1 && proof.sources == 1
}

type uploadProof struct {
	event, command  string
	remote, sources int
	sensitive       bool
}

func (p *uploadProof) argument(args []string, i int) (int, bool) {
	command := p.command

	arg := args[i]
	if command == valueCurl && (arg == "-s" || arg == "--silent" || arg == "-S" || arg == "--show-error" || arg == "-sS" || arg == "--fail") {
		return i, true
	}

	if command == valueCurl && arg == "-X" {
		if i+1 >= len(args) || args[i+1] != "POST" {
			return i, false
		}

		i++

		return i, true
	}

	if command == valueCurl && arg == valueURL {
		if i+1 >= len(args) || !externalHTTP(args[i+1]) {
			return i, false
		}

		p.remote++
		i++

		return i, true
	}

	return p.sourceArgument(args, i)
}

func (p *uploadProof) sourceArgument(args []string, i int) (int, bool) {
	command, arg := p.command, args[i]

	flag, value, inline := arg, "", false
	if strings.HasPrefix(arg, "--") {
		if before, after, ok := strings.Cut(arg, "="); ok {
			flag, value, inline = before, after, true
		}
	}

	data := command == valueCurl && (flag == "-d" || flag == valueData || flag == valueDataASCII || flag == valueDataBinary)
	upload := command == valueCurl && (flag == "-T" || flag == valueUploadFile)

	postFile := command == valueWget && (flag == "--post-file" || flag == "--body-file")
	if data || upload || postFile {
		p.sources++

		if !inline {
			if i+1 >= len(args) {
				return i, false
			}

			i++
			value = args[i]
		}

		if data {
			p.sensitive = (value == "@-" && sensitiveEvents[p.event]) || (strings.HasPrefix(value, "@") && sensitiveAbsoluteFile(value[1:]))
		}

		if upload {
			p.sensitive = (value == "-" && sensitiveEvents[p.event]) || sensitiveAbsoluteFile(value)
		}

		if postFile {
			p.sensitive = sensitiveAbsoluteFile(value)
		}

		return i, true
	}

	if externalHTTP(arg) {
		p.remote++
		return i, true
	}

	return i, false
}
