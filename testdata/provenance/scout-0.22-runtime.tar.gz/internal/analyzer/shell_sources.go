// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Adapted SC10 shell declarations, with bounded literal-only shell ownership.

package analyzer

import (
	"context"
	"maps"
	"path"
	"regexp"
	"strings"

	"github.com/skarm/scout/frontend"
	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/shellsyntax"
	"github.com/skarm/scout/internal/source"
)

var shellConfigVariable = regexp.MustCompile(`\$(?:\{[A-Za-z_][A-Za-z0-9_]*\}|[A-Za-z_][A-Za-z0-9_]*)`)

func sourceEnvKind(key string) string {
	key = strings.ToUpper(key)
	switch key {
	case "NPM_CONFIG_REGISTRY":
		return valueNpm
	case "PIP_INDEX_URL", "PIP_EXTRA_INDEX_URL", "PIP_FIND_LINKS", "UV_INDEX_URL", "UV_EXTRA_INDEX_URL", "UV_DEFAULT_INDEX", "UV_INDEX":
		return valuePyPI
	}

	if strings.HasPrefix(key, "CARGO_REGISTRIES_") && strings.HasSuffix(key, "_INDEX") {
		return "cargo"
	}

	return ""
}

func defaultShellSource(value, kind string) bool {
	if kind == "cargo" {
		v := strings.TrimRight(value, "/")
		return v == "sparse+https://index.crates.io" || v == "https://github.com/rust-lang/crates.io-index"
	}

	return defaultSource(value, kind)
}

func shellSourceDeclarations(ctx context.Context, d document.File, emit func(source.Span)) {
	for _, u := range d.Units() {
		t, ok := u.Tree.(parse.ShellTree)
		if !ok || t.Tree == nil {
			continue
		}

		tree := t.Tree

		if u.Status != "parsed_limited" {
			if parsed, err := shellsyntax.ParseDeclarations(ctx, u.View.Text()); err == nil {
				tree = parsed
			}
		}

		w := shellSourceWalker{ctx: ctx, unit: u, emit: emit, variables: map[string]string{}, functions: map[string]*shellsyntax.File{}}
		w.walk(tree, 0)
	}
}

type shellSourceWalker struct {
	ctx        context.Context
	unit       document.Unit
	emit       func(source.Span)
	operations int
	variables  map[string]string
	functions  map[string]*shellsyntax.File
}

func (w *shellSourceWalker) walk(tree *shellsyntax.File, depth int) {
	if tree == nil || depth > 32 {
		return
	}

	for _, statement := range tree.Statements {
		for _, command := range statement.Commands {
			w.operations++
			if w.operations > 8192 || w.ctx.Err() != nil {
				return
			}

			w.command(command, depth)
		}

		if statement.Next == "&&" || statement.Next == "||" || statement.Next == "&" || len(statement.Commands) > 1 {
			clear(w.variables)
		}
	}
}

func (w *shellSourceWalker) command(command *shellsyntax.Command, depth int) {
	u, emit := w.unit, w.emit
	mark := func(span source.Span) {
		if at, e := u.View.Original(span); e == nil {
			emit(at)
		}
	}

	if command.FunctionName != "" {
		w.functions[command.FunctionName] = command.FunctionBody
		// Observe potential declarations without committing effects of
		// an uncalled function to the surrounding script.
		w.isolated(command.FunctionBody, depth+1)

		return
	}

	for _, key := range command.Invalidates {
		if key == "*" {
			clear(w.variables)
		} else {
			delete(w.variables, key)
		}
	}

	if command.Group != nil {
		w.walk(command.Group, depth+1)
		return
	}

	if command.Prelude != nil {
		w.walk(command.Prelude, depth+1)
	}

	if len(command.Alternatives) > 0 {
		w.alternatives(command.Alternatives, depth)
		return
	}

	w.simpleCommand(command, depth, mark)
}

func (w *shellSourceWalker) isolated(tree *shellsyntax.File, depth int) {
	saved, savedFunctions := w.variables, w.functions
	w.variables, w.functions = maps.Clone(saved), maps.Clone(savedFunctions)
	w.walk(tree, depth)
	w.variables, w.functions = saved, savedFunctions
}

func (w *shellSourceWalker) alternatives(branches []*shellsyntax.File, depth int) {
	before := w.variables
	beforeFunctions := w.functions

	var (
		merged          map[string]string
		mergedFunctions map[string]*shellsyntax.File
	)

	for _, branch := range branches {
		w.variables = maps.Clone(before)
		w.functions = maps.Clone(beforeFunctions)
		w.walk(branch, depth+1)

		if merged == nil {
			merged = maps.Clone(w.variables)
			mergedFunctions = maps.Clone(w.functions)
		} else {
			for key, value := range merged {
				if other, ok := w.variables[key]; !ok || other != value {
					delete(merged, key)
				}
			}

			for key, body := range mergedFunctions {
				if w.functions[key] != body {
					delete(mergedFunctions, key)
				}
			}
		}
	}

	w.variables = merged
	w.functions = mergedFunctions
}

func (w *shellSourceWalker) simpleCommand(command *shellsyntax.Command, depth int, mark func(source.Span)) {
	variables := w.variables
	ctx, u := w.ctx, w.unit

	assignment := func(key, value string, known bool, span source.Span) {
		kind := sourceEnvKind(key)
		if kind != "" && (!known || !defaultShellSource(value, kind)) {
			mark(span)
		}
	}
	for _, a := range command.Assignments {
		value, known := sourceWord(a.Value, variables)
		assignment(a.Name, value, known, a.Span)

		if known && len(command.Words) == 0 && len(variables) < 256 {
			variables[a.Name] = value
		} else {
			delete(variables, a.Name)
		}
	}

	words := make([]string, 0, len(command.Words))
	known := make([]bool, 0, len(command.Words))

	for _, word := range command.Words {
		value, ok := sourceWord(word, variables)
		words = append(words, value)
		known = append(known, ok)

		for _, part := range word.Parts {
			if part.Tree != nil {
				w.isolated(part.Tree, depth+1)
			}
		}
	}

	binding := sourceBinding(command, words, known, assignment)

	if len(words) > 0 && words[0] == "export" {
		for i := 1; i < len(words); i++ {
			binding(i)
		}
	}

	at := sourceWrapperOffset(command, words, binding)
	if at < len(words) && w.sourceArguments(command, words[at:], known[at:], depth, mark) {
		return
	}

	generatedShellSources(ctx, command, u.View.Text(), variables, mark)

	if len(command.Words) > 0 {
		first, ok := command.Words[0].Literal()
		if !ok || (first != valueCat && first != valueTee && first != valuePrintf && first != valueEcho) {
			clear(variables)
		}
	}

	if command.Subshell != nil {
		w.isolated(command.Subshell, depth+1)
	}
}

func sourceBinding(command *shellsyntax.Command, words []string, known []bool, assignment func(string, string, bool, source.Span)) func(int) {
	return func(index int) {
		key, value, ok := strings.Cut(words[index], "=")
		if (!ok || key == "") && len(command.Words[index].Parts) > 0 {
			key, _, ok = strings.Cut(command.Words[index].Parts[0].Text, "=")
		}

		if ok {
			assignment(key, value, known[index], command.Span)
		}
	}
}

func sourceWrapperOffset(command *shellsyntax.Command, words []string, binding func(int)) int {
	at := 0
	for steps := 0; at < len(words) && steps < 16; steps++ {
		head := words[at]
		if head != valueEnv && head != valueCommand && head != valueSudo {
			break
		}

		at = sourceWrapperArguments(command, words, at+1, head, binding)
	}

	return at
}

func sourceWrapperArguments(command *shellsyntax.Command, words []string, at int, head string, binding func(int)) int {
	for at < len(words) {
		v := words[at]
		if head == valueCommand && (v == "-v" || v == "-V") || head == valueSudo && (v == "-V" || v == "-l" || v == "--version" || v == "--list") || head == valueEnv && (v == "-S" || v == "--split-string" || v == "--help" || v == "--version") {
			at = len(words)
			break
		}

		if v == "--" {
			at++
			break
		}

		if v == "-u" || v == "--unset" || v == "-C" || v == "--chdir" || head == valueSudo && (v == "-g" || v == "-h" || v == "-p") {
			at += 2
			continue
		}

		if strings.HasPrefix(v, "-") {
			at++
			continue
		}

		_, _, bound := strings.Cut(v, "=")
		if !bound && len(command.Words[at].Parts) > 0 {
			_, _, bound = strings.Cut(command.Words[at].Parts[0].Text, "=")
		}

		if bound && head != valueCommand {
			binding(at)
			at++

			continue
		}

		break
	}

	return at
}

func (w *shellSourceWalker) sourceArguments(command *shellsyntax.Command, args []string, flags []bool, depth int, mark func(source.Span)) bool {
	if args[0] == "poetry" {
		if len(args) >= 5 && args[1] == valueSource && args[2] == "add" && (!flags[len(args)-1] || !defaultSource(args[len(args)-1], valuePyPI)) {
			mark(command.Span)
		}

		if len(args) >= 4 && args[1] == valueConfig && strings.HasPrefix(args[2], "repositories.") && (!flags[3] || !defaultSource(args[3], valuePyPI)) {
			mark(command.Span)
		}
	}

	if args[0] == "mvn" || args[0] == "mvnw" {
		for _, arg := range args[1:] {
			if value, ok := strings.CutPrefix(arg, "-Dmaven.repo.remote="); ok && !strings.ContainsAny(value, " \t\r\n") && strings.TrimRight(value, "/") != "https://repo.maven.apache.org/maven2" && strings.TrimRight(value, "/") != "https://repo1.maven.org/maven2" {
				mark(command.Span)
			}
		}
	}

	if body := w.functions[args[0]]; body != nil && flags[0] {
		w.walk(body, depth+1)
		return true
	}

	observeInstallSources(command.Span, args, flags, mark)

	return false
}

func observeInstallSources(span source.Span, args []string, flags []bool, mark func(source.Span)) {
	if len(args) >= 3 && (args[0] == "python" || strings.HasPrefix(args[0], "python3")) && args[1] == "-m" && args[2] == valuePip {
		args = append([]string{valuePip}, args[3:]...)
		flags = append([]bool{true}, flags[3:]...)
	}

	if len(args) >= 5 && (args[0] == valueNpm || args[0] == "pnpm" || args[0] == "yarn") && args[1] == valueConfig && args[2] == valueSet && (args[3] == "registry" || args[3] == "npmRegistryServer") && (!flags[4] || !defaultShellSource(args[4], valueNpm)) {
		mark(span)
	}

	if len(args) > 1 && (args[0] == valuePip || args[0] == "pip3" || args[0] == "uv") {
		observePythonInstallSources(span, args, flags, mark)
	}
}

func observePythonInstallSources(span source.Span, args []string, flags []bool, mark func(source.Span)) {
	for i, arg := range args {
		for _, flag := range []string{"--index-url", "--extra-index-url", "--find-links", "-i", "-f"} {
			if arg == flag && i+1 < len(args) && (!flags[i+1] || !defaultShellSource(args[i+1], valuePyPI)) {
				mark(span)
			}

			if strings.HasPrefix(arg, flag+"=") && !defaultShellSource(strings.TrimPrefix(arg, flag+"="), valuePyPI) {
				mark(span)
			}
		}
	}

	if len(args) >= 5 && args[1] == valueConfig && args[2] == valueSet && (strings.HasSuffix(args[3], ".index-url") || strings.HasSuffix(args[3], ".extra-index-url")) && (!flags[4] || !defaultShellSource(args[4], valuePyPI)) {
		mark(span)
	}
}

// A literal config basename in an output redirection owns the heredoc body.
// This observes a possible declaration, without opening a file or running cat.
func generatedShellSources(ctx context.Context, command *shellsyntax.Command, text string, vars map[string]string, emit func(source.Span)) {
	if len(command.Words) == 0 {
		return
	}

	exe, ok := command.Words[0].Literal()
	if !ok || (exe != valueCat && exe != valueTee) {
		return
	}

	if exe == valueCat {
		if !sourceCatReadsStdin(command.Words[1:]) {
			return
		}
	}

	names := generatedConfigNames(command, exe, vars)

	stdin, stdout := generatedRedirects(command)
	if stdin == nil || stdin.Body == nil {
		return
	}

	for _, r := range command.Redirects {
		if r == stdout && (r.Op == ">" || r.Op == ">>") && r.Target != nil {
			var b strings.Builder

			for _, part := range r.Target.Parts {
				if part.Kind == valueLiteral {
					b.WriteString(part.Text)
				} else {
					b.WriteByte('$')
				}
			}

			if name := generatedConfigName(b.String()); name != "" {
				names = append(names, name)
			}
		}
	}

	generatedBodySources(ctx, stdin, names, text, vars, emit)
}

func sourceCatReadsStdin(words []*shellsyntax.Word) bool {
	stdin, operand := false, false

	for _, word := range words {
		value, literal := word.Literal()
		if !literal {
			return false
		}

		if value == "-" {
			stdin = true
		}

		if value != "--" && !strings.HasPrefix(value, "-") {
			operand = true
		}
	}

	return !operand || stdin
}

func generatedConfigNames(command *shellsyntax.Command, exe string, vars map[string]string) []string {
	names := []string{}

	if exe == valueTee {
		for _, word := range command.Words[1:] {
			value, known := sourceWord(word, vars)
			if known && !strings.HasPrefix(value, "-") {
				if name := generatedConfigName(value); name != "" {
					names = append(names, name)
				}
			}
		}
	}

	return names
}

func generatedConfigName(value string) string {
	name := strings.ToLower(path.Base(value))
	if name == valueConfigToml && !strings.Contains(value, ".cargo/") {
		return ""
	}

	switch name {
	case ".npmrc", valueYarnrc, "pip.conf", "pip.ini", "pyproject.toml", ".yarnrc.yml", ".yarnrc.yaml", "settings.xml", "pom.xml", "nuget.config", valueConfigToml, "pipfile", "pipfile.lock", "uv.lock", "poetry.lock":
		// Retain .cargo/ for the existing namespace-aware config analyzer.
		if name == valueConfigToml {
			name = ".cargo/config.toml"
		}

		return name
	}

	return ""
}

func generatedRedirects(command *shellsyntax.Command) (*shellsyntax.Redirect, *shellsyntax.Redirect) {
	var (
		stdin  *shellsyntax.Redirect
		stdout *shellsyntax.Redirect
	)

	for _, r := range command.Redirects {
		if (r.FD == "" || r.FD == "0") && (r.Body != nil || r.Op == "<" || r.Op == "<&") {
			stdin = r
		}

		if (r.FD == "" || r.FD == "1") && (r.Op == ">" || r.Op == ">>" || r.Op == ">&") {
			stdout = r
		}
	}

	return stdin, stdout
}

func generatedBodySources(ctx context.Context, r *shellsyntax.Redirect, names []string, text string, vars map[string]string, emit func(source.Span)) {
	if r.Body == nil || r.Body.Span.Start < 0 || r.Body.Span.End > len(text) {
		return
	}

	body := text[r.Body.Span.Start:r.Body.Span.End]
	if !r.QuotedDelimiter {
		body = expandShellConfig(body, vars)
	}

	for _, name := range names {
		registry, err := parse.WithFrontends(frontend.Options{YAML: true, TOML: true, Timeout: frontend.DefaultOptions().Timeout})
		if err != nil {
			continue
		}

		files := document.PrepareAllWithRegistry(ctx, []artifact.File{artifact.NewFile(name, []byte(body), false)}, registry)

		result, err := (sourceRedirection{}).FindDocument(ctx, files[0], 1)
		if err == nil && len(result.Matches) > 0 {
			emit(r.Body.Span)
		}
	}
}

func expandShellConfig(original string, vars map[string]string) string {
	var expanded strings.Builder

	previous := 0
	for _, at := range shellConfigVariable.FindAllStringIndex(original, -1) {
		expanded.WriteString(original[previous:at[0]])
		token := original[at[0]:at[1]]

		backslashes := 0
		for i := at[0] - 1; i >= 0 && original[i] == '\\'; i-- {
			backslashes++
		}

		key := strings.TrimSuffix(strings.TrimPrefix(strings.TrimPrefix(token, "$"), "{"), "}")
		if v, ok := vars[key]; ok && backslashes%2 == 0 {
			expanded.WriteString(v)
		} else {
			expanded.WriteString(token)
		}

		previous = at[1]
	}

	expanded.WriteString(original[previous:])

	return expanded.String()
}

func sourceWord(word *shellsyntax.Word, variables map[string]string) (string, bool) {
	if word == nil || word.Expands {
		return "", false
	}

	var b strings.Builder

	for _, p := range word.Parts {
		switch p.Kind {
		case valueLiteral:
			b.WriteString(p.Text)
		case valueParameter:
			value, ok := variables[p.Text]
			if !ok {
				return "", false
			}

			b.WriteString(value)
		default:
			return "", false
		}

		if b.Len() > 8192 {
			return "", false
		}
	}

	return b.String(), true
}
