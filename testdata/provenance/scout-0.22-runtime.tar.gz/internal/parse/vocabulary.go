package parse

// Shared vocabulary used by this package's protocols and reports.
const (
	valueAmbiguousConfiguration = "ambiguous_configuration"
	valueParserLimit            = "parser_limit"
	languagePython              = "python"
	valueUnsupportedSyntax      = "unsupported_syntax"
)
