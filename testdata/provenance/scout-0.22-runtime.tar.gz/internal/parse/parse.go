// Package parse dispatches trusted, language-specific parsers. Registration is
// immutable and local to a preparation pass, not a dynamically loaded plugin API.
package parse

import (
	"context"
	"errors"
	"go/ast"
	"go/parser"
	"go/token"
	"strings"

	"golang.org/x/mod/modfile"

	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/language"
	"github.com/skarm/scout/internal/modconfig"
	"github.com/skarm/scout/internal/shellsyntax"
	"github.com/skarm/scout/internal/source"
)

const (
	MaxUnitBytes = 256 << 10
	MaxScanBytes = 2 << 20
)

type Descriptor struct {
	ID, Language, Version string
	UnitBytes, ScanBytes  int
}

type Backend interface {
	Descriptor() Descriptor
	// The value is an immutable, backend-specific tree consumed by matching
	// analyzers. An error may accompany a usable partial tree. Errors are never
	// echoed to reports, because a parser may include input contents in them.
	Parse(context.Context, source.View) (any, error)
}

type Registry struct{ backends map[string]Backend }

func New(backends ...Backend) (Registry, error) {
	r := Registry{backends: make(map[string]Backend, len(backends))}
	for _, b := range backends {
		if b == nil {
			return Registry{}, errors.New("nil parser backend")
		}

		d := b.Descriptor()
		if d.ID == "" || d.Version == "" || language.Normalize(d.Language) != d.Language || !language.Structured(d.Language) ||
			d.UnitBytes < 1 || d.UnitBytes > MaxUnitBytes || d.ScanBytes < d.UnitBytes || d.ScanBytes > MaxScanBytes {
			return Registry{}, errors.New("invalid parser descriptor")
		}

		if _, ok := r.backends[d.Language]; ok {
			return Registry{}, errors.New("duplicate language backend")
		}

		r.backends[d.Language] = b
	}

	return r, nil
}

func Defaults() Registry {
	r, _ := New(goBackend{}, shellBackend{}, jsonBackend{}, goModBackend{})
	return r
}
func (r Registry) Lookup(id string) (Backend, bool) { b, ok := r.backends[id]; return b, ok }

type GoTree struct {
	Tree   *ast.File
	Tokens *token.FileSet
}
type goBackend struct{}

func (goBackend) Descriptor() Descriptor {
	return Descriptor{"go-stdlib", "go", "1", MaxUnitBytes, MaxScanBytes}
}

func (goBackend) Parse(ctx context.Context, v source.View) (any, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}

	fs := token.NewFileSet()
	tree, err := parser.ParseFile(fs, "", v.Text(), parser.AllErrors)

	return GoTree{tree, fs}, err
}

// ShellTree is a native bounded grammar, not a full POSIX/Bash compatibility claim.
type (
	ShellTree    struct{ Tree *shellsyntax.File }
	shellBackend struct{}
)

func (shellBackend) Descriptor() Descriptor {
	return Descriptor{"shell-native-subset", "shell", "4", shellsyntax.MaxBytes, MaxScanBytes}
}

func (shellBackend) Parse(ctx context.Context, v source.View) (any, error) {
	tree, err := shellsyntax.Parse(ctx, v.Text())
	if err != nil {
		if syntaxErr, ok := errors.AsType[*shellsyntax.Error](err); ok {
			category := "syntax_error"
			if strings.HasPrefix(syntaxErr.Code, "unsupported_") {
				category = valueUnsupportedSyntax
			}

			if strings.HasSuffix(syntaxErr.Code, "_limit") {
				category = valueParserLimit
			}

			err = &Failure{Category: category}
		}
	}

	return ShellTree{Tree: tree}, err
}

// Failure gives preparation a finite, source-free classification. Arbitrary
// parser error strings are never forwarded into reports.
type Failure struct{ Category string }

func (f *Failure) Error() string { return "parser failure" }
func FailureCategory(err error) string {
	if failure, ok := errors.AsType[*Failure](err); ok {
		switch failure.Category {
		case valueUnsupportedSyntax, valueParserLimit, valueAmbiguousConfiguration, "backend_unavailable":
			return failure.Category
		}
	}

	return "syntax_error"
}

// JSONTree uses a strict bounded standard-library token decoder, not a runtime
// config loader. No key can change scanner policy or enable tools.
type JSONTree struct {
	Root            *jsonconfig.Node
	Runtime, Format string
}

func (t JSONTree) RuntimeIdentity() string { return t.Runtime }

type jsonBackend struct{}

func (jsonBackend) Descriptor() Descriptor {
	return Descriptor{"json-stdlib-strict", "json", "1", jsonconfig.MaxBytes, MaxScanBytes}
}

func (jsonBackend) Parse(ctx context.Context, v source.View) (any, error) {
	root, err := jsonconfig.Parse(ctx, v.Text())
	if err != nil {
		if e, ok := errors.AsType[*jsonconfig.Error](err); ok {
			if strings.HasSuffix(e.Code, "_limit") {
				err = &Failure{Category: valueParserLimit}
			}

			if e.Code == "duplicate_key" {
				err = &Failure{Category: valueAmbiguousConfiguration}
			}
		}

		return nil, err
	}

	return JSONTree{Root: root, Format: "json"}, nil
}

// GoModTree is parsed from captured bytes, without go list, module resolution,
// downloading dependencies or executing tools/toolchains declared in the file.
type (
	GoModTree    struct{ File *modfile.File }
	goModBackend struct{}
)

func (goModBackend) Descriptor() Descriptor {
	return Descriptor{"go-mod-xmod", "gomod", "0.19.0-adapter1", modconfig.MaxBytes, MaxScanBytes}
}

func (goModBackend) Parse(ctx context.Context, v source.View) (any, error) {
	f, err := modconfig.Parse(ctx, v.Text())
	if err != nil {
		if e, ok := errors.AsType[*modconfig.Error](err); ok {
			if strings.HasSuffix(e.Code, "_limit") {
				return nil, &Failure{Category: valueParserLimit}
			}

			if strings.HasPrefix(e.Code, "duplicate_") {
				return nil, &Failure{Category: valueAmbiguousConfiguration}
			}
		}

		return nil, err
	}

	return GoModTree{File: f}, nil
}
