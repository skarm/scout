package parse

import (
	"context"
	"errors"

	"github.com/skarm/scout/frontend"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/source"
)

type embeddedBackend struct {
	lang    string
	options frontend.Options
}

type PythonTree struct {
	Root    *frontend.Node
	Runtime string
}

// WithFrontends keeps every default backend. Optional parsers are compiled
// capabilities; no source file can start an interpreter or choose a library path.
func WithFrontends(o frontend.Options) (Registry, error) {
	if err := o.Validate(); err != nil {
		return Registry{}, err
	}

	backends := []Backend{goBackend{}, shellBackend{}, jsonBackend{}, goModBackend{}}

	for _, item := range []struct {
		language string
		enabled  bool
	}{{languagePython, o.Python}, {"yaml", o.YAML}, {"toml", o.TOML}} {
		if item.enabled {
			backends = append(backends, embeddedBackend{item.language, o})
		}
	}

	return New(backends...)
}

func (b embeddedBackend) Descriptor() Descriptor {
	backend := frontend.BackendFor(b.lang)
	return Descriptor{backend.Name, b.lang, backend.Version + "-adapter-v5", MaxUnitBytes, MaxScanBytes}
}

func (b embeddedBackend) Parse(ctx context.Context, v source.View) (any, error) {
	r, e := frontend.Parse(ctx, b.options, b.lang, v.Text())
	if e != nil {
		var f *frontend.Failure
		if b.lang == languagePython && r.AST != nil && errors.As(e, &f) && f.Category == "unsupported_projection" {
			return PythonTree{Root: r.AST, Runtime: r.RuntimeIdentity()}, &Failure{Category: valueUnsupportedSyntax}
		}

		if errors.As(e, &f) && f.Category == "unavailable" {
			return nil, &Failure{Category: "backend_unavailable"}
		}

		if errors.As(e, &f) && f.Category == "ambiguous_key" {
			return nil, &Failure{Category: valueAmbiguousConfiguration}
		}

		if errors.As(e, &f) && (f.Category == "input_limit" || f.Category == "output_limit" || f.Category == "limit" || f.Category == "deadline") {
			return nil, &Failure{Category: valueParserLimit}
		}

		return nil, &Failure{Category: valueUnsupportedSyntax}
	}

	if b.lang == languagePython {
		return PythonTree{Root: r.AST, Runtime: r.RuntimeIdentity()}, nil
	}

	var convert func(*frontend.ConfigNode) *jsonconfig.Node

	convert = func(n *frontend.ConfigNode) *jsonconfig.Node {
		if n == nil {
			return nil
		}

		out := &jsonconfig.Node{Kind: n.Kind, Span: source.Span{Start: n.Start, End: n.End}, String: n.Text, Bool: n.Bool}
		for _, m := range n.Members {
			out.Members = append(out.Members, jsonconfig.Member{Key: m.Key, KeySpan: source.Span{Start: m.Start, End: m.End}, Value: convert(m.Value)})
		}

		for _, v := range n.Elements {
			out.Elements = append(out.Elements, convert(v))
		}

		return out
	}

	return JSONTree{Root: convert(r.Config), Runtime: r.RuntimeIdentity(), Format: b.lang}, nil
}

func (t PythonTree) RuntimeIdentity() string { return t.Runtime }
