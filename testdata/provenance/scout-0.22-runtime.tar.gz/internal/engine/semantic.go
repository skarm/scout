package engine

import (
	"sort"

	"github.com/skarm/scout/internal/model"
)

// Propagate task failures to the corresponding file scopes. The semantic child
// ledger remains authoritative; this view must not show successful per-file
// coverage when the requested semantic pass failed for that file.
func semanticFileCoverage(r *model.Report) {
	if !r.Semantic.Enabled {
		return
	}

	byPath := map[string]*model.FileCoverage{}
	for i := range r.Coverage.Files {
		byPath[r.Coverage.Files[i].Path] = &r.Coverage.Files[i]
	}

	outcomes := map[string]model.SemanticOutcome{}
	for _, o := range r.Semantic.Outcomes {
		outcomes[o.TaskID] = o
	}

	checks := map[string]map[string]string{}

	for _, task := range r.Semantic.Tasks {
		status := "missing"
		if o, ok := outcomes[task.ID]; ok {
			status = o.Status
		}

		for _, input := range task.Inputs {
			path := input.Source.Path
			if checks[path] == nil {
				checks[path] = map[string]string{}
			}

			id := "semantic_" + task.Mode + "_v" + r.Semantic.ProtocolVersion

			old, ok := checks[path][id]
			if !ok || semanticStatusRank(status) > semanticStatusRank(old) {
				checks[path][id] = status
			}
		}
	}

	for path, modes := range checks {
		if fc := byPath[path]; fc != nil {
			for id, status := range modes {
				fc.Checks = append(fc.Checks, model.FileCheck{AnalyzerID: id, Status: status})
				if status != valueCompleted {
					fc.Completeness = model.Partial
					fc.Gaps = append(fc.Gaps, id+":"+status)
				}
			}
		}
	}

	applySemanticGaps(r, byPath)
	sortSemanticCoverage(byPath)
}

func sortSemanticCoverage(byPath map[string]*model.FileCoverage) {
	for _, fc := range byPath {
		sort.Slice(fc.Checks, func(i, j int) bool { return fc.Checks[i].AnalyzerID < fc.Checks[j].AnalyzerID })
		sort.Strings(fc.Gaps)

		unique := fc.Gaps[:0]
		for _, s := range fc.Gaps {
			if len(unique) == 0 || unique[len(unique)-1] != s {
				unique = append(unique, s)
			}
		}

		fc.Gaps = unique
	}
}

func semanticStatusRank(status string) int {
	switch status {
	case valueCompleted:
		return 0
	case statusPartial:
		return 1
	default:
		return 2
	}
}

func applySemanticGaps(r *model.Report, byPath map[string]*model.FileCoverage) {
	proposals := make(map[string]model.SemanticProposal, len(r.Semantic.Proposals))
	for _, p := range r.Semantic.Proposals {
		proposals[p.ID] = p
	}

	for _, gap := range r.Semantic.Gaps {
		if p, ok := proposals[gap.ProposalID]; ok {
			for _, e := range p.Evidence {
				if fc := byPath[e.Path]; fc != nil {
					fc.Completeness = model.Partial
					fc.Gaps = append(fc.Gaps, "semantic:"+gap.Code)
				}
			}
		}

		if fc := byPath[gap.Path]; fc != nil {
			fc.Completeness = model.Partial
			fc.Gaps = append(fc.Gaps, "semantic:"+gap.Code)
		}
	}
}
