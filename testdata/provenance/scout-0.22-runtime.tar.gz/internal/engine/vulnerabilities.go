package engine

import (
	"context"
	"time"

	"github.com/skarm/scout/internal/analyzer"
	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/vulnerability"
)

//nolint:gochecknoglobals // Immutable rule template; callers receive deep copies through VulnerabilityRule.
var vulnerabilityRule = model.WithGuidance(model.Rule{ID: valueOSV001, Version: "1", Title: "Known vulnerability for an exact declared package coordinate", Description: "The explicitly selected database reported an advisory for the captured exact package version.", Severity: model.High, Category: "known-vulnerable-dependency", Method: "exact-coordinate-vulnerability-lookup", Limitation: "Database match is not proof of installation, reachability or exploitability. Range-only and unresolved Go MVS versions are not queried."})

// VulnerabilityRule returns a copy for rule-catalog inspection without network access.
func VulnerabilityRule() model.Rule { return model.CloneRule(vulnerabilityRule) }

func applyVulnerabilities(ctx context.Context, r *model.Report, docs []document.File, o vulnerability.Options, budget int) {
	v, err := vulnerability.Check(ctx, r.Dependencies, o, time.Now())

	r.Vulnerabilities = v
	if err != nil {
		r.Vulnerabilities.Completeness = model.Failed
		r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: "vulnerability_failed", Message: "Requested vulnerability lookup failed; no clean result can be inferred.", AffectsScope: true})
	}

	if !o.Enabled {
		return
	}

	r.Profile += "+osv-v1"
	r.Rules = append(r.Rules, model.CloneRule(vulnerabilityRule))
	byID := map[string]model.Dependency{}
	byPath := map[string]document.File{}

	for _, d := range r.Dependencies.Declarations {
		byID[d.ID] = d
	}

	for _, d := range docs {
		byPath[d.Artifact().Metadata().Path] = d
	}

	for _, v := range r.Vulnerabilities.Matches {
		for _, id := range v.DependencyIDs {
			d, ok := byID[id]
			if !ok {
				r.Vulnerabilities.Completeness = model.Partial
				continue
			}

			doc, ok := byPath[d.Source.Path]
			if !ok {
				r.Vulnerabilities.Completeness = model.Partial
				continue
			}

			if len(r.Findings) >= budget {
				r.Vulnerabilities.Completeness = model.Partial
				r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: "vulnerability_finding_limit", Path: d.Source.Path, Message: "Additional vulnerability findings exceeded the shared finding budget; database matches remain in the vulnerability report.", AffectsScope: true})

				continue
			}

			f, e := makeFinding(vulnerabilityRule, doc, analyzer.Match{Start: d.Source.ByteStart, End: d.Source.ByteEnd})
			if e != nil {
				r.Vulnerabilities.Completeness = model.Partial
				continue
			}

			f.ID = artifact.Hash([]byte(f.ID + "\x00" + v.ID))
			f.AdvisoryIDs = []string{v.ID}
			r.Findings = append(r.Findings, f)
		}
	}

	if r.Vulnerabilities.Completeness != model.Complete {
		r.Coverage.Completeness = model.Partial
		r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: "vulnerability_incomplete", Message: "Some requested dependency coordinates, pages or database results are unresolved; see per-query outcomes.", AffectsScope: true})
	}

	applyVulnerabilityCoverage(r, byID)
}

func applyVulnerabilityCoverage(r *model.Report, byID map[string]model.Dependency) {
	fc := map[string]*model.FileCoverage{}
	for i := range r.Coverage.Files {
		fc[r.Coverage.Files[i].Path] = &r.Coverage.Files[i]
	}

	for _, q := range r.Vulnerabilities.Queries {
		if d, ok := byID[q.DependencyID]; ok {
			if f := fc[d.Source.Path]; f != nil {
				f.Checks = append(f.Checks, model.FileCheck{AnalyzerID: valueOSV001, Status: q.Status})
				if q.Status != valueCompleted && q.Status != "cached" {
					f.Completeness = model.Partial
					f.Gaps = append(f.Gaps, "OSV001:"+q.Status)
				}
			}
		}
	}

	status := valueCompleted
	if r.Vulnerabilities.Completeness != model.Complete {
		status = statusPartial
	}

	r.Coverage.Checks = append(r.Coverage.Checks, model.Check{AnalyzerID: valueOSV001, Version: "1", Status: status, FilesTotal: len(r.Dependencies.Manifests), Findings: len(r.Vulnerabilities.Matches), Detail: "Per-coordinate plan and outcomes are in vulnerabilities.queries; not every declaration has an exact version."})
}
