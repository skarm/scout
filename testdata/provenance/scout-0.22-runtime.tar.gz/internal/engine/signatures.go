package engine

import (
	"context"

	"github.com/skarm/scout/internal/analyzer"
	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/signatures"
)

func SignatureRules() []model.Rule {
	out := make([]model.Rule, 0, 5)

	for _, x := range []struct{ id, title string }{{"YR1", "YARA-X malware-category signature"}, {"YR2", "YARA-X webshell-category signature"}, {"YR3", "YARA-X cryptominer-category signature"}, {"YR4", "YARA-X hack-tool or exploit-category signature"}, {"YR5", "YARA-X uncategorized operator signature"}} {
		severity := model.High
		if x.id == "YR5" {
			severity = model.Medium
		}

		out = append(out, model.Rule{ID: x.id, Version: "3", Title: x.title, Description: x.title, Severity: severity, Category: "signature-match", Method: "embedded-yara-x", Limitation: "Embedded YARA-X engine; native availability is explicit; twenty-seven bundled SkillSpector malware/agent/webshell/hacktool/cryptominer rules plus optional trusted operator rules. A match is not a verdict about intent; broad tool references/examples can match. External corpora are not bundled. Category severity is scanner-owned, not source-controlled metadata."})
	}

	for i := range out {
		out[i] = model.WithGuidance(out[i])
	}

	return out
}

func applySignatures(ctx context.Context, r *model.Report, docs []document.File, o signatures.Options, budget int) {
	inputs := make([]signatures.Input, 0, len(docs))
	byPath := map[string]document.File{}

	for _, d := range docs {
		m := d.Artifact().Metadata()
		inputs = append(inputs, signatures.Input{Path: m.Path, SHA256: m.SHA256, Data: d.Artifact().Content()})
		byPath[m.Path] = d
	}

	out, err := signatures.Check(ctx, inputs, o)
	r.Signatures = out

	if !o.Enabled {
		return
	}

	r.Profile += "+yara-x-v2"
	rules := SignatureRules()
	r.Rules = append(r.Rules, rules...)

	partial := err != nil || out.Completeness != "complete"
	for _, step := range out.Outcomes {
		for _, m := range step.Matches {
			i := 4

			switch m.Category {
			case "malware":
				i = 0
			case "webshell":
				i = 1
			case "cryptominer":
				i = 2
			case "hack_tool", "exploit":
				i = 3
			}

			if len(r.Findings) >= budget {
				partial = true
				continue
			}

			doc, ok := byPath[step.Path]
			if !ok || len(m.Spans) == 0 {
				partial = true
				continue
			}
			// A complete YARA-X condition is supported by all reported string spans, not
			// by pretending that one substring independently establishes that condition.
			match := analyzer.Match{Start: m.Spans[0].Start, End: m.Spans[0].End}
			for _, s := range m.Spans[1:] {
				b := doc.Artifact().Content()
				if s.Start < 0 || s.End > len(b) || s.Start >= s.End {
					partial = true
					continue
				}

				match.Related = append(match.Related, model.SourceRef{Path: step.Path, SHA256: step.SHA256, ByteStart: s.Start, ByteEnd: s.End, SpanSHA256: artifact.Hash([]byte(b[s.Start:s.End]))})
			}

			f, e := makeFinding(rules[i], doc, match)
			if e != nil {
				partial = true
				continue
			}

			f.ID = artifact.Hash([]byte(f.ID + "\x00" + r.Signatures.RulesSHA256 + "\x00" + m.Rule))
			f.SignatureNames = []string{m.Rule}

			f.RelatedEvidence = append([]model.SourceRef(nil), match.Related...)
			r.Findings = append(r.Findings, f)
		}

		signatureFileCoverage(r, step)
	}

	status := valueCompleted
	if partial {
		status = statusPartial
		r.Coverage.Completeness = model.Partial
		r.Signatures.Completeness = statusPartial
		r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: "yara_incomplete", Message: "Requested YARA-X inspection is unavailable, limited, failed or has invalid evidence; see its fixed input plan and outcomes.", AffectsScope: true})
	}

	r.Coverage.Checks = append(r.Coverage.Checks, model.Check{AnalyzerID: "yara-x", Version: "2", Status: status, FilesTotal: len(inputs), Detail: "Plan and per-object outcomes are in signatures; target contents were not executed."})
}

func signatureFileCoverage(r *model.Report, step signatures.Outcome) {
	for i := range r.Coverage.Files {
		fc := &r.Coverage.Files[i]
		if fc.Path != step.Path {
			continue
		}

		fc.Checks = append(fc.Checks, model.FileCheck{AnalyzerID: "yara-x", Status: step.Status})
		if step.Status != valueCompleted || step.Truncated {
			fc.Completeness = model.Partial
			fc.Gaps = append(fc.Gaps, "yara:"+step.Status)
		}

		return
	}
}
