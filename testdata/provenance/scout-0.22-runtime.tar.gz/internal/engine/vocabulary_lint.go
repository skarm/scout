package engine

// Shared vocabulary used by this package's protocols and reports.
const (
	valueNotApplicable = "not_applicable"
)
