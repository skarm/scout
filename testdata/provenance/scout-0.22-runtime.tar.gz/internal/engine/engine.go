// Package engine executes trusted checks over one immutable artifact snapshot.
package engine

import (
	"context"
	"errors"
	"fmt"
	"slices"
	"sort"
	"strconv"
	"strings"
	"sync"
	"unicode/utf8"

	"github.com/skarm/scout/internal/analyzer"
	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/dependencies"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/extract"
	"github.com/skarm/scout/internal/filetype"
	"github.com/skarm/scout/internal/harness"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/metadata"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/policy"
	"github.com/skarm/scout/internal/semantic"
	"github.com/skarm/scout/internal/shellsyntax"
	"github.com/skarm/scout/internal/source"
	"github.com/skarm/scout/internal/validation"
	"github.com/skarm/scout/knowledge"
	"github.com/skarm/scout/review"
	"github.com/skarm/scout/signatures"
	"github.com/skarm/scout/vulnerability"
)

type Engine struct {
	signatures signatures.Options
	registry   parse.Registry
	analyzers  []analyzer.Analyzer
	rules      []model.Rule
	workers    int
}
type outcome struct {
	findings    []model.Finding
	check       model.Check
	diagnostics []model.Diagnostic
	fileChecks  []model.FileCheck
}

// RunOptions contains trusted per-scan configuration. Keeping it in one value
// makes every execution path use the same services without a ladder of wrappers.
// Callers must supply validated budgets; zero values never enable a service.
type RunOptions struct {
	Limits          model.Limits
	Policy          model.Policy
	Extraction      model.ExtractionLimits
	Harness         model.HarnessOptions
	Semantic        review.Options
	Provider        review.Provider
	Vulnerabilities vulnerability.Options
}

func New(checks []analyzer.Analyzer, workers int) (*Engine, error) {
	return NewWithRegistry(checks, workers, parse.Defaults())
}

func NewWithRegistry(checks []analyzer.Analyzer, workers int, r parse.Registry) (*Engine, error) {
	if workers < 1 || workers > 32 {
		return nil, errors.New("workers must be in 1..32")
	}

	if len(checks) == 0 || len(checks) > 256 {
		return nil, errors.New("need 1..256 analyzers")
	}

	seen := make(map[string]bool, len(checks))

	rules := make([]model.Rule, len(checks))
	for i, a := range checks {
		if a == nil {
			return nil, errors.New("nil analyzer")
		}

		r := model.WithGuidance(a.Rule())
		if r.ID == "" || r.Version == "" || r.Severity.Rank() < 0 || seen[r.ID] {
			return nil, errors.New("invalid or duplicate analyzer descriptor")
		}

		seen[r.ID] = true
		rules[i] = r
	}

	return &Engine{signatures: signatures.DefaultOptions(), registry: r, analyzers: append([]analyzer.Analyzer(nil), checks...), rules: rules, workers: workers}, nil
}

// WithSignatures returns a new immutable engine configuration.
func (e *Engine) WithSignatures(o signatures.Options) (*Engine, error) {
	if err := o.Validate(); err != nil {
		return nil, err
	}

	o.ExtraRules = append([]byte(nil), o.ExtraRules...)
	n := *e
	n.signatures = o

	return &n, nil
}

// Run executes one snapshot under the caller's explicit service selection.
func (e *Engine) Run(ctx context.Context, s artifact.Snapshot, options RunOptions) (model.Report, error) {
	if err := options.Vulnerabilities.Validate(); err != nil {
		return model.Report{}, err
	}

	if err := options.Semantic.Validate(); err != nil {
		return model.Report{}, err
	}

	if err := options.Harness.Validate(); err != nil {
		return model.Report{}, err
	}

	if ctx == nil {
		return model.Report{}, errors.New("nil context")
	}

	if err := options.Limits.Validate(); err != nil {
		return model.Report{}, err
	}

	if err := options.Policy.Validate(); err != nil {
		return model.Report{}, err
	}

	files := s.Files()
	capturedCount := len(files)

	expanded, extractionErr := extract.Expand(ctx, files, options.Extraction)
	if extractionErr != nil && ctx.Err() == nil {
		return model.Report{}, extractionErr
	}

	files = append(files, expanded.Files...)
	documents := document.PrepareAllWithRegistry(ctx, files, e.registry)
	graph := harness.Discover(ctx, s.Metadata().Files, documents, expanded.Report, options.Harness)
	documents = harness.ApplyConfigScopes(documents, graph)
	checks := analyzer.BindContexts(ctx, e.analyzers, documents, expanded.Report)
	checks = analyzer.BindGraph(checks, documents, graph)

	inputs := make([]model.File, len(files))
	for i, f := range files {
		inputs[i] = f.Metadata()
	}

	ledger := validation.NewWithSemantic(inputs, e.rules, graph, options.Semantic.Enabled)
	results := make([]outcome, len(e.analyzers))
	jobs := make(chan int)

	var wg sync.WaitGroup
	for w := 0; w < min(e.workers, len(e.analyzers)); w++ {
		wg.Go(func() {
			for i := range jobs {
				results[i] = e.runCheck(ctx, checks[i], e.rules[i], documents, options.Limits.MaxFindings, ledger)
			}
		})
	}

	for i := range e.analyzers {
		jobs <- i
	}

	close(jobs)
	wg.Wait()

	r := model.Report{
		Knowledge: knowledge.Inventory(), SchemaVersion: model.SchemaVersion, EngineVersion: model.EngineVersion, RulesVersion: model.RulesVersion,
		Dependencies: dependencies.Collect(ctx, documents),
		Metadata:     metadata.Collect(ctx, documents, options.Harness.Host), Components: graph, Profile: model.ProfileID, Artifact: s.Metadata(), Limits: options.Limits, Extraction: expanded.Report, Rules: model.CloneRules(e.rules),
		AnalysisLimits: model.AnalysisLimits{
			GoFlowOperations: analyzer.MaxGoFlowOperations, GoFlowBindings: analyzer.MaxGoFlowBindings, AgentJSONBytes: jsonconfig.MaxBytes, AgentJSONNodes: jsonconfig.MaxNodes, AgentJSONDepth: jsonconfig.MaxDepth, AgentJSONScanBytes: parse.MaxScanBytes, ShellUnitBytes: shellsyntax.MaxBytes, ShellScanBytes: parse.MaxScanBytes, ShellParserDepth: shellsyntax.MaxDepth, ShellParserNodes: shellsyntax.MaxNodes, ShellOperations: analyzer.MaxShellOperations, ShellBindings: analyzer.MaxShellBindings, ShellTraceTransforms: analyzer.MaxShellTraceSteps, JSONNestingDepth: extract.MaxJSONDepth, DocumentRegions: document.MaxRegions, SourceSegments: document.MaxSourceSegments,
			UnitsPerFile: document.MaxRegions, EmbeddedUnitBytes: document.MaxGoBytes,
			GoUnitBytes: document.MaxGoBytes, GoScanBytes: document.MaxScanGoBytes,
			ConstantOperations: analyzer.MaxConstantOperations, ConstantStringBytes: analyzer.MaxStaticStringBytes,
		},
		Findings: []model.Finding{}, Diagnostics: append(append([]model.Diagnostic{}, s.Diagnostics()...), expanded.Diagnostics...),
		Coverage: model.Coverage{Completeness: model.Complete, CapturedFiles: capturedCount, AnalyzedObjects: len(files), Checks: []model.Check{}},
		Limitations: []string{
			"Skills and harness plugin static MVP: instruction signals, selected agent/MCP JSON configuration risks, and supporting Go/Shell checks; not a general SAST or install attestation.",
			"Versioned Claude/Codex layout subsets, no runtime-loader compatibility claim. Optional semantic review is advisory; install attestation is not implemented.",
			"All captured byte streams receive raw literal checks. NUL, invalid UTF-8, hidden paths and names do not exempt content.",
			"Language/signature hints are non-authoritative. Go and a bounded Shell grammar are built in; Python syntax uses an explicitly enabled linked Tree-sitter backend and a limited analysis IR, not CPython AST. JS/TS/PowerShell have no AST backend.",
			"Markdown is one embedded container, not the scan boundary. Its envelope parser is not full CommonMark; optional real YAML/TOML parsers preserve explicitly stated limitations.",
			"Bounded ZIP32/GZIP/basic-TAR, PNG text metadata, JSON string tokens, BOM UTF-16 and selected Base64 extraction; originals are retained. No PDF/Office semantics, OCR, pixel/steganographic analysis or arbitrary encodings.",
			"Derived findings use virtual object coordinates, not fabricated offsets inside compressed parents. Provenance links are in the extraction graph.",
			"Shell coverage is a documented subset, NOT complete POSIX/Bash. Optional Python analysis remains bounded intra-scope. No general cross-file/type analysis, MCP execution or universal Unicode normalization.",
			"Agent configuration findings describe supported declarations, not effective host permissions. A pinned package version is not verified integrity or absence of vulnerabilities. YAML/TOML syntax requires explicit parser configuration; effective loader precedence and all host versions remain unverified.",
			"Surface hints and Markdown fences never grant trust or suppress findings. Literal examples and negations can require review.",
			"Source excerpts and credential values are omitted; file paths and content hashes may still be sensitive.",
			"Capture is immutable after reading but is not an atomic filesystem snapshot; mounts, hard links and hostile same-user writers require external isolation.",
		},
	}
	if r.Metadata.Completeness != model.Complete {
		r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: "metadata_contract_partial", Message: "Metadata syntax/schema review is incomplete; see metadata files and their issue codes.", AffectsScope: true})
	}

	for _, issue := range graph.Issues {
		r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: issue.Code, Path: issue.Path, Message: "Harness component interpretation is incomplete; see component graph for the bounded declaration and its status.", AffectsScope: true})
	}

	for i, outcome := range results {
		ledger.CompleteAnalyzer(e.rules[i].ID, inputs, outcome.fileChecks)
	}

	return e.completeRun(ctx, &r, s, options, files, documents, results, ledger)
}

func (e *Engine) completeRun(ctx context.Context, r *model.Report, s artifact.Snapshot, options RunOptions, files []artifact.File, documents []document.File, results []outcome, ledger *validation.Ledger) (model.Report, error) {
	if !s.Complete() {
		r.Coverage.Completeness = model.Partial
	}

	for _, d := range r.Diagnostics {
		if d.AffectsScope {
			r.Coverage.Completeness = model.Partial
		}
	}

	fileIndex := initializeFileCoverage(r, documents)

	return e.finalizeRun(ctx, r, options, files, documents, results, ledger, fileIndex)
}

func initializeFileCoverage(r *model.Report, documents []document.File) map[string]int {
	inventory := append([]model.File(nil), r.Artifact.Files...)
	for _, object := range r.Extraction.Objects {
		inventory = append(inventory, object.File)
	}

	fileIndex := make(map[string]int, len(inventory))
	for _, m := range inventory {
		fc := model.FileCoverage{
			Path: m.Path, ReadStatus: m.Status, Completeness: model.Complete,
			Checks: []model.FileCheck{}, Units: []model.UnitCoverage{}, Gaps: []string{},
			Classification: filetype.Description{Format: valueUnknown, Category: valueUnknown, Encoding: "not_read", Basis: "not_inspected"},
		}
		if m.Status != "captured" {
			fc.Completeness = model.Partial
			fc.Gaps = append(fc.Gaps, m.Reason)
		}

		fileIndex[m.Path] = len(r.Coverage.Files)
		r.Coverage.Files = append(r.Coverage.Files, fc)
	}

	extracted := make(map[string]bool)
	for _, step := range r.Extraction.Steps {
		extracted[step.ParentPath] = true
	}

	for _, diagnostic := range r.Diagnostics {
		if index, ok := fileIndex[diagnostic.Path]; ok && diagnostic.AffectsScope {
			r.Coverage.Files[index].Completeness = model.Partial
			r.Coverage.Files[index].Gaps = append(r.Coverage.Files[index].Gaps, diagnostic.Code)
		}
	}

	for _, doc := range documents {
		f := doc.Artifact()
		fc := &r.Coverage.Files[fileIndex[f.Metadata().Path]]
		classifyCoverage(r, fc, doc, extracted)
	}

	return fileIndex
}

func classifyCoverage(r *model.Report, fc *model.FileCoverage, doc document.File, extracted map[string]bool) {
	f := doc.Artifact()

	fc.Classification = doc.Classification()
	for _, u := range doc.Units() {
		fc.Units = append(fc.Units, model.UnitCoverage{
			Language: u.Language, Origin: u.Origin,
			ParserID: u.ParserID, ParserVersion: u.ParserVersion, Status: u.Status, ByteStart: u.Span.Start, ByteEnd: u.Span.End,
		})
	}

	for _, d := range doc.Diagnostics() {
		r.Diagnostics = append(r.Diagnostics, d)
		if d.AffectsScope {
			r.Coverage.Completeness = model.Partial
			fc.Completeness = model.Partial
			fc.Gaps = append(fc.Gaps, d.Code)
		}
	}

	m := f.Metadata()
	if m.Kind == formatText {
		r.Coverage.TextFiles++
	}

	code := ""
	message := ""

	c := fc.Classification
	if m.Kind == "binary" || c.Executable {
		code = "opaque_content"
		message = "Raw byte patterns were checked, but encoded contents, embedded objects and behavior remain unverified."
	} else if c.Structured && !doc.HasParsedUnits() {
		code = "structural_analysis_unavailable"
		message = "Literal patterns were checked; required code/configuration semantics are not implemented in this prototype."
	}

	switch c.Category {
	case "archive":
		code = "nested_archive_unsupported"
		message = "This archive format has no extractor; raw bytes remain subject to checks."

		if extracted[m.Path] {
			code = "container_semantics_limited"
			message = "Extraction was attempted for supported members and metadata; see extraction statuses. This is not complete container or behavior analysis."
		}
	case "image", "document", "database", "media":
		code = "container_semantics_unavailable"
		message = "Raw bytes were checked but this format's text, metadata, attachments and encoded contents were not extracted."

		if extracted[m.Path] {
			code = "container_semantics_limited"
			message = "Selected metadata was extracted; pixels, arbitrary attachments and full format semantics remain unverified."
		}
	case valueUnknown:
		if code == "" {
			code = "unrecognized_content"
			message = "Unknown file format: raw patterns were checked, but syntax and encoded or embedded content remain unverified."
		}
	}

	if code != "" {
		r.Coverage.Completeness = model.Partial

		fc.Completeness = model.Partial
		if !slices.Contains(fc.Gaps, code) {
			fc.Gaps = append(fc.Gaps, code)
			r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: code, Path: m.Path, Message: message, AffectsScope: true})
		}
	}

	if c.Conflict {
		fc.Completeness, r.Coverage.Completeness = model.Partial, model.Partial
		fc.Gaps = append(fc.Gaps, "conflicting_content_hints")
		r.Diagnostics = append(r.Diagnostics, model.Diagnostic{
			Code: "conflicting_content_hints", Path: m.Path,
			Message: "Filename, signature or language declarations conflict; none grants a security exemption.", AffectsScope: true,
		})
	}
}

func (e *Engine) finalizeRun(ctx context.Context, r *model.Report, options RunOptions, files []artifact.File, documents []document.File, results []outcome, ledger *validation.Ledger, fileIndex map[string]int) (model.Report, error) {
	for _, o := range results {
		for i, check := range o.fileChecks {
			fc := &r.Coverage.Files[fileIndex[documents[i].Artifact().Metadata().Path]]

			fc.Checks = append(fc.Checks, check)
			if check.Status != valueCompleted && check.Status != valueNotApplicable {
				fc.Completeness = model.Partial
				fc.Gaps = append(fc.Gaps, check.AnalyzerID+":"+check.Status)
			}
		}

		r.Coverage.Checks = append(r.Coverage.Checks, o.check)
		r.Findings = append(r.Findings, o.findings...)

		r.Diagnostics = append(r.Diagnostics, o.diagnostics...)
		if o.check.Status != valueCompleted && o.check.Status != valueNotApplicable {
			r.Coverage.Completeness = model.Partial
		}
	}

	applyVulnerabilities(ctx, r, documents, options.Vulnerabilities, options.Limits.MaxFindings)
	applySignatures(ctx, r, documents, e.signatures, options.Limits.MaxFindings)
	limitFindings(r, fileIndex, options.Limits.MaxFindings)

	return finishRun(ctx, r, options, files, ledger)
}

func limitFindings(r *model.Report, fileIndex map[string]int, budget int) {
	sort.Slice(r.Findings, func(i, j int) bool {
		a, b := r.Findings[i], r.Findings[j]
		if a.Severity != b.Severity {
			return a.Severity.Rank() > b.Severity.Rank()
		}

		if a.Location.Path != b.Location.Path {
			return a.Location.Path < b.Location.Path
		}

		if a.Location.ByteStart != b.Location.ByteStart {
			return a.Location.ByteStart < b.Location.ByteStart
		}

		if a.Location.ByteEnd != b.Location.ByteEnd {
			return a.Location.ByteEnd < b.Location.ByteEnd
		}

		return a.RuleID < b.RuleID
	})
	// Keep distinct occurrences. Duplicate observations of the EXACT same rule
	// and span are harmless to merge; identical text on another line is not.
	unique := r.Findings[:0]

	ids := make(map[string]struct{}, len(r.Findings))
	for _, f := range r.Findings {
		if _, ok := ids[f.ID]; ok {
			continue
		}

		ids[f.ID] = struct{}{}
		unique = append(unique, f)
	}

	r.Findings = unique
	if len(r.Findings) > budget {
		r.Coverage.Completeness = model.Partial

		r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: "finding_limit", Message: "Report finding budget exhausted; highest-severity occurrences retained.", AffectsScope: true})
		for _, f := range r.Findings[budget:] {
			fc := &r.Coverage.Files[fileIndex[f.Location.Path]]
			fc.Completeness = model.Partial
			fc.Gaps = append(fc.Gaps, "report_finding_limit")
		}

		r.Findings = r.Findings[:budget]
	}
}

func finishRun(ctx context.Context, r *model.Report, options RunOptions, files []artifact.File, ledger *validation.Ledger) (model.Report, error) {
	if harness.Enrich(r.Findings, r.Components) {
		r.Coverage.Completeness = model.Partial
		r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: "finding_context_limit", Message: "Additional component contexts exceeded the per-finding budget.", AffectsScope: true})
	}

	for i := range r.Coverage.Files {
		fc := &r.Coverage.Files[i]
		sort.Slice(fc.Checks, func(i, j int) bool { return fc.Checks[i].AnalyzerID < fc.Checks[j].AnalyzerID })
		sort.Strings(fc.Gaps)

		gaps := fc.Gaps[:0]
		for _, g := range fc.Gaps {
			if len(gaps) == 0 || gaps[len(gaps)-1] != g {
				gaps = append(gaps, g)
			}
		}

		fc.Gaps = gaps
	}

	r.Semantic = semantic.RunWithExtraction(ctx, files, r.Components, r.Findings, r.Artifact.SnapshotSHA256, options.Semantic, options.Provider, r.Extraction)
	if options.Semantic.Enabled {
		semanticFileCoverage(r)
		r.Profile += "+semantic-v3"
		ledger.CompleteSemantic(r.Semantic.Completeness)

		if r.Semantic.Completeness != model.Complete {
			r.Coverage.Completeness = model.Partial
			r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: "semantic_incomplete", Message: "Requested semantic tasks failed, were limited, or lack context; source-free task outcomes are in the semantic report.", AffectsScope: true})
		}

		r.Limitations = append(r.Limitations, "Semantic responses are evidence-linked model opinions, not proof of correctness. They cannot erase static findings; proposals require review rather than automatic trust. Only text is sent, with explicit consent and no automatic secret redaction.", "Semantic context and request budgets are byte-based, not a guarantee of provider token fit or cost. A complete semantic task means a valid response was received, not that all threats were detected.")
	}

	r.Validation = ledger.Finalize()
	if r.Validation.Completeness != model.Complete {
		r.Coverage.Completeness = model.Partial
		r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: "validation_plan_incomplete", Message: "Required planned tasks are unsupported, failed, missing or limited; no automatic admission.", AffectsScope: true})
	}

	if len(files) == 0 || ctx.Err() != nil {
		r.Coverage.Completeness = model.Failed
	}

	if ctx.Err() != nil {
		r.Diagnostics = append(r.Diagnostics, model.Diagnostic{Code: valueCancelled, Message: "Scan was cancelled or timed out.", AffectsScope: true})
	}

	sort.Slice(r.Rules, func(i, j int) bool { return r.Rules[i].ID < r.Rules[j].ID })
	sort.Slice(r.Coverage.Checks, func(i, j int) bool { return r.Coverage.Checks[i].AnalyzerID < r.Coverage.Checks[j].AnalyzerID })
	sort.Slice(r.Diagnostics, func(i, j int) bool {
		a, b := r.Diagnostics[i], r.Diagnostics[j]
		if a.Path != b.Path {
			return a.Path < b.Path
		}

		if a.Code != b.Code {
			return a.Code < b.Code
		}

		return a.Message < b.Message
	})
	r.Policy = policy.EvaluateWithSemantic(options.Policy, r.Coverage.Completeness, r.Findings, r.Semantic)

	return *r, ctx.Err()
}

func (e *Engine) runCheck(ctx context.Context, a analyzer.Analyzer, rule model.Rule, files []document.File, budget int, plan *validation.Ledger) (out outcome) {
	out.check = model.Check{AnalyzerID: rule.ID, Version: rule.Version, Status: valueCompleted}

	out.fileChecks = make([]model.FileCheck, len(files))
	for i := range files {
		out.fileChecks[i] = model.FileCheck{AnalyzerID: rule.ID, Status: "not_run"}
	}
	// Panic text is untrusted and can contain source content. Do not leak it.
	defer func() {
		out.check.Findings = len(out.findings)
		if recover() != nil {
			out.check.Status = statusFailed
			out.check.Detail = "Analyzer panic; existing findings retained."
			out.diagnostics = append(out.diagnostics, model.Diagnostic{Code: "analyzer_panic", Message: rule.ID + ": analyzer failed.", AffectsScope: true})
		}

		for i := range out.fileChecks {
			if out.fileChecks[i].Status == "running" {
				out.fileChecks[i].Status = statusFailed
			}
		}
	}()

	structured, isStructured := a.(analyzer.DocumentAnalyzer)

	applies := func(f document.File) bool {
		if isStructured {
			return structured.AppliesToDocument(f)
		}

		return a.AppliesTo(f.Artifact())
	}
	for i, f := range files {
		if !plan.Scheduled(rule.ID, f.Artifact().Metadata().Path) {
			out.fileChecks[i].Status = "not_planned"
			out.check.Status = statusPartial

			continue
		}

		if applies(f) {
			out.check.FilesTotal++
		} else {
			out.fileChecks[i].Status = valueNotApplicable
		}
	}

	if out.check.FilesTotal == 0 {
		out.check.Status = valueNotApplicable
		return out
	}

	for i, doc := range files {
		f := doc.Artifact()

		if out.fileChecks[i].Status == valueNotApplicable || out.fileChecks[i].Status == "not_planned" {
			continue
		}

		if err := ctx.Err(); err != nil {
			out.check.Status = valueCancelled
			out.fileChecks[i].Status = valueCancelled

			return out
		}

		var (
			result analyzer.Result
			err    error
		)

		out.fileChecks[i].Status = "running"
		if isStructured {
			result, err = structured.FindDocument(ctx, doc, budget-len(out.findings))
		} else {
			result, err = a.Find(ctx, f, budget-len(out.findings))
		}

		acceptAnalyzerResult(&out, rule, doc, result, err, files, budget, i)
	}

	out.check.Findings = len(out.findings)

	return out
}

func acceptAnalyzerResult(out *outcome, rule model.Rule, doc document.File, result analyzer.Result, err error, files []document.File, budget, index int) {
	f := doc.Artifact()

	failed := err != nil
	if err != nil {
		out.check.Status = statusFailed
		out.diagnostics = append(out.diagnostics, model.Diagnostic{Code: "analyzer_failed", Path: f.Metadata().Path, Message: rule.ID + ": analyzer returned an error; results are incomplete.", AffectsScope: true})
		// A partial result may carry valid evidence from before the failure.
		// Validate and retain it; never silently turn it into an empty result.
	}

	if len(result.Matches) > budget-len(out.findings) {
		out.check.Status = statusFailed
		out.diagnostics = append(out.diagnostics, model.Diagnostic{Code: "analyzer_contract", Path: f.Metadata().Path, Message: rule.ID + ": analyzer exceeded its result budget.", AffectsScope: true})
		result.Matches = result.Matches[:budget-len(out.findings)]
		failed = true
	}

	valid := true

	for _, m := range result.Matches {
		finding, err := makeFinding(rule, doc, m)
		if err == nil {
			err = attachRelated(&finding, m.Related, files)
		}

		if err != nil {
			valid = false
			out.check.Status = statusFailed
			out.diagnostics = append(out.diagnostics, model.Diagnostic{Code: "invalid_evidence", Path: f.Metadata().Path, Message: rule.ID + ": invalid source coordinates rejected.", AffectsScope: true})

			continue
		}

		out.findings = append(out.findings, finding)
	}

	if result.Truncated {
		if out.check.Status != statusFailed {
			out.check.Status = statusPartial
		}

		out.diagnostics = append(out.diagnostics, model.Diagnostic{Code: "finding_limit", Path: f.Metadata().Path, Message: rule.ID + ": additional matches omitted at the finding budget.", AffectsScope: true})
	} else if valid && !failed {
		out.check.FilesDone++
	}

	switch {
	case failed || !valid:
		out.fileChecks[index].Status = statusFailed
	case result.Truncated:
		out.fileChecks[index].Status = statusPartial
	default:
		out.fileChecks[index].Status = valueCompleted
	}
}

func makeFinding(rule model.Rule, doc document.File, m analyzer.Match) (model.Finding, error) {
	severity := rule.Severity
	if m.Severity != "" {
		if m.Severity.Rank() < 0 || m.Severity.Rank() > severity.Rank() {
			return model.Finding{}, errors.New("invalid finding severity")
		}

		severity = m.Severity
	}

	f := doc.Artifact()
	s := f.Content()
	meta := f.Metadata()

	loc, err := location(doc, source.Span{Start: m.Start, End: m.End})
	if err != nil {
		return model.Finding{}, err
	}

	if len(m.Trace) > 8 {
		return model.Finding{}, errors.New("trace budget exceeded")
	}

	trace := make([]model.TraceStep, 0, len(m.Trace))
	for _, step := range m.Trace {
		if step.Role != "source" && step.Role != "sink" && step.Role != "transform" {
			return model.Finding{}, errors.New("invalid trace role")
		}

		at, err := location(doc, source.Span{Start: step.Start, End: step.End})
		if err != nil {
			return model.Finding{}, err
		}

		trace = append(trace, model.TraceStep{Role: step.Role, Location: at, Evidence: model.Evidence{FileSHA256: meta.SHA256, SpanSHA256: artifact.Hash([]byte(s[step.Start:step.End]))}})
	}

	identity := strings.Join([]string{"finding-v1", rule.ID, rule.Version, meta.Path, meta.SHA256, strconv.Itoa(m.Start), strconv.Itoa(m.End)}, "\x00")

	signals := knowledge.ContextSignals(s, m.Start, m.End)
	if len(m.ContextSignals) > 8 {
		return model.Finding{}, errors.New("context signal budget exceeded")
	}

	for _, signal := range m.ContextSignals {
		switch signal {
		case "registry_assertion", "evidence_unavailable":
			signals = append(signals, signal)
		default:
			return model.Finding{}, errors.New("invalid analyzer context signal")
		}
	}

	if m.InactiveForSurface {
		signals = append(signals, "ignored_by_supported_project_surface")
	}

	return model.Finding{ContextSignals: signals, ID: artifact.Hash([]byte(identity)), RuleID: rule.ID, RuleVersion: rule.Version, Severity: severity, Category: rule.Category, Method: rule.Method, Message: rule.Title, Location: loc, Evidence: model.Evidence{FileSHA256: meta.SHA256, SpanSHA256: artifact.Hash([]byte(s[m.Start:m.End]))}, Trace: trace}, nil
}

func location(doc document.File, span source.Span) (model.Location, error) {
	f := doc.Artifact()
	s := f.Content()
	meta := f.Metadata()

	if span.Start < 0 || span.End < span.Start || span.End > len(s) || (span.Start == span.End && len(s) > 0) {
		return model.Location{}, errors.New("invalid span")
	}

	if meta.Kind == formatText && ((span.Start < len(s) && !utf8.RuneStart(s[span.Start])) || (span.End < len(s) && !utf8.RuneStart(s[span.End]))) {
		return model.Location{}, errors.New("span bisects UTF-8")
	}

	line, column, endLine, endColumn := 0, 0, 0, 0

	coordinates := "bytes"
	if meta.Kind == formatText {
		coordinates = formatText

		var err error

		line, column, err = doc.Index().Position(span.Start)
		if err != nil {
			return model.Location{}, err
		}

		endLine, endColumn, err = doc.Index().Position(span.End)
		if err != nil {
			return model.Location{}, err
		}
	}

	kind, language := doc.Context(span)

	return model.Location{Derived: strings.HasPrefix(meta.Path, "scout-object://"), Path: meta.Path, Coordinates: coordinates, ByteStart: span.Start, ByteEnd: span.End, StartLine: line, StartColumn: column, EndLine: endLine, EndColumn: endColumn, Context: analyzer.Surface(meta.Path), Structure: kind, Language: language}, nil
}

// Validate every cross-object reference against captured bytes. It is related
// evidence, not fabricated interprocedural taint or runtime execution.
func attachRelated(f *model.Finding, refs []model.SourceRef, docs []document.File) error {
	if len(refs) > 8 {
		return errors.New("related evidence budget")
	}

	for _, ref := range refs {
		found := false

		for _, doc := range docs {
			meta := doc.Artifact().Metadata()
			if meta.Path != ref.Path {
				continue
			}

			found = true

			if meta.SHA256 != ref.SHA256 {
				return errors.New("related object digest")
			}

			if _, e := location(doc, source.Span{Start: ref.ByteStart, End: ref.ByteEnd}); e != nil {
				return e
			}

			if artifact.Hash([]byte(doc.Artifact().Content()[ref.ByteStart:ref.ByteEnd])) != ref.SpanSHA256 {
				return errors.New("related evidence digest")
			}

			break
		}

		if !found {
			return errors.New("unknown related object")
		}

		f.RelatedEvidence = append(f.RelatedEvidence, ref)
	}

	if len(refs) > 0 {
		var identity strings.Builder
		identity.WriteString(f.ID)

		for _, ref := range refs {
			fmt.Fprintf(&identity, "\x00%s\x00%s\x00%d\x00%d\x00%s", ref.Path, ref.SHA256, ref.ByteStart, ref.ByteEnd, ref.SpanSHA256)
		}

		f.ID = artifact.Hash([]byte(identity.String()))
	}

	return nil
}
