package engine

// Shared vocabulary used by this package's protocols and reports.
const (
	valueOSV001    = "OSV001"
	valueCancelled = "cancelled"
	valueCompleted = "completed"
	statusFailed   = "failed"
	statusPartial  = "partial"
	formatText     = "text"
	valueUnknown   = "unknown"
)
