package dependencies

// Shared vocabulary used by this package's protocols and reports.
const (
	valueExactDeclarationNotInstallEvidence = "exact-declaration-not-install-evidence"
	valueExactLockfile                      = "exact-lockfile"
	kindObject                              = "object"
	statusPartial                           = "partial"
	valueRangeOrSourceUnresolved            = "range-or-source-unresolved"
	valueUvLock                             = "uv.lock"
)
