// Package dependencies inventories captured declarations without invoking any
// build tool, importer, resolver, checksum service or vulnerability API.
package dependencies

import (
	"context"
	"strconv"

	"golang.org/x/mod/modfile"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/source"
)

func Collect(ctx context.Context, docs []document.File) model.DependencyReport {
	out := model.DependencyReport{Scope: "captured-go-npm-python-declarations-not-install-attestation", Manifests: []model.DependencyManifest{}, Declarations: []model.Dependency{}, Limitations: []string{
		"go.mod require versions are declared minimums under Go MVS, not evidence of the version that would be selected or installed.",
		"No dependencies are downloaded, built or executed. Optional vulnerability checks are reported separately; declarations do not establish reachability or integrity.",
		"Replacement paths are not opened. An exact replacement version does not establish source trust or integrity. Unsupported ecosystems remain in whole-artifact coverage.",
	}}
	for _, doc := range docs {
		collectPackages(ctx, doc, &out)

		for _, u := range doc.Units() {
			if u.Language != "gomod" {
				continue
			}

			out.Manifests = append(out.Manifests, model.DependencyManifest{Path: doc.Artifact().Metadata().Path, Status: u.Status, Parser: u.ParserID, ParserVersion: u.ParserVersion})
			if !collectGoModule(ctx, doc, u, &out) {
				return out
			}
		}
	}

	return out
}

func collectGoModule(ctx context.Context, doc document.File, u document.Unit, out *model.DependencyReport) bool {
	tree, ok := u.Tree.(parse.GoModTree)
	if !ok || tree.File == nil {
		return true
	}

	for _, r := range tree.File.Require {
		if ctx.Err() != nil {
			out.Limitations = append(out.Limitations, "Dependency declaration inventory was cancelled.")
			return false
		}

		start, end := r.Syntax.Span()

		span, err := u.View.Original(source.Span{Start: start.Byte, End: end.Byte})
		if err != nil {
			out.Manifests[len(out.Manifests)-1].Status = "evidence_mapping_failed"
			out.Limitations = append(out.Limitations, "A declaration could not be mapped to captured bytes; it was not published as verified evidence.")

			continue
		}

		meta := doc.Artifact().Metadata()
		d := model.Dependency{Ecosystem: "Go", Module: r.Mod.Path, DeclaredVersion: r.Mod.Version, VersionSemantics: "declared-minimum-unresolved-MVS", Indirect: r.Indirect, Replacement: "none", Source: model.SourceRef{Path: meta.Path, SHA256: meta.SHA256, ByteStart: span.Start, ByteEnd: span.End, SpanSHA256: artifact.Hash([]byte(doc.Artifact().Content()[span.Start:span.End]))}}
		applyGoReplacements(&d, doc, u, tree.File, r, out)
		d.ID = artifact.Hash([]byte("dependency-v1\x00" + meta.Path + "\x00" + meta.SHA256 + "\x00" + strconv.Itoa(span.Start) + "\x00" + strconv.Itoa(span.End)))
		out.Declarations = append(out.Declarations, d)
	}

	return true
}

func applyGoReplacements(d *model.Dependency, doc document.File, u document.Unit, file *modfile.File, required *modfile.Require, out *model.DependencyReport) {
	// Wildcards are applied first so exact-version replacements take precedence.
	for _, exact := range []bool{false, true} {
		for _, replacement := range file.Replace {
			if replacement.Old.Path != required.Mod.Path || (exact && replacement.Old.Version != required.Mod.Version) || (!exact && replacement.Old.Version != "") {
				continue
			}

			start, end := replacement.Syntax.Span()

			meta := doc.Artifact().Metadata()
			if mapped, err := u.View.Original(source.Span{Start: start.Byte, End: end.Byte}); err == nil {
				d.ReplacementSource = &model.SourceRef{Path: meta.Path, SHA256: meta.SHA256, ByteStart: mapped.Start, ByteEnd: mapped.End, SpanSHA256: artifact.Hash([]byte(doc.Artifact().Content()[mapped.Start:mapped.End]))}
			} else {
				d.ReplacementSource = nil
				out.Manifests[len(out.Manifests)-1].Status = "evidence_mapping_failed"
				out.Limitations = append(out.Limitations, "A replacement declaration could not be mapped to captured bytes.")
			}

			if replacement.New.Version == "" {
				d.Replacement, d.ReplacementModule, d.ReplacementVersion = "local-unresolved", "", ""
			} else {
				d.Replacement, d.ReplacementModule, d.ReplacementVersion = "module", replacement.New.Path, replacement.New.Version
			}
		}
	}
}
