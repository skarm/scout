package dependencies

import (
	"context"
	"net/url"
	"path"
	"regexp"
	"strconv"
	"strings"

	"golang.org/x/mod/semver"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/source"
)

const maxDeclarations = 8192

var (
	requirement     = regexp.MustCompile(`^([A-Za-z0-9][A-Za-z0-9_.-]*)(?:\[[A-Za-z0-9_,.-]+\])?\s*(===|==|~=|>=|<=|!=|>|<)?\s*([^\s;#]+)?`)
	exactPyVersion  = regexp.MustCompile(`^[0-9]+(?:\.[0-9]+)*(?:(?:a|b|rc)[0-9]+)?(?:\.post[0-9]+)?(?:\.dev[0-9]+)?$`)
	exactNPMVersion = regexp.MustCompile(`^(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$`)
)

var validPackage = regexp.MustCompile(`^[A-Za-z0-9@][A-Za-z0-9@/_.-]{0,255}$`)

func exactNPM(v string) bool { return exactNPMVersion.MatchString(v) && semver.IsValid("v"+v) }

func logicalName(p string) string {
	// Derived URIs contain escaped member names; this is only a format hint, not
	// file ownership or permission. The raw source still identifies the object.
	if u, e := url.PathUnescape(p); e == nil {
		p = u
	}

	return strings.ToLower(path.Base(p))
}

func appendDecl(out *model.DependencyReport, doc document.File, u *document.Unit, eco, name, version, semantics string, span source.Span, indirect bool) bool {
	if len(out.Declarations) >= maxDeclarations {
		return false
	}

	if !validPackage.MatchString(name) || len(version) > 256 {
		return false
	}
	// Source references and digests retain the declaration. An unresolved source
	// specifier may carry a credential-bearing URL: do not print it as a version.
	if semantics == valueRangeOrSourceUnresolved {
		version = "unresolved"
	}

	if u != nil {
		var err error

		span, err = u.View.Original(span)
		if err != nil {
			return false
		}
	}

	raw := doc.Artifact().Content()
	if span.Start < 0 || span.End > len(raw) || span.Start >= span.End {
		return false
	}

	m := doc.Artifact().Metadata()
	ref := model.SourceRef{Path: m.Path, SHA256: m.SHA256, ByteStart: span.Start, ByteEnd: span.End, SpanSHA256: artifact.Hash([]byte(raw[span.Start:span.End]))}
	id := artifact.Hash([]byte("dependency-v2\x00" + m.Path + "\x00" + m.SHA256 + "\x00" + eco + "\x00" + name + "\x00" + strconv.Itoa(span.Start) + "\x00" + strconv.Itoa(span.End) + "\x00" + strconv.Itoa(len(out.Declarations))))
	out.Declarations = append(out.Declarations, model.Dependency{ID: id, Ecosystem: eco, Module: name, DeclaredVersion: version, VersionSemantics: semantics, Indirect: indirect, Replacement: "none", Source: ref})

	return true
}

func collectPackages(ctx context.Context, doc document.File, out *model.DependencyReport) {
	name := logicalName(doc.Artifact().Metadata().Path)
	if name == "pyproject.toml" || name == valueUvLock || name == "poetry.lock" || name == "pipfile" {
		collectPythonTOML(ctx, doc, out, name)
		return
	}

	if name == "requirements.txt" || strings.HasPrefix(name, "requirements-") && strings.HasSuffix(name, ".txt") {
		collectRequirements(ctx, doc, out)
		return
	}

	if name != "package.json" && name != "package-lock.json" && name != "npm-shrinkwrap.json" && name != "pipfile.lock" {
		return
	}

	status := "unsupported"

	var (
		unit document.Unit
		root *jsonconfig.Node
	)

	for _, u := range doc.Units() {
		if u.Language == "json" && u.Origin == "file" {
			status = u.Status

			unit = u
			if t, ok := u.Tree.(parse.JSONTree); ok {
				root = t.Root
			}

			break
		}
	}

	mi := len(out.Manifests)
	out.Manifests = append(out.Manifests, model.DependencyManifest{Path: doc.Artifact().Metadata().Path, Status: status, Parser: "json-stdlib-strict", ParserVersion: "1"})

	if root == nil || root.Kind != kindObject {
		return
	}

	partial := false
	add := func(eco, pkg, v, kind string, n *jsonconfig.Node, indirect bool) {
		if !appendDecl(out, doc, &unit, eco, pkg, v, kind, n.Span, indirect) {
			partial = true
		}
	}

	var malformed bool

	switch name {
	case "package.json":
		malformed = collectPackageManifest(root, add)
	case "pipfile.lock":
		malformed = collectPipfileLock(root, add)
	default:
		malformed = collectNPMLock(ctx, root, unit.View.Text(), add)
	}

	if partial || malformed {
		out.Manifests[mi].Status = statusPartial
	}
}

type dependencyAdder func(eco, pkg, version, kind string, node *jsonconfig.Node, indirect bool)

func collectPackageManifest(root *jsonconfig.Node, add dependencyAdder) bool {
	partial := false

	for _, field := range []string{"dependencies", "devDependencies", "optionalDependencies", "peerDependencies"} {
		n := root.Get(field)
		if n == nil {
			continue
		}

		if n.Kind != kindObject {
			partial = true
			continue
		}

		for _, m := range n.Members {
			v, ok := m.Value.Text()
			if !ok {
				partial = true
				continue
			}

			kind := valueRangeOrSourceUnresolved
			if exactNPM(v) {
				kind = valueExactDeclarationNotInstallEvidence
			}

			add("npm", m.Key, v, kind, m.Value, false)
		}
	}

	return partial
}

func collectPipfileLock(root *jsonconfig.Node, add dependencyAdder) bool {
	partial := false

	for _, field := range []string{"default", "develop"} {
		n := root.Get(field)
		if n == nil {
			continue
		}

		if n.Kind != kindObject {
			partial = true
			continue
		}

		for _, m := range n.Members {
			v, ok := m.Value.Get("version").Text()
			if !ok {
				partial = true
				continue
			}

			kind := valueRangeOrSourceUnresolved

			plain := strings.TrimPrefix(v, "==")
			if strings.HasPrefix(v, "==") && exactPyVersion.MatchString(plain) && m.Value.Get("markers") == nil {
				v = plain
				kind = valueExactLockfile
			}

			add("PyPI", normalizePy(m.Key), v, kind, m.Value, false)
		}
	}

	return partial
}

func collectNPMLock(ctx context.Context, root *jsonconfig.Node, text string, add dependencyAdder) bool {
	partial := false
	lv := root.Get("lockfileVersion")

	v := ""
	if lv != nil && lv.Kind == "number" {
		v = text[lv.Span.Start:lv.Span.End]
	}

	switch v {
	case "2", "3":
		n := root.Get("packages")
		if n == nil || n.Kind != kindObject {
			partial = true
			break
		}

		for _, m := range n.Members {
			if ctx.Err() != nil {
				partial = true
				break
			}

			if m.Key == "" {
				continue
			}

			p := m.Key

			i := strings.LastIndex(p, "node_modules/")
			if i < 0 {
				partial = true
				continue
			}

			pkg := p[i+len("node_modules/"):]
			if explicit, ok := m.Value.Get("name").Text(); ok {
				pkg = explicit
			}

			v, ok := m.Value.Get("version").Text()
			if !ok {
				partial = true
				continue
			}

			kind := valueRangeOrSourceUnresolved
			if exactNPM(v) && m.Value.Get("link") == nil && trustedNPMResolution(m.Value.Get("resolved")) {
				kind = valueExactLockfile
			}

			add("npm", pkg, v, kind, m.Value, true)
		}
	case "1":
		partial = collectNPMLockV1(ctx, root.Get("dependencies"), 0, add)
	default:
		partial = true
	}

	return partial
}

func collectNPMLockV1(ctx context.Context, n *jsonconfig.Node, depth int, add dependencyAdder) bool {
	if n == nil {
		return false
	}

	if depth > 32 || n.Kind != kindObject {
		return true
	}

	partial := false

	for _, member := range n.Members {
		if ctx.Err() != nil {
			return true
		}

		version, ok := member.Value.Get("version").Text()
		if !ok {
			partial = true
			continue
		}

		kind := valueRangeOrSourceUnresolved
		if exactNPM(version) && trustedNPMResolution(member.Value.Get("resolved")) {
			kind = valueExactLockfile
		}

		add("npm", member.Key, version, kind, member.Value, depth > 0)

		if collectNPMLockV1(ctx, member.Value.Get("dependencies"), depth+1, add) {
			partial = true
		}
	}

	return partial
}

func normalizePy(s string) string {
	var out strings.Builder

	dash := false

	for _, r := range strings.ToLower(s) {
		if r == '_' || r == '.' || r == '-' {
			if !dash {
				out.WriteByte('-')
			}

			dash = true
		} else {
			out.WriteRune(r)

			dash = false
		}
	}

	return out.String()
}

func collectRequirements(ctx context.Context, doc document.File, out *model.DependencyReport) {
	mi := len(out.Manifests)
	out.Manifests = append(out.Manifests, model.DependencyManifest{Path: doc.Artifact().Metadata().Path, Status: "completed", Parser: "pep508-constrained-lines", ParserVersion: "1"})
	raw := doc.Artifact().Content()
	offset := 0

	for _, line := range strings.SplitAfter(raw, "\n") {
		if ctx.Err() != nil {
			out.Manifests[mi].Status = "cancelled"
			return
		}

		s := strings.TrimSpace(line)
		start := offset
		offset += len(line)

		if s == "" || strings.HasPrefix(s, "#") {
			continue
		}

		if strings.HasPrefix(s, "-") || strings.Contains(s, "\\") {
			out.Manifests[mi].Status = statusPartial
			continue
		}

		idx := requirement.FindStringSubmatchIndex(s)
		if idx == nil || idx[0] != 0 {
			out.Manifests[mi].Status = statusPartial
			continue
		}

		get := func(n int) string {
			if idx[n*2] < 0 {
				return ""
			}

			return s[idx[n*2]:idx[n*2+1]]
		}
		pkg, op, v := get(1), get(2), get(3)
		suffix := strings.TrimSpace(s[idx[1]:])

		kind := valueRangeOrSourceUnresolved
		if op == "==" && exactPyVersion.MatchString(v) && (suffix == "" || strings.HasPrefix(suffix, "#")) {
			kind = valueExactDeclarationNotInstallEvidence
		}

		if suffix != "" && !strings.HasPrefix(suffix, "#") {
			out.Manifests[mi].Status = statusPartial
		}

		if !appendDecl(out, doc, nil, "PyPI", normalizePy(pkg), v, kind, source.Span{Start: start, End: offset}, false) {
			out.Manifests[mi].Status = statusPartial
			return
		}
	}
}

// A different registry/source may serve different bytes for the same name/version.
// We do not query the public ecosystem database as if that origin were resolved.
func trustedNPMResolution(n *jsonconfig.Node) bool {
	if n == nil {
		return true
	} // Missing provenance is reported as a declaration, not attested installation.

	s, ok := n.Text()
	if !ok {
		return false
	}

	u, e := url.Parse(s)

	return e == nil && u.Scheme == "https" && u.Host == "registry.npmjs.org" && u.User == nil && u.RawQuery == "" && u.Fragment == ""
}
