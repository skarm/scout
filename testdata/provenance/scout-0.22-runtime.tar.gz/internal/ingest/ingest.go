// Package ingest captures untrusted local inputs without executing their code.
package ingest

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/skarm/scout/internal/archiveutil"
	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/rootfs"
)

var ErrEmpty = errors.New("input contains no files")

type builder struct {
	limits      model.Limits
	files       []artifact.File
	skipped     []model.File
	diagnostics []model.Diagnostic
	complete    bool
	consumed    int64
	entries     int
	fileEntries int
	names       archiveutil.Namespace
}

type contextReader struct {
	ctx    context.Context
	reader io.Reader
}

func newBuilder(l model.Limits) *builder {
	return &builder{limits: l, complete: true, names: archiveutil.Namespace{MaxNodes: l.MaxEntries}}
}

// Read accepts only an explicit local path. No URL, user configuration, ignore
// file, archive hook, or project command is evaluated.
func Read(ctx context.Context, target string, limits model.Limits) (artifact.Snapshot, error) {
	if err := limits.Validate(); err != nil {
		return artifact.Snapshot{}, err
	}

	if err := ctx.Err(); err != nil {
		return artifact.Snapshot{}, err
	}

	if target == "" || strings.Contains(target, "://") {
		return artifact.Snapshot{}, errors.New("an explicit local file, directory or ZIP path is required; remote inputs are not implemented")
	}

	info, err := os.Lstat(target)
	if err != nil {
		return artifact.Snapshot{}, fmt.Errorf("inspect input: %w", err)
	}

	if info.Mode()&os.ModeSymlink != 0 || (!info.IsDir() && !info.Mode().IsRegular()) {
		return artifact.Snapshot{}, errors.New("input must be a regular file or directory, not a link or special file")
	}

	if info.IsDir() {
		return readDirectory(ctx, target, info, limits)
	}

	if strings.EqualFold(filepath.Ext(target), ".zip") {
		data, err := readSelectedFile(ctx, target, info, min(limits.MaxArchiveBytes, limits.MaxTotalBytes))
		if err != nil {
			return artifact.Snapshot{}, err
		}

		name := filepath.Base(target)
		if err := ValidatePath(name, limits.MaxPathBytes, limits.MaxDepth); err != nil {
			return artifact.Snapshot{}, fmt.Errorf("invalid input filename: %w", err)
		}
		// Preserve the exact container, including metadata and padding. Member
		// extraction is a separate, bounded stage shared with nested archives.
		return artifact.New("file", []artifact.File{artifact.NewFile(name, data, info.Mode()&0o111 != 0)}, nil, nil, true), nil
	}

	b := newBuilder(limits)

	name := filepath.Base(target)
	if err := ValidatePath(name, limits.MaxPathBytes, limits.MaxDepth); err != nil {
		return artifact.Snapshot{}, fmt.Errorf("invalid input filename: %w", err)
	}

	if info.Size() > limits.MaxFileBytes {
		b.skip(name, "file", "file_size_limit", "File exceeds the per-file budget; no prefix was scanned.", info.Size())
		return b.snapshot("file"), nil
	}

	data, err := readSelectedFile(ctx, target, info, limits.MaxFileBytes)
	if err != nil {
		return artifact.Snapshot{}, err
	}

	b.files = append(b.files, artifact.NewFile(name, data, info.Mode()&0o111 != 0))

	return b.snapshot("file"), nil
}

func (b *builder) snapshot(kind string) artifact.Snapshot {
	return artifact.New(kind, b.files, b.skipped, b.diagnostics, b.complete)
}

func (b *builder) issue(code, path, message string) {
	b.complete = false
	b.diagnostics = append(b.diagnostics, model.Diagnostic{Code: code, Path: path, Message: message, AffectsScope: true})
}

func (b *builder) skip(name, kind, code, message string, size int64) {
	b.skipped = append(b.skipped, model.File{Path: name, Kind: kind, Size: size, Status: "skipped", Reason: code})
	b.issue(code, name, message)
}

func (b *builder) countEntry(name string) bool {
	b.entries++
	if b.entries > b.limits.MaxEntries {
		b.issue("entry_limit", name, "Inventory stopped at the entry limit; remaining entries are unknown.")
		return false
	}

	return true
}

func (b *builder) captureFile(ctx context.Context, root *rootfs.Root, name string) {
	f, err := root.Open(name)
	if err != nil {
		b.skip(name, "file", "file_unreadable", "File could not be opened safely.", -1)
		return
	}
	defer func() { _ = f.Close() }()

	before, err := f.Stat()
	if err != nil {
		b.skip(name, "file", "file_unreadable", "File metadata could not be read.", -1)
		return
	}

	if !before.Mode().IsRegular() {
		b.skip(name, "special", "nonregular_refused", "Entry was not a regular file at capture time.", -1)
		return
	}

	budget := min(b.limits.MaxFileBytes, b.limits.MaxTotalBytes-b.consumed)
	if before.Size() > b.limits.MaxFileBytes {
		b.skip(name, "file", "file_size_limit", "File exceeds the per-file budget; no prefix was scanned.", before.Size())
		return
	}

	if budget <= 0 || before.Size() > budget {
		b.skip(name, "file", "total_size_limit", "Aggregate byte budget exhausted; file was not captured.", before.Size())
		return
	}

	data, err := readBounded(ctx, f, budget)

	b.consumed += int64(len(data))
	if err != nil {
		b.skip(name, "file", "file_read_error", "Bounded file capture failed; no prefix was scanned.", before.Size())
		return
	}

	after, err := f.Stat()
	if err != nil || changed(before, after, int64(len(data))) {
		b.skip(name, "file", "file_changed", "File changed while being captured; captured bytes were discarded.", before.Size())
		return
	}

	b.files = append(b.files, artifact.NewFile(name, data, before.Mode()&0o111 != 0))
}

func (r contextReader) Read(p []byte) (int, error) {
	if err := r.ctx.Err(); err != nil {
		return 0, err
	}

	return r.reader.Read(p)
}

func readSelectedFile(ctx context.Context, target string, info os.FileInfo, maxBytes int64) ([]byte, error) {
	if info.Size() < 0 || info.Size() > maxBytes {
		return nil, errors.New("input exceeds byte budget")
	}

	root, err := rootfs.Open(filepath.Dir(target))
	if err != nil {
		return nil, fmt.Errorf("open input parent: %w", err)
	}
	defer func() { _ = root.Close() }()

	f, err := root.Open(filepath.Base(target))
	if err != nil {
		return nil, fmt.Errorf("open input: %w", err)
	}
	defer func() { _ = f.Close() }()

	before, err := f.Stat()
	if err != nil {
		return nil, err
	}

	if !before.Mode().IsRegular() || !os.SameFile(info, before) {
		return nil, errors.New("input changed before capture")
	}

	data, err := readBounded(ctx, f, maxBytes)
	if err != nil {
		return nil, err
	}

	after, err := f.Stat()
	if err != nil {
		return nil, err
	}

	if changed(before, after, int64(len(data))) {
		return nil, errors.New("input changed during capture")
	}

	return data, nil
}

func readDirectory(ctx context.Context, target string, initial os.FileInfo, limits model.Limits) (artifact.Snapshot, error) {
	root, err := rootfs.Open(target)
	if err != nil {
		return artifact.Snapshot{}, err
	}
	defer func() { _ = root.Close() }()

	b := newBuilder(limits)

	probe, err := root.Open(".")
	if err != nil {
		return artifact.Snapshot{}, err
	}

	actual, statErr := probe.Stat()
	_ = probe.Close()

	if statErr != nil {
		return artifact.Snapshot{}, statErr
	}

	if !os.SameFile(initial, actual) {
		return artifact.Snapshot{}, errors.New("input directory changed before capture")
	}

	queue := []string{"."}

	stop := false
	for len(queue) > 0 && !stop {
		if err := ctx.Err(); err != nil {
			return b.snapshot("directory"), err
		}

		dir := queue[0]
		queue = queue[1:]

		f, err := root.Open(dir)
		if err != nil {
			b.issue("directory_unreadable", dir, "Directory could not be opened safely; its contents are unknown.")
			continue
		}

		entries, limited, readErr := b.directoryEntries(ctx, f, dir)
		_ = f.Close()

		if readErr != nil {
			return b.snapshot("directory"), readErr
		}

		sort.Slice(entries, func(i, j int) bool { return entries[i].Name() < entries[j].Name() })

		entryLimit, visitErr := b.visitDirectoryEntries(ctx, root, dir, entries, &queue)
		if visitErr != nil {
			return b.snapshot("directory"), visitErr
		}

		stop = limited || entryLimit
	}

	snapshot := b.snapshot("directory")
	if err := ctx.Err(); err != nil {
		return snapshot, err
	}

	if len(b.files) == 0 && len(b.skipped) == 0 && b.complete {
		return snapshot, ErrEmpty
	}

	return snapshot, nil
}

func (b *builder) visitDirectoryEntries(ctx context.Context, root *rootfs.Root, dir string, entries []os.DirEntry, queue *[]string) (bool, error) {
	for _, entry := range entries {
		if err := ctx.Err(); err != nil {
			return false, err
		}

		name := entry.Name()
		if dir != "." {
			name = dir + "/" + name
		}

		if err := ValidatePath(name, b.limits.MaxPathBytes, b.limits.MaxDepth); err != nil {
			b.skip(name, "unknown", "invalid_path", "Entry has an unsupported or ambiguous path; descendants were not visited.", -1)
			continue
		}

		if err := b.names.Add(name, entry.IsDir()); err != nil {
			b.skip(name, "unknown", "path_collision", "Entry conflicts with another portable path; descendants were not visited.", -1)
			continue
		}

		if entry.Type()&os.ModeSymlink != 0 {
			b.skip(name, "symlink", "symlink_refused", "Symbolic links are not followed.", -1)
			continue
		}

		if entry.Type() != 0 && !entry.IsDir() {
			b.skip(name, "special", "special_file_refused", "Sockets, devices and other special files are not read.", -1)
			continue
		}

		if entry.IsDir() {
			*queue = append(*queue, name)
			continue
		}

		b.fileEntries++
		if b.fileEntries > b.limits.MaxFiles {
			b.issue("file_count_limit", name, "File count budget exhausted; remaining file contents were not captured.")

			return true, nil
		}

		b.captureFile(ctx, root, name)
	}

	return false, nil
}

func (b *builder) directoryEntries(ctx context.Context, f *os.File, dir string) ([]os.DirEntry, bool, error) {
	// Read in bounded chunks; os.ReadDir would allocate every entry at once.
	entries := []os.DirEntry{}

	for {
		if err := ctx.Err(); err != nil {
			return entries, false, err
		}

		batch, readErr := f.ReadDir(64)
		limited := false

		for _, entry := range batch {
			if !b.countEntry(dir) {
				limited = true
				break
			}

			entries = append(entries, entry)
		}

		if limited || readErr != nil {
			if readErr != nil && !errors.Is(readErr, io.EOF) {
				b.issue("directory_read_error", dir, "Directory enumeration was incomplete.")
			}

			return entries, limited, nil
		}
	}
}

func changed(before, after os.FileInfo, size int64) bool {
	return !os.SameFile(before, after) || before.Size() != after.Size() || after.Size() != size ||
		!before.ModTime().Equal(after.ModTime()) || before.Mode() != after.Mode()
}

func readBounded(ctx context.Context, r io.Reader, maxBytes int64) ([]byte, error) {
	if maxBytes < 0 {
		return nil, errors.New("negative read budget")
	}

	data, err := io.ReadAll(io.LimitReader(contextReader{ctx: ctx, reader: r}, maxBytes+1))
	if err != nil {
		return data, err
	}

	if int64(len(data)) > maxBytes {
		return data, errors.New("byte budget exceeded")
	}

	if err := ctx.Err(); err != nil {
		return data, err
	}

	return data, nil
}
