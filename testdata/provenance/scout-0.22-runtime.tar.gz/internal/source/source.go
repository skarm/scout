// Package source maps analysis views and coordinates to original source bytes.
// It never normalizes, executes or reopens the captured content.
package source

import (
	"errors"
	"sort"
	"strings"
	"unicode/utf8"
)

// Span is a zero-based, half-open byte interval.
type Span struct{ Start, End int }

// Index is immutable and safe for concurrent readers. Line endings remain in
// the original text; columns count Unicode code points, not bytes or UTF-16.
type Index struct {
	text  string
	lines []int
}

// A sparse index avoids eight bytes of metadata for every byte of an input
// consisting entirely of newlines. A lookup scans at most one 64-line block.
const indexStride = 64

func NewIndex(text string) Index {
	lines := make([]int, 1, strings.Count(text, "\n")/indexStride+1)
	line := 0

	for at := 0; at < len(text); {
		n := strings.IndexByte(text[at:], '\n')
		if n < 0 {
			break
		}

		at += n + 1

		line++
		if line%indexStride == 0 {
			lines = append(lines, at)
		}
	}

	return Index{text: text, lines: lines}
}

func (i Index) Position(offset int) (line, column int, err error) {
	if offset < 0 || offset > len(i.text) || (offset < len(i.text) && !utf8.RuneStart(i.text[offset])) {
		return 0, 0, errors.New("invalid source offset")
	}

	n := sort.Search(len(i.lines), func(n int) bool { return i.lines[n] > offset }) - 1
	if n < 0 {
		return 0, 0, errors.New("uninitialized source index")
	}

	block := i.text[i.lines[n]:offset]

	return n*indexStride + strings.Count(block, "\n") + 1,
		utf8.RuneCountInString(block[strings.LastIndexByte(block, '\n')+1:]) + 1, nil
}

type segment struct {
	viewStart int
	original  Span
	replaced  bool
}

// View is an immutable concatenation of original source spans. Its mapping is
// piecewise, not an assumed constant offset: Markdown indentation may differ
// between lines. A mapped multi-line span encloses intervening original bytes.
type View struct {
	text     string
	segments []segment
	parent   *View
}

// Replacement projects trusted scanner text onto an enclosing original span.
// It never assigns invented per-character coordinates to expanded Unicode.
type Replacement struct {
	Span Span
	Text string
}

func NewView(original string, spans []Span) (View, error) {
	var b strings.Builder

	last := 0
	total := 0

	for _, s := range spans {
		if s.Start < last || s.End < s.Start || s.End > len(original) ||
			(s.Start < len(original) && !utf8.RuneStart(original[s.Start])) ||
			(s.End < len(original) && !utf8.RuneStart(original[s.End])) {
			return View{}, errors.New("invalid or overlapping source spans")
		}

		last = s.End
		total += s.End - s.Start
	}

	b.Grow(total)

	segments := make([]segment, 0, len(spans))
	for _, s := range spans {
		if s.Start == s.End {
			continue
		}

		segments = append(segments, segment{viewStart: b.Len(), original: s})
		b.WriteString(original[s.Start:s.End])
	}

	return View{text: b.String(), segments: segments}, nil
}

func (v View) Replace(replacements []Replacement) (View, error) {
	var b strings.Builder

	segments := []segment{}
	last := 0

	appendPart := func(s Span, text string, replaced bool) {
		if text == "" {
			return
		}

		start := b.Len()
		b.WriteString(text)

		segments = append(segments, segment{viewStart: start, original: s, replaced: replaced})
	}
	for _, r := range replacements {
		s := r.Span
		if s.Start < last || s.End <= s.Start || s.End > len(v.text) ||
			!utf8.RuneStart(v.text[s.Start]) || (s.End < len(v.text) && !utf8.RuneStart(v.text[s.End])) || !utf8.ValidString(r.Text) {
			return View{}, errors.New("invalid projected source span")
		}

		appendPart(Span{last, s.Start}, v.text[last:s.Start], false)
		appendPart(s, r.Text, true)
		last = s.End
	}

	appendPart(Span{last, len(v.text)}, v.text[last:], false)

	return View{text: b.String(), segments: segments, parent: &v}, nil
}

func (v View) Text() string { return v.text }

func (v View) Original(s Span) (Span, error) {
	if s.Start < 0 || s.End <= s.Start || s.End > len(v.text) || len(v.segments) == 0 ||
		!utf8.RuneStart(v.text[s.Start]) || (s.End < len(v.text) && !utf8.RuneStart(v.text[s.End])) {
		return Span{}, errors.New("invalid analysis span")
	}

	lookup := func(offset int, end bool) int {
		n := sort.Search(len(v.segments), func(n int) bool { return v.segments[n].viewStart > offset }) - 1
		if v.segments[n].replaced {
			if end {
				return v.segments[n].original.End
			}

			return v.segments[n].original.Start
		}

		if end {
			return v.segments[n].original.Start + offset - v.segments[n].viewStart + 1
		}

		return v.segments[n].original.Start + offset - v.segments[n].viewStart
	}

	result := Span{Start: lookup(s.Start, false), End: lookup(s.End-1, true)}
	if v.parent != nil {
		return v.parent.Original(result)
	}

	return result, nil
}
