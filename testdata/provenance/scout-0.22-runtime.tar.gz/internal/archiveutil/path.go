// Package archiveutil validates archive structure without extracting to disk.
package archiveutil

import (
	"errors"
	"io/fs"
	"strings"
	"unicode"
	"unicode/utf8"
)

// Namespace catches duplicate paths, case-fold collisions, and file/directory
// prefix conflicts before any archive payload is accepted.
type Namespace struct {
	nodes    map[string]pathNode
	MaxNodes int
	bytes    int
}
type pathNode struct {
	spelling  string
	directory bool
	explicit  bool
}

// ValidatePath applies one conservative path policy on every OS. ZIP names are
// rejected, never cleaned into a different path. Backslashes and Windows device
// names are rejected even on Linux. Unicode normalization is NOT implemented.
func ValidatePath(name string, maxBytes, maxDepth int) error {
	if len(name) > maxBytes || !utf8.ValidString(name) || !fs.ValidPath(name) || name == "." {
		return errors.New("invalid or overlong relative path")
	}

	if strings.ContainsAny(name, `\:<>"|?*`) {
		return errors.New("nonportable path character")
	}

	for _, r := range name {
		if unicode.IsControl(r) || unicode.Is(unicode.Cf, r) {
			return errors.New("control or format character in path")
		}
	}

	parts := strings.Split(name, "/")
	if len(parts) > maxDepth {
		return errors.New("path depth limit exceeded")
	}

	for _, part := range parts {
		if strings.TrimRight(part, " .") != part || strings.HasPrefix(part, " ") {
			return errors.New("ambiguous path component")
		}

		base, _, _ := strings.Cut(strings.ToUpper(part), ".")
		switch base {
		case "CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$":
			return errors.New("reserved device name")
		}

		if len(base) == 4 && (strings.HasPrefix(base, "COM") || strings.HasPrefix(base, "LPT")) && base[3] >= '1' && base[3] <= '9' {
			return errors.New("reserved device name")
		}

		if base == "COM¹" || base == "COM²" || base == "COM³" || base == "LPT¹" || base == "LPT²" || base == "LPT³" {
			return errors.New("reserved device name")
		}
	}

	return nil
}

func (i *Namespace) Add(name string, directory bool) error {
	if i.nodes == nil {
		i.nodes = make(map[string]pathNode)
	}

	parts := strings.Split(name, "/")
	for n := range parts {
		prefix := strings.Join(parts[:n+1], "/")
		key := foldPath(prefix)
		last := n == len(parts)-1
		dir := !last || directory

		previous, exists := i.nodes[key]
		if exists {
			if previous.spelling != prefix {
				return errors.New("case-fold path collision")
			}

			if !previous.directory || !dir {
				return errors.New("duplicate path or file/directory conflict")
			}

			if last && previous.explicit {
				return errors.New("duplicate directory entry")
			}
		} else {
			// ZIP entries may imply many parent directories. Bound the
			// expanded namespace as well as the central-directory count.
			if (i.MaxNodes > 0 && len(i.nodes) >= i.MaxNodes) || i.bytes+len(prefix)+len(key) > 8<<20 {
				return errors.New("expanded namespace metadata budget exceeded")
			}

			i.bytes += len(prefix) + len(key)
			previous = pathNode{spelling: prefix, directory: dir}
		}

		if last {
			previous.explicit = true
		}

		i.nodes[key] = previous
	}

	return nil
}

func foldPath(s string) string {
	return strings.Map(func(r rune) rune {
		minimumRune := r
		for next := unicode.SimpleFold(r); next != r; next = unicode.SimpleFold(next) {
			if next < minimumRune {
				minimumRune = next
			}
		}

		return minimumRune
	}, s)
}
