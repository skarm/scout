package archiveutil

import (
	"archive/zip"
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"io"
	"sort"
	"strings"
)

// OpenZIP accepts only bounded, single-disk ZIP32 with an unambiguous namespace.
// The central-directory envelope is inspected BEFORE archive/zip may allocate
// its entry inventory. No member contents are decompressed by this function.
func OpenZIP(ctx context.Context, data []byte, maxEntries, maxPath, maxDepth int) (*zip.Reader, error) {
	return OpenZIPWithBudget(ctx, data, maxEntries, maxPath, maxDepth, nil)
}

// OpenZIPWithBudget charges entries during envelope validation, including an
// entry that later fails validation. The callback is trusted scanner code.
func OpenZIPWithBudget(ctx context.Context, data []byte, maxEntries, maxPath, maxDepth int, visit func() error) (*zip.Reader, error) {
	if ctx == nil || maxEntries < 0 || maxEntries > 100000 || maxPath < 1 || maxPath > 4096 || maxDepth < 1 || maxDepth > 128 {
		return nil, errors.New("invalid ZIP validation arguments")
	}

	if err := zipEnvelope(ctx, data, maxEntries, visit); err != nil {
		return nil, err
	}

	zr, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		return nil, err
	}

	names := Namespace{MaxNodes: maxEntries}

	for _, entry := range zr.File {
		if err := ctx.Err(); err != nil {
			return nil, err
		}

		name := strings.TrimSuffix(entry.Name, "/")
		if err := ValidatePath(name, maxPath, maxDepth); err != nil {
			return nil, errors.New("unsafe ZIP path")
		}

		directory := strings.HasSuffix(entry.Name, "/")
		if err := names.Add(name, directory); err != nil {
			return nil, err
		}

		mode := entry.Mode()
		if directory != mode.IsDir() || (!mode.IsRegular() && !mode.IsDir()) {
			return nil, errors.New("ZIP link, special file or inconsistent directory")
		}

		if entry.Flags&1 != 0 || entry.Flags&64 != 0 {
			return nil, errors.New("encrypted ZIP entry")
		}

		if entry.Method != zip.Store && entry.Method != zip.Deflate {
			return nil, errors.New("unsupported ZIP compression")
		}

		if directory && entry.UncompressedSize64 != 0 {
			return nil, errors.New("directory payload")
		}
	}

	return zr, nil
}

func zipEnvelope(ctx context.Context, data []byte, maxEntries int, visit func() error) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	// EOCD must end at EOF. Appended data and self-extracting wrappers are not
	// part of this deliberately narrow archive profile.
	end := -1

	for i := len(data) - 22; i >= max(0, len(data)-22-65535); i-- {
		if binary.LittleEndian.Uint32(data[i:i+4]) == 0x06054b50 && i+22+int(binary.LittleEndian.Uint16(data[i+20:i+22])) == len(data) {
			end = i
			break
		}
	}

	if end < 0 {
		return errors.New("invalid ZIP end record")
	}

	e := data[end:]
	count := int(binary.LittleEndian.Uint16(e[10:12]))
	size := uint64(binary.LittleEndian.Uint32(e[12:16]))

	offset := binary.LittleEndian.Uint32(e[16:20])
	if binary.LittleEndian.Uint16(e[4:6]) != 0 || binary.LittleEndian.Uint16(e[6:8]) != 0 || int(binary.LittleEndian.Uint16(e[8:10])) != count {
		return errors.New("multi-disk ZIP is unsupported")
	}

	if count == 0xffff || size == 0xffffffff || offset == 0xffffffff {
		return errors.New("ZIP64 is not supported in this profile")
	}

	if count > maxEntries {
		return errors.New("ZIP inventory exceeds entry budget")
	}

	if uint64(offset)+size != uint64(end) || uint64(offset) > uint64(len(data)) || uint64(offset) > uint64(^uint(0)>>1) {
		return errors.New("invalid or unsupported ZIP central directory")
	}

	records := zipRecords{data: data, offset: offset, end: end, cursor: int(offset), extents: make([]zipExtent, 0, count)}

	for range count {
		if visit != nil {
			if err := visit(); err != nil {
				return err
			}
		}

		if err := ctx.Err(); err != nil {
			return err
		}

		if err := records.readRecord(); err != nil {
			return err
		}
	}

	if records.cursor != end {
		return errors.New("ZIP entry count does not match central directory")
	}

	extents := records.extents
	sort.Slice(extents, func(i, j int) bool { return extents[i].start < extents[j].start })

	for i := 1; i < len(extents); i++ {
		if extents[i].start < extents[i-1].end {
			return errors.New("overlapping ZIP members")
		}
	}

	if len(extents) > 0 && extents[0].start != 0 {
		return errors.New("ZIP preambles are unsupported")
	}

	return nil
}

type zipExtent struct{ start, end int64 }

type zipRecords struct {
	data        []byte
	offset      uint32
	end, cursor int
	extents     []zipExtent
}

func (r *zipRecords) readRecord() error {
	data, offset, end, cursor := r.data, r.offset, r.end, r.cursor
	if cursor > end-46 || binary.LittleEndian.Uint32(data[cursor:cursor+4]) != 0x02014b50 {
		return errors.New("invalid ZIP central record")
	}

	record := data[cursor : cursor+46]
	// ZIP64 fields and split archives are rejected before parser expansion.
	if binary.LittleEndian.Uint16(record[34:36]) != 0 || binary.LittleEndian.Uint32(record[20:24]) == 0xffffffff || binary.LittleEndian.Uint32(record[24:28]) == 0xffffffff || binary.LittleEndian.Uint32(record[42:46]) == 0xffffffff {
		return errors.New("ZIP64 or split member is unsupported")
	}

	localOffset := int64(binary.LittleEndian.Uint32(record[42:46]))
	if localOffset+30 > int64(offset) || binary.LittleEndian.Uint32(data[localOffset:localOffset+4]) != 0x04034b50 {
		return errors.New("invalid ZIP local header")
	}

	nameLength := int(binary.LittleEndian.Uint16(record[28:30]))

	next := cursor + 46 + nameLength + int(binary.LittleEndian.Uint16(record[30:32])) + int(binary.LittleEndian.Uint16(record[32:34]))
	if next > end {
		return io.ErrUnexpectedEOF
	}

	local := data[localOffset : localOffset+30]
	localNameLength := int64(binary.LittleEndian.Uint16(local[26:28]))
	localExtraLength := int64(binary.LittleEndian.Uint16(local[28:30]))
	payloadStart := localOffset + 30 + localNameLength + localExtraLength

	payloadEnd := payloadStart + int64(binary.LittleEndian.Uint32(record[20:24]))
	if payloadEnd > int64(offset) {
		return errors.New("ZIP member overlaps central directory")
	}

	if localNameLength != int64(nameLength) || !bytes.Equal(data[localOffset+30:localOffset+30+localNameLength], data[cursor+46:cursor+46+nameLength]) {
		return errors.New("ZIP local and central names disagree")
	}

	if !bytes.Equal(local[6:10], record[8:12]) {
		return errors.New("ZIP local and central flags/method disagree")
	}

	recordEnd := payloadEnd

	if binary.LittleEndian.Uint16(local[6:8])&8 == 0 {
		if !bytes.Equal(local[14:26], record[16:28]) {
			return errors.New("ZIP local and central CRC/size disagree")
		}
	} else {
		// A descriptor is 12 bytes, optionally preceded by its signature.
		// Bound it against the central directory before slicing it.
		dd := payloadEnd
		if dd+12 > int64(offset) {
			return io.ErrUnexpectedEOF
		}

		if binary.LittleEndian.Uint32(data[dd:dd+4]) == 0x08074b50 {
			dd += 4
		}

		if dd+12 > int64(offset) {
			return io.ErrUnexpectedEOF
		}

		if !bytes.Equal(data[dd:dd+12], record[16:28]) {
			return errors.New("ZIP descriptor disagrees with directory")
		}

		recordEnd = dd + 12

		for i := range 3 {
			value := binary.LittleEndian.Uint32(local[14+i*4 : 18+i*4])
			if value != 0 && value != binary.LittleEndian.Uint32(record[16+i*4:20+i*4]) {
				return errors.New("ZIP descriptor-mode local field disagrees")
			}
		}
	}

	r.extents = append(r.extents, zipExtent{localOffset, recordEnd})
	r.cursor = next

	return nil
}
