package language

// Shared vocabulary used by this package's protocols and reports.
const (
	valueDockerfile = "dockerfile"
	valueMakefile   = "makefile"
	formatMarkdown  = "markdown"
	valuePhp        = "php"
	languagePython  = "python"
	valueRuby       = "ruby"
	formatText      = "text"
	valueUnknown    = "unknown"
)
