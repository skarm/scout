// Package language identifies candidate languages, not trusted file types or
// implemented analysis capabilities. Detection never suppresses byte checks.
package language

import (
	"path"
	"slices"
	"strings"
)

// Hint contains only scanner-owned labels; source excerpts are never echoed.
type Hint struct {
	Language string `json:"language"`
	Basis    string `json:"basis"`
}

// Normalize also accepts conventional Markdown fence aliases. Unknown labels
// remain unknown, rather than becoming arbitrary output fields or parser names.
func Normalize(s string) string {
	switch strings.ToLower(s) {
	case "go", "golang":
		return "go"
	case "py", languagePython, "python2", "python3":
		return languagePython
	case "sh", "bash", "dash", "zsh", "ksh", "shell", "shellscript":
		return "shell"
	case "js", "javascript", "node", "nodejs", "jsx":
		return "javascript"
	case "ts", "typescript", "tsx":
		return "typescript"
	case "ps1", "powershell", "pwsh":
		return "powershell"
	case "bat", "batch", "cmd":
		return "batch"
	case "rb", valueRuby:
		return valueRuby
	case "pl", "perl":
		return "perl"
	case valuePhp:
		return valuePhp
	case "lua":
		return "lua"
	case "rs", "rust":
		return "rust"
	case "c", "h":
		return "c"
	case "cpp", "c++", "cxx", "cc", "hpp", "hxx":
		return "cpp"
	case "cs", "csharp", "c#":
		return "csharp"
	case "java":
		return "java"
	case "kt", "kts", "kotlin":
		return "kotlin"
	case "swift":
		return "swift"
	case "r":
		return "r"
	case "sql":
		return "sql"
	default:
		return normalizeDocument(s)
	}
}

func normalizeDocument(s string) string {
	switch strings.ToLower(s) {
	case "json", "jsonl", "ndjson", "jsonc", "json5":
		return "json"
	case "yaml", "yml":
		return "yaml"
	case "toml":
		return "toml"
	case "xml", "svg":
		return "xml"
	case "html", "htm":
		return "html"
	case "ini", "cfg", "env":
		return "ini"
	case "hcl", "tf", "tfvars":
		return "hcl"
	case valueDockerfile, "containerfile":
		return valueDockerfile
	case valueMakefile, "make":
		return valueMakefile
	case "gomod":
		return "gomod"
	case "dependency-manifest":
		return "dependency-manifest"
	case "md", formatMarkdown, "mdown":
		return formatMarkdown
	case "txt", formatText, "plaintext", "output", "rst", "csv", "tsv":
		return formatText
	default:
		return valueUnknown
	}
}

func Structured(id string) bool {
	return id != valueUnknown && id != formatText && id != formatMarkdown
}

// Detect preserves conflicting candidates instead of trusting one declaration.
// Content heuristics are intentionally narrow; this is not language recognition.
func Detect(name, data string) []Hint {
	var out []Hint

	add := func(id, basis string) {
		if id != valueUnknown {
			out = append(out, Hint{id, basis})
		}
	}
	base := strings.ToLower(path.Base(name))

	ext := strings.TrimPrefix(strings.ToLower(path.Ext(base)), ".")
	switch ext {
	case "mjs", "cjs":
		ext = "js"
	case "mts", "cts":
		ext = "ts"
	case "pyw", "pyi":
		ext = "py"
	case "psm1", "psd1":
		ext = "ps1"
	case "phtml", "php3", "php4", "php5", "php7", "php8":
		ext = valuePhp
	case "rake":
		ext = valueRuby
	}

	add(Normalize(ext), "extension")

	switch base {
	case valueDockerfile, "containerfile":
		add(valueDockerfile, "basename")
	case valueMakefile, "gnumakefile":
		add(valueMakefile, "basename")
	case "gemfile", "rakefile":
		add(valueRuby, "basename")
	case ".bashrc", ".bash_profile", ".zshrc", ".profile":
		add("shell", "basename")
	case ".env":
		add("ini", "basename")
	case "go.mod":
		add("gomod", "basename")
	case "uv.lock", "poetry.lock", "pipfile", "cargo.lock":
		add("toml", "basename")
	case "go.sum", "requirements.txt", "pipfile.lock":
		add("dependency-manifest", "basename")
	case "readme":
		add(formatMarkdown, "basename")
	case "license", "licence", "copying", "notice":
		add(formatText, "basename")
	}

	prefix := data
	if len(prefix) > 512 {
		prefix = prefix[:512]
	}

	prefix = strings.TrimPrefix(prefix, "\ufeff")
	if hint, ok := shebangHint(prefix); ok {
		add(hint.Language, hint.Basis)
	}

	trimmed := strings.TrimSpace(prefix)
	// JSON can be renamed or embedded in an otherwise unrecognized file. This
	// is only a candidate; syntax and duplicate keys are checked by the backend.
	if len(trimmed) > 1 && (trimmed[0] == '{' || trimmed[0] == '[') {
		next := strings.TrimSpace(trimmed[1:])
		if strings.HasPrefix(next, "\"") || strings.HasPrefix(next, "{") {
			add("json", "content-prefix")
		}
	}

	if strings.HasPrefix(trimmed, "<?php") {
		add(valuePhp, "content-prefix")
	}
	// A renamed Go file can still reach the Go parser. This is only a candidate:
	// the parser will reject false positives and preserve incomplete coverage.
	if strings.HasPrefix(trimmed, "package ") {
		line, _, _ := strings.Cut(trimmed, "\n")
		if !strings.Contains(line, ";") {
			add("go", "content-prefix")
		}
	}

	return out
}

func shebangHint(prefix string) (Hint, bool) {
	if !strings.HasPrefix(prefix, "#!") {
		return Hint{}, false
	}

	line, _, _ := strings.Cut(prefix[2:], "\n")
	fields := strings.Fields(line)
	// Only fixed tokens are recognized; options and assignments are never executed.
	for _, field := range fields {
		if strings.HasPrefix(field, "-") || strings.Contains(field, "=") {
			continue
		}

		exe := path.Base(field)
		if exe == "uv" {
			return Hint{languagePython, "uv-shebang"}, slices.Contains(fields, "run")
		}

		if exe == "env" {
			continue
		}

		id := Normalize(exe)
		if strings.HasPrefix(exe, "python3.") || strings.HasPrefix(exe, "python2.") {
			id = languagePython
		}

		if Structured(id) {
			return Hint{id, "shebang"}, true
		}
	}

	return Hint{}, false
}
