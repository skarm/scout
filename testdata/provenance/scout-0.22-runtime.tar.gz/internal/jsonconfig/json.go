// Package jsonconfig builds a bounded, source-located JSON tree using the Go
// standard decoder. It never loads files, resolves references or executes hooks.
package jsonconfig

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/skarm/scout/internal/source"
)

const (
	MaxBytes = 256 << 10
	MaxDepth = 32
	MaxNodes = 8192
)

// Node and Member are private to one preparation pass. Only trusted read-only
// checks receive them. Values are not copied to public reports.
type Node struct {
	Kind     string
	Span     source.Span
	String   string
	Bool     bool
	Members  []Member
	Elements []*Node
}
type Member struct {
	Key     string
	KeySpan source.Span
	Value   *Node
}

// Error never contains input text. No partial configuration tree is returned:
// an ambiguous key or malformed document cannot choose which policy to inspect.
type Error struct{ Code string }

type reader struct {
	ctx     context.Context
	text    string
	decoder *json.Decoder
	nodes   int
}

func Parse(ctx context.Context, text string) (*Node, error) {
	if ctx == nil {
		return nil, &Error{"nil_context"}
	}

	if err := ctx.Err(); err != nil {
		return nil, err
	}

	if len(text) > MaxBytes {
		return nil, &Error{"byte_limit"}
	}

	if !utf8.ValidString(text) {
		return nil, &Error{"invalid_unicode"}
	}

	r := reader{ctx: ctx, text: text, decoder: json.NewDecoder(strings.NewReader(text))}
	r.decoder.UseNumber()

	n, err := r.value(0)
	if err != nil {
		return nil, err
	}

	if _, err = r.decoder.Token(); !errors.Is(err, io.EOF) {
		return nil, &Error{"trailing_data"}
	}

	if err := ctx.Err(); err != nil {
		return nil, err
	}

	return n, nil
}

func (n *Node) Get(key string) *Node {
	if n == nil {
		return nil
	}

	for _, m := range n.Members {
		if m.Key == key {
			return m.Value
		}
	}

	return nil
}

func (n *Node) GetOrEmpty(key string) *Node {
	if v := n.Get(key); v != nil {
		return v
	}

	return &Node{}
}

func (n *Node) Text() (string, bool) {
	if n == nil || n.Kind != "string" {
		return "", false
	}

	return n.String, true
}

func (e *Error) Error() string { return "configuration JSON: " + e.Code }

func (r *reader) token() (json.Token, source.Span, error) {
	if err := r.ctx.Err(); err != nil {
		return nil, source.Span{}, err
	}

	start := int(r.decoder.InputOffset())
	// InputOffset precedes separators/whitespace consumed by Token. These are
	// not part of a string value's evidence. Token still validates the grammar.
	for start < len(r.text) && strings.ContainsRune(" \t\r\n,:", rune(r.text[start])) {
		start++
	}

	t, err := r.decoder.Token()
	if err != nil {
		return nil, source.Span{}, &Error{valueSyntaxError}
	}

	end := int(r.decoder.InputOffset())

	span := source.Span{Start: start, End: end}
	if start >= end || end > len(r.text) {
		return nil, source.Span{}, &Error{"invalid_span"}
	}

	if _, ok := t.(string); ok && !validString(r.text[start:end]) {
		return nil, span, &Error{"invalid_unicode"}
	}

	return t, span, nil
}

func (r *reader) charge() error {
	r.nodes++
	if r.nodes > MaxNodes {
		return &Error{"node_limit"}
	}

	return nil
}

func (r *reader) value(depth int) (*Node, error) {
	if depth > MaxDepth {
		return nil, &Error{"depth_limit"}
	}

	if err := r.charge(); err != nil {
		return nil, err
	}

	t, span, err := r.token()
	if err != nil {
		return nil, err
	}

	n := &Node{Span: span}

	switch v := t.(type) {
	case json.Delim:
		switch v {
		case '{':
			return r.object(n, depth)
		case '[':
			n.Kind = "array"

			for r.decoder.More() {
				child, err := r.value(depth + 1)
				if err != nil {
					return nil, err
				}

				n.Elements = append(n.Elements, child)
			}

			closing, at, err := r.token()
			if err != nil || closing != json.Delim(']') {
				return nil, &Error{valueSyntaxError}
			}

			n.Span.End = at.End
		default:
			return nil, &Error{valueSyntaxError}
		}
	case string:
		n.Kind, n.String = "string", v
	case bool:
		n.Kind, n.Bool = "bool", v
	case nil:
		n.Kind = "null"
	case json.Number:
		n.Kind, n.String = "number", string(v)
	default:
		return nil, &Error{valueSyntaxError}
	}

	return n, nil
}

func (r *reader) object(n *Node, depth int) (*Node, error) {
	n.Kind = "object"
	keys := make(map[string]bool)

	for r.decoder.More() {
		if err := r.charge(); err != nil {
			return nil, err
		}

		key, at, err := r.token()
		if err != nil {
			return nil, err
		}

		name, ok := key.(string)
		if !ok {
			return nil, &Error{valueSyntaxError}
		}
		// Compare decoded keys, including their escaped spellings.
		if keys[name] {
			return nil, &Error{"duplicate_key"}
		}

		keys[name] = true

		child, err := r.value(depth + 1)
		if err != nil {
			return nil, err
		}

		n.Members = append(n.Members, Member{name, at, child})
	}

	closing, at, err := r.token()
	if err != nil || closing != json.Delim('}') {
		return nil, &Error{valueSyntaxError}
	}

	n.Span.End = at.End

	return n, nil
}

// encoding/json accepts lone UTF-16 surrogate escapes by replacement. Reject
// these rather than analyzing a different string from another host's parser.
func validString(raw string) bool {
	if len(raw) < 2 || raw[0] != '"' || raw[len(raw)-1] != '"' {
		return false
	}

	for i := 1; i < len(raw)-1; {
		if raw[i] != '\\' {
			i++
			continue
		}

		if i+1 >= len(raw)-1 {
			return false
		}

		if raw[i+1] != 'u' {
			i += 2
			continue
		}

		if i+6 > len(raw)-1 {
			return false
		}

		x, err := strconv.ParseUint(raw[i+2:i+6], 16, 16)
		if err != nil {
			return false
		}

		i += 6
		if x >= 0xd800 && x <= 0xdbff {
			if i+6 > len(raw)-1 || raw[i:i+2] != "\\u" {
				return false
			}

			y, err := strconv.ParseUint(raw[i+2:i+6], 16, 16)
			if err != nil || y < 0xdc00 || y > 0xdfff {
				return false
			}

			i += 6
		} else if x >= 0xdc00 && x <= 0xdfff {
			return false
		}
	}

	return true
}
