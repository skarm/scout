package jsonconfig

// Shared vocabulary used by this package's protocols and reports.
const (
	valueSyntaxError = "syntax_error"
)
