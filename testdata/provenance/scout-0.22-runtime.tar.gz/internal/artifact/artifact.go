// Package artifact owns immutable, bounded, in-memory scan inputs.
package artifact

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"hash"
	"path"
	"sort"
	"unicode/utf8"

	"github.com/skarm/scout/internal/model"
)

type File struct {
	meta          model.File
	data          string
	generatedName bool
}

func NewFile(name string, data []byte, executable bool) File {
	kind := "text"
	if !utf8.Valid(data) || bytes.IndexByte(data, 0) >= 0 {
		kind = "binary"
	}

	return File{
		meta: model.File{
			Path: name, Size: int64(len(data)), SHA256: Hash(data),
			Executable: executable, Kind: kind, Status: "captured",
		},
		data: string(data), // Copy: callers cannot mutate bytes after capture.
	}
}

func (f File) Metadata() model.File { return f.meta }
func (f File) Content() string      { return f.data }

// GeneratedName marks scanner-created labels, not author-declared filenames.
// It never disables raw checks or changes the captured bytes/identity.
func (f File) GeneratedName() bool     { return f.generatedName }
func (f File) WithGeneratedName() File { f.generatedName = true; return f }

// Snapshot exposes immutable strings and defensive copies of slices.
type Snapshot struct {
	files       []File
	inventory   []model.File
	diagnostics []model.Diagnostic
	complete    bool
	kind        string
	digest      string
}

func New(kind string, files []File, skipped []model.File, diagnostics []model.Diagnostic, complete bool) Snapshot {
	files = append([]File(nil), files...)
	sort.Slice(files, func(i, j int) bool { return files[i].meta.Path < files[j].meta.Path })

	inventory := make([]model.File, 0, len(files)+len(skipped))
	for _, f := range files {
		inventory = append(inventory, f.meta)
	}

	inventory = append(inventory, skipped...)
	sort.Slice(inventory, func(i, j int) bool { return inventory[i].Path < inventory[j].Path })

	diagnostics = append([]model.Diagnostic(nil), diagnostics...)
	sort.Slice(diagnostics, func(i, j int) bool {
		if diagnostics[i].Path != diagnostics[j].Path {
			return diagnostics[i].Path < diagnostics[j].Path
		}

		return diagnostics[i].Code < diagnostics[j].Code
	})

	h := sha256.New()
	writeField(h, "scout-snapshot-v1")

	if complete {
		writeField(h, "complete")
	} else {
		writeField(h, "partial")
	}

	for _, f := range inventory {
		writeField(h, f.Path)
		writeField(h, f.Kind)
		writeField(h, f.Status)
		writeField(h, f.Reason)
		writeField(h, f.SHA256)

		var n [8]byte

		_, _ = binary.Encode(n[:], binary.BigEndian, f.Size)
		h.Write(n[:])

		if f.Executable {
			h.Write([]byte{1})
		} else {
			h.Write([]byte{0})
		}
	}

	return Snapshot{
		files: files, inventory: inventory, diagnostics: diagnostics,
		complete: complete, kind: kind, digest: hex.EncodeToString(h.Sum(nil)),
	}
}

func (s Snapshot) Files() []File { return append([]File(nil), s.files...) }
func (s Snapshot) Diagnostics() []model.Diagnostic {
	return append([]model.Diagnostic(nil), s.diagnostics...)
}
func (s Snapshot) Complete() bool { return s.complete }
func (s Snapshot) Count() int     { return len(s.files) }
func (s Snapshot) Metadata() model.Artifact {
	inventory := append([]model.File{}, s.inventory...)
	skills := []string{}

	for _, f := range s.files {
		if path.Base(f.meta.Path) == "SKILL.md" {
			skills = append(skills, f.meta.Path)
		}
	}

	return model.Artifact{
		SourceKind: s.kind, SnapshotSHA256: s.digest,
		InventoryComplete: s.complete, IdentityScope: "captured-content-not-install-attestation",
		Files: inventory, Skills: skills,
	}
}

func Hash(data []byte) string {
	h := sha256.Sum256(data)
	return hex.EncodeToString(h[:])
}

func writeField(h hash.Hash, value string) {
	var length [8]byte
	binary.BigEndian.PutUint64(length[:], uint64(len(value)))
	h.Write(length[:])
	h.Write([]byte(value))
}
