package hookpolicy

// Shared vocabulary used by this package's protocols and reports.
const (
	kindArray  = "array"
	valueBool  = "bool"
	kindObject = "object"
)
