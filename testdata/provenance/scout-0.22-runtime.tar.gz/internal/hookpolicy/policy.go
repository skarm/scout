// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Adapted closed settings/disable grammar from SkillSpector. Scope isolation,
// captured-byte parsing and immutable binding are Scout-specific.

// Package hookpolicy validates and binds hook settings without executing them.
package hookpolicy

import (
	"context"
	"math"
	"net/url"
	"path"
	"regexp"
	"strconv"
	"strings"

	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
)

//nolint:gochecknoglobals // Fixed event, setting and permission vocabularies shared read-only by scans.
var (
	Events = set("ConfigChange CwdChanged DirectoryAdded Elicitation ElicitationResult FileChanged InstructionsLoaded MessageDisplay Notification PermissionDenied PermissionRequest PostCompact PostToolBatch PostToolUse PostToolUseFailure PreCompact PreToolUse SessionEnd SessionStart Setup Stop StopFailure SubagentStart SubagentStop TaskCompleted TaskCreated TeammateIdle UserPromptExpansion UserPromptSubmit WorktreeCreate WorktreeRemove")
	keys   = set("$schema disableAllHooks env fileSuggestion hooks includeCoAuthoredBy model permissions statusLine")
	modes  = set("acceptEdits auto bypassPermissions default dontAsk manual plan")
)

var (
	toolName    = regexp.MustCompile(`^[A-Za-z0-9_*.-]+$`)
	mcpWildcard = regexp.MustCompile(`^mcp__[A-Za-z0-9_.-]+__[A-Za-z0-9_.-]*\*$`)
)

type (
	State  struct{ Disabled, Uncertain bool }
	Policy map[string]State
)

func IsSettings(name string) bool {
	b := path.Base(name)
	return b == "settings.json" || b == "settings.local.json"
}

// ValidDisable only trusts the closed modeled schema. Unknown fields cannot
// make a risky hook disappear; a false flag is never an exemption.
func ValidDisable(n *jsonconfig.Node) bool {
	if n == nil || n.Kind != kindObject {
		return false
	}

	flag := n.Get("disableAllHooks")
	if flag == nil || flag.Kind != valueBool || !flag.Bool {
		return false
	}

	for _, m := range n.Members {
		if !keys[m.Key] {
			return false
		}

		if !validSetting(m.Key, m.Value) {
			return false
		}
	}

	return true
}

func validSetting(key string, n *jsonconfig.Node) bool {
	switch key {
	case "$schema", "model":
		if !text(n, false) {
			return false
		}
	case "includeCoAuthoredBy":
		if n.Kind != valueBool {
			return false
		}
	case "env":
		if n.Kind != kindObject {
			return false
		}

		for _, v := range n.Members {
			if !text(v.Value, false) {
				return false
			}
		}
	case "statusLine", "fileSuggestion":
		if n.Kind != kindObject {
			return false
		}

		if v := n.Get("type"); v != nil && !text(v, false) {
			return false
		}

		if v := n.Get("command"); v != nil && !text(v, false) && !stringsList(v) {
			return false
		}
	case "permissions":
		if !permissionsValid(n) {
			return false
		}
	case "hooks":
		if !hooksValid(n) {
			return false
		}
	}

	return true
}

func Local(n *jsonconfig.Node) State {
	if n == nil || n.Get("disableAllHooks") == nil {
		return State{}
	}

	flag := n.Get("disableAllHooks")
	if flag.Kind == valueBool && !flag.Bool {
		return State{}
	}

	valid := ValidDisable(n)

	return State{Disabled: valid, Uncertain: !valid}
}

// Bind honors local-before-project precedence only in the same captured
// namespace and project root. Derived strings/fences cannot supply settings.
// A nested skill/plugin is a scope boundary, even without its own settings.
type (
	address struct{ ns, name string }
	setting struct{ root *jsonconfig.Node }
)

func Bind(ctx context.Context, docs []document.File, extraction model.ExtractionReport) Policy {
	addresses := map[string]address{}

	for _, d := range docs {
		p := d.Artifact().Metadata().Path
		if !strings.HasPrefix(p, "scout-object://") {
			addresses[p] = address{"snapshot", p}
		}
	}

	for _, o := range extraction.Objects {
		if o.Role == "archive_member" {
			addresses[o.File.Path] = address{o.ParentPath, o.MemberName}
		}
	}

	settings := map[string]setting{}
	scopes := map[string]bool{}

	for _, d := range docs {
		if ctx.Err() != nil {
			return Policy{}
		}

		a, ok := addresses[d.Artifact().Metadata().Path]
		if !ok {
			continue
		}

		if path.Base(a.name) == "SKILL.md" {
			scopes[a.ns+"\x00"+path.Dir(a.name)] = true
		}

		if strings.HasSuffix(a.name, ".claude-plugin/plugin.json") || strings.HasSuffix(a.name, ".codex-plugin/plugin.json") {
			scopes[a.ns+"\x00"+path.Dir(path.Dir(a.name))] = true
		}

		if !IsSettings(a.name) {
			continue
		}

		root := path.Dir(a.name)
		if path.Base(root) == ".claude" {
			root = path.Dir(root)
		}

		scopes[a.ns+"\x00"+root] = true
		// Record invalid/unparsed files too: a malformed higher-priority setting
		// prevents an inherited disable from being treated as a closed proof.
		var n *jsonconfig.Node

		for _, u := range d.Units() {
			if t, ok := u.Tree.(parse.JSONTree); ok && u.Origin == "file" {
				n = t.Root
				break
			}
		}

		settings[a.ns+"\x00"+a.name] = setting{n}
	}

	states := scopeStates(scopes, settings)

	return bindAddresses(addresses, states)
}

func scopeStates(scopes map[string]bool, settings map[string]setting) map[string]State {
	states := map[string]State{}

	for key := range scopes {
		ns, root, _ := strings.Cut(key, "\x00")
		state := State{}

		for _, name := range []string{path.Join(root, ".claude/settings.local.json"), path.Join(root, ".claude/settings.json"), path.Join(root, "settings.local.json"), path.Join(root, "settings.json")} {
			s, ok := settings[ns+"\x00"+name]
			if !ok {
				continue
			}

			if s.root == nil || s.root.Kind != kindObject {
				state.Uncertain = true
				break
			}

			if s.root.Get("disableAllHooks") != nil {
				state = Local(s.root)
				break
			}
		}

		states[key] = state
	}

	return states
}

func bindAddresses(addresses map[string]address, states map[string]State) Policy {
	out := Policy{}

	for p, a := range addresses {
		root := path.Dir(a.name)
		for {
			if state, ok := states[a.ns+"\x00"+root]; ok {
				out[p] = state
				break
			}

			if root == "." {
				break
			}

			root = path.Dir(root)
		}
	}

	return out
}

func set(s string) map[string]bool {
	m := map[string]bool{}
	for v := range strings.FieldsSeq(s) {
		m[v] = true
	}

	return m
}

func text(n *jsonconfig.Node, nonempty bool) bool {
	s, ok := n.Text()
	return ok && len(s) <= 65536 && !strings.ContainsRune(s, 0) && (!nonempty || strings.TrimSpace(s) != "")
}

func stringsList(n *jsonconfig.Node) bool {
	if n == nil {
		return true
	}

	if n.Kind != kindArray {
		return false
	}

	for _, v := range n.Elements {
		if !text(v, true) {
			return false
		}
	}

	return true
}

func permissionsValid(n *jsonconfig.Node) bool {
	if n.Kind != kindObject {
		return false
	}

	for _, key := range []string{"allow", "ask", "deny", "additionalDirectories"} {
		if !stringsList(n.Get(key)) {
			return false
		}

		if key != "additionalDirectories" {
			for _, v := range n.GetOrEmpty(key).Elements {
				if !permissionRule(v.String, key == "allow") {
					return false
				}
			}
		}
	}

	if v := n.Get("defaultMode"); v != nil {
		s, ok := v.Text()
		if !ok || !modes[s] {
			return false
		}
	}

	for _, key := range []string{"disableBypassPermissionsMode", "disableAutoMode"} {
		if v := n.Get(key); v != nil {
			s, ok := v.Text()
			if !ok || s != "disable" {
				return false
			}
		}
	}

	return true
}

func permissionRule(s string, allow bool) bool {
	tool, tail, has := strings.Cut(s, "(")
	if !toolName.MatchString(tool) || allow && strings.Contains(tool, "*") && !mcpWildcard.MatchString(tool) {
		return false
	}

	if !has {
		return !strings.Contains(s, ")")
	}

	if !strings.HasSuffix(tail, ")") || len(tail) < 2 {
		return false
	}

	depth := 0

	for _, r := range tail[:len(tail)-1] {
		if r == '(' {
			depth++
		}

		if r == ')' {
			depth--
			if depth < 0 {
				return false
			}
		}
	}

	return depth == 0
}

func optionalHandlerFields(h *jsonconfig.Node) bool {
	for key := range strings.FieldsSeq("if statusMessage model rewakeMessage rewakeSummary") {
		if v := h.Get(key); v != nil && !text(v, false) {
			return false
		}
	}

	for key := range strings.FieldsSeq("once async asyncRewake continueOnBlock") {
		if v := h.Get(key); v != nil && v.Kind != valueBool {
			return false
		}
	}

	if v := h.Get("timeout"); v != nil {
		number, e := strconv.ParseFloat(v.String, 64)
		if v.Kind != "number" || e != nil || number <= 0 || math.IsInf(number, 0) || math.IsNaN(number) {
			return false
		}
	}

	if v := h.Get("shell"); v != nil {
		s, ok := v.Text()
		if !ok || (s != "bash" && s != "powershell") {
			return false
		}
	}

	if !stringsList(h.Get("allowedEnvVars")) {
		return false
	}

	if v := h.Get("headers"); v != nil {
		if v.Kind != kindObject {
			return false
		}

		for _, m := range v.Members {
			if !text(m.Value, false) {
				return false
			}
		}
	}

	if v := h.Get("input"); v != nil && v.Kind != kindObject {
		return false
	}

	return true
}

func hooksValid(n *jsonconfig.Node) bool {
	if n.Kind != kindObject {
		return false
	}

	for _, event := range n.Members {
		if !Events[event.Key] || event.Value.Kind != kindArray {
			return false
		}

		for _, group := range event.Value.Elements {
			if !hookGroupValid(group) {
				return false
			}
		}
	}

	return true
}

func hookGroupValid(group *jsonconfig.Node) bool {
	if group == nil || group.Kind != kindObject {
		return false
	}

	if v := group.Get("matcher"); v != nil && !text(v, false) {
		return false
	}

	handlers := group.Get("hooks")
	if handlers == nil || handlers.Kind != kindArray {
		return false
	}

	for _, h := range handlers.Elements {
		if !handlerValid(h) {
			return false
		}
	}

	return true
}

func handlerValid(h *jsonconfig.Node) bool {
	if h == nil || h.Kind != kindObject {
		return false
	}

	if !optionalHandlerFields(h) {
		return false
	}

	kind, _ := h.Get("type").Text()
	switch kind {
	case "command":
		if !text(h.Get("command"), true) || !stringsList(h.Get("args")) {
			return false
		}
	case "http":
		if !text(h.Get("url"), true) {
			return false
		}

		u, e := url.Parse(h.Get("url").String)
		if e != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Hostname() == "" {
			return false
		}
	case "prompt", "agent":
		if !text(h.Get("prompt"), true) {
			return false
		}
	case "mcp_tool":
		if !text(h.Get("server"), true) || !text(h.Get("tool"), true) {
			return false
		}
	default:
		return false
	}

	return true
}
