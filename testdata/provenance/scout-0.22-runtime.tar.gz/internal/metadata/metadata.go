// Package metadata records parsed skill/agent metadata separately from security
// findings. A valid document is not trusted policy or proof of loader activation.
package metadata

import (
	"context"
	"net/url"
	"path"
	"regexp"
	"slices"
	"strings"
	"unicode/utf8"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
)

var skillName = regexp.MustCompile(`^[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?$`)

func Collect(ctx context.Context, docs []document.File, host string) model.MetadataReport {
	r := model.MetadataReport{Files: []model.MetadataFile{}, Completeness: model.Complete, Limitations: []string{"Syntax and selected frontmatter types only; no complete harness schema, settings precedence, environment interpolation or effective permission guarantee.", "YAML aliases, merges, custom tags and multiple documents are explicitly rejected by the selected parser profile. TOML evidence is whole-unit, not per-token.", "Name/description values are hashed, not copied into reports; existence of a declaration does not establish author trust."}}

	for _, d := range docs {
		if ctx.Err() != nil {
			r.Completeness = model.Partial
			break
		}

		name := d.Artifact().Metadata().Path
		if p, e := url.PathUnescape(name); e == nil {
			name = p
		}

		isSkill := strings.EqualFold(path.Base(name), "SKILL.md")
		isManifest := path.Base(name) == "plugin.json" || path.Base(name) == "manifest.json" || path.Base(name) == "skill.json"
		found := false

		for _, u := range d.Units() {
			if u.Origin != valueFrontmatter && u.Language != "yaml" && u.Language != "toml" && !(isManifest && u.Language == "json") {
				continue
			}

			if len(r.Files) >= 512 {
				r.Completeness = model.Partial
				return r
			}

			found = true

			f := collectUnit(d, u, isSkill, host)
			if len(f.Issues) > 0 {
				r.Completeness = model.Partial
			}

			r.Files = append(r.Files, f)
		}

		if isSkill && !found {
			status := "not_declared"

			if host == "agent-skills" {
				r.Completeness = model.Partial
				status = "required_missing"
			}

			r.Files = append(r.Files, model.MetadataFile{Path: d.Artifact().Metadata().Path, Format: valueFrontmatter, Status: status, Fields: []model.MetadataField{}, Issues: []string{"no_parsed_frontmatter_not_a_loader_validation"}})
		}
	}

	return r
}

func collectUnit(d document.File, u document.Unit, isSkill bool, host string) model.MetadataFile {
	f := model.MetadataFile{Path: d.Artifact().Metadata().Path, Format: u.Language, Status: u.Status, Parser: u.ParserID, ParserVersion: u.ParserVersion, Fields: []model.MetadataField{}, Issues: []string{}}

	t, ok := u.Tree.(parse.JSONTree)
	if !ok || t.Root == nil || t.Root.Kind != "object" {
		f.Issues = append(f.Issues, "metadata_mapping_unavailable")
		return f
	}

	f.Status = "parsed_subset"
	collectFields(d, u, t.Root, &f)

	if isSkill && u.Origin == valueFrontmatter {
		validateSkill(t.Root, host, &f)
	}

	return f
}

func collectFields(d document.File, u document.Unit, root *jsonconfig.Node, f *model.MetadataFile) {
	for _, m := range root.Members {
		known := false
		if m.Key == "parameters" {
			known = true
		}

		if slices.Contains([]string{"name", "description", "triggers", "permissions", "license", "compatibility", "metadata", valueAllowedTools, "disallowed-tools", "disable-model-invocation", "user-invocable", "context", "agent", "model", "hooks", "policy", "interface", "dependencies", "approval_policy", "sandbox_mode", "mcp_servers", "mcpServers"}, m.Key) {
			known = true
		}

		if m.Key == valueTriggers {
			valid := m.Value.Kind == kindArray
			for _, n := range m.Value.Elements {
				if n.Kind != kindString {
					valid = false
				}
			}

			if !valid {
				f.Issues = append(f.Issues, "trigger_declaration_type_unverified")
			}
		}

		if !known {
			f.Issues = append(f.Issues, "uninterpreted_field")
			continue
		}

		at, e := u.View.Original(m.Value.Span)
		if e != nil {
			f.Issues = append(f.Issues, "source_mapping_failed")
			continue
		}

		raw := d.Artifact().Content()
		meta := d.Artifact().Metadata()

		field := model.MetadataField{Name: m.Key, Kind: m.Value.Kind, ValueSHA256: canonicalHash(m.Value), Source: model.SourceRef{Path: meta.Path, SHA256: meta.SHA256, ByteStart: at.Start, ByteEnd: at.End, SpanSHA256: artifact.Hash([]byte(raw[at.Start:at.End]))}}
		if m.Key == "permissions" || m.Key == valueAllowedTools || m.Key == valueTriggers {
			collectListItems(m.Value, &field)
		}

		if m.Key == "parameters" {
			collectParameters(m.Value, &field)
		}

		f.Fields = append(f.Fields, field)
	}
}

const valueTriggers = "triggers"

func collectListItems(n *jsonconfig.Node, field *model.MetadataField) {
	field.ItemsComplete = n.Kind == kindArray || n.Kind == kindString

	items := n.Elements
	if n.Kind == kindString {
		items = []*jsonconfig.Node{n}
	}

	for _, item := range items {
		if item.Kind != kindString {
			field.ItemsComplete = false
			continue
		}

		if strings.TrimSpace(item.String) == "" {
			continue
		}

		hash := canonicalHash(item)
		field.Items = append(field.Items, model.MetadataItem{NameSHA256: hash, ValueSHA256: hash})
	}
}

func collectParameters(n *jsonconfig.Node, field *model.MetadataField) {
	seenParameters := map[string]bool{}

	field.ItemsComplete = n.Kind == "object" || n.Kind == kindArray
	for _, item := range n.Members {
		field.Items = append(field.Items, model.MetadataItem{NameSHA256: artifact.Hash([]byte(item.Key)), ValueSHA256: canonicalHash(item.Value)})
	}

	for _, item := range n.Elements {
		n, ok := item.Get("name").Text()
		if !ok {
			field.ItemsComplete = false
			continue
		}

		if seenParameters[n] {
			field.ItemsComplete = false
		}

		seenParameters[n] = true
		field.Items = append(field.Items, model.MetadataItem{NameSHA256: artifact.Hash([]byte(n)), ValueSHA256: canonicalHash(item)})
	}
}

func validateSkill(root *jsonconfig.Node, host string, f *model.MetadataFile) {
	n, nok := root.Get("name").Text()

	desc, dok := root.Get("description").Text()
	if host != "claude-code" && (!nok || n == "" || !dok || strings.TrimSpace(desc) == "") {
		f.Issues = append(f.Issues, "required_skill_fields_missing_or_wrong_type")
	}

	if nok && (!skillName.MatchString(n) || strings.Contains(n, "--")) {
		f.Issues = append(f.Issues, "skill_name_contract_invalid")
	}

	if dok && (utf8.RuneCountInString(desc) > 1024 || strings.TrimSpace(desc) == "") {
		f.Issues = append(f.Issues, "skill_description_contract_invalid")
	}

	for _, k := range []string{"disable-model-invocation", "user-invocable"} {
		if v := root.Get(k); v != nil && v.Kind != "bool" {
			f.Issues = append(f.Issues, "invocation_switch_type_invalid")
		}
	}

	for _, k := range []string{valueAllowedTools, "disallowed-tools"} {
		validateTools(root.Get(k), host, f)
	}
}

func validateTools(v *jsonconfig.Node, host string, f *model.MetadataFile) {
	if v != nil {
		valid := v.Kind == kindString
		if v.Kind == kindArray && host == "claude-code" {
			valid = true

			for _, x := range v.Elements {
				if x.Kind != kindString {
					valid = false
				}
			}
		}

		if !valid {
			f.Issues = append(f.Issues, "tool_declaration_type_unverified")
		}
	}
}
