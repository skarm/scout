package metadata

// Shared vocabulary used by this package's protocols and reports.
const (
	valueAllowedTools = "allowed-tools"
	kindArray         = "array"
	valueFrontmatter  = "frontmatter"
	kindString        = "string"
)
