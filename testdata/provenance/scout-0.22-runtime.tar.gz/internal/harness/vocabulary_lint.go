package harness

// Shared vocabulary used by this package's protocols and reports.
const (
	valueMcpConfig = "mcp_config"
)
