package harness

// Shared vocabulary used by this package's protocols and reports.
const (
	valueSKILLMd            = "SKILL.md"
	kindArray               = "array"
	valueClaudeCode         = "claude-code"
	valueCodex              = "codex"
	valueHookConfig         = "hook_config"
	valueInactiveForProfile = "inactive_for_profile"
	valueInvalid            = "invalid"
	valueLspConfig          = "lsp_config"
	kindObject              = "object"
	statusPartial           = "partial"
	valueSkill              = "skill"
	kindString              = "string"
	valueUnknown            = "unknown"
)
