package harness

import (
	"fmt"
	"path"
	"strings"

	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/model"
)

func (p *plugin) discover() {
	if p.host == valueUnknown {
		p.issue("plugin_layout_unverified", p.manifest.meta.Path, statusPartial)
		return
	}

	var root *jsonconfig.Node
	if p.manifest != nil {
		root = p.object(p.manifest)
		if root != nil {
			p.validateManifest(root)
		}
	} else if p.host == valueCodex {
		p.issue("plugin_manifest_missing", "", valueInvalid)
	}
	// Defaults remain candidates even after malformed manifests. No inference
	// that an invalid declaration makes the rest of a package harmless.
	p.issue("plugin_loader_semantics_limited", p.manifestPath(), statusPartial)
	p.directory("skills", "skills", root, valueSkill, false)

	if p.host == valueClaudeCode {
		p.directory("commands", "commands", root, "command", true)
		p.directory("agents", "agents", root, "agent", true)
		p.directory("outputStyles", "output-styles", root, "instruction", true)
		p.directory("workflows", "workflows", root, "workflow", true)
	}

	if e := p.entry(valueSKILLMd); e != nil {
		act := p.activation
		if root.Get("skills") != nil || p.hasDirectory("skills") {
			act = valueInactiveForProfile
		}

		p.component(valueSkill, e, act, "host_default", whole(e), "root-skill")
	}

	p.configs("hooks", "hooks/hooks.json", valueHookConfig, root)
	p.configs("mcpServers", ".mcp.json", valueMcpConfig, root)

	if p.host == valueClaudeCode {
		p.configs("lspServers", ".lsp.json", valueLspConfig, root)
	}

	if p.host == valueCodex {
		p.configs("apps", ".app.json", "app_config", root)
	}

	p.discoverHostConfigs()
	p.discoverExtensions(root)
}

func (p *plugin) discoverHostConfigs() {
	for _, name := range []string{"AGENTS.md", "CLAUDE.md", "settings.json", ".claude/settings.json", ".claude/settings.local.json", ".codex/config.toml", "agents/openai.yaml"} {
		if e := p.entry(name); e != nil {
			id := p.component("host_config", e, valueUnknown, "package_inventory", whole(e), name)
			if name == "settings.json" || strings.HasSuffix(name, "/settings.json") || strings.HasSuffix(name, "/settings.local.json") {
				if settings := p.object(e); settings != nil {
					p.settings(e, settings, id)
				}
			}

			p.issue("plugin_host_configuration_unverified", e.meta.Path, statusPartial)
		}
	}
}

func (p *plugin) discoverExtensions(root *jsonconfig.Node) {
	if root != nil {
		if deps := root.Get("dependencies"); deps != nil {
			for i, item := range deps.Elements {
				if !p.b.step() {
					break
				}

				src := ref(p.manifest, item.Span)
				id := p.component("dependency", p.manifest, p.activation, "manifest", src, fmt.Sprintf("dependency:%d", i))
				p.reference(id, "dependency", "unresolved", "external_dependency_not_materialized", "", src)
			}
		}

		for _, key := range []string{"experimental", "monitors", "themes", "channels", "extensions", "userConfig"} {
			if n := root.Get(key); n != nil {
				p.component("unsupported_extension", p.manifest, valueUnknown, "manifest", ref(p.manifest, n.Span), key)
				p.issue("plugin_extension_unverified", p.manifest.meta.Path, statusPartial)
			}
		}
	}
}

func (p *plugin) manifestPath() string {
	if p.manifest != nil {
		return p.manifest.meta.Path
	}

	return ""
}

func (p *plugin) validateManifest(n *jsonconfig.Node) {
	name, ok := n.Get("name").Text()
	if !ok || !validName(name) {
		p.issue("plugin_name_invalid", p.manifest.meta.Path, valueInvalid)
	}
	// Metadata values are never used as authority, IDs or output messages.
	known := map[string]bool{}
	for _, k := range []string{"name", "displayName", "version", "description", "author", "homepage", "repository", "license", "keywords", "metadata", "skills", "commands", "agents", "hooks", "mcpServers", "lspServers", "apps", "outputStyles", "workflows", "dependencies", "defaultEnabled", "experimental", "monitors", "themes", "channels", "extensions", "userConfig", "interface"} {
		known[k] = true
	}

	for _, m := range n.Members {
		if !p.b.step() {
			return
		}

		if !known[m.Key] {
			p.issue("plugin_unknown_field", p.manifest.meta.Path, statusPartial)
		}

		switch m.Key {
		case "name", "displayName", "version", "description", "homepage", "repository", "license":
			if m.Value.Kind != kindString {
				p.issue("plugin_metadata_type_invalid", p.manifest.meta.Path, valueInvalid)
			}
		case "defaultEnabled":
			if m.Value.Kind != "bool" {
				p.issue("plugin_metadata_type_invalid", p.manifest.meta.Path, valueInvalid)
			}
			// false must NOT suppress inspection; effective enablement depends on host policy.
		case "keywords":
			if m.Value.Kind != kindArray {
				p.issue("plugin_metadata_type_invalid", p.manifest.meta.Path, valueInvalid)
			}

			for _, v := range m.Value.Elements {
				if v.Kind != kindString {
					p.issue("plugin_metadata_type_invalid", p.manifest.meta.Path, valueInvalid)
				}
			}
		case "dependencies":
			if m.Value.Kind != kindArray {
				p.issue("plugin_dependency_shape_unverified", p.manifest.meta.Path, statusPartial)
			}
		}
	}
}

func (p *plugin) component(kind string, e *entry, activation, basis string, s *model.SourceRef, salt string) string {
	if p.activation == valueInactiveForProfile {
		activation = p.activation
	}

	id := p.b.node(p.id, kind, e, p.host, activation, s, salt)
	p.b.edge(p.rootNode, id, "includes", basis, activation, s)

	return id
}

func (p *plugin) hasDirectory(name string) bool {
	prefix := path.Join(p.root, name) + "/"
	for _, f := range p.ns.names {
		if !p.b.step() {
			return false
		}

		if strings.HasPrefix(f, prefix) {
			return true
		}
	}

	return false
}

func (p *plugin) directory(field, defaultName string, root *jsonconfig.Node, kind string, replace bool) {
	custom := root.Get(field)

	activation := p.activation
	if p.host == valueCodex {
		activation = valueUnknown
	}

	if replace && custom != nil {
		activation = valueInactiveForProfile
	}

	p.selectFiles(defaultName, kind, activation, "host_default", nil, false)

	if custom == nil {
		return
	}

	for _, n := range pathValues(custom) {
		if !p.b.step() {
			return
		}

		if text, ok := n.Text(); ok {
			p.selectFiles(text, kind, p.activation, "manifest", ref(p.manifest, n.Span), true)
		} else {
			p.issue("plugin_component_path_type_invalid", p.manifestPath(), valueInvalid)
		}
	}

	if custom.Kind != kindString && custom.Kind != kindArray {
		p.issue("plugin_component_path_type_invalid", p.manifestPath(), valueInvalid)
	}
}

func (p *plugin) selectFiles(raw, kind, activation, basis string, s *model.SourceRef, required bool) {
	if p.activation == valueInactiveForProfile {
		activation = p.activation
	}

	rel, reason := localPath(raw, required)
	if reason != "" {
		p.reference(p.rootNode, "component_path", "unresolved", reason, "", s)
		return
	}

	name := path.Join(p.root, rel)
	found := false

	for _, key := range p.ns.names {
		if !p.b.step() {
			return
		}

		if key != name && !strings.HasPrefix(key, name+"/") && !(name == "." && !strings.HasPrefix(key, "../")) {
			continue
		}

		match := false

		switch kind {
		case valueSkill:
			match = path.Base(key) == valueSKILLMd
		case "workflow":
			match = true
		default:
			match = strings.EqualFold(path.Ext(key), ".md")
		}

		if !match {
			continue
		}

		found = true

		p.selectedFile(key, name, kind, activation, basis, s)
	}

	if required && !found {
		p.reference(p.rootNode, "component_path", "unresolved", "missing_or_unsupported_component", "", s)
	}
}

func (p *plugin) selectedFile(key, name, kind, activation, basis string, s *model.SourceRef) {
	e := p.ns.entries[key]
	effective := activation

	rest := strings.TrimPrefix(key, name+"/")
	if name == "." {
		rest = key
	}

	depth := strings.Count(rest, "/")
	if (kind == valueSkill && depth > 1) || (kind != valueSkill && depth > 0 && key != name) {
		if effective != valueInactiveForProfile {
			effective = valueUnknown
		}

		p.issue("nested_component_discovery_unverified", e.meta.Path, statusPartial)
	}

	id := p.component(kind, e, effective, basis, whole(e), "file")
	if s != nil {
		p.b.edge(p.rootNode, id, "declares", basis, effective, s)
	}

	if e.doc == nil {
		p.issue("plugin_input_unavailable", e.meta.Path, statusPartial)
	}

	if kind == valueSkill || kind == "agent" {
		p.issue("component_frontmatter_unverified", e.meta.Path, statusPartial)
	}
}

func (p *plugin) configs(field, defaultName, kind string, root *jsonconfig.Node) {
	n := root.Get(field)

	def := p.entry(defaultName)
	if def != nil {
		activation := p.activation
		if p.host == valueCodex && n == nil && kind != valueHookConfig {
			activation = valueUnknown

			p.issue("plugin_default_config_activation_unverified", def.meta.Path, statusPartial)
		}

		if n != nil {
			if p.host == valueCodex {
				activation = valueInactiveForProfile
			} else {
				activation = valueUnknown

				p.issue("plugin_config_merge_unverified", def.meta.Path, statusPartial)
			}
		}

		p.configFile(def, kind, activation, "host_default", whole(def))
	}

	if n == nil {
		return
	}

	for i, item := range pathValues(n) {
		if !p.b.step() {
			return
		}

		s := ref(p.manifest, item.Span)
		if raw, ok := item.Text(); ok {
			rel, reason := localPath(raw, true)
			if reason != "" {
				p.reference(p.rootNode, "component_path", "unresolved", reason, "", s)
				continue
			}

			e := p.entry(rel)
			if e == nil {
				p.reference(p.rootNode, "component_path", "unresolved", "missing_component", "", s)
				continue
			}

			id := p.configFile(e, kind, p.activation, "manifest", s)
			if e.doc == nil {
				p.reference(p.rootNode, "component_path", "unresolved", "component_not_captured", "", s)
			} else {
				p.reference(p.rootNode, "component_path", "resolved", "captured_file", id, s)
			}
		} else if item.Kind == kindObject {
			id := p.component(kind, p.manifest, p.activation, "manifest", s, fmt.Sprintf("%s:inline:%d", field, i))
			p.inspectConfig(p.manifest, item, kind, id, p.activation)
		} else {
			p.issue("plugin_config_shape_invalid", p.manifestPath(), valueInvalid)
		}
	}
}

func (p *plugin) configFile(e *entry, kind, activation, basis string, s *model.SourceRef) string {
	if p.activation == valueInactiveForProfile {
		activation = p.activation
	}

	id := p.component(kind, e, activation, basis, whole(e), kind)
	if s != nil {
		p.b.edge(p.rootNode, id, "declares", basis, activation, s)
	}

	key := kind + "\x00" + e.meta.Path + "\x00" + activation
	if p.processedConfigs[key] {
		return id
	}

	p.processedConfigs[key] = true

	n := p.object(e)
	if n != nil {
		p.inspectConfig(e, n, kind, id, activation)
	}

	return id
}

func (p *plugin) inspectConfig(e *entry, n *jsonconfig.Node, kind, parent, activation string) {
	switch kind {
	case valueHookConfig:
		p.hooks(e, n, parent, activation)
	case valueMcpConfig, valueLspConfig:
		p.servers(e, n, kind, parent, activation)
	default:
		p.issue("plugin_app_mapping_unverified", e.meta.Path, statusPartial)
	}
}

func (p *plugin) reference(component, kind, status, reason, target string, s *model.SourceRef) {
	if component == "" {
		return
	}

	if status == "resolved" && target == "" {
		status = "unresolved"
		reason = "component_graph_budget_exceeded"
	}

	if len(p.b.r.References) >= p.b.r.Limits.References {
		p.issue("plugin_reference_limit", "", statusPartial)
		return
	}

	encoded := ""
	if s != nil {
		encoded = fmt.Sprintf("%s:%d:%d", s.Path, s.ByteStart, s.ByteEnd)
	}

	id := identity("reference-v1", p.id, component, kind, status, reason, target, encoded)
	// Exact repeats may arise from a default config also explicitly declared.
	if p.b.references[id] {
		return
	}

	p.b.references[id] = true

	p.b.r.References = append(p.b.r.References, model.ComponentReference{ID: id, PluginID: p.id, ComponentID: component, Kind: kind, Status: status, Reason: reason, TargetID: target, Source: s})
	if status != "resolved" {
		file := ""
		if s != nil {
			file = s.Path
		}

		p.issue("plugin_reference_unresolved", file, statusPartial)
	}
}

func validName(s string) bool {
	if len(s) == 0 || len(s) > 128 {
		return false
	}

	for i, c := range []byte(s) {
		if c >= 'a' && c <= 'z' || c >= '0' && c <= '9' {
			continue
		}

		if c == '-' && i > 0 && i < len(s)-1 {
			continue
		}

		return false
	}

	return true
}

func pathValues(n *jsonconfig.Node) []*jsonconfig.Node {
	if n == nil {
		return nil
	}

	if n.Kind == kindArray {
		return n.Elements
	}

	return []*jsonconfig.Node{n}
}

// localPath accepts only portable paths. It never performs decoding, expansion,
// filesystem lookup or resolution against the scanner's working directory.
func localPath(raw string, requireDot bool) (string, string) {
	if raw == "" {
		return "", "empty_reference"
	}

	if strings.ContainsAny(raw, "\\\x00\r\n\t") || strings.Contains(raw, ":") || strings.HasPrefix(raw, "/") {
		return "", "nonlocal_reference"
	}

	if strings.ContainsAny(raw, "$~*?[]{}") {
		return "", "symbolic_reference"
	}

	if requireDot && raw != "." && !strings.HasPrefix(raw, "./") {
		return "", "relative_prefix_required"
	}

	clean := path.Clean(raw)
	if clean == ".." || strings.HasPrefix(clean, "../") {
		return "", "outside_package"
	}

	return clean, ""
}
