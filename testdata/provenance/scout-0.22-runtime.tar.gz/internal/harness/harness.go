// Package harness interprets captured packages without filesystem, process,
// environment or network access. Adapters describe declarations, not execution.
package harness

import (
	"context"
	"encoding/json"
	"path"
	"sort"
	"strings"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/hookpolicy"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/parse"
	"github.com/skarm/scout/internal/source"
)

const Version = "2"

type entry struct {
	meta model.File
	doc  *document.File
	name string
}
type namespace struct {
	id      string
	entries map[string]*entry
	names   []string
}
type builder struct {
	ctx            context.Context
	r              model.ComponentGraph
	spaces         []*namespace
	nodes          map[string]int
	edges          map[string]bool
	issues         map[string]bool
	references     map[string]bool
	containerRoots map[string]bool
	operations     int
	stopped        bool
	hooks          hookpolicy.Policy
}
type candidate struct {
	ns                   *namespace
	root, host, manifest string
}
type plugin struct {
	manifest                   *entry
	b                          *builder
	ns                         *namespace
	root, host, id, activation string
	index                      int
	processedConfigs           map[string]bool
	rootNode                   string
}

func Limits() model.HarnessLimits {
	return model.HarnessLimits{Plugins: 128, Components: 4096, Edges: 8192, References: 4096, Operations: 500000}
}

// Discover reuses whole-file JSON trees from bounded preparation. Fenced JSON is
// never mistaken for an installed manifest. Only actual archive members form
// virtual directory namespaces; decoded strings and metadata cannot impersonate files.
func Discover(ctx context.Context, inventory []model.File, docs []document.File, extraction model.ExtractionReport, opts model.HarnessOptions) model.ComponentGraph {
	host := opts.Host
	if host == "" {
		host = "auto"
	}

	b := builder{ctx: ctx, nodes: map[string]int{}, edges: map[string]bool{}, references: map[string]bool{}, containerRoots: map[string]bool{}, issues: map[string]bool{}, r: model.ComponentGraph{
		RequestedHost: host, FormatScope: "documented-subset-not-runtime-loader-validation", Limits: Limits(),
		Plugins: []model.PluginInterpretation{}, Components: []model.Component{}, Edges: []model.ComponentEdge{}, References: []model.ComponentReference{}, Issues: []model.HarnessIssue{},
	}}
	if opts.Validate() != nil {
		b.issue("invalid_harness_request", "", "", valueInvalid)
		return b.r
	}

	b.spaces = namespaces(inventory, docs, extraction)

	b.hooks = hookpolicy.Bind(ctx, docs, extraction)
	for _, space := range b.spaces {
		if space.id != "snapshot" {
			b.containerRoots[space.id] = true
		}
	}

	candidates := b.candidates(host)
	for _, c := range candidates {
		if !b.step() {
			break
		}

		p := b.plugin(c)
		p.discover()
	}

	b.standaloneSkills()
	b.finish()

	return b.r
}

func (b *builder) candidates(host string) []candidate {
	var candidates []candidate

	seen := map[string]bool{}

	add := func(ns *namespace, root, host, manifest string) {
		key := ns.id + "\x00" + root + "\x00" + host
		if seen[key] {
			return
		}

		seen[key] = true

		if len(candidates) >= b.r.Limits.Plugins {
			b.issue("plugin_limit", "", "", statusPartial)
			return
		}

		candidates = append(candidates, candidate{ns, root, host, manifest})
	}
	for _, ns := range b.spaces {
		found := false

		for _, name := range ns.names {
			if !b.step() {
				break
			}

			base := path.Base(name)
			if base == "plugin.json" {
				dir := path.Dir(name)
				switch path.Base(dir) {
				case ".claude-plugin":
					add(ns, path.Dir(dir), valueClaudeCode, name)

					found = true
				case ".codex-plugin":
					add(ns, path.Dir(dir), valueCodex, name)

					found = true
				default:
					// The previously discussed root-portable format is not verified by
					// current sources. Retain it without guessing overlay precedence.
					add(ns, dir, valueUnknown, name)

					found = true
				}
			}

			if base == "marketplace.json" && (strings.Contains(name, ".claude-plugin/") || strings.Contains(name, ".agents/plugins/")) {
				e := ns.entries[name]
				b.node("", "marketplace", e, valueUnknown, valueUnknown, whole(e), "catalog")
				b.issue("marketplace_install_closure_unverified", "", e.meta.Path, statusPartial)
			}
		}
		// Manifestless Claude plugins require explicit caller intent. Auto cannot
		// distinguish a plugin directory from an arbitrary repository with hooks.
		if !found && !b.containerCollection(ns) && (host == valueClaudeCode || host == valueCodex) {
			add(ns, ".", host, "")
		}
	}

	sort.Slice(candidates, func(i, j int) bool {
		a, c := candidates[i], candidates[j]
		if a.ns.id != c.ns.id {
			return a.ns.id < c.ns.id
		}

		if a.root != c.root {
			return a.root < c.root
		}

		return a.host < c.host
	})

	return candidates
}

func (b *builder) standaloneSkills() {
	// Inventory skills independently of plugins. These are instruction candidates,
	// not assertions of schema validity or automatic model invocation.
	for _, ns := range b.spaces {
		for _, name := range ns.names {
			if !b.step() {
				break
			}

			if path.Base(name) == valueSKILLMd {
				e := ns.entries[name]
				b.node("", valueSkill, e, "agent-skills", valueUnknown, whole(e), "standalone")
			}
		}
	}
}

func (b *builder) step() bool {
	if b.stopped {
		return false
	}

	if b.ctx == nil || b.ctx.Err() != nil {
		b.stopped = true
		b.issue("harness_cancelled", "", "", statusPartial)

		return false
	}

	b.operations++
	if b.operations > b.r.Limits.Operations {
		b.stopped = true
		b.issue("harness_operation_limit", "", "", statusPartial)

		return false
	}

	return true
}

func (b *builder) issue(code, pid, file, status string) {
	if b.issues["issue_limit"] {
		return
	}

	key := identity(code, pid, file, status)
	if b.issues[key] {
		return
	}

	b.issues[key] = true
	if len(b.r.Issues) >= b.r.Limits.References {
		if !b.issues["issue_limit"] {
			b.issues["issue_limit"] = true
			b.r.Issues = append(b.r.Issues, model.HarnessIssue{Code: "harness_issue_limit", Status: statusPartial})
		}

		return
	}

	b.r.Issues = append(b.r.Issues, model.HarnessIssue{Code: code, PluginID: pid, Path: file, Status: status})
}

func (b *builder) node(pid, kind string, e *entry, host, activation string, s *model.SourceRef, salt string) string {
	file := ""
	name := ""

	if e != nil {
		file = e.meta.Path
		name = e.name
	}

	sourceID := ""

	if s != nil {
		raw, _ := json.Marshal(s)
		sourceID = string(raw)
	}

	id := identity("component-v1", pid, kind, file, host, activation, sourceID, salt)
	if _, ok := b.nodes[id]; ok {
		return id
	}

	if len(b.r.Components) >= b.r.Limits.Components {
		b.issue("component_limit", pid, file, statusPartial)
		return ""
	}

	b.nodes[id] = len(b.r.Components)
	b.r.Components = append(b.r.Components, model.Component{ID: id, PluginID: pid, Kind: kind, Path: file, PackagePath: name, Host: host, Activation: activation, Source: s})

	return id
}

func (b *builder) edge(from, to, relation, basis, activation string, s *model.SourceRef) {
	if from == "" || to == "" {
		return
	}

	raw, _ := json.Marshal(s)

	id := identity("edge-v1", from, to, relation, basis, activation, string(raw))
	if b.edges[id] {
		return
	}

	if len(b.r.Edges) >= b.r.Limits.Edges {
		b.issue("edge_limit", "", "", statusPartial)
		return
	}

	b.edges[id] = true
	b.r.Edges = append(b.r.Edges, model.ComponentEdge{ID: id, From: from, To: to, Relation: relation, Basis: basis, Activation: activation, Source: s})
}

func (b *builder) plugin(c candidate) *plugin {
	id := identity("plugin-v1", c.ns.id, c.root, c.host)
	activation := valueUnknown

	if b.r.RequestedHost != "auto" && c.host != valueUnknown {
		if b.r.RequestedHost == c.host {
			activation = "conditional"
		} else {
			activation = valueInactiveForProfile
		}
	}

	manifests := []string{}

	var e *entry
	if c.manifest != "" {
		e = c.ns.entries[c.manifest]
		manifests = append(manifests, e.meta.Path)
	}

	p := &plugin{manifest: e, b: b, ns: c.ns, root: c.root, host: c.host, id: id, activation: activation, index: len(b.r.Plugins), processedConfigs: map[string]bool{}}
	b.r.Plugins = append(b.r.Plugins, model.PluginInterpretation{ID: id, Host: c.host, Namespace: c.ns.id, Root: c.root, Manifests: manifests, AdapterID: c.host + "-layout-subset", AdapterVersion: Version, Contract: "docs-2026-10-26-subset", FormatStatus: statusPartial, Activation: activation, Assumptions: []string{"No host binary/version, trust grants or installation are evaluated; only closed captured Claude hook-disable precedence is modeled.", "Paths are resolved only against this package namespace; external configuration is not read."}})
	p.rootNode = b.node(id, "plugin", e, c.host, activation, whole(e), c.ns.id+"/"+c.root)

	return p
}

func (b *builder) finish() {
	sort.Slice(b.r.Components, func(i, j int) bool { return b.r.Components[i].ID < b.r.Components[j].ID })
	sort.Slice(b.r.Edges, func(i, j int) bool { return b.r.Edges[i].ID < b.r.Edges[j].ID })
	sort.Slice(b.r.References, func(i, j int) bool { return b.r.References[i].ID < b.r.References[j].ID })
	sort.Slice(b.r.Issues, func(i, j int) bool {
		a, c := b.r.Issues[i], b.r.Issues[j]
		if a.PluginID != c.PluginID {
			return a.PluginID < c.PluginID
		}

		if a.Path != c.Path {
			return a.Path < c.Path
		}

		return a.Code < c.Code
	})
}

// A scan of a bundle is not an instruction to install an invented outer plugin.
// Manifestless default-layout candidates remain supported inside each namespace.
func (b *builder) containerCollection(ns *namespace) bool {
	for _, name := range ns.names {
		if name == valueSKILLMd || name == "hooks/hooks.json" || name == ".mcp.json" || name == ".lsp.json" || strings.HasPrefix(name, "skills/") || strings.HasPrefix(name, "commands/") || strings.HasPrefix(name, "agents/") {
			return false
		}
	}

	for _, e := range ns.entries {
		if !b.step() {
			return true
		}

		if b.containerRoots[e.meta.Path] {
			return true
		}
	}

	return false
}

func (p *plugin) issue(code, file, status string) {
	p.b.issue(code, p.id, file, status)

	if status == valueInvalid {
		p.b.r.Plugins[p.index].FormatStatus = valueInvalid
	}
}
func (p *plugin) entry(name string) *entry { return p.ns.entries[path.Join(p.root, name)] }
func (p *plugin) object(e *entry) *jsonconfig.Node {
	if e == nil {
		return nil
	}

	if e.doc == nil {
		p.issue("plugin_input_unavailable", e.meta.Path, statusPartial)
		return nil
	}

	for _, u := range e.doc.Units() {
		if u.Origin == "file" && u.Language == "json" {
			if t, ok := u.Tree.(parse.JSONTree); ok && t.Root != nil {
				if t.Root.Kind != kindObject {
					p.issue("plugin_object_expected", e.meta.Path, valueInvalid)
					return nil
				}

				return t.Root
			}

			status := statusPartial
			code := "plugin_json_unavailable"

			if u.Status == "failed" || u.Status == "parse_error" {
				status = valueInvalid
				code = "plugin_json_invalid"
			}

			p.issue(code, e.meta.Path, status)

			return nil
		}
	}

	p.issue("plugin_json_unavailable", e.meta.Path, statusPartial)

	return nil
}

func namespaces(inventory []model.File, docs []document.File, extraction model.ExtractionReport) []*namespace {
	byPath := make(map[string]*document.File, len(docs))
	for i := range docs {
		byPath[docs[i].Artifact().Metadata().Path] = &docs[i]
	}

	spaces := map[string]*namespace{}

	put := func(id, name string, m model.File) {
		n := spaces[id]
		if n == nil {
			n = &namespace{id: id, entries: map[string]*entry{}}
			spaces[id] = n
		}
		// Input paths have already been validated by capture/extraction. Do not
		// normalize ambiguous duplicate names into a trusted entry.
		if _, ok := n.entries[name]; ok {
			return
		}

		n.entries[name] = &entry{meta: m, doc: byPath[m.Path], name: name}
		n.names = append(n.names, name)
	}
	for _, m := range inventory {
		put("snapshot", m.Path, m)
	}

	for _, o := range extraction.Objects {
		if o.Role == "archive_member" && (o.ExtractorID == "zip32" || o.ExtractorID == "tar") {
			put(o.ParentPath, o.MemberName, o.File)
		}
	}

	for _, o := range extraction.Skipped {
		if o.Role == "archive_member" && (o.ExtractorID == "zip32" || o.ExtractorID == "tar") {
			put(o.ParentPath, o.MemberName, model.File{Path: o.ParentPath + "#unread-member/" + o.MemberName, Size: o.DeclaredSize, Status: "skipped", Reason: o.Reason})
		}
	}

	ids := make([]string, 0, len(spaces))
	for id := range spaces {
		ids = append(ids, id)
	}

	sort.Strings(ids)

	out := make([]*namespace, 0, len(ids))
	for _, id := range ids {
		n := spaces[id]
		sort.Strings(n.names)
		out = append(out, n)
	}

	return out
}
func identity(v ...string) string { raw, _ := json.Marshal(v); return artifact.Hash(raw) }
func whole(e *entry) *model.SourceRef {
	if e == nil || e.doc == nil {
		return nil
	}

	return &model.SourceRef{Path: e.meta.Path, SHA256: e.meta.SHA256, ByteEnd: len(e.doc.Artifact().Content()), SpanSHA256: e.meta.SHA256}
}

func ref(e *entry, s source.Span) *model.SourceRef {
	if e == nil || e.doc == nil {
		return nil
	}

	f := e.doc.Artifact()

	text := f.Content()
	if s.Start < 0 || s.End < s.Start || s.End > len(text) {
		return nil
	}

	return &model.SourceRef{Path: e.meta.Path, SHA256: e.meta.SHA256, ByteStart: s.Start, ByteEnd: s.End, SpanSHA256: artifact.Hash([]byte(text[s.Start:s.End]))}
}
