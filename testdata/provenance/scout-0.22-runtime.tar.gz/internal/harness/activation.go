package harness

import (
	"fmt"
	"strings"

	"github.com/skarm/scout/internal/document"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/internal/shellsyntax"
	"github.com/skarm/scout/internal/source"
)

// Enrich attaches only bounded contextual references. Findings retain all IDs,
// severity, evidence and traces. A graph edge is not a new taint-flow claim.
func Enrich(findings []model.Finding, g model.ComponentGraph) bool {
	byPath := map[string][]model.Component{}

	nodes := map[string]model.Component{}
	for _, n := range g.Components {
		nodes[n.ID] = n
		if n.Path != "" {
			byPath[n.Path] = append(byPath[n.Path], n)
		}
	}

	incoming := map[string][]model.ComponentEdge{}

	for _, edge := range g.Edges {
		if edge.Relation == "invokes" {
			incoming[edge.To] = append(incoming[edge.To], edge)
		}
	}

	truncated := false
	operations := 0
	maxOperations := Limits().Operations

	for i := range findings {
		f := &findings[i]

		add := findingContextAdder(f, &truncated)
		for _, n := range byPath[f.Location.Path] {
			operations++
			if operations > maxOperations {
				return true
			}

			if n.Source != nil && (f.Location.ByteEnd <= n.Source.ByteStart || f.Location.ByteStart >= n.Source.ByteEnd) {
				continue
			}

			add(n, "same_component_bytes")

			for _, edge := range incoming[n.ID] {
				operations++
				if operations > maxOperations {
					return true
				}

				if source, ok := nodes[edge.From]; ok {
					add(source, "declared_handler_reference")
				}
			}
		}
	}

	return truncated
}

func findingContextAdder(f *model.Finding, truncated *bool) func(model.Component, string) {
	seen := map[string]bool{}

	return func(n model.Component, relation string) {
		key := n.ID + "/" + relation
		if seen[key] {
			return
		}

		seen[key] = true

		if len(f.Contexts) >= 32 {
			*truncated = true
			return
		}

		f.Contexts = append(f.Contexts, model.FindingContext{ComponentID: n.ID, PluginID: n.PluginID, Host: n.Host, Relation: relation, Activation: n.Activation})
	}
}

// ApplyConfigScopes annotates actual config objects only. It never turns quoted
// examples or JSON extracted string tokens into installed configuration.
func ApplyConfigScopes(docs []document.File, g model.ComponentGraph) []document.File {
	byPath := map[string][]document.ConfigScope{}
	seen := map[string]bool{}

	for _, n := range g.Components {
		if n.Source == nil || (n.Kind != valueMcpConfig && n.Kind != "hook_config") {
			continue
		}

		key := fmt.Sprintf("%s:%s:%s:%d:%d", n.Host, n.Kind, n.Source.Path, n.Source.ByteStart, n.Source.ByteEnd)
		if seen[key] {
			continue
		}

		seen[key] = true

		byPath[n.Source.Path] = append(byPath[n.Source.Path], document.ConfigScope{Role: n.Kind, Host: n.Host, Span: source.Span{Start: n.Source.ByteStart, End: n.Source.ByteEnd}})
	}

	out := append([]document.File(nil), docs...)
	for i := range out {
		out[i] = out[i].WithConfigScopes(byPath[out[i].Artifact().Metadata().Path])
	}

	return out
}

func (p *plugin) hooks(e *entry, n *jsonconfig.Node, parent, activation string) {
	state := p.b.hooks[e.meta.Path]
	if state.Uncertain {
		p.issue("plugin_hook_disable_unverified", e.meta.Path, "partial")
	}

	if state.Disabled && p.host == valueClaudeCode {
		return
	}

	hooks := n.Get("hooks")
	if hooks == nil {
		hooks = n
	}

	if hooks.Kind != kindObject {
		p.issue("plugin_hooks_invalid", e.meta.Path, "invalid")
		return
	}

	for eventIndex, event := range hooks.Members {
		if !p.b.step() {
			return
		}

		if event.Value.Kind != kindArray {
			p.issue("plugin_hooks_invalid", e.meta.Path, "invalid")
			continue
		}

		for gi, group := range event.Value.Elements {
			if !p.b.step() {
				return
			}

			items := group.Get("hooks")
			if items == nil || items.Kind != kindArray {
				p.issue("plugin_hooks_invalid", e.meta.Path, "invalid")
				continue
			}

			for hi, h := range items.Elements {
				if !p.b.step() {
					return
				}

				p.hookHandler(e, h, parent, activation, eventIndex, gi, hi)
			}
		}
	}
}

func (p *plugin) hookHandler(e *entry, h *jsonconfig.Node, parent, activation string, eventIndex, gi, hi int) {
	s := ref(e, h.Span)
	id := p.component("hook", e, activation, "configuration", s, fmt.Sprintf("hook:%d:%d:%d", eventIndex, gi, hi))
	p.b.edge(parent, id, "registers", "configuration", activation, s)
	// Event/matcher values may be arbitrary or hostile strings. They
	// remain available by source reference, never copied into diagnostics.
	kind, _ := h.Get("type").Text()
	switch kind {
	case "command":
		cmd := h.Get("command")

		text, ok := cmd.Text()
		if !ok || strings.TrimSpace(text) == "" {
			p.issue("plugin_hook_command_invalid", e.meta.Path, "invalid")
			return
		}

		args := []string{}
		argv := false
		valid := true

		if n := h.Get("args"); n != nil {
			argv = true

			valid = n.Kind == kindArray
			for _, arg := range n.Elements {
				v, ok := arg.Text()
				if !ok {
					valid = false
				}

				args = append(args, v)
			}
		}

		if !valid {
			p.issue("plugin_hook_args_invalid", e.meta.Path, "invalid")
			return
		}

		p.command(id, text, args, argv, ref(e, h.Span), activation)
	case "http":
		p.reference(id, "remote_endpoint", "unresolved", "remote_behavior_unverified", "", s)
	case "prompt", "agent":
		prompt := h.Get("prompt")
		if text, ok := prompt.Text(); ok && strings.TrimSpace(text) != "" {
			child := p.component("instruction", e, activation, "hook_payload", ref(e, prompt.Span), fmt.Sprintf("prompt:%d:%d:%d", eventIndex, gi, hi))
			p.b.edge(id, child, "invokes", "hook_payload", activation, ref(e, prompt.Span))
		} else {
			p.issue("plugin_hook_prompt_invalid", e.meta.Path, "invalid")
		}

		p.reference(id, "hook_behavior", "unresolved", "semantic_or_tool_resolution_unavailable", "", s)
	case "mcp_tool":
		p.reference(id, "hook_behavior", "unresolved", "semantic_or_tool_resolution_unavailable", "", s)
	default:
		p.issue("plugin_hook_type_unverified", e.meta.Path, "partial")
	}
}

func (p *plugin) settings(e *entry, n *jsonconfig.Node, parent string) {
	state := p.b.hooks[e.meta.Path]
	if state.Uncertain {
		p.issue("plugin_hook_disable_unverified", e.meta.Path, "partial")
	}

	off := state.Disabled
	if n.Get("hooks") != nil && !off {
		p.hooks(e, n, parent, "unknown")
	}

	for key := range strings.FieldsSeq("apiKeyHelper awsAuthRefresh awsCredentialExport gcpAuthRefresh otelHeadersHelper statusLine fileSuggestion") {
		value := n.Get(key)
		if value == nil {
			continue
		}

		if key == "statusLine" || key == "fileSuggestion" {
			if off {
				continue
			}

			kind, _ := value.Get("type").Text()
			if kind != "command" {
				continue
			}

			value = value.Get("command")
		}

		if value == nil {
			p.issue("plugin_settings_command_invalid", e.meta.Path, "invalid")
			continue
		}

		id := p.component("settings_command", e, "unknown", "settings", ref(e, value.Span), key)
		p.b.edge(parent, id, "registers", "settings", "unknown", ref(e, value.Span))
		p.settingsCommand(e, value, id)
	}
}

func (p *plugin) settingsCommand(e *entry, value *jsonconfig.Node, id string) {
	if text, ok := value.Text(); ok {
		p.command(id, text, nil, false, ref(e, value.Span), "unknown")
	} else if value.Kind == kindArray && len(value.Elements) > 0 {
		words := make([]string, 0, len(value.Elements))
		valid := true

		for _, item := range value.Elements {
			s, ok := item.Text()
			if !ok {
				valid = false
			}

			words = append(words, s)
		}

		if valid {
			p.command(id, words[0], words[1:], true, ref(e, value.Span), "unknown")
		} else {
			p.issue("plugin_settings_command_invalid", e.meta.Path, "invalid")
		}
	} else {
		p.issue("plugin_settings_command_invalid", e.meta.Path, "invalid")
	}
}

func (p *plugin) servers(e *entry, n *jsonconfig.Node, kind, parent, activation string) {
	servers := n

	camel, snake := n.Get("mcpServers"), n.Get("mcp_servers")
	if kind == valueMcpConfig {
		if camel != nil && snake != nil {
			p.issue("plugin_mcp_wrappers_ambiguous", e.meta.Path, "invalid")
			return
		}

		if camel != nil {
			servers = camel
		}

		if snake != nil {
			servers = snake
		}

		if p.host == valueClaudeCode && snake != nil {
			p.issue("plugin_mcp_wrapper_unverified", e.meta.Path, "partial")
		}
	}

	if kind == "lsp_config" && n.Get("lspServers") != nil {
		servers = n.Get("lspServers")
	}

	if servers.Kind != kindObject {
		p.issue("plugin_server_map_invalid", e.meta.Path, "invalid")
		return
	}

	for i, m := range servers.Members {
		if !p.b.step() {
			return
		}

		p.serverEntry(e, m.Value, kind, parent, activation, i)
	}
}

func (p *plugin) serverEntry(e *entry, n *jsonconfig.Node, kind, parent, activation string, i int) {
	s := ref(e, n.Span)

	role := "mcp_server"
	if kind == "lsp_config" {
		role = "lsp_server"
	}

	id := p.component(role, e, activation, "configuration", s, fmt.Sprintf("%s:%d", role, i))
	p.b.edge(parent, id, "declares", "configuration", activation, s)

	if n.Kind != kindObject {
		p.issue("plugin_server_invalid", e.meta.Path, "invalid")
		return
	}

	command := n.Get("command")

	url := n.Get("url")
	if command != nil && url != nil {
		p.issue("plugin_server_transport_ambiguous", e.meta.Path, "partial")
	}

	if url != nil {
		if _, ok := url.Text(); !ok {
			p.issue("plugin_server_url_invalid", e.meta.Path, "invalid")
		}

		p.reference(id, "remote_endpoint", "unresolved", "remote_implementation_not_scanned", "", ref(e, url.Span))
	}

	if command != nil {
		text, ok := command.Text()
		argsNode := n.Get("args")

		var args []string

		valid := true

		if argsNode != nil {
			if argsNode.Kind != kindArray {
				valid = false
			}

			for _, arg := range argsNode.Elements {
				v, ok := arg.Text()
				if !ok {
					valid = false
				}

				args = append(args, v)
			}
		}

		if !ok || text == "" || !valid {
			p.issue("plugin_server_command_invalid", e.meta.Path, "invalid")
			return
		}

		p.command(id, text, args, true, s, activation)
	} else if url == nil {
		p.issue("plugin_server_transport_unverified", e.meta.Path, "partial")
	}
}

// command recognizes only simple direct argv or one simple shell command. It
// NEVER treats an arbitrary substring in an echo, comment or shell string as a
// handler. Relative working directories and environment expansion are unknown.
func (p *plugin) command(component, text string, args []string, argv bool, s *model.SourceRef, activation string) {
	if strings.ContainsRune(text, 0) {
		p.reference(component, "command", "unresolved", "invalid_command_bytes", "", s)
		return
	}

	words := []string{text}
	if argv {
		words = append(words, args...)
	} else {
		tree, err := shellsyntax.Parse(p.b.ctx, text)
		if err != nil || tree == nil || len(tree.Statements) != 1 || len(tree.Statements[0].Commands) != 1 {
			p.reference(component, "command", "unresolved", "complex_shell_command", "", s)
			return
		}

		statement := tree.Statements[0]

		command := statement.Commands[0]
		if len(command.Assignments) != 0 || len(command.Redirects) != 0 || command.Subshell != nil || len(command.Words) == 0 || statement.Next == "&" || statement.Next == "&&" || statement.Next == "||" {
			p.reference(component, "command", "unresolved", "complex_shell_command", "", s)
			return
		}

		words = nil

		for _, word := range command.Words {
			v, ok := symbolicWord(word, p.host)
			if !ok {
				p.reference(component, "command", "unresolved", "dynamic_command", "", s)
				return
			}

			words = append(words, v)
		}
	}

	p.resolveCommand(component, words, argv, s, activation)
}

func (p *plugin) resolveCommand(component string, words []string, argv bool, s *model.SourceRef, activation string) {
	candidate := words[0]
	// Only exact allowlisted interpreter names with a direct first script
	// operand are supported. PATH binaries are not resolved on the scanner host.
	externalRuntime := false

	switch candidate {
	case "sh", "bash", "dash", "zsh", "python", "python3", "node", "ruby", "perl":
		if len(words) < 2 || strings.HasPrefix(words[1], "-") {
			p.reference(component, "command", "unresolved", "interpreter_arguments_unverified", "", s)
			return
		}

		candidate = words[1]
		externalRuntime = true
	case "go":
		if len(words) < 3 || words[1] != "run" || strings.HasPrefix(words[2], "-") {
			p.reference(component, "command", "unresolved", "launcher_arguments_unverified", "", s)
			return
		}

		candidate = words[2]
		externalRuntime = true
	}

	if externalRuntime {
		p.reference(component, "runtime", "unresolved", "runtime_not_materialized", "", s)
	}

	prefix := "${CLAUDE_PLUGIN_ROOT}/"
	if p.host == "codex" {
		prefix = "${PLUGIN_ROOT}/"
	}

	if !argv {
		prefix = "\x00scout-plugin-root/"
	}

	if !strings.HasPrefix(candidate, prefix) {
		reason := "external_command_not_materialized"
		if strings.HasPrefix(candidate, "./") || strings.HasPrefix(candidate, "../") {
			reason = "working_directory_unknown"
		}

		p.reference(component, "command", "unresolved", reason, "", s)

		return
	}

	rel, reason := localPath(strings.TrimPrefix(candidate, prefix), false)
	if reason != "" {
		p.reference(component, "handler", "unresolved", reason, "", s)
		return
	}

	e := p.entry(rel)
	if e == nil || e.doc == nil {
		p.reference(component, "handler", "unresolved", "handler_not_captured", "", s)
		return
	}

	id := p.component("handler", e, activation, "static_reference", whole(e), "handler")
	p.b.edge(component, id, "invokes", "static_reference", activation, s)
	p.reference(component, "handler", "resolved", "captured_handler_not_runtime_proof", id, s)
	// A single source operand cannot attest the rest of go run's build inputs.
	if externalRuntime {
		p.issue("handler_dependency_closure_unverified", e.meta.Path, "partial")
	}
}

func symbolicWord(w *shellsyntax.Word, host string) (string, bool) {
	if w == nil || w.Expands {
		return "", false
	}

	var b strings.Builder

	for _, part := range w.Parts {
		switch part.Kind {
		case "literal":
			b.WriteString(part.Text)
		case "parameter":
			if part.Text == "CLAUDE_PLUGIN_ROOT" && host == valueClaudeCode || part.Text == "PLUGIN_ROOT" && host == "codex" {
				b.WriteString("\x00scout-plugin-root")
			} else {
				return "", false
			}
		default:
			return "", false
		}
	}

	return b.String(), true
}
