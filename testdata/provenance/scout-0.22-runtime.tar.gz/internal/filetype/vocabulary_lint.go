package filetype

// Shared vocabulary used by this package's protocols and reports.
const (
	valueDocument = "document"
	valueMachO    = "mach-o"
)
