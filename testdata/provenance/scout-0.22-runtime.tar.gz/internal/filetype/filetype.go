// Package filetype provides bounded, conservative content hints. Neither a
// suffix nor a magic signature proves a type, safety, or absence of a polyglot.
package filetype

import (
	"path"
	"strings"
	"unicode/utf8"

	"github.com/skarm/scout/internal/language"
)

type Description struct {
	Format     string          `json:"format"`
	Category   string          `json:"category"`
	Encoding   string          `json:"encoding"`
	Basis      string          `json:"basis"`
	Languages  []language.Hint `json:"languages"`
	Conflict   bool            `json:"conflicting_hints"`
	Executable bool            `json:"executable_candidate"`
	Structured bool            `json:"requires_structural_analysis"`
}

func Inspect(name, data string, executable bool) Description {
	d := Description{Format: valueUnknown, Category: valueUnknown, Encoding: "bytes", Basis: "unrecognized", Languages: language.Detect(name, data)}
	if utf8.ValidString(data) && !strings.ContainsRune(data, 0) {
		d.Encoding = valueUtf8
	}

	if strings.HasPrefix(data, "\xff\xfe") {
		d.Encoding = "utf-16le-or-utf-32le"
	}

	if strings.HasPrefix(data, "\xfe\xff") {
		d.Encoding = "utf-16be"
	}

	if strings.HasPrefix(data, "\x00\x00\xfe\xff") {
		d.Encoding = "utf-32be"
	}

	namedFormat, namedCategory := named(strings.ToLower(path.Ext(name)))
	if namedFormat != "" {
		d.Format, d.Category, d.Basis = namedFormat, namedCategory, "extension"
	}

	magicFormat, magicCategory := magic(data)
	if magicFormat != "" {
		d.Conflict = conflictingFormat(namedFormat, namedCategory, magicFormat, magicCategory)

		d.Format, d.Category, d.Basis = magicFormat, magicCategory, "signature"
	}

	first := ""
	for _, h := range d.Languages {
		if first != "" && h.Language != first {
			d.Conflict = true
		}

		first = h.Language
		if language.Structured(h.Language) {
			d.Structured = true
		}
	}

	if namedCategory == valueExecutable || magicCategory == valueExecutable || (executable && d.Encoding != valueUtf8) {
		d.Executable = true
	}

	if d.Format == valueUnknown && len(d.Languages) > 0 && d.Encoding == valueUtf8 {
		d.Format, d.Category, d.Basis = "text", "text", "language-hint"
		if d.Structured {
			d.Category = "source-or-config"
		}
	}
	// A misleading .txt or SKILL.md name cannot exempt a recognized binary.
	if magicFormat != "" && len(d.Languages) > 0 {
		d.Conflict = true
	}

	if executable || strings.HasPrefix(strings.TrimPrefix(data, "\ufeff"), "#!") {
		d.Structured = true
	}

	return d
}

func conflictingFormat(namedFormat, namedCategory, magicFormat, magicCategory string) bool {
	// OOXML and OpenDocument are containers by design.
	if magicCategory == valueArchive && namedCategory == valueDocument && (namedFormat == "ooxml" || namedFormat == "opendocument") {
		return false
	}

	if namedCategory == magicCategory && namedFormat != "" && !equivalent(namedFormat, magicFormat) {
		return true
	}

	return namedCategory != "" && namedCategory != magicCategory
}

func equivalent(named, detected string) bool {
	if named == detected {
		return true
	}

	switch named {
	case "jpg":
		return detected == "jpeg"
	case "tif":
		return detected == valueTiff
	case "gz", "tgz":
		return detected == "gzip"
	case "bz2":
		return detected == "bzip2"
	case "zst":
		return detected == "zstd"
	case "exe", "dll":
		return detected == "pe-candidate"
	case "so":
		return detected == "elf"
	case "dylib":
		return detected == valueMachO || detected == "fat-mach-o" || detected == valueJavaOrFatMachO
	case "class":
		return detected == valueJavaOrFatMachO
	case "jar", "whl", "nupkg":
		return detected == valueZip
	case "doc", "xls", "ppt":
		return detected == "ole-container"
	case valueDatabase:
		return detected == "sqlite"
	}

	return false
}

func named(ext string) (string, string) {
	switch ext {
	case ".zip", ".gz", ".tgz", ".tar", ".bz2", ".xz", ".7z", ".rar", ".zst", ".jar", ".whl", ".nupkg":
		return strings.TrimPrefix(ext, "."), valueArchive
	case ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".ico", ".heic", ".avif":
		return strings.TrimPrefix(ext, "."), valueImage
	case ".pdf", ".rtf", ".doc", ".xls", ".ppt":
		return strings.TrimPrefix(ext, "."), valueDocument
	case ".docx", ".xlsx", ".pptx", ".docm", ".xlsm", ".pptm":
		return "ooxml", valueDocument
	case ".odt", ".ods", ".odp":
		return "opendocument", valueDocument
	case ".exe", ".dll", ".so", ".dylib", ".wasm", ".pyc", ".pyo", ".class", ".o", ".a":
		return strings.TrimPrefix(ext, "."), valueExecutable
	case ".db", ".sqlite", ".sqlite3":
		return valueDatabase, valueDatabase
	case ".mp3", ".wav", ".mp4", ".mov", ".ogg", ".flac":
		return strings.TrimPrefix(ext, "."), "media"
	}

	return "", ""
}

func magic(s string) (string, string) {
	for _, sig := range []struct{ prefix, format, category string }{
		{"\x7fELF", "elf", valueExecutable},
		{"MZ", "pe-candidate", valueExecutable},
		{"\x00asm", "wasm", valueExecutable},
		{"\xfe\xed\xfa\xce", valueMachO, valueExecutable},
		{"\xce\xfa\xed\xfe", valueMachO, valueExecutable},
		{"\xfe\xed\xfa\xcf", valueMachO, valueExecutable},
		{"\xcf\xfa\xed\xfe", valueMachO, valueExecutable},
		{"\xca\xfe\xba\xbe", valueJavaOrFatMachO, valueExecutable},
		{"\xbe\xba\xfe\xca", "fat-mach-o", valueExecutable},
		{"PK\x03\x04", valueZip, valueArchive},
		{"PK\x05\x06", valueZip, valueArchive},
		{"PK\x07\x08", valueZip, valueArchive},
		{"\x1f\x8b", "gzip", valueArchive},
		{"BZh", "bzip2", valueArchive},
		{"\xfd7zXZ\x00", "xz", valueArchive},
		{"7z\xbc\xaf\x27\x1c", "7z", valueArchive},
		{"Rar!\x1a\x07", "rar", valueArchive},
		{"\x28\xb5\x2f\xfd", "zstd", valueArchive},
		{"\x89PNG\r\n\x1a\n", "png", valueImage},
		{"\xff\xd8\xff", "jpeg", valueImage},
		{"GIF87a", "gif", valueImage},
		{"GIF89a", "gif", valueImage},
		{"II\x2a\x00", valueTiff, valueImage},
		{"MM\x00\x2a", valueTiff, valueImage},
		{"%PDF-", "pdf", valueDocument},
		{"{\\rtf", "rtf", valueDocument},
		{"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", "ole-container", valueDocument},
		{"SQLite format 3\x00", "sqlite", valueDatabase},
	} {
		if strings.HasPrefix(s, sig.prefix) {
			return sig.format, sig.category
		}
	}

	if len(s) >= 12 && s[:4] == "RIFF" && s[8:12] == "WEBP" {
		return "webp", valueImage
	}

	if len(s) >= 262 && s[257:262] == "ustar" {
		return "tar", valueArchive
	}

	return "", ""
}
