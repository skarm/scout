package filetype

// Shared vocabulary used by this package's protocols and reports.
const (
	valueArchive        = "archive"
	valueDatabase       = "database"
	valueExecutable     = "executable"
	valueImage          = "image"
	valueJavaOrFatMachO = "java-or-fat-mach-o"
	valueTiff           = "tiff"
	valueUnknown        = "unknown"
	valueUtf8           = "utf-8"
	valueZip            = "zip"
)
