package model

// Suppression is an operator decision, not deletion of a security observation.
type Suppression struct {
	FindingID    string `json:"finding_id"`
	EntryIndex   int    `json:"entry_index"`
	Kind         string `json:"kind"`
	ReasonSHA256 string `json:"reason_sha256"`
	Expires      string `json:"expires"`
}
type BaselineReport struct {
	Enabled        bool          `json:"enabled"`
	DocumentSHA256 string        `json:"document_sha256,omitempty"`
	Status         string        `json:"status"`
	Suppressed     []Suppression `json:"suppressed"`
	Expired        int           `json:"expired_entries"`
	Pending        int           `json:"pending_entries"`
	Unmatched      int           `json:"unmatched_entries"`
}

// Risk is an advisory prioritization measure, never a probability or admission.
type Risk struct {
	Algorithm            string `json:"algorithm"`
	Score                int    `json:"score"`
	Level                string `json:"level"`
	ActiveFindings       int    `json:"active_findings"`
	SuppressedFindings   int    `json:"suppressed_findings"`
	ConfidenceAssumption string `json:"confidence_assumption"`
}
type Vulnerability struct {
	ID               string   `json:"id"`
	DependencyIDs    []string `json:"dependency_ids"`
	Aliases          []string `json:"aliases,omitempty"`
	DatabaseModified string   `json:"database_modified,omitempty"`
}
type VulnerabilityQuery struct {
	DependencyID string `json:"dependency_id"`
	Ecosystem    string `json:"ecosystem"`
	Name         string `json:"name"`
	Version      string `json:"version"`
	Status       string `json:"status"`
}
type VulnerabilityReport struct {
	Enabled        bool                 `json:"enabled"`
	Source         string               `json:"source"`
	DatabaseSHA256 string               `json:"database_sha256,omitempty"`
	QueriedAt      string               `json:"queried_at,omitempty"`
	Completeness   Completeness         `json:"completeness"`
	Queries        []VulnerabilityQuery `json:"queries"`
	Matches        []Vulnerability      `json:"matches"`
	Limitations    []string             `json:"limitations"`
}
