package model

import "errors"

// HarnessOptions is trusted caller configuration, never read from the artifact.
// Host selects an interpretation, not a whitelist of files to scan.
type HarnessOptions struct {
	Host string `json:"host"`
}

// SourceRef identifies immutable bytes without embedding source/secret values.
type SourceRef struct {
	Path       string `json:"path"`
	SHA256     string `json:"sha256"`
	ByteStart  int    `json:"byte_start"`
	ByteEnd    int    `json:"byte_end"`
	SpanSHA256 string `json:"span_sha256"`
}

type HarnessLimits struct {
	Plugins    int `json:"plugins"`
	Components int `json:"components"`
	Edges      int `json:"edges"`
	References int `json:"references"`
	Operations int `json:"operations"`
}

type PluginInterpretation struct {
	ID             string   `json:"id"`
	Host           string   `json:"host"`
	Namespace      string   `json:"namespace"`
	Root           string   `json:"root"`
	Manifests      []string `json:"manifests"`
	AdapterID      string   `json:"adapter_id"`
	AdapterVersion string   `json:"adapter_version"`
	Contract       string   `json:"contract"`
	FormatStatus   string   `json:"format_status"`
	Activation     string   `json:"activation"`
	Assumptions    []string `json:"assumptions"`
}

type Component struct {
	ID          string     `json:"id"`
	PluginID    string     `json:"plugin_id,omitempty"`
	Kind        string     `json:"kind"`
	Path        string     `json:"path,omitempty"`
	PackagePath string     `json:"package_path,omitempty"`
	Host        string     `json:"host"`
	Activation  string     `json:"activation"`
	Source      *SourceRef `json:"source,omitempty"`
}

type ComponentEdge struct {
	ID         string     `json:"id"`
	From       string     `json:"from"`
	To         string     `json:"to"`
	Relation   string     `json:"relation"`
	Basis      string     `json:"basis"`
	Activation string     `json:"activation"`
	Source     *SourceRef `json:"source,omitempty"`
}

// ComponentReference never exposes the raw command, URL or environment placeholder.
// A resolved file does not prove that its command is reachable or will execute.
type ComponentReference struct {
	ID          string     `json:"id"`
	PluginID    string     `json:"plugin_id"`
	ComponentID string     `json:"component_id"`
	Kind        string     `json:"kind"`
	Status      string     `json:"status"`
	Reason      string     `json:"reason"`
	TargetID    string     `json:"target_id,omitempty"`
	Source      *SourceRef `json:"source,omitempty"`
}

type HarnessIssue struct {
	Code     string `json:"code"`
	PluginID string `json:"plugin_id,omitempty"`
	Path     string `json:"path,omitempty"`
	Status   string `json:"status"`
}

type ComponentGraph struct {
	RequestedHost string                 `json:"requested_host"`
	FormatScope   string                 `json:"format_scope"`
	Limits        HarnessLimits          `json:"limits"`
	Plugins       []PluginInterpretation `json:"plugins"`
	Components    []Component            `json:"components"`
	Edges         []ComponentEdge        `json:"edges"`
	References    []ComponentReference   `json:"references"`
	Issues        []HarnessIssue         `json:"issues"`
}

// FindingContext enriches interpretation but never changes evidence, ID or severity.
type FindingContext struct {
	ComponentID string `json:"component_id"`
	PluginID    string `json:"plugin_id,omitempty"`
	Host        string `json:"host"`
	Relation    string `json:"relation"`
	Activation  string `json:"activation"`
}

// AnalysisTask is fixed after discovery and BEFORE security checks run.
// Capture/extraction/preparation have their own ledgers; they are not retroactively
// claimed to have been scheduled by this plan.
type AnalysisTask struct {
	PluginID    string `json:"plugin_id,omitempty"`
	ReferenceID string `json:"reference_id,omitempty"`
	ID          string `json:"id"`
	Kind        string `json:"kind"`
	AnalyzerID  string `json:"analyzer_id,omitempty"`
	Version     string `json:"version"`
	Path        string `json:"path,omitempty"`
	InputSHA256 string `json:"input_sha256,omitempty"`
	ComponentID string `json:"component_id,omitempty"`
	Required    bool   `json:"required"`
}

type TaskOutcome struct {
	TaskID string `json:"task_id"`
	Status string `json:"status"`
	Reason string `json:"reason"`
}

type ValidationReport struct {
	Scope        string         `json:"scope"`
	PlanSHA256   string         `json:"plan_sha256"`
	MaxTasks     int            `json:"max_tasks"`
	OmittedTasks int            `json:"omitted_tasks"`
	Tasks        []AnalysisTask `json:"tasks"`
	Outcomes     []TaskOutcome  `json:"outcomes"`
	Completeness Completeness   `json:"completeness"`
	Issues       []string       `json:"issues"`
}

func (o HarnessOptions) Validate() error {
	switch o.Host {
	case "", "auto", "claude-code", "codex", "agent-skills":
		return nil
	default:
		return errors.New("harness must be auto, claude-code, codex or agent-skills")
	}
}
