package model

import "github.com/skarm/scout/knowledge"

// WithGuidance adds trusted review instructions without changing rule severity,
// detector behavior or occurrence identity. Caller-defined unknown rules are left
// untouched rather than silently attaching an unrelated generic explanation.
func WithGuidance(r Rule) Rule {
	if r.Guidance == nil {
		if g, ok := knowledge.Lookup(r.ID); ok {
			r.Guidance = &g
		}
	}

	return CloneRule(r)
}

// CloneRule isolates published reports from the engine's immutable rule catalog.
// In particular, mutating a prior report must not change a later scan's guidance.
func CloneRule(r Rule) Rule {
	if r.Guidance != nil {
		g := *r.Guidance
		g.ReviewChecks = append([]string(nil), g.ReviewChecks...)
		g.BenignConsiderations = append([]string(nil), g.BenignConsiderations...)
		g.Sources = append([]knowledge.Reference(nil), g.Sources...)
		r.Guidance = &g
	}

	return r
}

func CloneRules(rules []Rule) []Rule {
	out := make([]Rule, len(rules))
	for i, r := range rules {
		out[i] = CloneRule(r)
	}

	return out
}
