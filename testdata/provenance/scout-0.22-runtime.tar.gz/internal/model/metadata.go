package model

type MetadataField struct {
	Name          string         `json:"name"`
	ValueSHA256   string         `json:"value_sha256"`
	Kind          string         `json:"kind"`
	Source        SourceRef      `json:"source"`
	Items         []MetadataItem `json:"items,omitempty"`
	ItemsComplete bool           `json:"items_complete,omitempty"`
}

// MetadataItem holds hashed declarations for update comparison without leaking parameter
// defaults, permission text, descriptions or trigger phrases into reports.
type MetadataItem struct {
	NameSHA256  string `json:"name_sha256"`
	ValueSHA256 string `json:"value_sha256"`
}
type MetadataFile struct {
	Path          string          `json:"path"`
	Format        string          `json:"format"`
	Status        string          `json:"status"`
	Parser        string          `json:"parser"`
	ParserVersion string          `json:"parser_version"`
	Fields        []MetadataField `json:"fields"`
	Issues        []string        `json:"issues"`
}
type MetadataReport struct {
	Files        []MetadataFile `json:"files"`
	Completeness Completeness   `json:"completeness"`
	Limitations  []string       `json:"limitations"`
}
