package model

import (
	"github.com/skarm/scout/knowledge"
	"github.com/skarm/scout/review"
)

// SemanticReport contains model proposals and assessments, not deterministic findings.
// No response prose, source bytes, API keys or endpoint URLs enter this contract.
type SemanticReport struct {
	InstructionPack        knowledge.Manifest           `json:"instruction_pack"`
	InitialTaskCount       int                          `json:"initial_task_count"`
	InitialGapCount        int                          `json:"initial_gap_count"`
	InitialOmittedGaps     int                          `json:"initial_omitted_gaps"`
	OmittedGaps            int                          `json:"omitted_gaps"`
	Enabled                bool                         `json:"enabled"`
	Scope                  string                       `json:"scope"`
	ProtocolVersion        string                       `json:"protocol_version"`
	PromptVersion          string                       `json:"prompt_version"`
	PromptSHA256           string                       `json:"prompt_sha256"`
	ResponseSchemaSHA256   string                       `json:"response_schema_sha256"`
	Provider               review.Identity              `json:"provider"`
	Options                review.Options               `json:"options"`
	VerificationPlanSHA256 string                       `json:"verification_plan_sha256,omitempty"`
	ProposalAssessments    []SemanticProposalAssessment `json:"proposal_assessments"`
	PlanSHA256             string                       `json:"plan_sha256,omitempty"`
	Completeness           Completeness                 `json:"completeness,omitempty"`
	Tasks                  []SemanticTask               `json:"tasks"`
	Outcomes               []SemanticOutcome            `json:"outcomes"`
	Gaps                   []SemanticGap                `json:"gaps"`
	Proposals              []SemanticProposal           `json:"proposals"`
	Assessments            []SemanticAssessment         `json:"assessments"`
	RequestBytes           int                          `json:"request_bytes"`
	CompletedRequests      int                          `json:"completed_requests"`
}
type SemanticTask struct {
	KnowledgeTopicIDs []string        `json:"knowledge_topic_ids"`
	PromptSHA256      string          `json:"prompt_sha256"`
	PromptBytes       int             `json:"prompt_bytes"`
	DependsOn         []string        `json:"depends_on,omitempty"`
	ProposalIDs       []string        `json:"proposal_ids,omitempty"`
	ScopeID           string          `json:"scope_id"`
	ID                string          `json:"id"`
	Mode              string          `json:"mode"`
	RequestSHA256     string          `json:"request_sha256"`
	RequestBytes      int             `json:"request_bytes"`
	Inputs            []SemanticInput `json:"inputs"`
	FindingIDs        []string        `json:"finding_ids"`
	LinkIDs           []string        `json:"link_ids"`
}
type SemanticInput struct {
	ID     string    `json:"id"`
	Source SourceRef `json:"source"`
}
type SemanticOutcome struct {
	TaskID              string `json:"task_id"`
	Status              string `json:"status"`
	Reason              string `json:"reason"`
	ResponseSHA256      string `json:"response_sha256,omitempty"`
	ReportedModelSHA256 string `json:"reported_model_sha256,omitempty"`
	FingerprintSHA256   string `json:"fingerprint_sha256,omitempty"`
	InputTokens         int64  `json:"reported_input_tokens"`
	OutputTokens        int64  `json:"reported_output_tokens"`
}
type SemanticGap struct {
	ProposalID string `json:"proposal_id,omitempty"`
	Code       string `json:"code"`
	Path       string `json:"path,omitempty"`
	ByteStart  int    `json:"byte_start,omitempty"`
	ByteEnd    int    `json:"byte_end,omitempty"`
	FindingID  string `json:"finding_id,omitempty"`
	PluginID   string `json:"plugin_id,omitempty"`
}
type SemanticProposal struct {
	KnowledgeTopicID  string           `json:"knowledge_topic_id,omitempty"`
	Guidance          *knowledge.Guide `json:"guidance,omitempty"`
	UpstreamRuleID    string           `json:"upstream_rule_id,omitempty"`
	ID                string           `json:"id"`
	TaskID            string           `json:"task_id"`
	Reason            string           `json:"reason"`
	Category          string           `json:"category"`
	SuggestedSeverity Severity         `json:"suggested_severity"`
	Evidence          []SourceRef      `json:"evidence"`
}
type SemanticAssessment struct {
	TaskID    string      `json:"task_id"`
	FindingID string      `json:"finding_id"`
	Verdict   string      `json:"verdict"`
	Reason    string      `json:"reason"`
	Evidence  []SourceRef `json:"evidence"`
}

// SemanticProposalAssessment records a second model pass, not an independent security proof.
// Original proposal identity/evidence/severity remains unchanged for all verdicts.
type SemanticProposalAssessment struct {
	TaskID     string      `json:"task_id"`
	ProposalID string      `json:"proposal_id"`
	Verdict    string      `json:"verdict"`
	Reason     string      `json:"reason"`
	Evidence   []SourceRef `json:"evidence"`
}
