package model

// BatchReport never grants a package an exemption because a sibling passed.
type BatchReport struct {
	SchemaVersion string       `json:"schema_version"`
	EngineVersion string       `json:"engine_version"`
	Completeness  Completeness `json:"completeness"`
	Decision      Decision     `json:"decision"`
	Items         []BatchItem  `json:"items"`
	Limitations   []string     `json:"limitations"`
}
type BatchItem struct {
	Index        int     `json:"index"`
	TargetSHA256 string  `json:"target_sha256"`
	Status       string  `json:"status"`
	Report       *Report `json:"report,omitempty"`
}
