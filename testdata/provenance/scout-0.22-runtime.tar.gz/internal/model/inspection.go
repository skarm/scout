package model

// InspectionPlan describes selection and compiled availability before execution.
// Outcomes and completeness remain in Coverage/Validation; availability is not
// evidence that a selected check completed or that its detection is exhaustive.
type InspectionPlan struct {
	Name             string            `json:"name"`
	RequestedProfile string            `json:"requested_profile,omitempty"`
	Checks           []InspectionCheck `json:"checks"`
	Egress           InspectionEgress  `json:"egress"`
	Requirements     []string          `json:"requirements"`
}

type InspectionCheck struct {
	ID        string `json:"id"`
	Selected  bool   `json:"selected"`
	Available bool   `json:"available"`
	Reason    string `json:"reason,omitempty"`
}

type InspectionEgress struct {
	Download             bool `json:"download"`
	VulnerabilityNetwork bool `json:"vulnerability_network"`
	SourceUpload         bool `json:"source_upload"`
}
