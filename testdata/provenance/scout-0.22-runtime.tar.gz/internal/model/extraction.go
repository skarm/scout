package model

import "errors"

// ExtractionLimits are scan-wide and independent of capture limits. They apply
// across all roots and all recursion levels, including failed output reads.
type ExtractionLimits struct {
	MaxDepth       int   `json:"max_depth"`
	MaxObjects     int   `json:"max_objects"`
	MaxEntries     int   `json:"max_entries"`
	MaxObjectBytes int64 `json:"max_object_bytes"`
	MaxTotalBytes  int64 `json:"max_total_bytes"`
}

// DerivedObject is a virtual, never-on-disk object. Byte offsets in findings
// refer to File, NOT to the compressed or encoded parent. ParentRange, when
// present, encloses the source representation; it is NOT a byte-to-byte map.
type DerivedObject struct {
	Role             string     `json:"role"` // archive_member, metadata or decoded; not a trust label
	ID               string     `json:"id"`
	File             File       `json:"file"`
	ParentPath       string     `json:"parent_path"`
	ParentSHA256     string     `json:"parent_sha256"`
	ExtractorID      string     `json:"extractor_id"`
	ExtractorVersion string     `json:"extractor_version"`
	Depth            int        `json:"depth"`
	Ordinal          int        `json:"ordinal"`
	MemberName       string     `json:"member_name,omitempty"`
	ParentRange      *ByteRange `json:"parent_range,omitempty"`
	CoordinateSpace  string     `json:"coordinate_space"`
}

type ByteRange struct {
	Start int `json:"start"`
	End   int `json:"end"`
}

type ExtractionStep struct {
	ParentPath  string `json:"parent_path"`
	ExtractorID string `json:"extractor_id"`
	Version     string `json:"version"`
	Status      string `json:"status"`
	Objects     int    `json:"objects"`
}

// SkippedObject records a known child whose complete validated bytes were not
// obtained. It has no fabricated hash, source coordinates, or analysis result.
type SkippedObject struct {
	Role         string `json:"role"`
	ParentPath   string `json:"parent_path"`
	ExtractorID  string `json:"extractor_id"`
	MemberName   string `json:"member_name"`
	Ordinal      int    `json:"ordinal"`
	DeclaredSize int64  `json:"declared_size"` // -1 means unknown
	Reason       string `json:"reason"`
}

type ExtractionReport struct {
	Skipped        []SkippedObject  `json:"skipped"`
	Limits         ExtractionLimits `json:"limits"`
	Skills         []string         `json:"skills"`
	Objects        []DerivedObject  `json:"objects"`
	Steps          []ExtractionStep `json:"steps"`
	EntriesVisited int              `json:"entries_visited"`
	BytesProduced  int64            `json:"bytes_produced"`
}

func DefaultExtractionLimits() ExtractionLimits {
	return ExtractionLimits{MaxDepth: 4, MaxObjects: 256, MaxEntries: 8192, MaxObjectBytes: 1 << 20, MaxTotalBytes: 16 << 20}
}

func (l ExtractionLimits) Validate() error {
	if l.MaxDepth < 1 || l.MaxDepth > 16 {
		return errors.New("extraction depth must be in 1..16")
	}

	if l.MaxObjects < 1 || l.MaxObjects > 4096 {
		return errors.New("extraction objects must be in 1..4096")
	}

	if l.MaxEntries < 1 || l.MaxEntries > 100000 {
		return errors.New("extraction entries must be in 1..100000")
	}

	if l.MaxObjectBytes < 1 || l.MaxObjectBytes > 32<<20 {
		return errors.New("extraction object bytes must be in 1..33554432")
	}

	if l.MaxTotalBytes < l.MaxObjectBytes || l.MaxTotalBytes > 128<<20 {
		return errors.New("extraction total bytes must be >= object bytes and <= 134217728")
	}

	return nil
}
