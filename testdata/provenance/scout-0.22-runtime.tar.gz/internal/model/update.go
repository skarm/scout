package model

import "errors"

// UpdateOptions limits retained deltas, independently of each scan's input limits.
// The update workflow always rescans both local targets using one Scanner config.
type UpdateOptions struct {
	MaxChanges int `json:"max_changes"`
}

// ObjectAddress identifies corresponding captured objects without content hashes.
// Archive members use names, not ZIP order. Non-member transforms use ordinals:
// changes to their ordering are conservative deltas, not guessed semantic matches.
// SingleFile is used ONLY when both operator-selected targets are standalone files.
type ObjectAddress struct {
	SingleFile bool         `json:"single_file,omitempty"`
	Root       string       `json:"root,omitempty"`
	Steps      []ObjectStep `json:"steps,omitempty"`
}
type ObjectStep struct {
	Role             string `json:"role"`
	Extractor        string `json:"extractor"`
	ExtractorVersion string `json:"extractor_version"`
	Member           string `json:"member,omitempty"`
	Ordinal          int    `json:"ordinal,omitempty"`
}

type FileChange struct {
	ObjectID string        `json:"object_id"`
	Address  ObjectAddress `json:"address"`
	Change   string        `json:"change"` // added, removed, modified, renamed_input, unverified
	Reasons  []string      `json:"reasons"`
	Before   *File         `json:"before,omitempty"`
	After    *File         `json:"after,omitempty"`
}

// ComponentChange compares multisets, not arbitrary one-to-one identities for
// unnamed hooks. IDs resolve to the corresponding before/after component graphs.
type ComponentChange struct {
	GroupID          string   `json:"group_id"`
	ObjectID         string   `json:"object_id,omitempty"`
	Kind             string   `json:"kind"`
	Host             string   `json:"host"`
	Change           string   `json:"change"`
	BeforeIDs        []string `json:"before_ids"`
	AfterIDs         []string `json:"after_ids"`
	NotMatchedBefore []string `json:"not_matched_before"`
	NotMatchedAfter  []string `json:"not_matched_after"`
	Matched          int      `json:"matched"`
}

type DependencyChange struct {
	GroupID  string       `json:"group_id"`
	ObjectID string       `json:"object_id"`
	Change   string       `json:"change"`
	Before   []Dependency `json:"before"`
	After    []Dependency `json:"after"`
}

// FindingChange never removes findings from either report. not_observed is NOT
// a claim of remediation; unverified means the relevant candidate check did not
// complete or the containing object was unavailable.
type FindingChange struct {
	ObjectID       string    `json:"object_id"`
	Change         string    `json:"change"` // introduced, not_observed, unverified, relocated, context_changed
	RuleID         string    `json:"rule_id"`
	BeforeID       string    `json:"before_id,omitempty"`
	AfterID        string    `json:"after_id,omitempty"`
	BeforeLocation *Location `json:"before_location,omitempty"`
	AfterLocation  *Location `json:"after_location,omitempty"`
}

type UpdateCounts struct {
	ManifestSignals    int `json:"manifest_signals"`
	FileChanges        int `json:"file_changes"`
	UnchangedObjects   int `json:"unchanged_objects"`
	ComponentChanges   int `json:"component_changes"`
	DependencyChanges  int `json:"dependency_changes"`
	FindingChanges     int `json:"finding_changes"`
	PersistentFindings int `json:"persistent_findings"`
	IntroducedFindings int `json:"introduced_findings"`
	UnobservedFindings int `json:"unobserved_findings"`
}
type UpdateDelta struct {
	ManifestSignals  []ManifestSignal   `json:"manifest_signals"`
	AlgorithmVersion string             `json:"algorithm_version"`
	Completeness     Completeness       `json:"completeness"`
	SameSnapshot     bool               `json:"same_snapshot"`
	Counts           UpdateCounts       `json:"counts"`
	Files            []FileChange       `json:"files"`
	Components       []ComponentChange  `json:"components"`
	Dependencies     []DependencyChange `json:"dependencies"`
	Findings         []FindingChange    `json:"findings"`
	OmittedChanges   int                `json:"omitted_changes"`
	Issues           []string           `json:"issues"`
}
type ManifestSignal struct {
	RuleID   string     `json:"rule_id"`
	Severity Severity   `json:"severity"`
	Field    string     `json:"field"`
	Change   string     `json:"change"`
	Before   *SourceRef `json:"before,omitempty"`
	After    *SourceRef `json:"after,omitempty"`
}

// UpdateReport includes BOTH fresh reports. It accepts no author-supplied report
// or baseline and is not an install attestation, signature or suppression file.
type UpdateReport struct {
	SchemaVersion string        `json:"schema_version"`
	Kind          string        `json:"kind"`
	EngineVersion string        `json:"engine_version"`
	Options       UpdateOptions `json:"options"`
	Before        Report        `json:"before"`
	After         Report        `json:"after"`
	Delta         UpdateDelta   `json:"delta"`
	Completeness  Completeness  `json:"completeness"`
	Policy        PolicyResult  `json:"policy"`
	Limitations   []string      `json:"limitations"`
}

func DefaultUpdateOptions() UpdateOptions { return UpdateOptions{MaxChanges: 4096} }
func (o UpdateOptions) Validate() error {
	if o.MaxChanges < 1 || o.MaxChanges > 20000 {
		return errors.New("max update changes must be in 1..20000")
	}

	return nil
}
