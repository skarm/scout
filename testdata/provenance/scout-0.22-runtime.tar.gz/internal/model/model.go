// Package model defines the versioned, presentation-independent scan contract.
package model

import (
	"errors"
	"fmt"

	"github.com/skarm/scout/fetch"
	"github.com/skarm/scout/internal/filetype"
	"github.com/skarm/scout/internal/signaturecontract"
	"github.com/skarm/scout/knowledge"
)

const (
	SchemaVersion = "0.15"
	EngineVersion = "0.22.0-preview"
	ProfileID     = "agent-extensions-static-mvp-v1"
	RulesVersion  = "0.20.0"
)

type Severity string

const (
	Info     Severity = "info"
	Low      Severity = "low"
	Medium   Severity = "medium"
	High     Severity = "high"
	Critical Severity = "critical"
)

func (s Severity) Rank() int {
	switch s {
	case Info:
		return 0
	case Low:
		return 1
	case Medium:
		return 2
	case High:
		return 3
	case Critical:
		return 4
	default:
		return -1
	}
}

type Completeness string

const (
	Complete Completeness = "complete"
	Partial  Completeness = "partial"
	Failed   Completeness = "failed"
)

type Decision string

const (
	Allow  Decision = "allow"
	Review Decision = "review"
	Block  Decision = "block"
)

type Rule struct {
	Guidance    *knowledge.Guide `json:"guidance,omitempty"`
	ID          string           `json:"id"`
	Version     string           `json:"version"`
	Title       string           `json:"title"`
	Description string           `json:"description"`
	Severity    Severity         `json:"severity"`
	Category    string           `json:"category"`
	Method      string           `json:"method"`
	Limitation  string           `json:"limitation"`
}

// Location uses zero-based, half-open original byte offsets. Text locations also
// use one-based Unicode code-point line/column coordinates. Binary locations have
// Coordinates="bytes" and zero line/column values. End coordinates are exclusive.
type Location struct {
	Derived     bool   `json:"derived,omitempty"`
	Path        string `json:"path"`
	Coordinates string `json:"coordinates"` // text or bytes; byte-only locations have no fabricated lines
	ByteStart   int    `json:"byte_start"`
	ByteEnd     int    `json:"byte_end"`
	StartLine   int    `json:"start_line"`
	StartColumn int    `json:"start_column"`
	EndLine     int    `json:"end_line"`
	EndColumn   int    `json:"end_column"`
	Context     string `json:"context"`
	Structure   string `json:"structure,omitempty"`
	Language    string `json:"language,omitempty"`
}

// Evidence deliberately contains no source excerpt or credential value.
type Evidence struct {
	FileSHA256 string `json:"file_sha256"`
	SpanSHA256 string `json:"span_sha256"`
}

type Finding struct {
	ContextSignals  []string         `json:"context_signals,omitempty"`
	SignatureNames  []string         `json:"signature_names,omitempty"`
	RelatedEvidence []SourceRef      `json:"related_evidence,omitempty"`
	AdvisoryIDs     []string         `json:"advisory_ids,omitempty"`
	Contexts        []FindingContext `json:"contexts,omitempty"`
	ID              string           `json:"id"`
	RuleID          string           `json:"rule_id"`
	RuleVersion     string           `json:"rule_version"`
	Severity        Severity         `json:"severity"`
	Category        string           `json:"category"`
	Method          string           `json:"method"`
	Message         string           `json:"message"`
	Location        Location         `json:"location"`
	Evidence        Evidence         `json:"evidence"`
	Trace           []TraceStep      `json:"trace,omitempty"`
}

type TraceStep struct {
	Role     string   `json:"role"`
	Location Location `json:"location"`
	Evidence Evidence `json:"evidence"`
}

type Diagnostic struct {
	Code         string `json:"code"`
	Path         string `json:"path,omitempty"`
	Message      string `json:"message"`
	AffectsScope bool   `json:"affects_scope"`
}

type File struct {
	Path       string `json:"path"`
	Size       int64  `json:"size"`
	SHA256     string `json:"sha256,omitempty"`
	Executable bool   `json:"executable"`
	Kind       string `json:"kind"`
	Status     string `json:"status"`
	Reason     string `json:"reason,omitempty"`
}

type Artifact struct {
	SourceKind        string   `json:"source_kind"`
	SnapshotSHA256    string   `json:"snapshot_sha256,omitempty"`
	InventoryComplete bool     `json:"inventory_complete"`
	IdentityScope     string   `json:"identity_scope"`
	Files             []File   `json:"files"`
	Skills            []string `json:"skills"`
}

type Check struct {
	AnalyzerID string `json:"analyzer_id"`
	Version    string `json:"version"`
	Status     string `json:"status"`
	FilesTotal int    `json:"files_total"`
	FilesDone  int    `json:"files_done"`
	Findings   int    `json:"findings"`
	Detail     string `json:"detail,omitempty"`
}

type Coverage struct {
	AnalyzedObjects int            `json:"analyzed_objects"`
	Completeness    Completeness   `json:"completeness"`
	CapturedFiles   int            `json:"captured_files"`
	TextFiles       int            `json:"text_files"`
	Checks          []Check        `json:"checks"`
	Files           []FileCoverage `json:"files"`
}

// FileCoverage covers every inventoried entry, including unread or unsupported
// files. complete refers only to the selected profile, not arbitrary behavior.
type FileCoverage struct {
	Path           string               `json:"path"`
	ReadStatus     string               `json:"read_status"`
	Classification filetype.Description `json:"classification"`
	Completeness   Completeness         `json:"completeness"`
	Checks         []FileCheck          `json:"checks"`
	Units          []UnitCoverage       `json:"units"`
	Gaps           []string             `json:"gaps"`
}
type FileCheck struct {
	AnalyzerID string `json:"analyzer_id"`
	Status     string `json:"status"`
}
type UnitCoverage struct {
	Language      string `json:"language"`
	Origin        string `json:"origin"`
	ParserID      string `json:"parser_id,omitempty"`
	ParserVersion string `json:"parser_version,omitempty"`
	Status        string `json:"status"`
	ByteStart     int    `json:"byte_start"`
	ByteEnd       int    `json:"byte_end"`
}

type Policy struct {
	ID      string   `json:"id"`
	BlockAt Severity `json:"block_at"`
}

func (p Policy) Validate() error {
	if p.ID == "" || len(p.ID) > 128 {
		return errors.New("policy ID must contain 1..128 bytes")
	}

	if p.BlockAt.Rank() < 0 {
		return fmt.Errorf("invalid block threshold %q", p.BlockAt)
	}

	return nil
}

type PolicyResult struct {
	ID       string   `json:"id"`
	BlockAt  Severity `json:"block_at"`
	Decision Decision `json:"decision"`
	Reasons  []string `json:"reasons"`
}

type Limits struct {
	MaxEntries      int   `json:"max_entries"`
	MaxFiles        int   `json:"max_files"`
	MaxFileBytes    int64 `json:"max_file_bytes"`
	MaxTotalBytes   int64 `json:"max_total_bytes"`
	MaxArchiveBytes int64 `json:"max_archive_bytes"`
	MaxPathBytes    int   `json:"max_path_bytes"`
	MaxDepth        int   `json:"max_depth"`
	MaxFindings     int   `json:"max_findings"`
}

func DefaultLimits() Limits {
	return Limits{
		MaxEntries: 8192, MaxFiles: 4096,
		MaxFileBytes: 1 << 20, MaxTotalBytes: 32 << 20,
		MaxArchiveBytes: 32 << 20, MaxPathBytes: 1024,
		MaxDepth: 32, MaxFindings: 1024,
	}
}

// Validate applies hard ceilings that also bound allocations before per-entry validation.
func (l Limits) Validate() error {
	if l.MaxEntries < 1 || l.MaxEntries > 100_000 {
		return errors.New("max entries must be in 1..100000")
	}

	if l.MaxFiles < 1 || l.MaxFiles > l.MaxEntries {
		return errors.New("max files must be positive and <= max entries")
	}

	if l.MaxFileBytes < 1 || l.MaxFileBytes > 32<<20 {
		return errors.New("max file bytes must be in 1..33554432")
	}

	if l.MaxTotalBytes < l.MaxFileBytes || l.MaxTotalBytes > 256<<20 {
		return errors.New("max total bytes must be >= max file bytes and <= 268435456")
	}

	if l.MaxArchiveBytes < 1 || l.MaxArchiveBytes > 128<<20 {
		return errors.New("max archive bytes must be in 1..134217728")
	}

	if l.MaxPathBytes < 1 || l.MaxPathBytes > 4096 || l.MaxDepth < 1 || l.MaxDepth > 128 {
		return errors.New("path budget must be in 1..4096 bytes and depth in 1..128")
	}

	if l.MaxFindings < 1 || l.MaxFindings > 100_000 {
		return errors.New("max findings must be in 1..100000")
	}

	return nil
}

type Report struct {
	Inspection      InspectionPlan           `json:"inspection"`
	Knowledge       knowledge.Manifest       `json:"knowledge"`
	Signatures      signaturecontract.Report `json:"signatures"`
	Metadata        MetadataReport           `json:"metadata"`
	Baseline        BaselineReport           `json:"baseline"`
	Risk            Risk                     `json:"risk"`
	Vulnerabilities VulnerabilityReport      `json:"vulnerabilities"`
	Dependencies    DependencyReport         `json:"dependencies"`
	Source          *fetch.Provenance        `json:"source,omitempty"`
	Semantic        SemanticReport           `json:"semantic"`
	Components      ComponentGraph           `json:"components"`
	Validation      ValidationReport         `json:"validation"`
	SchemaVersion   string                   `json:"schema_version"`
	EngineVersion   string                   `json:"engine_version"`
	RulesVersion    string                   `json:"rules_version"`
	Profile         string                   `json:"profile"`
	Artifact        Artifact                 `json:"artifact"`
	Coverage        Coverage                 `json:"coverage"`
	Policy          PolicyResult             `json:"policy"`
	Limits          Limits                   `json:"limits"`
	Extraction      ExtractionReport         `json:"extraction"`
	AnalysisLimits  AnalysisLimits           `json:"analysis_limits"`
	Rules           []Rule                   `json:"rules"`
	Findings        []Finding                `json:"findings"`
	Diagnostics     []Diagnostic             `json:"diagnostics"`
	Limitations     []string                 `json:"limitations"`
}

// AnalysisLimits records fixed implementation ceilings, distinct from the
// configurable input/output limits. Unknown semantics remain partial.
type AnalysisLimits struct {
	GoFlowOperations     int `json:"go_flow_operations"`
	GoFlowBindings       int `json:"go_flow_bindings"`
	AgentJSONBytes       int `json:"agent_json_unit_bytes"`
	AgentJSONNodes       int `json:"agent_json_nodes"`
	AgentJSONDepth       int `json:"agent_json_depth"`
	AgentJSONScanBytes   int `json:"agent_json_scan_bytes"`
	ShellUnitBytes       int `json:"shell_unit_bytes"`
	ShellScanBytes       int `json:"shell_scan_bytes"`
	ShellParserDepth     int `json:"shell_parser_depth"`
	ShellParserNodes     int `json:"shell_parser_nodes"`
	ShellOperations      int `json:"shell_analysis_operations"`
	ShellBindings        int `json:"shell_bindings"`
	ShellTraceTransforms int `json:"shell_trace_transforms"`
	JSONNestingDepth     int `json:"json_extraction_nesting_depth"`
	UnitsPerFile         int `json:"analysis_units_per_file"`
	EmbeddedUnitBytes    int `json:"embedded_unit_bytes"`
	DocumentRegions      int `json:"document_regions_per_file"`
	SourceSegments       int `json:"source_segments_per_unit"`
	GoUnitBytes          int `json:"go_unit_bytes"`
	GoScanBytes          int `json:"go_scan_bytes"`
	ConstantOperations   int `json:"constant_operations"`
	ConstantStringBytes  int `json:"constant_string_bytes"`
}
