package model

// Dependency describes a declaration, NOT a resolved build graph. In go.mod a
// require version is a minimum under MVS; no installed version is inferred.
type Dependency struct {
	ID                 string     `json:"id"`
	Ecosystem          string     `json:"ecosystem"`
	Module             string     `json:"module"`
	DeclaredVersion    string     `json:"declared_version"`
	VersionSemantics   string     `json:"version_semantics"`
	Indirect           bool       `json:"indirect"`
	Replacement        string     `json:"replacement"`
	ReplacementModule  string     `json:"replacement_module,omitempty"`
	ReplacementVersion string     `json:"replacement_version,omitempty"`
	Source             SourceRef  `json:"source"`
	ReplacementSource  *SourceRef `json:"replacement_source,omitempty"`
}
type DependencyManifest struct {
	Path          string `json:"path"`
	Status        string `json:"status"`
	Parser        string `json:"parser"`
	ParserVersion string `json:"parser_version"`
}
type DependencyReport struct {
	Scope        string               `json:"scope"`
	Manifests    []DependencyManifest `json:"manifests"`
	Declarations []Dependency         `json:"declarations"`
	Limitations  []string             `json:"limitations"`
}
