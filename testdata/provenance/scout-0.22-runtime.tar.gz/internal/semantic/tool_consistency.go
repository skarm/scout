// SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES.
// SPDX-License-Identifier: Apache-2.0
// Modified TP4 planner: scanner-issued excerpts, nearest package scope,
// independent verification and explicit omissions replace free-form model text.

package semantic

import (
	"path"
	"regexp"
	"sort"
	"strings"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/review"
)

var descriptionField = regexp.MustCompile(`(?m)^[\t ]*description[\t ]*:[\t ]*\S`)

type (
	toolAddress struct{ namespace, name string }
	toolScope   struct {
		file    artifact.File
		address toolAddress
		root    string
	}
)

func (p *planner) planToolConsistency() {
	addresses := map[string]toolAddress{}

	for name := range p.files {
		if !strings.HasPrefix(name, "scout-object://") {
			addresses[name] = toolAddress{"snapshot", name}
		}
	}

	for _, o := range p.extraction.Objects {
		if o.Role == "archive_member" && (o.ExtractorID == "zip32" || o.ExtractorID == "tar") {
			addresses[o.File.Path] = toolAddress{o.ParentPath, o.MemberName}
		}
	}

	scopes, ok := p.toolScopes(addresses)
	if !ok {
		return
	}

	names := make([]string, 0, len(addresses))
	for name := range addresses {
		names = append(names, name)
	}

	sort.Strings(names)

	for _, name := range names {
		p.planCodeConsistency(name, addresses[name], scopes)
	}
}

func (p *planner) toolScopes(addresses map[string]toolAddress) ([]toolScope, bool) {
	scopes := []toolScope{}

	for name, addr := range addresses {
		if p.ctx.Err() != nil {
			p.gap("tool_consistency_planning_cancelled", name, 0, 0, "", "")
			return nil, false
		}

		f := p.files[name]
		text := f.Content()
		base := path.Base(addr.name)
		isSkill := strings.EqualFold(base, "SKILL.md")

		isPlugin := strings.HasSuffix(addr.name, ".claude-plugin/plugin.json") || strings.HasSuffix(addr.name, ".codex-plugin/plugin.json")
		if !isSkill && !isPlugin {
			continue
		}

		// Like upstream TP4, no description means no consistency assertion.
		// Discovery/intent remain independently planned for missing metadata.
		if !p.toolDescriptionDeclared(text, isSkill) {
			continue
		}

		root := path.Dir(addr.name)
		if isPlugin {
			root = path.Dir(root)
		}

		scopes = append(scopes, toolScope{file: f, address: addr, root: root})
	}

	sort.Slice(scopes, func(i, j int) bool {
		if len(scopes[i].root) != len(scopes[j].root) {
			return len(scopes[i].root) > len(scopes[j].root)
		}

		return scopes[i].file.Metadata().Path < scopes[j].file.Metadata().Path
	})

	return scopes, true
}

func (p *planner) toolDescriptionDeclared(text string, isSkill bool) bool {
	if isSkill {
		trim := strings.TrimPrefix(text, "\ufeff")
		if strings.HasPrefix(trim, "---\n") || strings.HasPrefix(trim, "---\r\n") {
			body := trim[strings.IndexByte(trim, '\n')+1:]
			if before, _, ok := strings.Cut(body, "\n---"); ok {
				return descriptionField.MatchString(before)
			}
		}

		return false
	}

	if node, err := jsonconfig.Parse(p.ctx, text); err == nil {
		description, ok := node.Get("description").Text()
		return ok && strings.TrimSpace(description) != ""
	}

	return false
}

func (p *planner) planCodeConsistency(name string, addr toolAddress, scopes []toolScope) {
	f := p.files[name]
	if f.Metadata().Kind != formatText || contentKind(name, f.Content()) != valueCode {
		return
	}

	var scope *toolScope

	for i := range scopes {
		candidate := &scopes[i]
		if addr.namespace == candidate.address.namespace && (candidate.root == "." || strings.HasPrefix(addr.name, candidate.root+"/")) {
			scope = candidate
			break
		}
	}

	if scope == nil {
		return
	}

	decl := scope.file
	if len(decl.Content()) > p.options.ChunkBytes/2 {
		p.gap("tool_consistency_declaration_limit", name, 0, len(f.Content()), "", "")
		return
	}

	if len(f.Content()) == 0 {
		return
	}

	chunk := p.options.ChunkBytes - len(decl.Content())
	for start := 0; start < len(f.Content()); {
		if p.ctx.Err() != nil {
			p.gap("tool_consistency_planning_cancelled", name, start, len(f.Content()), "", "")
			break
		}

		end := boundary(f.Content(), start, min(len(f.Content()), start+chunk))
		req := p.request(valueToolConsistency)
		req.ScopeID = artifact.Hash([]byte("TP4\x00" + decl.Metadata().Path))

		req.Excerpts = p.excerpts(decl, 0, len(decl.Content()))
		for i := range req.Excerpts {
			req.Excerpts[i].ContentKind = "tool_declaration"
		}

		code := p.excerpts(f, start, end)
		for i := range code {
			code[i].ContentKind = valueCode
		}

		req.Excerpts = append(req.Excerpts, code...)

		req.Links = p.links(req.Excerpts)
		if reason := p.add(req); reason != "" {
			p.gap("tool_consistency_"+reason, name, start, len(f.Content()), "", "")
			break
		}

		start = end
	}
}

func toolConsistencyEvidence(citations []review.Citation, excerpts []review.Excerpt) bool {
	seen := map[string]bool{}
	for _, c := range citations {
		seen[c.ExcerptID] = true
	}

	declaration, code := false, false

	for _, ex := range excerpts {
		if !seen[ex.ID] {
			continue
		}

		if ex.ContentKind == "tool_declaration" {
			declaration = true
		}

		if ex.ContentKind == valueCode {
			code = true
		}
	}

	return declaration && code
}
