package semantic

import (
	"github.com/skarm/scout/internal/language"
	"github.com/skarm/scout/review"
)

// This is an applicability hint, not an execution or trust classification. Code
// candidates win conflicts so a .txt shebang cannot be used as a trigger manifest.
func contentKind(name, text string) string {
	kind := valueUnknown

	for _, h := range language.Detect(name, text) {
		switch h.Language {
		case formatText:
			if kind == valueUnknown {
				kind = formatText
			}
		case formatMarkdown:
			if kind == valueUnknown || kind == formatText {
				kind = formatMarkdown
			}
		case "json", "yaml", "toml", "ini", "gomod", "dependency-manifest":
			if kind != valueCode {
				kind = "configuration"
			}
		case valueUnknown:
		default:
			return valueCode
		}
	}

	return kind
}

// A quality claim needs at least one supporting excerpt of the rule's declared
// applicability. Related cross-file context may have other types. Unknown types
// do not silently establish eligibility. Security discovery remains unrestricted.
func qualityApplies(reason string, citations []review.Citation, excerpts []review.Excerpt) bool {
	if reason == "quality_language_policy" {
		return true
	}

	cited := map[string]bool{}
	for _, c := range citations {
		cited[c.ExcerptID] = true
	}

	for _, ex := range excerpts {
		if !cited[ex.ID] {
			continue
		}

		k := ex.ContentKind
		if k == "" {
			k = contentKind(ex.Path, ex.Text)
		}

		if reason == "quality_vague_triggers" && (k == formatMarkdown || k == formatText || k == "configuration") {
			return true
		}

		if reason == "quality_missing_warnings" && (k == valueCode || k == formatMarkdown) {
			return true
		}
	}

	return false
}
