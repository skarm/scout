package semantic

import (
	"encoding/json"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/knowledge"
	"github.com/skarm/scout/review"
)

// planVerification constructs a NEW, evidence-bound phase after discovery.
// The initial plan is never rewritten. All verification tasks are fixed before
// the first verification call. Budgets are shared with the first phase; they
// are NOT reset for each proposal or phase. A missing task becomes a named gap.
func (p *planner) planVerification(proposals []model.SemanticProposal, initialPlan string) ([]work, string) {
	start, gapStart, omittedStart := len(p.works), len(p.gaps), p.omittedGaps

	parents := make(map[string]work, start)
	for _, w := range p.works {
		parents[w.metadata.ID] = w
	}

	for _, proposal := range proposals {
		if p.ctx.Err() != nil {
			p.proposalGap("proposal_assessment_cancelled", proposal.ID)
			continue
		}

		parent, ok := parents[proposal.TaskID]
		if !ok || (parent.request.Mode != valueDiscovery && parent.request.Mode != "intent" && parent.request.Mode != valueQuality && parent.request.Mode != valueToolConsistency) {
			p.proposalGap("proposal_parent_missing", proposal.ID)
			continue
		}
		// Reuse the complete ORIGINAL bounded context, not a summary or model
		// explanation. Only the fixed reason/severity is supplied as a hypothesis.
		req := p.request(valueProposalAssessment)
		req.ScopeID, req.ParentTaskID = parent.request.ScopeID, parent.metadata.ID
		req.Excerpts = append(req.Excerpts, parent.request.Excerpts...)
		req.Links = append(req.Links, parent.request.Links...)

		evidence := make([]review.Citation, 0, len(proposal.Evidence))
		for _, ref := range proposal.Evidence {
			for _, ex := range req.Excerpts {
				if sourceRef(ex) == ref {
					evidence = append(evidence, review.Citation{ExcerptID: ex.ID, SHA256: ex.SHA256})
					break
				}
			}
		}

		if len(evidence) == 0 || len(evidence) != len(proposal.Evidence) || len(evidence) > review.MaxEvidence {
			p.proposalGap("proposal_evidence_missing", proposal.ID)
			continue
		}

		req.Findings = []review.Finding{{
			ID: proposal.ID, Origin: "semantic_proposal",
			Reason: proposal.Reason, Category: proposal.Category, Severity: string(proposal.SuggestedSeverity), Evidence: evidence,
		}}
		if guide, ok := knowledge.GuideForReason(proposal.Reason); ok {
			req.Findings[0].Guidance = &guide
		}

		if code := p.add(req); code != "" {
			p.proposalGap("proposal_assessment_"+code, proposal.ID)
		}
	}

	tasks := make([]model.SemanticTask, 0, len(p.works)-start)
	for _, w := range p.works[start:] {
		tasks = append(tasks, w.metadata)
	}

	raw, _ := json.Marshal(struct {
		Phase      string
		ParentPlan string
		Proposals  []model.SemanticProposal
		Tasks      []model.SemanticTask
		Gaps       []model.SemanticGap
		Omitted    int
	}{"proposal-assessment-v1", initialPlan, proposals, tasks, p.gaps[gapStart:], p.omittedGaps - omittedStart})

	return p.works[start:], artifact.Hash(raw)
}

func (p *planner) proposalGap(code, proposalID string) {
	if len(p.gaps) >= 4096 {
		p.omittedGaps++
		return
	}

	p.gaps = append(p.gaps, model.SemanticGap{Code: code, ProposalID: proposalID})
}
