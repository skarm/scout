package semantic

// Shared vocabulary used by this package's protocols and reports.
const (
	kindArray                = "array"
	valueCancelled           = "cancelled"
	valueCode                = "code"
	valueDiscovery           = "discovery"
	statusFailed             = "failed"
	valueInsufficientContext = "insufficient_context"
	valueIntentMismatch      = "intent_mismatch"
	formatMarkdown           = "markdown"
	valuePromptInjection     = "prompt_injection"
	valueProposalAssessment  = "proposal_assessment"
	valueQuality             = "quality"
	valueQualityPolicy       = "quality_policy"
	formatText               = "text"
	valueToolConsistency     = "tool_consistency"
	valueToolPoisoning       = "tool_poisoning"
	valueUnknown             = "unknown"
)
