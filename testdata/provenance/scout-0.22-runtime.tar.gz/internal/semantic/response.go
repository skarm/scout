package semantic

import (
	"context"
	"encoding/json"
	"sort"
	"strings"

	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/knowledge"
	"github.com/skarm/scout/review"
)

//nolint:gochecknoglobals,gosec // Immutable classification labels shared by concurrent requests; G101 does not denote credentials here.
var categories = map[string]string{
	"tool_description_code_mismatch": valueToolPoisoning,
	"semantic_prompt_injection":      valuePromptInjection, "paraphrased_attack": valuePromptInjection, "natural_language_exfiltration": "data_exfiltration", "gradual_deception": valuePromptInjection,
	"description_behavior_mismatch": valueIntentMismatch, "context_inappropriate_capability": valueIntentMismatch, "declared_scope_creep": "permissions", "intent_code_divergence": valueIntentMismatch,
	"instruction_override": valuePromptInjection, "secret_transfer": "data_exfiltration",
	"unapproved_execution": "execution", "persistent_agent_change": "persistence",
	"reviewer_manipulation": valuePromptInjection, "untrusted_dependency": "supply_chain",
	"permission_expansion": "permissions", valueToolPoisoning: valueToolPoisoning,
	"purpose_capability_mismatch": valueIntentMismatch,
	"quality_vague_triggers":      valueQualityPolicy, "quality_missing_warnings": valueQualityPolicy, "quality_language_policy": valueQualityPolicy,
}

// ValidateResponse checks the exact protocol and evidence of ONE immutable task.
// Parsing success/JSON Schema alone is insufficient. No permissive repair or
// partial acceptance: malformed tasks are failed, prior task results retained.
func ValidateResponse(ctx context.Context, request review.Request, raw []byte, maxBytes int) (review.Response, string) {
	bad := func(code string) (review.Response, string) { return review.Response{}, code }
	if maxBytes < 1 || len(raw) > maxBytes {
		return bad("response_limit")
	}

	root, err := jsonconfig.Parse(ctx, string(raw))
	if err != nil {
		return bad("invalid_response_json")
	}

	if !object(root, "schema_version", "request_id", "proposals", "assessments") || !text(root.Get("schema_version")) || !text(root.Get("request_id")) {
		return bad("response_schema")
	}

	if root.Get("proposals").Kind != kindArray || root.Get("assessments").Kind != kindArray {
		return bad("response_schema")
	}

	if len(root.Get("proposals").Elements) > review.MaxItems || len(root.Get("assessments").Elements) > review.MaxItems {
		return bad("response_item_limit")
	}

	if !responseItemsShape(root) {
		return bad("response_schema")
	}

	var out review.Response
	if err := json.Unmarshal(raw, &out); err != nil {
		return bad("response_schema")
	}

	if out.SchemaVersion != review.ProtocolVersion || out.RequestID != request.RequestID {
		return bad("response_identity_mismatch")
	}

	if code := validateResponseEvidence(request, out); code != "" {
		return bad(code)
	}

	return out, ""
}

func responseItemsShape(root *jsonconfig.Node) bool {
	for _, n := range root.Get("proposals").Elements {
		if !object(n, "reason", "severity", "evidence") || !text(n.Get("reason")) || !text(n.Get("severity")) || !citationsShape(n.Get("evidence")) {
			return false
		}
	}

	for _, n := range root.Get("assessments").Elements {
		if !object(n, "finding_id", "verdict", "reason", "evidence") || !text(n.Get("finding_id")) || !text(n.Get("verdict")) || !text(n.Get("reason")) || !citationsShape(n.Get("evidence")) {
			return false
		}
	}

	return true
}

func validateResponseEvidence(request review.Request, out review.Response) string {
	excerpts := make(map[string]string, len(request.Excerpts))
	for _, s := range request.Excerpts {
		if _, ok := excerpts[s.ID]; ok {
			return "invalid_request_evidence"
		}

		excerpts[s.ID] = s.SHA256
	}

	check := func(cs []review.Citation) bool {
		seen := map[string]bool{}

		for _, c := range cs {
			hash, ok := excerpts[c.ExcerptID]
			if !ok || c.SHA256 != hash || seen[c.ExcerptID] {
				return false
			}

			seen[c.ExcerptID] = true
		}

		return true
	}
	if code := validateProposals(request, out.Proposals, check); code != "" {
		return code
	}

	return validateAssessments(request, out, check)
}

func validateProposals(request review.Request, proposals []review.Proposal, check func([]review.Citation) bool) string {
	seenProposals := map[string]bool{}

	for _, p := range proposals {
		if _, ok := proposalCategory(p.Reason); !ok {
			return "invalid_reason"
		}

		if (request.Mode == valueQuality) != strings.HasPrefix(p.Reason, "quality_") {
			return "wrong_quality_scope"
		}

		if mode := knowledge.ReasonMode(p.Reason); mode != "" && request.Mode != mode {
			return "wrong_specialized_scope"
		}

		if request.Mode == valueToolConsistency {
			if p.Reason != "tool_description_code_mismatch" || !toolConsistencyEvidence(p.Evidence, request.Excerpts) {
				return "tool_consistency_evidence_or_scope"
			}
		}

		switch p.Severity {
		case "low", "medium", "high", "critical":
		default:
			return "invalid_severity"
		}

		if !check(p.Evidence) {
			return "evidence_outside_request"
		}

		if request.Mode == valueQuality && !qualityApplies(p.Reason, p.Evidence, request.Excerpts) {
			return "quality_applicability_unverified"
		}

		ids := make([]string, 0, len(p.Evidence))
		for _, c := range p.Evidence {
			ids = append(ids, c.ExcerptID)
		}

		sort.Strings(ids)

		key := p.Reason + "\x00" + strings.Join(ids, "\x00")
		if seenProposals[key] {
			return "duplicate_proposal"
		}

		seenProposals[key] = true
	}

	return ""
}

func validateAssessments(request review.Request, out review.Response, check func([]review.Citation) bool) string {
	expected := map[string]review.Finding{}
	for _, f := range request.Findings {
		expected[f.ID] = f
	}

	seen := map[string]bool{}

	for _, a := range out.Assessments {
		f, ok := expected[a.FindingID]
		if !ok || seen[a.FindingID] {
			return "unknown_or_duplicate_finding"
		}

		seen[a.FindingID] = true
		if !check(a.Evidence) {
			return "evidence_outside_request"
		}

		cited := map[string]bool{}
		for _, c := range a.Evidence {
			cited[c.ExcerptID] = true
		}

		for _, c := range f.Evidence {
			if !cited[c.ExcerptID] {
				return "target_evidence_missing"
			}
		}

		if code := validateVerdict(a); code != "" {
			return code
		}
	}

	return validateResponseMode(request, out, len(seen), len(expected))
}

const invalidAssessmentReason = "invalid_assessment_reason"

func validateVerdict(a review.Assessment) string {
	switch a.Verdict {
	case "confirmed":
		if a.Reason != "supported_by_context" {
			return invalidAssessmentReason
		}
	case "disputed":
		if a.Reason != "benign_example" && a.Reason != "legitimate_use" {
			return invalidAssessmentReason
		}
	case valueInsufficientContext:
		if a.Reason != valueInsufficientContext {
			return invalidAssessmentReason
		}
	default:
		return "invalid_assessment_verdict"
	}

	return ""
}

func validateResponseMode(request review.Request, out review.Response, seen, expected int) string {
	switch request.Mode {
	case "assessment", valueProposalAssessment:
		if len(out.Proposals) > 0 || len(request.Findings) == 0 || seen != expected {
			return "missing_assessment_or_wrong_mode"
		}
	case valueDiscovery, "intent", valueQuality, valueToolConsistency:
		if len(out.Assessments) > 0 || len(request.Findings) > 0 {
			return "wrong_response_mode"
		}
	default:
		return "invalid_request_mode"
	}

	return ""
}

func proposalCategory(reason string) (string, bool) {
	if category, ok := categories[reason]; ok {
		return category, true
	}

	if topic, ok := knowledge.TopicForReason(reason); ok {
		return topic.Category, true
	}

	return "", false
}

func object(n *jsonconfig.Node, keys ...string) bool {
	if n == nil || n.Kind != "object" || len(n.Members) != len(keys) {
		return false
	}

	for _, k := range keys {
		if n.Get(k) == nil {
			return false
		}
	}

	return true
}
func text(n *jsonconfig.Node) bool { return n != nil && n.Kind == "string" }
func citationsShape(n *jsonconfig.Node) bool {
	if n == nil || n.Kind != kindArray || len(n.Elements) < 1 || len(n.Elements) > review.MaxEvidence {
		return false
	}

	for _, c := range n.Elements {
		if !object(c, "excerpt_id", "sha256") || !text(c.Get("excerpt_id")) || !text(c.Get("sha256")) {
			return false
		}
	}

	return true
}
