// Package semantic builds bounded evidence scopes before any model invocation.
// Discovery receives no static findings. Assessment is a separate task kind;
// model responses cannot change the input plan, evidence, or deterministic results.
package semantic

import (
	"context"
	"encoding/json"
	"sort"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/knowledge"
	"github.com/skarm/scout/review"
)

const excerptBytes = 768

type work struct {
	request  review.Request
	raw      []byte
	metadata model.SemanticTask
}
type planner struct {
	ctx         context.Context
	options     review.Options
	graph       model.ComponentGraph
	snapshot    string
	files       map[string]artifact.File
	components  map[string][]string
	works       []work
	gaps        []model.SemanticGap
	bytes       int
	omittedGaps int
	extraction  model.ExtractionReport
}

func (p *planner) request(mode string) review.Request {
	d, _ := knowledge.Describe(mode)
	return review.Request{PromptSHA256: d.SHA256, SchemaVersion: review.ProtocolVersion, PromptVersion: review.PromptVersion, Mode: mode, SnapshotSHA256: p.snapshot, Harness: p.graph.RequestedHost, Excerpts: []review.Excerpt{}, Findings: []review.Finding{}, Links: []review.Link{}}
}

func (p *planner) gap(code, path string, start, end int, finding, plugin string) {
	if len(p.gaps) >= 4096 {
		p.omittedGaps++
		return
	}

	p.gaps = append(p.gaps, model.SemanticGap{Code: code, Path: path, ByteStart: start, ByteEnd: end, FindingID: finding, PluginID: plugin})
}

func (p *planner) excerpt(f artifact.File, start, end int) review.Excerpt {
	m := f.Metadata()
	text := f.Content()[start:end]
	hash := artifact.Hash([]byte(text))
	raw, _ := json.Marshal([]string{"semantic-excerpt-v1", m.Path, m.SHA256, strconv.Itoa(start), strconv.Itoa(end), hash})
	// Component IDs may be large for hostile manifests: never silently truncate a
	// scope. Omitting an overly large request later becomes a request_limit gap.
	return review.Excerpt{ContentKind: contentKind(m.Path, f.Content()), ID: artifact.Hash(raw), Path: m.Path, ObjectSHA256: m.SHA256, ByteStart: start, ByteEnd: end, SHA256: hash, Text: text, Components: append([]string{}, p.components[m.Path]...)}
}

func (p *planner) excerpts(f artifact.File, start, end int) []review.Excerpt {
	var out []review.Excerpt

	for start < end {
		next := boundary(f.Content(), start, min(end, start+excerptBytes))
		out = append(out, p.excerpt(f, start, next))
		start = next
	}

	return out
}

func (p *planner) links(excerpts []review.Excerpt) []review.Link {
	out := []review.Link{}
	present := map[string]bool{}

	for _, s := range excerpts {
		for _, id := range s.Components {
			present[id] = true
		}
	}

	for _, edge := range p.graph.Edges {
		if !present[edge.From] || !present[edge.To] || edge.Source == nil {
			continue
		}

		citations := []review.Citation{}

		for _, s := range excerpts {
			if s.Path == edge.Source.Path && s.ObjectSHA256 == edge.Source.SHA256 && s.ByteStart <= edge.Source.ByteStart && s.ByteEnd >= edge.Source.ByteEnd {
				citations = append(citations, review.Citation{ExcerptID: s.ID, SHA256: s.SHA256})
				break
			}
		}

		if len(citations) > 0 {
			out = append(out, review.Link{ID: edge.ID, From: edge.From, To: edge.To, Relation: edge.Relation, Activation: edge.Activation, Evidence: citations})
		}
	}

	return out
}

func (p *planner) add(req review.Request) string {
	if len(p.works) >= p.options.MaxRequests {
		return "request_budget"
	}

	if len(req.Excerpts) > review.MaxSegments {
		return "context_segment_limit"
	}
	// Identical scopes are distinct when mode/finding differs. Repeated source
	// text from different objects retains its original path-based evidence ID.
	req.Components = []review.Component{}
	selected := map[string]bool{}

	for _, ex := range req.Excerpts {
		for _, id := range ex.Components {
			selected[id] = true
		}
	}

	for _, c := range p.graph.Components {
		if selected[c.ID] {
			req.Components = append(req.Components, review.Component{ID: c.ID, Kind: c.Kind, Host: c.Host, Activation: c.Activation})
		}
	}

	seed, _ := json.Marshal(req)
	req.RequestID = artifact.Hash(seed)

	raw, _ := json.Marshal(req)
	if len(raw) > p.options.MaxRequestBytes {
		return "request_byte_limit"
	}

	if p.bytes+len(raw) > p.options.MaxInputBytes {
		return "aggregate_request_budget"
	}

	pd, _ := knowledge.Describe(req.Mode)

	meta := model.SemanticTask{KnowledgeTopicIDs: knowledge.ReviewTopicIDs(req.Mode), PromptSHA256: pd.SHA256, PromptBytes: pd.Bytes, ScopeID: req.ScopeID, ID: req.RequestID, Mode: req.Mode, RequestSHA256: artifact.Hash(raw), RequestBytes: len(raw), Inputs: []model.SemanticInput{}, FindingIDs: []string{}, LinkIDs: []string{}}
	for _, s := range req.Excerpts {
		meta.Inputs = append(meta.Inputs, model.SemanticInput{ID: s.ID, Source: sourceRef(s)})
	}

	for _, f := range req.Findings {
		if req.Mode == valueProposalAssessment {
			meta.ProposalIDs = append(meta.ProposalIDs, f.ID)
		} else {
			meta.FindingIDs = append(meta.FindingIDs, f.ID)
		}
	}

	for _, l := range req.Links {
		meta.LinkIDs = append(meta.LinkIDs, l.ID)
	}

	if req.ParentTaskID != "" {
		meta.DependsOn = []string{req.ParentTaskID}
	}

	p.bytes += len(raw)
	p.works = append(p.works, work{request: req, raw: raw, metadata: meta})

	return ""
}

func build(ctx context.Context, files []artifact.File, g model.ComponentGraph, findings []model.Finding, snapshot string, o review.Options, extraction model.ExtractionReport) *planner {
	p := &planner{ctx: ctx, options: o, graph: g, snapshot: snapshot, files: map[string]artifact.File{}, components: map[string][]string{}, works: []work{}, gaps: []model.SemanticGap{}}
	p.extraction = extraction

	fs := append([]artifact.File(nil), files...)
	for _, f := range fs {
		p.files[f.Metadata().Path] = f
	}

	for _, c := range g.Components {
		if c.Path != "" {
			p.components[c.Path] = append(p.components[c.Path], c.ID)
		}
	}

	for path, ids := range p.components {
		sort.Strings(ids)

		if len(ids) > 32 {
			p.gap("component_context_limit", path, 0, 0, "", "")

			ids = ids[:32]
		}

		p.components[path] = ids
	}
	// Stable priority: declared components first, then every other text object.
	// Neither file names nor inactivity suppress whole-artifact discovery.
	sort.Slice(fs, func(i, j int) bool {
		a, b := fs[i].Metadata().Path, fs[j].Metadata().Path

		ac, bc := len(p.components[a]) > 0, len(p.components[b]) > 0
		if ac != bc {
			return ac
		}

		return a < b
	})

	for _, f := range fs {
		p.planDiscovery(f)
	}

	if o.QualityPolicy {
		p.planQuality()
	}

	p.planPluginIntents()
	p.planSkillIntents()
	p.planToolConsistency()

	for _, finding := range findings {
		p.planAssessment(finding)
	}

	p.sortGaps()

	return p
}

func (p *planner) planDiscovery(f artifact.File) {
	o := p.options
	m := f.Metadata()

	text := f.Content()
	if m.Kind != formatText || !utf8.ValidString(text) {
		p.gap("non_text_semantics_unsupported", m.Path, 0, len(text), "", "")
		return
	}

	for start := 0; start < len(text); {
		if p.ctx.Err() != nil {
			p.gap("planning_cancelled", m.Path, start, len(text), "", "")
			break
		}

		if len(p.works) >= o.MaxRequests || p.bytes >= o.MaxInputBytes {
			p.gap("request_budget", m.Path, start, len(text), "", "")
			break
		}

		end := boundary(text, start, min(len(text), start+o.ChunkBytes))
		req := p.request(valueDiscovery)

		req.Excerpts = p.excerpts(f, start, end)
		if code := p.add(req); code != "" {
			p.gap(code, m.Path, start, len(text), "", "")
			break
		}

		if end == len(text) {
			start = end
		} else {
			// Small overlap reduces simple seam misses, without claiming general
			// cross-chunk reasoning. Every byte remains covered by a discovery scope.
			start = end - min(512, o.ChunkBytes/8)
			for start > 0 && !boundaryAt(text, start) {
				start--
			}
		}
	}
}

// Quality review is a distinct opt-in mode, never silently conflated with
// the security discovery task. It shares the same request/input budgets.

func (p *planner) planQuality() {
	initial := append([]work(nil), p.works...)
	for _, w := range initial {
		if w.request.Mode != valueDiscovery {
			continue
		}

		req := p.request(valueQuality)
		req.Excerpts = append([]review.Excerpt(nil), w.request.Excerpts...)

		req.ScopeID = w.request.ScopeID
		if code := p.add(req); code != "" {
			for _, ex := range req.Excerpts {
				p.gap(code, ex.Path, ex.ByteStart, ex.ByteEnd, "", "")
			}
		}
	}
	// Plugin intent review has a separate bounded scope. If all contributing
	// component bytes do not fit, report a gap instead of pretending the whole
	// plugin was compared. The per-object discovery tasks above are retained.
}

func (p *planner) planPluginIntents() {
	for _, plugin := range p.graph.Plugins {
		p.planPluginIntent(plugin)
	}
}

func (p *planner) planPluginIntent(plugin model.PluginInterpretation) {
	o := p.options
	if p.ctx.Err() != nil {
		p.gap("planning_cancelled", "", 0, 0, "", plugin.ID)
		return
	}

	paths := map[string]bool{}

	for _, c := range p.graph.Components {
		if c.PluginID == plugin.ID && c.Path != "" {
			paths[c.Path] = true
		}
	}

	for _, m := range plugin.Manifests {
		paths[m] = true
	}

	names := make([]string, 0, len(paths))
	for name := range paths {
		names = append(names, name)
	}

	sort.Strings(names)

	req := p.request("intent")
	req.ScopeID = plugin.ID
	total := 0
	limited := false

	for _, name := range names {
		f, ok := p.files[name]
		if !ok || f.Metadata().Kind != formatText {
			limited = true
			continue
		}

		if total+len(f.Content()) > o.ChunkBytes || len(req.Excerpts)+(len(f.Content())+excerptBytes-1)/excerptBytes > review.MaxSegments {
			limited = true
			continue
		}

		req.Excerpts = append(req.Excerpts, p.excerpts(f, 0, len(f.Content()))...)
		total += len(f.Content())
	}

	if limited {
		p.gap("intent_context_incomplete", "", 0, 0, "", plugin.ID)
	}

	req.Links = p.links(req.Excerpts)
	if len(req.Excerpts) == 0 {
		p.gap("intent_no_readable_context", "", 0, 0, "", plugin.ID)
		return
	}

	if code := p.add(req); code != "" {
		p.gap(code, "", 0, 0, "", plugin.ID)
	}
	// A standalone skill gets an intent task over its own document. We do not
	// invent ownership of unrelated siblings or cross-archive relationships.
}

func (p *planner) planSkillIntents() {
	o := p.options
	owned := map[string]bool{}

	for _, c := range p.graph.Components {
		if c.PluginID != "" {
			owned[c.Path] = true
		}
	}

	for _, c := range p.graph.Components {
		if c.Kind != "skill" || c.PluginID != "" || owned[c.Path] {
			continue
		}

		f, ok := p.files[c.Path]
		if !ok || f.Metadata().Kind != formatText || len(f.Content()) > o.ChunkBytes {
			p.gap("skill_intent_context_incomplete", c.Path, 0, 0, "", "")
			continue
		}

		if len(f.Content()) == 0 {
			continue
		}

		req := p.request("intent")
		req.ScopeID = c.ID

		req.Excerpts = p.excerpts(f, 0, len(f.Content()))
		if code := p.add(req); code != "" {
			p.gap(code, c.Path, 0, len(f.Content()), "", "")
		}
	}
}

// Each finding has its own planned assessment, including all main/trace
// evidence. Findings themselves are never passed to discovery or intent.

func (p *planner) planAssessment(finding model.Finding) {
	o := p.options
	if p.ctx.Err() != nil {
		p.gap("planning_cancelled", finding.Location.Path, 0, 0, finding.ID, "")
		return
	}

	req := p.request("assessment")

	refs := make([]model.Location, 1, 1+len(finding.RelatedEvidence)+len(finding.Trace))

	refs[0] = finding.Location
	for _, related := range finding.RelatedEvidence {
		refs = append(refs, model.Location{Path: related.Path, ByteStart: related.ByteStart, ByteEnd: related.ByteEnd})
	}

	for _, trace := range finding.Trace {
		refs = append(refs, trace.Location)
	}

	evidence := []review.Citation{}
	seen := map[string]bool{}
	bytes := 0
	valid := true

	for _, loc := range refs {
		f, ok := p.files[loc.Path]
		if !ok || f.Metadata().Kind != formatText || loc.ByteStart < 0 || loc.ByteEnd <= loc.ByteStart || loc.ByteEnd > len(f.Content()) || !boundaryAt(f.Content(), loc.ByteStart) || !boundaryAt(f.Content(), loc.ByteEnd) {
			valid = false
			break
		}
		// Main evidence is exact; contextual windows cannot replace or obscure it.
		ex := p.excerpt(f, loc.ByteStart, loc.ByteEnd)
		if len(ex.Text) > o.ChunkBytes {
			valid = false
			break
		}

		if !seen[ex.ID] {
			req.Excerpts = append(req.Excerpts, ex)
			evidence = append(evidence, review.Citation{ExcerptID: ex.ID, SHA256: ex.SHA256})
			seen[ex.ID] = true
			bytes += len(ex.Text)
		}
	}

	if !valid || len(evidence) > review.MaxEvidence || bytes > o.ChunkBytes {
		p.gap("assessment_evidence_unsupported", finding.Location.Path, 0, 0, finding.ID, "")
		return
	}
	// Add a bounded window around the primary span; over-budget extra context is
	// explicitly reported. This review is not claimed to cover arbitrary callers.
	p.assessmentContext(&req, finding, seen, bytes)

	req.Findings = []review.Finding{{ID: finding.ID, Origin: "static", RuleID: finding.RuleID, Category: finding.Category, Method: finding.Method, Description: finding.Message, Severity: string(finding.Severity), Evidence: evidence}}
	if g, ok := knowledge.Lookup(finding.RuleID); ok {
		req.Findings[0].Guidance = &g
	}

	req.Findings[0].ContextSignals = append([]string(nil), finding.ContextSignals...)

	req.Links = p.links(req.Excerpts)
	if code := p.add(req); code != "" {
		p.gap(code, finding.Location.Path, 0, 0, finding.ID, "")
	}
}

func (p *planner) assessmentContext(req *review.Request, finding model.Finding, seen map[string]bool, bytes int) {
	o := p.options
	if f, ok := p.files[finding.Location.Path]; ok {
		start := max(0, finding.Location.ByteStart-384)
		for start > 0 && !boundaryAt(f.Content(), start) {
			start--
		}

		end := min(len(f.Content()), finding.Location.ByteEnd+384)
		for end < len(f.Content()) && !boundaryAt(f.Content(), end) {
			end++
		}

		for _, ex := range p.excerpts(f, start, end) {
			if !seen[ex.ID] && bytes+len(ex.Text) <= o.ChunkBytes && len(req.Excerpts) < review.MaxSegments {
				req.Excerpts = append(req.Excerpts, ex)
				seen[ex.ID] = true
				bytes += len(ex.Text)
			}
		}
	}
}

func (p *planner) sortGaps() {
	sort.Slice(p.gaps, func(i, j int) bool {
		a, b := p.gaps[i], p.gaps[j]
		if a.Code != b.Code {
			return a.Code < b.Code
		}

		if a.Path != b.Path {
			return a.Path < b.Path
		}

		if a.PluginID != b.PluginID {
			return a.PluginID < b.PluginID
		}

		if a.FindingID != b.FindingID {
			return a.FindingID < b.FindingID
		}

		if a.ByteStart != b.ByteStart {
			return a.ByteStart < b.ByteStart
		}

		return a.ByteEnd < b.ByteEnd
	})
}

func boundaryAt(text string, offset int) bool {
	return offset == len(text) || offset >= 0 && offset < len(text) && utf8.RuneStart(text[offset])
}

// Prefer complete lines where possible; never split a UTF-8 code point. Very
// long lines are segmented, not truncated. End is always strictly after start.
func boundary(text string, start, end int) int {
	for end < len(text) && end > start && !utf8.RuneStart(text[end]) {
		end--
	}

	if end <= start {
		_, n := utf8.DecodeRuneInString(text[start:])
		return start + n
	}

	if end < len(text) {
		if at := strings.LastIndexByte(text[start:end], '\n'); at >= ((end - start) / 2) {
			return start + at + 1
		}
	}

	return end
}

func sourceRef(s review.Excerpt) model.SourceRef {
	return model.SourceRef{Path: s.Path, SHA256: s.ObjectSHA256, ByteStart: s.ByteStart, ByteEnd: s.ByteEnd, SpanSHA256: s.SHA256}
}
