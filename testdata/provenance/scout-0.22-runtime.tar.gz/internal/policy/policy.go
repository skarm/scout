// Package policy evaluates evidence without editing or suppressing it.
package policy

import "github.com/skarm/scout/internal/model"

func Evaluate(p model.Policy, completeness model.Completeness, findings []model.Finding) model.PolicyResult {
	result := model.PolicyResult{ID: p.ID, BlockAt: p.BlockAt, Decision: model.Allow, Reasons: []string{}}

	for _, f := range findings {
		// Unknown severity is not safe; the engine normally rejects it earlier.
		if f.Severity.Rank() < 0 {
			result.Decision = model.Review
			result.Reasons = append(result.Reasons, "Invalid finding severity requires review.")

			continue
		}

		if f.Severity.Rank() >= p.BlockAt.Rank() {
			result.Decision = model.Block
			result.Reasons = append(result.Reasons, "A finding meets the configured blocking threshold.")

			break
		}
	}

	if completeness != model.Complete {
		if result.Decision != model.Block {
			result.Decision = model.Review
		}

		result.Reasons = append(result.Reasons, "Inspection is not complete; automatic admission is disabled.")
	}

	if len(findings) > 0 && result.Decision == model.Allow {
		result.Decision = model.Review
		result.Reasons = append(result.Reasons, "Findings below the blocking threshold still require review.")
	}

	if result.Decision == model.Allow {
		result.Reasons = append(result.Reasons, "No findings in the completed selected profile; this is not proof of safety.")
	}

	return result
}

// ExitCode is shared by all CLI report formats. Incompleteness takes precedence
// for automation even when a blocking finding has already been preserved.
func ExitCode(r model.Report) int {
	if r.Coverage.Completeness != model.Complete {
		return 2
	}

	if r.Policy.Decision != model.Allow {
		return 1
	}

	return 0
}

// EvaluateWithSemantic never lets a model delete/downgrade static evidence or
// grant an exception. New model proposals require human review even when their
// evidence references are structurally valid; severity is model-suggested only.
func EvaluateWithSemantic(p model.Policy, completeness model.Completeness, findings []model.Finding, semantic model.SemanticReport) model.PolicyResult {
	if semantic.Enabled && semantic.Completeness != model.Complete && completeness == model.Complete {
		completeness = model.Partial
	}

	result := Evaluate(p, completeness, findings)
	if semantic.Enabled && len(semantic.Proposals) > 0 {
		if result.Decision == model.Allow {
			result.Decision = model.Review
			result.Reasons = nil
		}

		result.Reasons = append(result.Reasons, "Evidence-linked model proposals require human review; they are not verified static findings.")
	}

	return result
}
