package policy

import "github.com/skarm/scout/internal/model"

// Score implements the documented upstream-style diminishing-repeat weights,
// using confidence=1 because our static engine does not claim calibrated confidence.
// It is separate from Evaluate; low scores must not hide incomplete inspection.
func Score(active []model.Finding, suppressed int, executable bool) model.Risk {
	score := 0.0
	counts := map[string]int{}

	for _, f := range active {
		w := 0.0

		switch f.Severity {
		case model.Critical:
			w = 50
		case model.High:
			w = 25
		case model.Medium:
			w = 10
		case model.Low:
			w = 5
		case model.Info:
			w = 0
		}

		n := counts[f.RuleID]
		counts[f.RuleID]++

		switch n {
		case 0:
		case 1:
			w *= 0.5
		case 2:
			w *= 0.25
		default:
			w = 0
		}

		score += w
	}

	if executable {
		score *= 1.3
	}

	if score > 100 {
		score = 100
	}

	level := "low"

	switch {
	case score >= 81:
		level = "critical"
	case score >= 51:
		level = "high"
	case score >= 21:
		level = "medium"
	}

	return model.Risk{Algorithm: "upstream-style-weights-v1-not-probability", Score: int(score), Level: level, ActiveFindings: len(active), SuppressedFindings: suppressed, ConfidenceAssumption: "uncalibrated static weights; no confidence-derived probability"}
}
