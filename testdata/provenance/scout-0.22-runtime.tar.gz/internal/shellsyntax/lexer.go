package shellsyntax

import (
	"strings"
	"unicode/utf8"

	"github.com/skarm/scout/internal/source"
)

func (p *parser) lex() (token, error) {
	if err := p.tick(); err != nil {
		return token{}, err
	}

	for p.at < p.end {
		if p.text[p.at] == ' ' || p.text[p.at] == '\t' {
			p.at++
			continue
		}

		if strings.HasPrefix(p.text[p.at:p.end], "\\\r\n") {
			p.at += 3
			continue
		}

		if strings.HasPrefix(p.text[p.at:p.end], "\\\n") {
			p.at += 2
			continue
		}

		if p.text[p.at] == '#' {
			for p.at < p.end && p.text[p.at] != '\n' {
				p.at++
			}

			continue
		}

		break
	}

	start := p.at
	if start == p.end {
		return token{kind: valueEOF, span: source.Span{Start: start, End: start}}, nil
	}

	if p.text[p.at] == '\n' {
		p.at++
		return token{kind: valueNewline, span: source.Span{Start: start, End: p.at}}, nil
	}

	for _, op := range []string{";;&", ";&", ";;", "((", "<(", ">("} {
		if strings.HasPrefix(p.text[p.at:p.end], op) {
			return token{}, p.fail("unsupported_operator")
		}
	}

	for _, op := range []string{"&>>", valueLiteral, "<<<", "&&", "||", "|&", ">>", "<<", "<&", ">&", "<>", ">|", "&>", ";", "&", "|", "(", ")", "<", ">"} {
		if strings.HasPrefix(p.text[p.at:p.end], op) {
			p.at += len(op)
			return token{kind: op, span: source.Span{Start: start, End: p.at}}, nil
		}
	}

	w := &Word{Span: source.Span{Start: start}}
	if err := p.parts(w, 0); err != nil {
		return token{}, err
	}

	w.Span.End = p.at
	if p.at == start {
		return token{}, p.fail("unexpected_token")
	}

	return token{kind: valueWord, word: w, span: w.Span}, nil
}

// mode: 0=ordinary word, '"'=double quoted word, 'h'=heredoc body.
func (p *parser) parts(w *Word, mode byte) error {
	for p.at < p.end {
		if err := p.budget.ctx.Err(); err != nil {
			return err
		}

		c := p.text[p.at]
		if mode == 0 && strings.ContainsRune(" \t\n;|&()<>", rune(c)) {
			return nil
		}

		if mode == '"' && c == '"' {
			p.at++
			return nil
		}

		start := p.at

		switch {
		case c == '\'' && mode == 0:
			if err := p.singleQuotedPart(w, start); err != nil {
				return err
			}
		case c == '"' && mode == 0:
			if err := p.doubleQuotedPart(w, start); err != nil {
				return err
			}
		case c == '\\':
			if err := p.escapedPart(w, mode, start); err != nil {
				return err
			}
		case c == '`':
			return p.fail("unsupported_backtick_substitution")
		case c == '$':
			if err := p.expansion(w, mode == '"'); err != nil {
				return err
			}
		default:
			if err := p.literalPart(w, mode, start); err != nil {
				return err
			}
		}
	}

	if mode == '"' {
		return p.fail("unclosed_double_quote")
	}

	return nil
}

func (p *parser) doubleQuotedPart(w *Word, start int) error {
	w.Quoted = true
	p.at++
	// Preserve the presence of an empty quote in word concatenation.
	if err := p.literal(w, start, p.at, "", true); err != nil {
		return err
	}

	return p.parts(w, '"')
}

func (p *parser) singleQuotedPart(w *Word, start int) error {
	w.Quoted = true
	p.at++
	inner := p.at

	n := strings.IndexByte(p.text[p.at:p.end], '\'')
	if n < 0 {
		return p.fail("unclosed_single_quote")
	}

	p.at += n + 1

	return p.literal(w, start, p.at, p.text[inner:p.at-1], true)
}

func (p *parser) escapedPart(w *Word, mode byte, start int) error {
	p.at++
	if p.at == p.end {
		return p.fail("trailing_escape")
	}

	next := p.text[p.at]
	if next == '\r' && p.at+1 < p.end && p.text[p.at+1] == '\n' {
		p.at += 2
		return nil
	}

	if next == '\n' {
		p.at++
		return nil
	}

	if mode != 0 && !strings.ContainsRune("$`\\", rune(next)) && !(mode == '"' && next == '"') {
		return p.literal(w, start, p.at, "\\", mode == '"')
	}

	w.Quoted = true
	_, n := utf8.DecodeRuneInString(p.text[p.at:p.end])
	p.at += n

	return p.literal(w, start, p.at, p.text[start+1:p.at], true)
}

func (p *parser) literalPart(w *Word, mode byte, start int) error {
	for p.at < p.end {
		c := p.text[p.at]
		if c == '$' || c == '`' || c == '\\' || mode == '"' && c == '"' || mode == 0 && (c == '\'' || c == '"' || strings.ContainsRune(" \t\n;|&()<>", rune(c))) {
			break
		}

		if mode == 0 && strings.ContainsRune("*?[{}~", rune(c)) {
			w.Expands = true
		}

		p.at++
	}

	return p.literal(w, start, p.at, p.text[start:p.at], mode == '"')
}

func (p *parser) literal(w *Word, start, end int, text string, quoted bool) error {
	if err := p.tick(); err != nil {
		return err
	}

	w.Parts = append(w.Parts, Part{Kind: valueLiteral2, Text: text, Span: source.Span{Start: start, End: end}, Quoted: quoted})

	return nil
}

func (p *parser) expansion(w *Word, quoted bool) error {
	if err := p.tick(); err != nil {
		return err
	}

	start := p.at

	p.at++
	if p.at == p.end {
		return p.literal(w, start, p.at, "$", quoted)
	}

	c := p.text[p.at]
	if c == '\'' || c == '"' {
		return p.fail("unsupported_dollar_quoting")
	}

	if c == '(' {
		return p.commandSubstitution(w, quoted, start)
	}

	return p.parameterExpansion(w, quoted, start, c)
}

func (p *parser) commandSubstitution(w *Word, quoted bool, start int) error {
	p.at++
	if p.at < p.end && p.text[p.at] == '(' {
		return p.fail("unsupported_arithmetic_expansion")
	}

	q, err := p.child(p.at, p.end)
	if err != nil {
		return err
	}

	tree, err := q.list(true)
	if err != nil {
		return err
	}

	closing, err := q.take()
	if err != nil || closing.kind != ")" {
		return p.fail("unclosed_substitution")
	}

	p.at = q.at
	w.Parts = append(w.Parts, Part{Kind: "substitution", Tree: tree, Span: source.Span{Start: start, End: p.at}, Quoted: quoted})

	return nil
}

func (p *parser) parameterExpansion(w *Word, quoted bool, start int, c byte) error {
	begin := p.at
	if c == '{' {
		p.at++

		begin = p.at
		if p.at < p.end && ident(p.text[p.at], true) {
			p.at++
			for p.at < p.end && ident(p.text[p.at], false) {
				p.at++
			}
		}

		if p.at == begin || p.at == p.end || p.text[p.at] != '}' {
			return p.fail("unsupported_parameter_expansion")
		}

		name := p.text[begin:p.at]
		p.at++
		w.Parts = append(w.Parts, Part{Kind: valueParameter, Text: name, Span: source.Span{Start: start, End: p.at}, Quoted: quoted})

		return nil
	}

	if ident(c, true) {
		p.at++
		for p.at < p.end && ident(p.text[p.at], false) {
			p.at++
		}
	} else if strings.ContainsRune("0123456789@*#?$!-", rune(c)) {
		p.at++
	} else {
		return p.literal(w, start, p.at, "$", quoted)
	}

	w.Parts = append(w.Parts, Part{Kind: valueParameter, Text: p.text[begin:p.at], Span: source.Span{Start: start, End: p.at}, Quoted: quoted})

	return nil
}

func (p *parser) hereBodies() error {
	pending := p.pending

	p.pending = nil
	for _, r := range pending {
		delim, _ := r.Target.Literal()
		start := p.at
		found := false

		end := start
		for p.at < p.end {
			if err := p.budget.ctx.Err(); err != nil {
				return err
			}

			line := p.at
			n := strings.IndexByte(p.text[line:p.end], '\n')

			next := p.end
			if n >= 0 {
				end = line + n
				next = end + 1
			} else {
				end = p.end
			}

			content := p.text[line:end]
			if r.Op == valueLiteral {
				content = strings.TrimLeft(content, "\t")
			}

			p.at = next

			if content == delim {
				end = line
				found = true

				break
			}
		}

		if !found {
			return p.fail("missing_heredoc")
		}

		body := &Word{Span: source.Span{Start: start, End: end}}
		if r.QuotedDelimiter {
			body.Quoted = true
			body.Parts = []Part{{Kind: valueLiteral2, Text: p.text[start:end], Span: body.Span, Quoted: true}}
		} else {
			q, err := p.child(start, end)
			if err != nil {
				return err
			}

			if err = q.parts(body, 'h'); err != nil {
				return err
			}
		}

		if r.Op == valueLiteral {
			body.Expands = true
		} // tab-removal is not represented as a constant value

		r.Body = body
	}

	return nil
}
