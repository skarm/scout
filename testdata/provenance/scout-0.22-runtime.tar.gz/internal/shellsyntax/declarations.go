package shellsyntax

// A broader syntax frontend for declaration observation. It does not replace
// the bounded execution-flow grammar or claim POSIX execution semantics.
import (
	"context"
	"errors"
	"io"
	"strings"

	"mvdan.cc/sh/v3/syntax"

	"github.com/skarm/scout/internal/source"
)

type contextReader struct {
	ctx    context.Context
	reader io.Reader
}

type declarationProjection struct {
	ctx   context.Context
	text  string
	nodes int
	err   error
}

func ParseDeclarations(ctx context.Context, text string) (*File, error) {
	if ctx == nil {
		return nil, &Error{Code: "nil_context"}
	}

	if len(text) > MaxBytes {
		return nil, &Error{Code: "byte_limit"}
	}

	input := text

	var (
		tree *syntax.File
		err  error
	)
	for range 16 {
		tree, err = syntax.NewParser(syntax.Variant(syntax.LangBash)).Parse(contextReader{ctx, strings.NewReader(input)}, "")
		if err == nil {
			break
		}

		masked, ok := maskLiteralHeredoc(ctx, input, err)
		if !ok {
			break
		}

		input = masked
	}

	if err != nil {
		return nil, &Error{Code: "unsupported_declaration_syntax"}
	}

	p := declarationProjection{ctx: ctx, text: text}
	out := p.list(tree.Stmts, 0)

	return out, p.err
}

func (r contextReader) Read(p []byte) (int, error) {
	if e := r.ctx.Err(); e != nil {
		return 0, e
	}

	return r.reader.Read(p)
}

func (p *declarationProjection) step(depth int) bool {
	p.nodes++
	if p.err == nil && (depth > MaxDepth || p.nodes > MaxNodes || p.ctx.Err() != nil) {
		p.err = &Error{Code: "declaration_limit"}
	}

	return p.err == nil
}

func (p *declarationProjection) list(stmts []*syntax.Stmt, depth int) *File {
	f := &File{}
	for _, stmt := range stmts {
		f.Statements = append(f.Statements, p.statement(stmt, depth+1)...)
		if p.err != nil {
			break
		}
	}

	return f
}

func (p *declarationProjection) statement(s *syntax.Stmt, depth int) []*Statement {
	if s == nil || !p.step(depth) {
		return nil
	}

	if b, ok := s.Cmd.(*syntax.BinaryCmd); ok {
		x, y := p.statement(b.X, depth+1), p.statement(b.Y, depth+1)
		if b.Op.String() == "|" || b.Op.String() == "|&" {
			if len(x) == 1 && len(y) == 1 {
				x[0].Commands = append(x[0].Commands, y[0].Commands...)
				x[0].Pipes = append(append(x[0].Pipes, b.Op.String()), y[0].Pipes...)
				x[0].Span = declarationSpan(s)

				return x
			}
		} else if len(x) > 0 {
			x[len(x)-1].Next = b.Op.String()
		}

		return append(x, y...)
	}

	c := &Command{Span: declarationSpan(s)}
	p.projectCommand(c, s.Cmd, depth)

	for _, r := range s.Redirs {
		c.Redirects = append(c.Redirects, p.projectRedirect(r, depth))
	}

	next := ""
	if s.Background {
		next = "&"
	}

	return []*Statement{{Span: c.Span, Commands: []*Command{c}, Next: next}}
}

func (p *declarationProjection) projectCommand(c *Command, cmd syntax.Command, depth int) {
	switch n := cmd.(type) {
	case *syntax.CallExpr:
		for _, a := range n.Assigns {
			if a.Name == nil {
				continue
			}

			value := p.word(a.Value, depth+1)
			if a.Append || a.Index != nil || a.Array != nil {
				value = &Word{Span: declarationSpan(a), Expands: true}
			}

			c.Assignments = append(c.Assignments, Assignment{Name: a.Name.Value, Value: value, Span: declarationSpan(a)})
		}

		for _, w := range n.Args {
			c.Words = append(c.Words, p.word(w, depth+1))
		}
	case *syntax.DeclClause:
		p.declarationAssignments(c, n, depth)
	default:
		p.projectCompound(c, cmd, depth)
	}
}

func (p *declarationProjection) declarationAssignments(c *Command, n *syntax.DeclClause, depth int) {
	for _, a := range n.Args {
		if a.Name == nil && a.Value != nil {
			value := p.word(a.Value, depth+1)
			if len(value.Parts) > 0 && value.Parts[0].Kind == valueLiteral2 {
				key, tail, ok := strings.Cut(value.Parts[0].Text, "=")

				valid := ok && key != ""
				for i := range len(key) {
					valid = valid && ident(key[i], i == 0)
				}

				if valid {
					value.Parts[0].Text = tail
					c.Assignments = append(c.Assignments, Assignment{Name: key, Value: value, Span: declarationSpan(a)})
				}
			}

			continue
		}

		if a.Name == nil || a.Naked {
			continue
		}

		c.Assignments = append(c.Assignments, Assignment{Name: a.Name.Value, Value: p.word(a.Value, depth+1), Span: declarationSpan(a)})
	}
}

func (p *declarationProjection) projectCompound(c *Command, cmd syntax.Command, depth int) {
	switch n := cmd.(type) {
	case *syntax.TimeClause:
		c.Group = &File{Statements: p.statement(n.Stmt, depth+1)}
	case *syntax.Block:
		c.Group = p.list(n.Stmts, depth+1)
	case *syntax.Subshell:
		c.Subshell = p.list(n.Stmts, depth+1)
	case *syntax.FuncDecl:
		if n.Name != nil {
			c.FunctionName = n.Name.Value
			c.FunctionBody = &File{Statements: p.statement(n.Body, depth+1)}
		}
	case *syntax.IfClause:
		c.Prelude = p.list(n.Cond, depth+1)

		other := &File{}
		if n.Else != nil {
			other = &File{Statements: p.statement(&syntax.Stmt{Position: n.Else.Pos(), Cmd: n.Else}, depth+1)}
		}

		c.Alternatives = []*File{p.list(n.Then, depth+1), other}
	case *syntax.WhileClause:
		c.Prelude = p.list(n.Cond, depth+1)
		c.Alternatives = []*File{p.list(n.Do, depth+1), {}}
	case *syntax.ForClause:
		if loop, ok := n.Loop.(*syntax.WordIter); ok && loop.Name != nil {
			c.Invalidates = []string{loop.Name.Value}
		}

		c.Alternatives = []*File{p.list(n.Do, depth+1), {}}
	case *syntax.CaseClause:
		c.Alternatives = []*File{{}}
		for _, item := range n.Items {
			c.Alternatives = append(c.Alternatives, p.list(item.Stmts, depth+1))
		}
	default:
		// Unsupported execution effects form an explicit variable barrier.
		c.Invalidates = []string{"*"}
	}
}

func (p *declarationProjection) projectRedirect(r *syntax.Redirect, depth int) *Redirect {
	raw := p.word(r.Word, depth+1)

	red := &Redirect{Span: declarationSpan(r), Op: r.Op.String(), Target: raw}
	if r.N != nil {
		red.FD = r.N.Value
	}

	if r.Hdoc != nil {
		red.Body = p.word(r.Hdoc, depth+1)
		red.QuotedDelimiter = raw != nil && raw.Quoted
		// mvdan's final heredoc literal position can include its closing
		// delimiter. The analyzer needs the physical body only.
		if delim, _, ok := literalDelimiter(p.text[int(r.Word.Pos().Offset()):int(r.Word.End().Offset())]); ok {
			_, quoted, _ := literalDelimiter(p.text[int(r.Word.Pos().Offset()):int(r.Word.End().Offset())])
			red.QuotedDelimiter = quoted

			red.Target = &Word{Span: raw.Span, Quoted: quoted, Parts: []Part{{Kind: valueLiteral2, Text: delim, Span: raw.Span, Quoted: quoted}}}
			for start := red.Body.Span.Start; start < len(p.text); {
				end := len(p.text)
				if n := strings.IndexByte(p.text[start:], '\n'); n >= 0 {
					end = start + n
				}

				line := strings.TrimSuffix(p.text[start:end], "\r")
				if r.Op.String() == valueLiteral {
					line = strings.TrimLeft(line, "\t")
				}

				if line == delim {
					red.Body.Span.End = start
					break
				}

				start = end + 1
			}
		}
	}

	return red
}

func (p *declarationProjection) word(w *syntax.Word, depth int) *Word {
	if w == nil {
		return &Word{}
	}

	out := &Word{Span: declarationSpan(w)}

	p.wordParts(out, w.Parts, false, depth+1)

	return out
}

func (p *declarationProjection) wordParts(out *Word, xs []syntax.WordPart, quoted bool, depth int) {
	for _, x := range xs {
		if !p.step(depth) {
			return
		}

		part := Part{Span: declarationSpan(x), Quoted: quoted}
		switch n := x.(type) {
		case *syntax.Lit:
			part.Kind = valueLiteral2
			part.Text = declarationLiteral(n.Value, quoted, out)
		case *syntax.SglQuoted:
			out.Quoted = true
			part.Quoted = true
			part.Kind = valueLiteral2

			part.Text = n.Value
			if n.Dollar {
				out.Expands = true
			}
		case *syntax.DblQuoted:
			out.Quoted = true
			p.wordParts(out, n.Parts, true, depth+1)

			continue
		case *syntax.ParamExp:
			part.Kind = valueParameter
			if n.Param != nil {
				part.Text = n.Param.Value

				raw := p.text[part.Span.Start:part.Span.End]
				if raw != "$"+part.Text && raw != "${"+part.Text+"}" {
					out.Expands = true
				}
			} else {
				out.Expands = true
			}
		case *syntax.CmdSubst:
			part.Kind = "substitution"
			part.Tree = p.list(n.Stmts, depth+1)
		default:
			out.Expands = true
		}

		out.Parts = append(out.Parts, part)
	}
}

func declarationLiteral(value string, quoted bool, out *Word) string {
	var literal strings.Builder

	for i := 0; i < len(value); i++ {
		b := value[i]
		if b == '\\' && i+1 < len(value) && (!quoted || strings.ContainsRune("$`\\\"\n", rune(value[i+1]))) {
			i++

			b = value[i]
			if b == '\n' {
				continue
			}
		} else if !quoted && strings.ContainsRune("*?[{~", rune(b)) {
			out.Expands = true
		}

		literal.WriteByte(b)
	}

	return literal.String()
}

// The syntax library rejects dollars in some literal heredoc delimiters.
// Only its explicit heredoc-word/unclosed-heredoc error authorizes this projection;
// quoted examples/comments and body bytes are never rewritten. The original
// delimiter is restored below, and all offsets remain physical byte offsets.
func maskLiteralHeredoc(ctx context.Context, text string, err error) (string, bool) {
	var failure syntax.ParseError
	if !errors.As(err, &failure) || failure.Text != "expansions not allowed in heredoc words" && !strings.HasPrefix(failure.Text, "unclosed here-document ") {
		return "", false
	}

	offset := int(failure.Pos.Offset())
	if offset > len(text) {
		return "", false
	}

	line := strings.LastIndexByte(text[:offset], '\n') + 1

	op := strings.LastIndex(text[line:min(len(text), offset+2)], "<<")
	if op < 0 {
		return "", false
	}

	op += line
	start := op + 2
	stripTabs := false

	if start < len(text) && text[start] == '-' {
		start++
		stripTabs = true
	}

	p := parser{text: text, at: start, end: len(text), budget: &budget{ctx: ctx}}

	word, e := p.heredocWord()
	if e != nil {
		return "", false
	}

	delim, ok := word.word.Literal()
	if !ok || !strings.Contains(delim, "$") {
		return "", false
	}

	masked := []byte(text)
	for i := word.span.Start; i < word.span.End; i++ {
		if masked[i] == '$' {
			masked[i] = '_'
		}
	}

	for at := strings.IndexByte(text[word.span.End:], '\n') + word.span.End + 1; at > word.span.End && at < len(text); {
		end := len(text)
		if n := strings.IndexByte(text[at:], '\n'); n >= 0 {
			end = at + n
		}

		value := strings.TrimSuffix(text[at:end], "\r")
		if stripTabs {
			value = strings.TrimLeft(value, "\t")
		}

		if value == delim {
			for i := at; i < end; i++ {
				if masked[i] == '$' {
					masked[i] = '_'
				}
			}

			return string(masked), true
		}

		at = end + 1
	}

	return "", false
}

func declarationSpan(n syntax.Node) source.Span {
	return source.Span{Start: int(n.Pos().Offset()), End: int(n.End().Offset())}
}
