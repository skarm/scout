package shellsyntax

// Shared vocabulary used by this package's protocols and reports.
const (
	valueLiteral   = "<<-"
	valueEOF       = "eof"
	valueLiteral2  = "literal"
	valueNewline   = "newline"
	valueParameter = "parameter"
	valueWord      = "word"
)
