package validation

// Shared vocabulary used by this package's protocols and reports.
const (
	valueCompleted     = "completed"
	statusFailed       = "failed"
	valueNotApplicable = "not_applicable"
)
