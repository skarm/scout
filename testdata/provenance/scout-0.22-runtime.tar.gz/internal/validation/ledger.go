// Package validation accounts for a fixed post-discovery plan. It does not run
// checks or infer missing results. An absent/duplicate/unknown result is an error.
package validation

import (
	"encoding/json"
	"sort"
	"strconv"

	"github.com/skarm/scout/internal/artifact"
	"github.com/skarm/scout/internal/model"
)

const MaxTasks = 131072

// Ledger is confined to the engine coordinator, not shared with workers.
// Tasks and inputs are copied before execution. Snapshot binds decisions to bytes.
type Ledger struct {
	tasks     []model.AnalysisTask
	index     map[string]int
	results   map[string]model.TaskOutcome
	scheduled map[string]bool
	issues    map[string]bool
	omitted   int
	max       int
	digest    string
}

func New(files []model.File, rules []model.Rule, g model.ComponentGraph) *Ledger {
	return NewWithLimit(files, rules, g, MaxTasks)
}

// NewWithSemantic creates a ledger with optional semantic analysis and a bounded task limit.
func NewWithSemantic(files []model.File, rules []model.Rule, g model.ComponentGraph, enabled bool) *Ledger {
	return newLedger(files, rules, g, MaxTasks, enabled)
}

func NewWithLimit(files []model.File, rules []model.Rule, g model.ComponentGraph, limit int) *Ledger {
	return newLedger(files, rules, g, limit, false)
}

func newLedger(files []model.File, rules []model.Rule, g model.ComponentGraph, limit int, semanticEnabled bool) *Ledger {
	if limit < 1 {
		limit = 1
	}

	if limit > MaxTasks {
		limit = MaxTasks
	}

	l := &Ledger{tasks: []model.AnalysisTask{}, index: map[string]int{}, results: map[string]model.TaskOutcome{}, scheduled: map[string]bool{}, issues: map[string]bool{}, max: limit}

	fs := append([]model.File(nil), files...)
	rs := append([]model.Rule(nil), rules...)

	sort.Slice(fs, func(i, j int) bool { return fs[i].Path < fs[j].Path })
	sort.Slice(rs, func(i, j int) bool { return rs[i].ID < rs[j].ID })
	// Discovery-dependent obligations are explicit; unsupported is not success.
	for _, p := range g.Plugins {
		t := model.AnalysisTask{Kind: "loader_contract", PluginID: p.ID, Version: p.AdapterVersion, Required: true}

		id := l.add(t)
		if id != "" {
			l.record(id, "unsupported", "full_runtime_loader_contract_not_verified")
		}
	}

	for _, ref := range g.References {
		t := model.AnalysisTask{Kind: "reference_resolution", PluginID: ref.PluginID, ComponentID: ref.ComponentID, ReferenceID: ref.ID, Version: "1", Required: true}
		if ref.Source != nil {
			t.Path = ref.Source.Path
			t.InputSHA256 = ref.Source.SHA256
		}

		id := l.add(t)
		if id != "" {
			if ref.Status == "resolved" {
				l.record(id, valueCompleted, "captured_reference_only")
			} else {
				l.record(id, "unsupported", "reference_or_dependency_unresolved")
			}
		}
	}

	for _, issue := range g.Issues {
		t := model.AnalysisTask{Kind: "discovery_gap", AnalyzerID: issue.Code, Version: "1", Path: issue.Path, PluginID: issue.PluginID, Required: true}

		id := l.add(t)
		if id != "" {
			status := "unsupported"
			if issue.Status == "invalid" {
				status = statusFailed
			}

			l.record(id, status, "discovery_reported_"+issue.Status)
		}
	}
	// Explicit non-selection is not silently downgraded from a requested mode.
	id := l.add(model.AnalysisTask{Kind: "semantic_review", Version: "1", Required: semanticEnabled})
	if id != "" && !semanticEnabled {
		l.record(id, "disabled", "semantic_review_not_requested")
	}

	for _, f := range fs {
		for _, r := range rs {
			t := model.AnalysisTask{Kind: "analyzer", AnalyzerID: r.ID, Version: r.Version, Path: f.Path, InputSHA256: f.SHA256, Required: true}

			id := l.add(t)
			if id != "" {
				l.scheduled[key(r.ID, f.Path)] = true
			}
		}
	}

	raw, _ := json.Marshal(struct {
		Version string
		Host    string
		Tasks   []model.AnalysisTask
	}{"validation-plan-v2", g.RequestedHost, l.tasks})
	l.digest = artifact.Hash(raw)

	return l
}
func (l *Ledger) Scheduled(rule, file string) bool { return l.scheduled[key(rule, file)] }

// Record reports a terminal outcome for a known task. No result can rewrite an
// earlier one. The first outcome is retained and the duplicate is a contract gap.
func (l *Ledger) Record(id, status, reason string) { l.record(id, status, reason) }

// CompleteAnalyzer maps the engine's file outcomes onto already planned tasks.
// Unscheduled files cannot retrospectively become successfully planned work.
func (l *Ledger) CompleteAnalyzer(rule string, files []model.File, checks []model.FileCheck) {
	if len(files) != len(checks) {
		l.issues["task_result_count_mismatch"] = true
	}

	byPath := make(map[string]model.FileCheck, len(checks))
	for i, c := range checks {
		if i >= len(files) {
			break
		}

		if c.AnalyzerID != rule {
			l.issues["task_analyzer_mismatch"] = true
			continue
		}

		byPath[files[i].Path] = c
	}

	for _, t := range l.tasks {
		if t.Kind != "analyzer" || t.AnalyzerID != rule {
			continue
		}

		check, ok := byPath[t.Path]
		if !ok {
			continue
		}

		reason := "engine_reported_" + check.Status
		if check.Status == valueNotApplicable {
			reason = "analyzer_declared_not_applicable"
		}

		l.record(t.ID, check.Status, reason)
	}
}

func (l *Ledger) Tasks() []model.AnalysisTask { return append([]model.AnalysisTask(nil), l.tasks...) }

func (l *Ledger) Finalize() model.ValidationReport {
	r := model.ValidationReport{Scope: "post-discovery-static-plan plus optional semantic parent; semantic child plan and capture/extraction/preparation reported separately", PlanSHA256: l.digest, MaxTasks: l.max, OmittedTasks: l.omitted, Tasks: l.Tasks(), Outcomes: []model.TaskOutcome{}, Completeness: model.Complete, Issues: []string{}}
	for _, t := range l.tasks {
		o, ok := l.results[t.ID]
		if !ok {
			o = model.TaskOutcome{TaskID: t.ID, Status: "missing", Reason: "planned_task_has_no_result"}
			r.Completeness = model.Partial
		}

		if t.Required && o.Status != valueCompleted && o.Status != valueNotApplicable {
			r.Completeness = model.Partial
		}

		r.Outcomes = append(r.Outcomes, o)
	}

	if l.omitted > 0 {
		r.Issues = append(r.Issues, "task_budget_exceeded:"+strconv.Itoa(l.omitted))
		r.Completeness = model.Partial
	}

	for issue := range l.issues {
		r.Issues = append(r.Issues, issue)
		r.Completeness = model.Partial
	}

	sort.Strings(r.Issues)

	return r
}

// CompleteSemantic closes the pre-scheduled parent task. Its bounded child plan
// and evidence scopes are reported separately under semantic, before any calls.
func (l *Ledger) CompleteSemantic(completeness model.Completeness) {
	status := valueCompleted
	if completeness != model.Complete {
		status = "partial"
	}

	if completeness == model.Failed {
		status = statusFailed
	}

	for _, t := range l.tasks {
		if t.Kind == "semantic_review" && t.Required {
			l.record(t.ID, status, "semantic_child_plan_"+status)
		}
	}
}

func (l *Ledger) add(t model.AnalysisTask) string {
	if len(l.tasks) >= l.max {
		l.omitted++
		return ""
	}

	raw, _ := json.Marshal(t)

	t.ID = artifact.Hash(raw)
	if _, ok := l.index[t.ID]; ok {
		l.issues["duplicate_planned_task"] = true
		return ""
	}

	l.index[t.ID] = len(l.tasks)
	l.tasks = append(l.tasks, t)

	return t.ID
}

func (l *Ledger) record(id, status, reason string) {
	if _, ok := l.index[id]; !ok {
		l.issues["unknown_task_result"] = true
		return
	}

	if _, ok := l.results[id]; ok {
		l.issues["duplicate_task_result"] = true
		return
	}

	switch status {
	case valueCompleted, valueNotApplicable, "unsupported", "disabled", "cancelled", statusFailed, "partial", "not_run":
	default:
		l.issues["invalid_task_outcome"] = true
		status = statusFailed
		reason = "invalid_outcome"
	}
	// Reasons are scanner-controlled enums, not analyzer error strings.
	if len(reason) == 0 || len(reason) > 128 {
		l.issues["invalid_task_reason"] = true
		reason = "invalid_reason"
		status = statusFailed
	}

	l.results[id] = model.TaskOutcome{TaskID: id, Status: status, Reason: reason}
}
func key(rule, file string) string { return rule + "\x00" + file }
