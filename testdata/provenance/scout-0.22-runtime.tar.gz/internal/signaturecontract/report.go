// Package signaturecontract defines signature results without linking a scanner.
// Both the native adapter and the scan report use these wire types; it contains
// no options, rule loading, engine selection or native dependencies.
package signaturecontract

type Capability struct {
	Name           string `json:"name"`
	BindingVersion string `json:"binding_version"`
	NativeVersion  string `json:"native_version"`
	Available      bool   `json:"available"`
	Reason         string `json:"reason,omitempty"`
}

type Span struct {
	Start int `json:"start"`
	End   int `json:"end"`
}
type Match struct {
	Rule     string `json:"rule"`
	Category string `json:"category"`
	Spans    []Span `json:"spans"`
}
type Outcome struct {
	Path          string  `json:"path"`
	SHA256        string  `json:"sha256"`
	Status        string  `json:"status"`
	EngineVersion string  `json:"engine_version,omitempty"`
	Matches       []Match `json:"matches"`
	Truncated     bool    `json:"truncated"`
}
type Report struct {
	Enabled      bool       `json:"enabled"`
	Engine       Capability `json:"engine"`
	RulesSHA256  string     `json:"rules_sha256,omitempty"`
	Completeness string     `json:"completeness"`
	Outcomes     []Outcome  `json:"outcomes"`
	Limitations  []string   `json:"limitations"`
}
