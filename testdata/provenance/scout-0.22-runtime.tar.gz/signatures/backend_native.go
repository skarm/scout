//go:build !coreonly && cgo

package signatures

import (
	"context"
	"errors"
	"strings"
	"time"

	"github.com/skarm/scout/internal/promptguard"

	yrx "github.com/VirusTotal/yara-x/go"
)

type nativeEngine struct {
	rules   *yrx.Rules
	scanner *yrx.Scanner
}

func compileRules(ctx context.Context, source string) (compiledEngine, error) {
	if e := ctx.Err(); e != nil {
		return nil, e
	}
	compiler, e := yrx.NewCompiler(yrx.EnableIncludes(false), yrx.BanModule("console", "disabled module", "console output is forbidden in a security scanner"), yrx.MaxWarnings(32))
	if e != nil {
		return nil, errors.New("YARA-X compiler initialization failed")
	}
	defer compiler.Destroy()
	if e = compiler.AddSource(source); e != nil {
		return nil, errors.New("YARA-X rules rejected")
	}
	if e = ctx.Err(); e != nil {
		return nil, e
	}
	rules := compiler.Build()
	if rules == nil {
		return nil, errors.New("YARA-X did not build rules")
	}
	if rules.Count() > 2048 {
		rules.Destroy()
		return nil, errors.New("YARA-X compiled rule limit")
	}
	scanner := yrx.NewScanner(rules)
	if scanner == nil {
		rules.Destroy()
		return nil, errors.New("YARA-X scanner initialization failed")
	}
	return &nativeEngine{rules: rules, scanner: scanner}, nil
}

// Linked-library presence follows from successful linking, not from probing a
// user's filesystem. The official binding does not expose a native version API.
func Backend() Capability {
	return Capability{Name: "yara-x", BindingVersion: "1.22.0", NativeVersion: "unknown", Available: true}
}

func (e *nativeEngine) scan(ctx context.Context, data []byte) (reply, error) {
	out := reply{Status: valueCompleted, Matches: []Match{}}
	if ctx.Err() != nil {
		out.Status = valueCancelled
		return out, nil
	}
	deadline, ok := ctx.Deadline()
	if !ok {
		return reply{}, errors.New("native scan requires a deadline")
	}
	// The pinned C API accepts whole seconds. Never let a sub-second timeout
	// become zero (= unbounded). Native timeout is cooperative, not hard preemption.
	seconds := time.Until(deadline) / time.Second
	if seconds < 1 {
		out.Status = "deadline"
		return out, nil
	}
	e.scanner.SetTimeout(seconds * time.Second)
	result, err := e.scanner.Scan(data)
	if err != nil && result == nil {
		if errors.Is(err, yrx.ErrTimeout) {
			out.Status = "deadline"
		} else {
			out.Status = statusFailed
		}
		return out, nil
	}
	if result == nil {
		return reply{}, errors.New("missing YARA-X scan results")
	}
	text := string(data)
	for _, r := range result.MatchingRules() {
		if len(out.Matches) >= 32 {
			out.Truncated = true
			break
		}
		m := Match{Rule: r.Identifier(), Category: "unknown", Spans: []Span{}}
		for _, meta := range r.Metadata() {
			if meta.Identifier() == "category" {
				if c, ok := meta.Value().(string); ok {
					switch c {
					case "malware", "webshell", "cryptominer", "hack_tool", "exploit":
						m.Category = c
					}
				}
			}
		}
		seen := map[Span]bool{}
		rejectedInstances := false
		patterns := r.Patterns()
		promptRule := r.Identifier() == "agent_skill_prompt_injection_hidden_instructions"
		if promptRule {
			identifiers := map[string]bool{}
			count, limited := 0, false
			for _, pattern := range patterns {
				for _, hit := range pattern.Matches() {
					count++
					if count > 4096 {
						limited = true
						break
					}
					at, size := hit.Offset(), hit.Length()
					if at > uint64(len(data)) || size > uint64(len(data))-at {
						return reply{}, errors.New("invalid YARA-X range")
					}
					if pattern.Identifier() == "$inj_reveal_prompt" && promptguard.Prohibited(text, int(at), int(at+size)) {
						continue
					}
					identifiers[pattern.Identifier()] = true
				}
				if limited {
					break
				}
			}
			hidden, injections := false, 0
			for id := range identifiers {
				hidden = hidden || strings.HasPrefix(id, "$hidden_")
				if strings.HasPrefix(id, "$inj_") {
					injections++
				}
			}
			if limited {
				out.Truncated = true
			} else if !(hidden || identifiers["$agent_context"] && injections > 0 || injections >= 2) {
				continue
			}
		}
		exhausted := false
		for _, p := range patterns {
			for _, hit := range p.Matches() {
				start, length := hit.Offset(), hit.Length()
				if start > uint64(len(data)) || length > uint64(len(data))-start {
					return reply{}, errors.New("invalid YARA-X range")
				}
				if length == 0 {
					continue
				}
				if promptRule && (p.Identifier() == "$agent_context" || p.Identifier() == "$inj_reveal_prompt" && promptguard.Prohibited(text, int(start), int(start+length))) {
					rejectedInstances = true
					continue
				}
				if r.Identifier() == "ransomware_behavior" && !acceptRansomwareInstance(p.Identifier(), data, int(start), int(start+length)) {
					rejectedInstances = true
					continue
				}
				span := Span{Start: int(start), End: int(start + length)}
				if seen[span] {
					continue
				}
				if len(m.Spans) >= 8 {
					out.Truncated = true
					exhausted = true
					break
				}
				seen[span] = true
				m.Spans = append(m.Spans, span)
			}
			if exhausted {
				break
			}
		}
		// Conditions without a matching string are observations about the full file,
		// not fabricated substring evidence. This also retains empty-file matches.
		if len(m.Spans) == 0 && rejectedInstances {
			continue
		}
		if len(m.Spans) == 0 {
			m.Spans = []Span{{Start: 0, End: len(data)}}
		}
		out.Matches = append(out.Matches, m)
	}
	if err != nil || ctx.Err() != nil {
		out.Status = statusPartial
	} // preserve already completed native evidence
	return out, nil
}
func (e *nativeEngine) close() { e.scanner.Destroy(); e.rules.Destroy() }
