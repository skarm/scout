package signatures

// Shared vocabulary used by this package's protocols and reports.
const (
	valueCancelled = "cancelled"
	valueCompleted = "completed"
	statusFailed   = "failed"
	statusPartial  = "partial"
)
