// Package signatures embeds YARA-X. It never invokes Python, a YARA executable,
// or inspected code. Extra rules are explicit trusted operator input.
package signatures

import (
	"context"
	"crypto/sha256"
	_ "embed"
	"encoding/hex"
	"errors"
	"regexp"
	"time"

	"github.com/skarm/scout/internal/signaturecontract"
)

//go:embed rules/agent_skills.yar
var agentRules string

//go:embed rules/webshells.yar
var webshellRules string

//go:embed rules/hacktools.yar
var hacktoolRules string

//go:embed rules/cryptominers.yar
var cryptominerRules string

//go:embed rules/malware.yar
var malwareRules string

//nolint:gochecknoglobals // Immutable embedded rule text shared by all compiled engines.
var builtinRules = malwareRules + "\n" + agentRules + "\n" + webshellRules + "\n" + hacktoolRules + "\n" + cryptominerRules

var safeID = regexp.MustCompile(`^[A-Za-z_][A-Za-z0-9_]{0,127}$`)

type Options struct {
	Enabled                               bool
	Interpreter, Library                  string // Deprecated: nonempty paths now fail configuration validation.
	ExtraRules                            []byte
	Timeout                               time.Duration
	MaxFileBytes, MaxTotalBytes, MaxFiles int
}

type Input struct{ Path, SHA256, Data string }

// Capability describes the linked backend without requiring report consumers
// to import the native adapter. The public result aliases preserve source and
// JSON compatibility.
type (
	Capability = signaturecontract.Capability
	Span       = signaturecontract.Span
	Match      = signaturecontract.Match
	Outcome    = signaturecontract.Outcome
	Report     = signaturecontract.Report
	reply      struct {
		Status    string
		Matches   []Match
		Truncated bool
	}
)

type compiledEngine interface {
	scan(context.Context, []byte) (reply, error)
	close()
}

func DefaultOptions() Options {
	return Options{Timeout: 3 * time.Second, MaxFileBytes: 1 << 20, MaxTotalBytes: 8 << 20, MaxFiles: 64}
}

func BuiltinRulesSHA256() string { return hash([]byte(builtinRules)) }

func Check(ctx context.Context, inputs []Input, o Options) (Report, error) {
	r := Report{Enabled: o.Enabled, Engine: Backend(), Completeness: "complete", Outcomes: []Outcome{}, Limitations: []string{
		"Embedded YARA-X observes signatures, not execution or intent. Native compiler/scanner memory is in-process; budgets and native scan timeout are not a hard OS sandbox. Compilation cannot be forcibly cancelled.",
		"Twenty SkillSpector agent/webshell/hacktool/cryptominer rules are bundled. Broad tool references and examples can match. Classic YARA and YARA-X differ; no general external rule-pack compatibility is claimed. Includes and the console module are disabled; invalid rules are never silently ignored.",
		"The reported binding version is not a measured native-library version. Native engine identity is unknown unless separately attested by the build system.",
	}}
	if ctx == nil {
		r.Completeness = statusFailed
		return r, errors.New("nil YARA-X context")
	}

	if e := o.Validate(); e != nil {
		r.Completeness = statusFailed
		return r, e
	}

	if !o.Enabled {
		return r, nil
	}

	rules := builtinRules + "\n" + string(o.ExtraRules)

	r.RulesSHA256 = hash([]byte(rules))
	for _, f := range inputs {
		r.Outcomes = append(r.Outcomes, Outcome{Path: f.Path, SHA256: f.SHA256, Status: "not_run", Matches: []Match{}})
	}

	var engine compiledEngine
	defer func() {
		if engine != nil {
			engine.close()
		}
	}()

	fatal := ""
	used, count := 0, 0

	for i, f := range inputs {
		out := &r.Outcomes[i]
		switch {
		case ctx.Err() != nil:
			out.Status = valueCancelled
		case fatal != "":
			out.Status = fatal
		case len(f.Data) > o.MaxFileBytes || len(f.Data) > o.MaxTotalBytes-used || count >= o.MaxFiles:
			out.Status = "limit"
		case hash([]byte(f.Data)) != f.SHA256:
			out.Status = "invalid_input"
		case !r.Engine.Available:
			out.Status = "unavailable"
		default:
			used += len(f.Data)
			count++

			if engine == nil {
				var e error

				engine, e = compileRules(ctx, rules)
				if e != nil || engine == nil {
					fatal = "invalid_rules"
					if ctx.Err() != nil {
						fatal = valueCancelled
					}

					out.Status = fatal

					break
				}
			}

			scanInput(ctx, engine, f, o.Timeout, out, r.Engine)
		}

		if out.Status != valueCompleted || out.Truncated {
			r.Completeness = statusPartial
		}
	}

	if ctx.Err() != nil && r.Completeness == "complete" {
		r.Completeness = statusPartial
	}

	return r, ctx.Err()
}

func scanInput(ctx context.Context, engine compiledEngine, f Input, timeout time.Duration, out *Outcome, info Capability) {
	call, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	result, err := engine.scan(call, []byte(f.Data))
	if err != nil {
		out.Status = statusFailed
	} else if err = validateReply(result, len(f.Data)); err != nil {
		out.Status = "invalid_evidence"
	} else {
		out.Status = result.Status
		out.Matches = result.Matches
		out.Truncated = result.Truncated
		out.EngineVersion = "go-binding-" + info.BindingVersion + ";native-" + info.NativeVersion
	}
}

func (o Options) Validate() error {
	if o.Timeout <= 0 || o.Timeout > 10*time.Second || o.MaxFiles < 1 || o.MaxFiles > 256 || o.MaxFileBytes < 1 || o.MaxFileBytes > 4<<20 || o.MaxTotalBytes < o.MaxFileBytes || o.MaxTotalBytes > 32<<20 || len(o.ExtraRules) > 256<<10 {
		return errors.New("invalid YARA-X budgets")
	}

	if o.Interpreter != "" || o.Library != "" {
		return errors.New("external YARA/Python paths are no longer supported; use a YARA-X linked build")
	}

	if !o.Enabled && len(o.ExtraRules) > 0 {
		return errors.New("YARA-X rules require explicit enablement")
	}

	return nil
}

func validateReply(r reply, size int) error {
	switch r.Status {
	case valueCompleted, statusPartial, "deadline", valueCancelled, statusFailed:
	default:
		return errors.New("invalid YARA-X status")
	}

	if len(r.Matches) > 32 {
		return errors.New("YARA-X match budget")
	}

	if r.Status != valueCompleted && r.Status != statusPartial && len(r.Matches) > 0 {
		return errors.New("unverified native results")
	}

	for _, m := range r.Matches {
		if !safeID.MatchString(m.Rule) || len(m.Spans) == 0 || len(m.Spans) > 8 {
			return errors.New("invalid YARA-X match")
		}

		switch m.Category {
		case "malware", "webshell", "cryptominer", "hack_tool", "exploit", "unknown":
		default:
			return errors.New("invalid category")
		}

		for _, s := range m.Spans {
			if s.Start < 0 || s.End < s.Start || s.End > size || s.End == s.Start && size > 0 {
				return errors.New("invalid signature evidence")
			}
		}
	}

	return nil
}
func hash(b []byte) string { h := sha256.Sum256(b); return hex.EncodeToString(h[:]) }
