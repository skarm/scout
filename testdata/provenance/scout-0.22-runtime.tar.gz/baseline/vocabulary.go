package baseline

// Shared vocabulary used by this package's protocols and reports.
const (
	valueFingerprint = "fingerprint"
	valueGlob        = "glob"
)
