// Package baseline applies explicit operator approvals without deleting evidence.
// A baseline is trusted configuration supplied by the caller, never discovered
// in an artifact. It cannot suppress incomplete inspection or model proposals.
package baseline

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"path"
	"strings"
	"time"

	"github.com/skarm/scout/internal/jsonconfig"
	"github.com/skarm/scout/internal/model"
)

const (
	Version    = 1
	MaxBytes   = 256 << 10
	MaxEntries = 4096
)

type Entry struct {
	Kind        string `json:"kind"` // fingerprint or glob
	Fingerprint string `json:"fingerprint,omitempty"`
	RuleID      string `json:"rule_id,omitempty"`
	PathGlob    string `json:"path_glob,omitempty"`
	MessageGlob string `json:"message_glob,omitempty"`
	Reason      string `json:"reason"`
	Expires     string `json:"expires"` // RFC3339, exclusive deadline
	Approved    bool   `json:"approved"`
}
type Document struct {
	Version       int     `json:"version"`
	EngineVersion string  `json:"engine_version"`
	Profile       string  `json:"profile"`
	Entries       []Entry `json:"entries"`
}
type (
	Applied = model.Suppression
	Result  = model.BaselineReport
)

func Parse(data []byte) (Document, error) {
	var d Document
	if len(data) == 0 || len(data) > MaxBytes {
		return d, errors.New("baseline byte limit")
	}

	if _, err := jsonconfig.Parse(context.Background(), string(data)); err != nil {
		return d, errors.New("invalid or ambiguous baseline JSON")
	}

	dec := json.NewDecoder(bytes.NewReader(data))
	dec.DisallowUnknownFields()

	if err := dec.Decode(&d); err != nil {
		return Document{}, errors.New("invalid baseline schema")
	}

	if dec.Decode(new(any)) != io.EOF {
		return Document{}, errors.New("trailing baseline data")
	}

	return d, Validate(d)
}

func Validate(d Document) error {
	if d.Version != Version || d.EngineVersion == "" || d.Profile == "" || len(d.EngineVersion) > 128 || len(d.Profile) > 256 || d.Entries == nil || len(d.Entries) > MaxEntries {
		return errors.New("invalid baseline header or entry limit")
	}

	for _, e := range d.Entries {
		if strings.TrimSpace(e.Reason) == "" || len(e.Reason) > 1024 {
			return errors.New("baseline reason required (1..1024 bytes)")
		}

		if _, err := time.Parse(time.RFC3339, e.Expires); err != nil {
			return errors.New("baseline expiry must be RFC3339")
		}

		switch e.Kind {
		case valueFingerprint:
			if !digest(e.Fingerprint) || e.RuleID != "" || e.PathGlob != "" || e.MessageGlob != "" {
				return errors.New("invalid exact baseline entry")
			}
		case valueGlob:
			if e.Fingerprint != "" || e.RuleID == "" || e.PathGlob == "" || len(e.RuleID) > 128 || len(e.PathGlob) > 1024 || len(e.MessageGlob) > 1024 {
				return errors.New("glob baseline requires explicit rule and path")
			}

			for _, g := range []string{e.RuleID, e.PathGlob, e.MessageGlob} {
				if _, err := path.Match(g, ""); err != nil {
					return errors.New("invalid baseline glob")
				}
			}
		default:
			return errors.New("unknown baseline entry kind")
		}
	}

	return nil
}

// Fingerprint binds an occurrence and all trace evidence to the exact engine,
// profile and captured file. Even a source edit outside the matched span requires
// reapproval. Equal text in separate occurrences is not collapsed.
func Fingerprint(r model.Report, f model.Finding) string {
	payload := struct {
		Version         int
		Engine, Profile string
		Finding         model.Finding
	}{Version, r.EngineVersion, r.Profile, f}
	b, _ := json.Marshal(payload)

	return hash(b)
}

func Create(r model.Report, reason string, expires time.Time, approve bool) (Document, error) {
	d := Document{Version: Version, EngineVersion: r.EngineVersion, Profile: r.Profile, Entries: []Entry{}}
	for _, f := range r.Findings {
		d.Entries = append(d.Entries, Entry{Kind: valueFingerprint, Fingerprint: Fingerprint(r, f), Reason: reason, Expires: expires.UTC().Format(time.RFC3339), Approved: approve})
	}

	return d, Validate(d)
}

// Apply always retains the input report. A version/profile mismatch matches no
// entries, and expired/pending entries never exempt a finding. now is trusted.
func Apply(r model.Report, d Document, now time.Time, allowGlobs bool) (Result, []model.Finding, error) {
	out := Result{Enabled: true, Status: "applied", Suppressed: []Applied{}}
	if err := Validate(d); err != nil {
		return out, nil, err
	}

	data, _ := json.Marshal(d)
	out.DocumentSHA256 = hash(data)

	active := make([]model.Finding, 0, len(r.Findings))
	if d.EngineVersion != r.EngineVersion || d.Profile != r.Profile {
		out.Status = "identity_mismatch"
		out.Unmatched = len(d.Entries)

		return out, append(active, r.Findings...), nil
	}

	if !allowGlobs {
		for _, e := range d.Entries {
			if e.Kind == valueGlob {
				return out, nil, errors.New("glob approvals require explicit permission")
			}
		}
	}

	used := make([]bool, len(d.Entries))

	eligible := make([]bool, len(d.Entries))
	for i, e := range d.Entries {
		expiry, _ := time.Parse(time.RFC3339, e.Expires)
		if !now.Before(expiry) {
			out.Expired++
			continue
		}

		if !e.Approved {
			out.Pending++
			continue
		}

		eligible[i] = true
	}

	for _, f := range r.Findings {
		fp := Fingerprint(r, f)
		found := -1

		for i, e := range d.Entries {
			if !eligible[i] {
				continue
			}

			if matchesEntry(e, f, fp) {
				found = i
				used[i] = true

				break
			}
		}

		if found < 0 {
			active = append(active, f)
			continue
		}

		e := d.Entries[found]
		out.Suppressed = append(out.Suppressed, Applied{FindingID: f.ID, EntryIndex: found, Kind: e.Kind, ReasonSHA256: hash([]byte(e.Reason)), Expires: e.Expires})
	}

	for i := range d.Entries {
		if eligible[i] && !used[i] {
			out.Unmatched++
		}
	}

	return out, active, nil
}

func matchesEntry(e Entry, f model.Finding, fingerprint string) bool {
	if e.Kind != valueGlob {
		return e.Kind == valueFingerprint && e.Fingerprint == fingerprint
	}

	rule, _ := path.Match(e.RuleID, f.RuleID)
	file, _ := path.Match(e.PathGlob, f.Location.Path)

	message := true
	if e.MessageGlob != "" {
		message, _ = path.Match(e.MessageGlob, f.Message)
	}

	return rule && file && message
}

func Marshal(d Document) ([]byte, error) {
	if err := Validate(d); err != nil {
		return nil, err
	}

	b, err := json.MarshalIndent(d, "", "  ")
	if err != nil {
		return nil, errors.New("baseline encoding failed")
	}

	return append(b, '\n'), nil
}

func digest(s string) bool {
	if len(s) != 64 {
		return false
	}

	_, e := hex.DecodeString(s)

	return e == nil && s == strings.ToLower(s)
}
func hash(b []byte) string { x := sha256.Sum256(b); return hex.EncodeToString(x[:]) }
