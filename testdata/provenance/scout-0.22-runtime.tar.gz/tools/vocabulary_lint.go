package tools

// Shared vocabulary used by this package's protocols and reports.
const (
	valueScan                   = "scan"
	valueOriginalRule           = "original_rule"
	valueRule                   = "rule"
	valueExtended               = "extended"
	valueUpstream               = "upstream"
	valueScope                  = "scope"
	valueLine                   = "line"
	valueSeverity               = "severity"
	valueJSON                   = "json"
	valueFormat                 = "--format"
	valueBI001AE3               = "BI001 AE3"
	valueCases                  = "cases"
	valueCompareUpstreamSuite   = "compare-upstream-suite"
	valueExecutionSuccessful    = "execution_successful"
	kindFile                    = "file"
	valuePublicOrDirectAnalyzer = "public_or_direct_analyzer"
	valueReason                 = "reason"
	valueRisk                   = "risk"
	valueSchemaVersion          = "schema_version"
	valueScout                  = "scout"
	valueUpstreamFixture        = "upstream_fixture"
	valueUpstreamFixtureFile    = "upstream_fixture_file"
)
