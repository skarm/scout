package tools

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"slices"
	"sync"
	"time"
)

const fixtureModel = "scripted-fixture-no-live-model"

type knowledgeCase struct {
	ID, Label, Topic, Path, Content string
	StaticExpected                  string `json:"static_expected"`
	StaticForbidden                 string `json:"static_forbidden"`
	RequiresPython                  bool   `json:"requires_python"`
}
type fixtureReviewer struct {
	mu                  sync.Mutex
	current             knowledgeCase
	topics              map[string]object
	prompts             map[string]string
	calls, verification int
	err                 error
}

func checkKnowledgeRuntime(ctx context.Context, o options, w io.Writer) error {
	if err := o.require("binary", "output"); err != nil {
		return err
	}

	binary, err := filepath.Abs(o.get("binary"))
	if err != nil {
		return err
	}

	var corpus struct{ Cases []knowledgeCase }
	if err = readJSON(filepath.Join(o.root, "testdata/knowledge-runtime/cases.json"), &corpus); err != nil {
		return err
	}

	pack, _, err := invokeJSON(ctx, binary, "knowledge")
	if err != nil {
		return err
	}

	reviewer, err := newFixtureReviewer(ctx, binary, pack)
	if err != nil {
		return err
	}

	if err = newOutput(o.get("output")); err != nil {
		return err
	}

	server := httptest.NewServer(http.HandlerFunc(reviewer.serve))
	defer server.Close()

	folder, err := os.MkdirTemp("", "scout-authored-knowledge-")
	if err != nil {
		return err
	}

	defer func() { _ = os.RemoveAll(folder) }()

	rows := make([]object, 0, len(corpus.Cases))
	for _, tc := range corpus.Cases {
		row, err := checkKnowledgeCase(ctx, o, binary, folder, server.URL+"/v1/chat/completions", reviewer, tc)
		if err != nil {
			return fmt.Errorf("%s: %w", tc.ID, err)
		}

		rows = append(rows, row)
	}

	binarySHA, err := fileDigest(binary)
	if err != nil {
		return err
	}

	summary := object{valueScope: "Actual static scans and scripted semantic transport integration. Not model quality or SQL detection accuracy.", "public_network": false, "live_model": false, "target_code_executed": false, "pack_sha256": at(pack, "manifest", "sha256"), "binary_sha256": binarySHA, valueCases: rows}

	destination := filepath.Join(o.get("output"), "summary.json")
	if err = writeJSON(destination, summary); err != nil {
		return err
	}

	risk := 0

	for _, tc := range corpus.Cases {
		if tc.Label == valueRisk {
			risk++
		}
	}

	return printJSON(w, object{valueCases: len(rows), "scripted_risk_responses": risk, "live_model": false, "summary": destination})
}

func newFixtureReviewer(ctx context.Context, binary string, pack object) (*fixtureReviewer, error) {
	reviewer := &fixtureReviewer{topics: map[string]object{}, prompts: map[string]string{}}
	for _, topic := range array(pack["review_topics"]) {
		reviewer.topics[text(at(topic, "id"))] = obj(topic)
	}

	for _, prompt := range array(at(pack, "manifest", "prompts")) {
		mode := text(at(prompt, "mode"))

		data, _, err := invokeCLI(ctx, binary, "knowledge", "--mode", mode)
		if err != nil {
			return nil, err
		}

		reviewer.prompts[mode] = string(data)
	}

	return reviewer, nil
}

func invokeCLI(ctx context.Context, binary string, args ...string) ([]byte, int, error) {
	call, cancel := context.WithTimeout(ctx, time.Minute)
	defer cancel()

	cmd := exec.CommandContext(call, binary, args...) //nolint:gosec // G204: explicitly selected trusted Scout binary; scanned artifact bytes are never executed.

	var stdout, stderr bytes.Buffer

	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	code := 0

	if err != nil {
		var exit *exec.ExitError
		if !errors.As(err, &exit) {
			return nil, 0, err
		}

		code = exit.ExitCode()
		if code < 0 || code > 2 {
			return nil, code, err
		}
	}

	if stderr.Len() != 0 {
		return nil, code, errors.New("scout wrote unexpected stderr")
	}

	return stdout.Bytes(), code, nil
}

func invokeJSON(ctx context.Context, binary string, args ...string) (object, int, error) {
	data, code, err := invokeCLI(ctx, binary, args...)
	if err != nil {
		return nil, code, err
	}

	var report object

	err = json.Unmarshal(data, &report)

	return report, code, err
}

func (s *fixtureReviewer) serve(w http.ResponseWriter, r *http.Request) {
	s.mu.Lock()
	defer s.mu.Unlock()

	body, err := s.answer(r)
	if err != nil {
		s.err = err

		http.Error(w, "fixture protocol check failed", http.StatusInternalServerError)

		return
	}

	w.Header().Set("Content-Type", "application/json")

	if err = json.NewEncoder(w).Encode(body); err != nil {
		s.err = err
	}
}

func (s *fixtureReviewer) answer(r *http.Request) (object, error) {
	if r.Method != http.MethodPost || r.ContentLength <= 0 || r.ContentLength >= 256<<10 {
		return nil, errors.New("unexpected fixture request")
	}

	var body object
	if err := json.NewDecoder(io.LimitReader(r.Body, 256<<10)).Decode(&body); err != nil {
		return nil, err
	}

	messages := array(body["messages"])
	if len(messages) < 2 {
		return nil, errors.New("missing fixture messages")
	}

	var request object
	if err := json.Unmarshal([]byte(text(at(messages[1], "content"))), &request); err != nil {
		return nil, err
	}

	mode := text(request["mode"])

	prompt, exists := s.prompts[mode]
	if !exists || text(at(messages[0], "role")) != "system" || text(at(messages[0], "content")) != prompt || text(request["prompt_sha256"]) != digest([]byte(prompt)) {
		return nil, errors.New("fixture prompt binding differs")
	}

	reason := "knowledge:" + s.current.Topic

	values := stringsOf(at(body, "response_format", "json_schema", "schema", "properties", "proposals", "items", "properties", valueReason, "enum"))
	if !slices.Contains(values, reason) {
		return nil, errors.New("knowledge reason is absent from response schema")
	}

	response, err := s.fixtureResponse(request, mode, reason)
	if err != nil {
		return nil, err
	}

	encoded, err := json.Marshal(response)
	if err != nil {
		return nil, err
	}

	s.calls++

	return object{"model": fixtureModel, "choices": []any{object{"index": 0, "finish_reason": "stop", "message": object{"role": "assistant", "content": string(encoded)}}}}, nil
}

func (s *fixtureReviewer) fixtureResponse(request object, mode, reason string) (object, error) {
	proposals, assessments := []any{}, []any{}

	if mode == "discovery" && s.current.Label == valueRisk {
		var evidence object

		for _, ex := range array(request["excerpts"]) {
			if text(at(ex, "path")) == s.current.Path {
				evidence = object{"excerpt_id": at(ex, "id"), "sha256": at(ex, "sha256")}
				break
			}
		}

		if evidence == nil {
			return nil, errors.New("fixture source excerpt missing")
		}

		proposals = append(proposals, object{valueReason: reason, valueSeverity: "high", "evidence": []any{evidence}})
	}

	for _, finding := range array(request[findingsKey]) {
		if mode == "proposal_assessment" {
			if err := s.checkFindingGuidance(obj(finding), reason); err != nil {
				return nil, err
			}

			s.verification++
		}

		assessments = append(assessments, object{"finding_id": at(finding, "id"), "verdict": "confirmed", valueReason: "supported_by_context", "evidence": at(finding, "evidence")})
	}

	return object{valueSchemaVersion: request[valueSchemaVersion], "request_id": request["request_id"], "proposals": proposals, "assessments": assessments}, nil
}

func (s *fixtureReviewer) checkFindingGuidance(finding object, reason string) error {
	topic, exists := s.topics[s.current.Topic]
	if !exists || text(finding[valueReason]) != reason || !reflect.DeepEqual(at(finding, "guidance", "review_checks"), topic["review_checks"]) || !reflect.DeepEqual(at(finding, "guidance", "remediation"), topic["remediation"]) || len(array(at(finding, "guidance", "sources"))) != len(array(topic["sources"])) {
		return errors.New("fixture knowledge guidance differs")
	}

	return nil
}

func checkKnowledgeCase(ctx context.Context, o options, binary, folder, endpoint string, s *fixtureReviewer, tc knowledgeCase) (object, error) {
	target, err := safeJoin(folder, tc.ID)
	if err != nil {
		return nil, err
	}

	path, err := safeJoin(target, tc.Path)
	if err != nil {
		return nil, err
	}

	if err = os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return nil, err
	}

	if err = os.WriteFile(path, []byte(tc.Content), 0o600); err != nil {
		return nil, err
	}

	flags := []string{}
	if tc.RequiresPython {
		flags = append(flags, "--python-ast")
	}

	static, staticCode, err := knowledgeScan(ctx, o, binary, target, tc.ID+"-static.json", flags)
	if err != nil {
		return nil, err
	}

	found, applicable, err := checkStaticKnowledge(static, tc)
	if err != nil {
		return nil, err
	}

	s.mu.Lock()
	s.current, s.calls, s.verification, s.err = tc, 0, 0, nil
	s.mu.Unlock()

	semanticFlags := append(slices.Clone(flags), "--semantic", "--allow-source-upload", "--llm-allow-loopback", "--llm-endpoint", endpoint, "--llm-model", fixtureModel)

	semantic, semanticCode, err := knowledgeScan(ctx, o, binary, target, tc.ID+"-fixture.json", semanticFlags)
	if err != nil {
		return nil, err
	}

	s.mu.Lock()
	defer s.mu.Unlock()

	if err = s.validateCase(static, semantic, tc); err != nil {
		return nil, err
	}

	expected := 0
	if tc.Label == valueRisk {
		expected = 1
	}

	return object{"id": tc.ID, "label": tc.Label, "topic": tc.Topic, "static_rule_ids": found, "static_control_applicable": applicable, "static_coverage": at(static, coverageKey, "completeness"), "static_exit": staticCode, "fixture_topic_proposals": expected, "fixture_verifications": s.verification, "fixture_calls": s.calls, "semantic_completeness": at(semantic, "semantic", "completeness"), "semantic_exit": semanticCode}, nil
}

func knowledgeScan(ctx context.Context, o options, binary, target, name string, flags []string) (object, int, error) {
	args := append([]string{valueScan, valueFormat, valueJSON}, flags...)
	args = append(args, "--", target)

	data, code, err := invokeCLI(ctx, binary, args...)
	if err != nil {
		return nil, code, err
	}

	if err = os.WriteFile(filepath.Join(o.get("output"), name), data, 0o600); err != nil {
		return nil, code, err
	}

	var result object

	err = json.Unmarshal(data, &result)

	return result, code, err
}

func checkStaticKnowledge(report object, tc knowledgeCase) ([]string, bool, error) {
	if boolean(at(report, "semantic", "enabled")) {
		return nil, false, errors.New("static scan enabled semantic review")
	}

	found := map[string]bool{}
	for _, finding := range array(report[findingsKey]) {
		found[text(at(finding, "rule_id"))] = true
	}

	available := false

	for _, check := range array(at(report, "inspection", "checks")) {
		if text(at(check, "id")) == "python" {
			available = boolean(at(check, "available"))
		}
	}

	applicable := !tc.RequiresPython || available
	if tc.StaticForbidden != "" && found[tc.StaticForbidden] {
		return nil, false, errors.New("forbidden static rule was reported")
	}

	if tc.StaticExpected != "" && applicable {
		if !found[tc.StaticExpected] {
			return nil, false, errors.New("expected static rule missing")
		}

		if !staticGuidanceContains(report, tc.StaticExpected, tc.Topic) {
			return nil, false, errors.New("static rule knowledge source missing")
		}
	}

	return sortedKeys(found), applicable, nil
}

func staticGuidanceContains(report object, rule, topic string) bool {
	for _, entry := range array(report["rules"]) {
		if text(at(entry, "id")) != rule {
			continue
		}

		for _, source := range array(at(entry, "guidance", "sources")) {
			if text(at(source, "symbol")) == topic {
				return true
			}
		}
	}

	return false
}

func (s *fixtureReviewer) validateCase(static, semantic object, tc knowledgeCase) error {
	if s.err != nil {
		return s.err
	}

	if !reflect.DeepEqual(semantic[findingsKey], static[findingsKey]) {
		return errors.New("semantic review changed static findings")
	}

	sem := obj(semantic["semantic"])

	expected := 0
	if tc.Label == valueRisk {
		expected = 1
	}

	if number(sem["completed_requests"]) != len(array(sem["tasks"])) || len(array(sem["proposals"])) != expected || len(array(sem["proposal_assessments"])) != expected || s.verification != expected {
		return errors.New("fixture requests or assessments incomplete")
	}

	if expected == 1 {
		proposal := array(sem["proposals"])[0]
		if text(at(proposal, "knowledge_topic_id")) != tc.Topic || len(array(at(proposal, "guidance", "sources"))) == 0 || text(at(semantic, "policy", decisionKey)) == decisionAllow {
			return errors.New("fixture proposal lost knowledge or policy evidence")
		}
	}

	return nil
}
