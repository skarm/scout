package tools

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path"
	"path/filepath"
	"reflect"
	"slices"
	"strings"
	"time"
)

type preparedCase struct {
	Spec                   object
	Argument, Root, SHA256 string
	Files                  []inventoryFile
}

func compareUpstream(ctx context.Context, o options, w io.Writer) error {
	if err := o.require("upstream-source", "skillspector", valueScout, "output"); err != nil {
		return err
	}

	if err := requireSandbox(); err != nil {
		return err
	}

	upstream, err := filepath.Abs(o.get("upstream-source"))
	if err != nil {
		return err
	}

	scanner, err := filepath.Abs(o.get("skillspector"))
	if err != nil {
		return err
	}

	scoutBinary, err := filepath.Abs(o.get(valueScout))
	if err != nil {
		return err
	}

	output, err := filepath.Abs(o.get("output"))
	if err != nil {
		return err
	}

	source, err := verifyUpstream(o.root, upstream)
	if err != nil {
		return err
	}

	python := filepath.Join(filepath.Dir(scanner), "python")

	installed, err := verifyInstalledRuntime(ctx, python, upstream)
	if err != nil {
		return err
	}

	if err = newOutput(output); err != nil {
		return err
	}

	home, tmp := filepath.Join(output, "home"), filepath.Join(output, "tmp")
	for _, dir := range []string{home, tmp, filepath.Join(output, "reports")} {
		if err = os.Mkdir(dir, 0o700); err != nil {
			return err
		}
	}

	profile, env := networkProfile(output, false), cleanEnvironment(scanner, home, tmp)

	env = append(env, "SKILLSPECTOR_OSV_TIMEOUT=0", "SKILLSPECTOR_MAX_WORKFLOW_SECONDS=45")
	if err = checkNetworkDenial(ctx, profile, home, env); err != nil {
		return err
	}

	runtimeInfo, err := asObject(installed)
	if err != nil {
		return err
	}

	binarySHA, err := fileDigest(scoutBinary)
	if err != nil {
		return err
	}

	runtimeInfo["executed_at"], runtimeInfo["source_commit"], runtimeInfo["source_inventory_files"] = time.Now().UTC().Format(time.RFC3339Nano), upstreamCommit, source.FileCount
	runtimeInfo["scout_binary_sha256"], runtimeInfo["network"] = binarySHA, "OS deny network* verified"

	runtimeInfo["scout_command"], runtimeInfo["upstream_command"] = []string{valueScan, "--profile", valueExtended, "--timeout", "45s", valueFormat, valueJSON}, []string{valueScan, valueFormat, valueJSON, "--no-llm"}
	if err = writeJSON(filepath.Join(output, "environment.json"), runtimeInfo); err != nil {
		return err
	}

	cases, err := prepareComparison(o.root, output, upstream, source)
	if err != nil {
		return err
	}

	results := make([]object, 0, len(cases))
	schemaErrors := 0
	rejections := []string{}

	for _, tc := range cases {
		row, err := runComparisonCase(ctx, output, home, profile, env, scanner, scoutBinary, tc)
		if err != nil {
			return err
		}

		results = append(results, row)
		schemaErrors += comparisonErrorCount(row)

		if boolean(at(row, valueUpstream, "expected_rejection")) {
			rejections = append(rejections, text(tc.Spec["id"]))
		}

		if _, err = fmt.Fprintf(w, "%d / %d %s\n", len(results), len(cases), text(tc.Spec["id"])); err != nil {
			return err
		}
	}

	slices.SortFunc(results, func(a, b object) int { return strings.Compare(text(a["id"]), text(b["id"])) })

	report := object{valueSchemaVersion: 1, "source_commit": upstreamCommit, "normalization": comparisonAliases(), valueScope: "Static same-byte packages; family+file sets, raw IDs/lines/severity retained. No score, coverage, verdict or semantic-equivalence claim.", "case_count": len(cases), "execution_or_schema_errors": schemaErrors, "expected_upstream_rejections": rejections, valueCases: results}
	if err = writeJSON(filepath.Join(output, "comparison.json"), report); err != nil {
		return err
	}

	if schemaErrors != 0 {
		return fmt.Errorf("comparison completed with %d execution or schema errors", schemaErrors)
	}

	return nil
}

func comparisonErrorCount(row object) int {
	count := 0

	for _, kind := range []string{valueUpstream, valueScout} {
		if at(row, kind, errorKey) != nil {
			count++
		}
	}

	return count
}

func prepareComparison(root, output, upstream string, pinned sourceInventory) ([]preparedCase, error) {
	var spec object
	if err := readJSON(filepath.Join(root, "testdata/differential/cases.json"), &spec); err != nil {
		return nil, err
	}

	if text(spec["upstream_commit"]) != upstreamCommit {
		return nil, errors.New("unexpected corpus source revision")
	}

	coverage := obj(spec["required_upstream_fixtures"])
	if coverage == nil {
		return nil, errors.New("fixture coverage metadata missing")
	}

	expected := map[string]bool{}

	for _, item := range pinned.Files {
		if strings.HasPrefix(item.Path, "tests/fixtures/") {
			expected[item.Path] = true
		}
	}

	if !slices.Equal(sortedKeys(coverage), sortedKeys(expected)) {
		return nil, errors.New("fixture inventory differs from pinned sources")
	}

	for _, value := range coverage {
		entry := obj(value)
		entry["package_cases"], entry["file_cases"] = []string{}, []string{}
	}

	cases := []preparedCase{}
	exported := []object{}
	packageRoots := map[string]bool{}

	for _, value := range array(spec[valueCases]) {
		tc, err := prepareComparisonCase(root, output, upstream, obj(value))
		if err != nil {
			return nil, err
		}

		if err = recordFixtureCoverage(coverage, tc); err != nil {
			return nil, err
		}

		cases = append(cases, tc)

		row, err := asObject(tc.Spec)
		if err != nil {
			return nil, err
		}

		row["path"], row["inventory_root"], row["files"], row["sha256"] = tc.Argument, tc.Root, tc.Files, tc.SHA256
		exported = append(exported, row)

		if text(at(tc.Spec, "source", "kind")) == valueUpstreamFixture {
			packageRoots[text(at(tc.Spec, "source", "path"))] = true
		}
	}

	for name, value := range coverage {
		entry := obj(value)
		if lenStringValues(entry["package_cases"]) == 0 || lenStringValues(entry["file_cases"]) == 0 {
			return nil, errors.New("uncovered upstream fixture")
		}

		if path.Base(name) == "SKILL.md" && !packageRoots[path.Dir(name)] {
			return nil, errors.New("missing skill package context")
		}
	}

	if err := writeJSON(filepath.Join(output, "fixture-coverage.json"), object{"source_commit": upstreamCommit, "files": coverage, "uncovered": []string{}}); err != nil {
		return nil, err
	}

	if err := writeJSON(filepath.Join(output, "corpus.json"), object{valueSchemaVersion: 1, valueCases: exported}); err != nil {
		return nil, err
	}

	return cases, nil
}

func lenStringValues(v any) int {
	if values, ok := v.([]string); ok {
		return len(values)
	}

	return len(array(v))
}

func prepareComparisonCase(root, output, upstream string, spec object) (preparedCase, error) {
	tc := preparedCase{Spec: spec}

	id := text(spec["id"])
	if id == "" {
		return tc, errors.New("case ID missing")
	}

	target, err := safeJoin(filepath.Join(output, "packages"), id)
	if err != nil {
		return tc, err
	}

	if err = os.MkdirAll(target, 0o700); err != nil {
		return tc, err
	}

	source := obj(spec["source"])

	kind, name := text(source["kind"]), text(source["path"])
	switch kind {
	case "authored_regression":
		if err = writeAuthoredFiles(target, obj(source["files"])); err != nil {
			return tc, err
		}
	case valueUpstreamFixtureFile:
		origin, err := safeJoin(upstream, name)
		if err != nil {
			return tc, err
		}

		if err = copyFile(origin, filepath.Join(target, filepath.Base(name))); err != nil {
			return tc, err
		}
	case valueUpstreamFixture, "scout_fixture":
		base := root
		if kind == valueUpstreamFixture {
			base = upstream
		}

		origin, err := safeJoin(base, name)
		if err != nil {
			return tc, err
		}

		if err = copyTree(origin, target); err != nil {
			return tc, err
		}
	default:
		return tc, fmt.Errorf("unknown comparison source kind %q", kind)
	}

	tc.Root, tc.Argument = target, target
	if kind == valueUpstreamFixtureFile {
		tc.Argument = filepath.Join(target, filepath.Base(name))
	}

	if input := text(spec["input_file"]); input != "" {
		tc.Argument, err = safeJoin(target, input)
		if err != nil {
			return tc, err
		}

		info, err := os.Stat(tc.Argument)
		if err != nil || !info.Mode().IsRegular() {
			return tc, errors.New("comparison input file missing")
		}
	}

	tc.Files, err = treeInventory(target)
	if err != nil {
		return tc, err
	}

	canonical, err := compactCanonical(tc.Files)
	if err != nil {
		return tc, err
	}

	tc.SHA256 = digest(canonical)

	return tc, nil
}

func writeAuthoredFiles(target string, files object) error {
	for file, content := range files {
		destination, err := safeJoin(target, file)
		if err != nil {
			return err
		}

		if err = os.MkdirAll(filepath.Dir(destination), 0o700); err != nil {
			return err
		}

		if err = os.WriteFile(destination, []byte(text(content)), 0o600); err != nil {
			return err
		}
	}

	return nil
}

func compactCanonical(value any) ([]byte, error) {
	data, err := captureCanonical(value)
	if err != nil {
		return nil, err
	}

	var (
		out             strings.Builder
		quoted, escaped bool
	)
	for _, r := range string(data) {
		if quoted {
			out.WriteRune(r)

			if escaped {
				escaped = false
			} else if r == '\\' {
				escaped = true
			} else if r == '"' {
				quoted = false
			}

			continue
		}

		if r == '"' {
			quoted = true
		}

		if r != ' ' && r != '\n' && r != '\t' {
			out.WriteRune(r)
		}
	}

	return []byte(out.String()), nil
}

func recordFixtureCoverage(coverage object, tc preparedCase) error {
	source := obj(tc.Spec["source"])

	kind, name := text(source["kind"]), text(source["path"])
	if !strings.HasPrefix(kind, valueUpstreamFixture) {
		return nil
	}

	for _, file := range tc.Files {
		original := name
		if kind != valueUpstreamFixtureFile {
			original += "/" + file.Path
		}

		entry := obj(coverage[original])
		if entry == nil || text(entry["sha256"]) != file.SHA256 || number(entry["bytes"]) != file.Bytes {
			return errors.New("fixture bytes differ from pinned coverage")
		}

		if mode := text(tc.Spec["mode"]); mode != "" && mode != "static" {
			continue
		}

		key := "package_cases"
		if kind == valueUpstreamFixtureFile {
			key = "file_cases"
		}

		values, ok := entry[key].([]string)
		if !ok {
			return errors.New("invalid fixture coverage list")
		}

		entry[key] = append(values, text(tc.Spec["id"]))
	}

	return nil
}

func runComparisonCase(ctx context.Context, output, home, profile string, env []string, scanner, scoutBinary string, tc preparedCase) (object, error) {
	mode := text(tc.Spec["mode"])
	if mode == "" {
		mode = "static"
	}

	id := text(tc.Spec["id"])
	row := object{"id": id, "mode": mode, "input_sha256": tc.SHA256}

	for _, kind := range []string{valueUpstream, valueScout} {
		args := []string{scanner, valueScan, valueFormat, valueJSON, "--no-llm"}
		if kind == valueScout {
			args = []string{scoutBinary, valueScan, "--profile", valueExtended, "--timeout", "45s", valueFormat, valueJSON}
		} else if mode == "mcp_registry" {
			args = append(args, "--mcp-registry")
		}

		args = append(args, tc.Argument)

		result, err := runSandboxed(ctx, profile, home, env, args...)
		if err != nil {
			return nil, err
		}

		for suffix, data := range map[string][]byte{valueJSON: result.Stdout, "stderr": result.Stderr} {
			if err = os.WriteFile(filepath.Join(output, "reports", id+"."+kind+"."+suffix), data, 0o600); err != nil {
				return nil, err
			}
		}

		normalized, err := normalizeComparisonResult(tc.Spec, kind, result)
		if err != nil {
			normalized = object{errorKey: err.Error()}
		}

		normalized["exit_code"], normalized["seconds"], normalized["report_sha256"] = result.Code, result.Seconds, digest(result.Stdout)
		row[kind] = normalized
	}

	current, err := treeInventory(tc.Root)
	if err != nil {
		return nil, err
	}

	if !reflect.DeepEqual(current, tc.Files) {
		return nil, errors.New("package changed during scanning")
	}

	if at(row, valueUpstream, errorKey) == nil && at(row, valueScout, errorKey) == nil {
		addComparisonDifferences(row)
	}

	return row, nil
}

func normalizeComparisonResult(spec object, kind string, result processResult) (object, error) {
	if kind == valueUpstream && text(spec["expected_upstream_rejection"]) == "invalid_registry_record" && result.Code == 2 && len(strings.TrimSpace(string(result.Stdout))) == 0 && strings.Contains(strings.Join(strings.Fields(string(result.Stderr)), " "), "MCP Registry payload has an invalid server record") {
		return object{findingsKey: []any{}, coverageKey: "rejected_invalid_registry", valueExecutionSuccessful: false, "expected_rejection": true}, nil
	}

	var report object
	if err := json.Unmarshal(result.Stdout, &report); err != nil {
		return nil, err
	}

	if kind == valueUpstream {
		return normalizeUpstreamReport(report)
	}

	return normalizeScoutReport(report)
}

func comparisonAliases() map[string]string {
	return map[string]string{"PI001": "P1", "PL001": "P6", "AC003": "BH1", "NV-TR1M": "TR1", "NV-TR2M": "TR2", "NV-TR3M": "TR3"}
}

func comparisonFamily(rule string) string {
	if alias := comparisonAliases()[rule]; alias != "" {
		return alias
	}

	originals := " SC001 SC002 SC003 AC001 AC002 AG001 AG002 MC001 MC002 MC003 BI001 EX001 SE001 FS001 GO001 GO002 GO003 GO004 SH001 SH002 SH003 SH004 DE001 MP001 PI002 PI003 NV-TR1 NV-TR2 NV-TR3 NV-SC7M "
	if strings.Contains(originals, " "+rule+" ") {
		return "scout:" + rule
	}

	return suiteFamily(rule)
}

func normalizeUpstreamReport(r object) (object, error) {
	findings := []object{}

	if boolean(r["mcp_registry"]) {
		for _, value := range array(r[findingsKey]) {
			f := obj(value)
			findings = append(findings, object{valueRule: f["id"], valueOriginalRule: f["id"], kindFile: filepath.Base(text(r["source"])), valueLine: 0, valueSeverity: f[valueSeverity], "evidence_kind": f["evidence"]})
		}

		return object{findingsKey: findings, coverageKey: "registry_posture_only", valueExecutionSuccessful: true, "server_count": r["server_count"], valueRisk: r["risk_score"]}, nil
	}

	issues, ok := r["issues"].([]any)
	if !ok || !boolean(r[valueExecutionSuccessful]) || text(at(r, "metadata", "skillspector_version")) != upstreamVersion || at(r, "metadata", "llm_requested") != false {
		return nil, errors.New("upstream report schema/runtime drift")
	}

	for _, value := range issues {
		f := obj(value)
		loc := obj(f["location"])
		findings = append(findings, object{valueRule: comparisonFamily(text(f["id"])), valueOriginalRule: f["id"], kindFile: loc[kindFile], valueLine: number(loc["start_line"]), valueSeverity: strings.ToLower(text(f[valueSeverity]))})
	}

	completeness := obj(r["analysis_completeness"])
	for _, status := range array(completeness["analyzer_statuses"]) {
		if boolean(at(status, "failed")) {
			return nil, errors.New("upstream analyzer failed")
		}
	}

	return object{findingsKey: findings, coverageKey: completeness["status"], valueExecutionSuccessful: true, "analyzer_statuses": completeness["analyzer_statuses"], valueRisk: r["risk_assessment"]}, nil
}

func normalizeScoutReport(r object) (object, error) {
	if text(at(r, "inspection", "name")) != valueExtended {
		return nil, errors.New("scout comparison requires extended profile")
	}

	objects := map[string]string{}

	for _, value := range array(at(r, "extraction", "objects")) {
		name := text(at(value, kindFile, "path"))

		member := text(at(value, "member_name"))
		if member == "" {
			member = name
		}

		objects[name] = member
	}

	findings := []object{}

	for _, value := range array(r[findingsKey]) {
		f := obj(value)
		loc := obj(f["location"])

		file := text(loc["path"])
		if name := objects[file]; name != "" {
			file = name
		}

		findings = append(findings, object{valueRule: comparisonFamily(text(f["rule_id"])), valueOriginalRule: f["rule_id"], kindFile: file, valueLine: number(loc["start_line"]), valueSeverity: f[valueSeverity]})
	}

	diagnostics := map[string]bool{}
	for _, value := range array(r["diagnostics"]) {
		diagnostics[text(at(value, "code"))] = true
	}

	return object{findingsKey: findings, coverageKey: at(r, coverageKey, "completeness"), "policy": at(r, "policy", decisionKey), "engine_version": r["engine_version"], "diagnostics": sortedKeys(diagnostics)}, nil
}

func addComparisonDifferences(row object) {
	upstream, scoutFound := comparisonFindingSets(row[valueUpstream]), comparisonFindingSets(row[valueScout])
	for _, pair := range []struct {
		Name string
		A, B map[string]bool
	}{{valueUpstream, upstream, scoutFound}, {valueScout, scoutFound, upstream}} {
		only := difference(pair.A, pair.B)
		files := make([][]string, 0, len(only))
		familiesA, familiesB := map[string]bool{}, map[string]bool{}

		for _, key := range only {
			rule, file, _ := strings.Cut(key, "\x00")
			files = append(files, []string{rule, file})
		}

		for key := range pair.A {
			rule, _, _ := strings.Cut(key, "\x00")
			familiesA[rule] = true
		}

		for key := range pair.B {
			rule, _, _ := strings.Cut(key, "\x00")
			familiesB[rule] = true
		}

		row[pair.Name+"_only"], row[pair.Name+"_only_families"] = files, difference(familiesA, familiesB)
	}
}

func comparisonFindingSets(value any) map[string]bool {
	out := map[string]bool{}

	findings, ok := at(value, findingsKey).([]object)
	if !ok {
		return out
	}

	for _, f := range findings {
		out[text(f[valueRule])+"\x00"+text(f[kindFile])] = true
	}

	return out
}
