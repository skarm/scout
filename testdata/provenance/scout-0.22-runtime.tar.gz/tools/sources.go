package tools

import (
	"bytes"
	"context"
	"crypto/sha1" //nolint:gosec // Git blob identities use SHA-1 by definition, independently of the SHA-256 content check.
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

const maxSourceBytes = 8 << 20

type sourceArtifact struct {
	Path, URL, SHA256 string
	Bytes             int
	GitBlobSHA1       string `json:"git_blob_sha1"`
}
type pinnedSource struct {
	ID, Repository, Revision string
	Artifacts                []sourceArtifact
}

func verifyKnowledgeSources(ctx context.Context, o options, w io.Writer) error {
	if err := o.require("cache"); err != nil {
		return err
	}

	var sources []pinnedSource
	if err := readJSON(filepath.Join(o.root, "knowledge/data/review_sources.json"), &sources); err != nil {
		return err
	}

	if *o.download {
		if err := os.MkdirAll(o.get("cache"), 0o700); err != nil {
			return err
		}
	}

	count := 0

	for _, source := range sources {
		n, err := verifySource(ctx, source, o.get("cache"), *o.download)
		if err != nil {
			return err
		}

		count += n
	}

	_, err := fmt.Fprintf(w, "verified %d source files from %d pinned repositories; no upstream code executed\n", count, len(sources))

	return err
}

func verifySource(ctx context.Context, s pinnedSource, cache string, download bool) (int, error) {
	repository, err := url.Parse(s.Repository)
	if err != nil || repository.Scheme != "https" || repository.Host != "github.com" || repository.User != nil || !hexLength(s.Revision, 40) {
		return 0, errors.New("invalid pinned source repository or revision")
	}

	for _, item := range s.Artifacts {
		if err = verifyArtifactURL(repository, s.Revision, item); err != nil {
			return 0, err
		}

		path := filepath.Join(cache, item.SHA256)
		data, readErr := os.ReadFile(path) //nolint:gosec // G304: the filename is a validated SHA-256 inside the explicitly selected cache.

		missing := errors.Is(readErr, os.ErrNotExist)
		if missing && download {
			data, readErr = downloadSource(ctx, item.URL)
		}

		if readErr != nil {
			return 0, readErr
		}

		if err = verifySourceBytes(data, item); err != nil {
			return 0, fmt.Errorf("%s/%s: %w", s.ID, item.Path, err)
		}

		if missing && download {
			if err = os.WriteFile(path, data, 0o600); err != nil { //nolint:gosec // G703: validated hexadecimal digest fixes the cache-relative filename.
				return 0, err
			}
		}
	}

	return len(s.Artifacts), nil
}

func verifyArtifactURL(repository *url.URL, revision string, item sourceArtifact) error {
	u, err := url.Parse(item.URL)
	if err != nil || u.Scheme != "https" || u.Host != "raw.githubusercontent.com" || u.User != nil || u.Path != repository.Path+"/"+revision+"/"+item.Path || u.RawQuery != "" || u.Fragment != "" {
		return errors.New("source URL does not match pinned repository/path")
	}

	if !hexLength(item.SHA256, 64) || item.Bytes <= 0 || item.Bytes > maxSourceBytes {
		return errors.New("invalid source digest or byte count")
	}

	return nil
}

func hexLength(s string, n int) bool {
	if len(s) != n {
		return false
	}

	for _, r := range s {
		if !(r >= '0' && r <= '9' || r >= 'a' && r <= 'f') {
			return false
		}
	}

	return true
}

func downloadSource(ctx context.Context, address string) ([]byte, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, address, nil)
	if err != nil {
		return nil, err
	}

	req.Header.Set("User-Agent", "scout-knowledge-verifier")

	client := &http.Client{Timeout: 30 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return errors.New("source redirects are not permitted") }}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("source HTTP status %d", resp.StatusCode)
	}

	return io.ReadAll(io.LimitReader(resp.Body, maxSourceBytes+1))
}

func verifySourceBytes(data []byte, item sourceArtifact) error {
	if len(data) != item.Bytes || digest(data) != item.SHA256 {
		return errors.New("source bytes differ")
	}

	blob := append(fmt.Appendf(nil, "blob %d\x00", len(data)), data...)

	sum := sha1.Sum(blob) //nolint:gosec // G401: mandated Git blob identity; content is also checked with SHA-256 above.
	if hex.EncodeToString(sum[:]) != item.GitBlobSHA1 {
		return errors.New("git blob differs")
	}

	return nil
}

type listedPackage struct {
	Dir                                           string
	Module                                        *struct{ Dir string }
	GoFiles, CgoFiles, IgnoredGoFiles, EmbedFiles []string
}

// ScannerRuntimeFiles binds evidence to both build variants, platform files and embeds.
func ScannerRuntimeFiles(ctx context.Context, root string) ([]string, error) {
	root, err := filepath.Abs(root)
	if err != nil {
		return nil, err
	}

	root, err = filepath.EvalSymlinks(root)
	if err != nil {
		return nil, err
	}

	files := map[string]bool{filepath.Join(root, "go.mod"): true, filepath.Join(root, "go.sum"): true}
	for _, tags := range []string{"coreonly", "static_link"} {
		listed, err := listRuntimeFiles(ctx, root, tags)
		if err != nil {
			return nil, err
		}

		for _, name := range listed {
			files[name] = true
		}
	}
	// Evidence tooling is a separate executable, so include it explicitly.
	err = filepath.WalkDir(filepath.Join(root, "tools"), func(path string, d os.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}

		if !d.IsDir() && !strings.HasSuffix(path, "_test.go") && (strings.HasSuffix(path, ".go") || strings.HasSuffix(path, ".json")) {
			files[path] = true
		}

		return nil
	})
	if err != nil {
		return nil, err
	}

	if !files[filepath.Join(root, "scan.go")] || !files[filepath.Join(root, "internal/engine/engine.go")] {
		return nil, errors.New("scanner dependency inventory is incomplete")
	}

	return sortedKeys(files), nil
}

func listRuntimeFiles(ctx context.Context, root, tags string) ([]string, error) {
	cmd := exec.CommandContext(ctx, "go", "list", "-mod=readonly", "-deps", "-json", "-tags="+tags, ".") //nolint:gosec // G204: fixed go-list command over trusted project metadata; tags come from the two literal build variants.
	cmd.Dir = root
	cmd.Env = offlineEnvironment()

	data, err := cmd.Output()
	if err != nil {
		return nil, fmt.Errorf("scanner dependency inventory: %w", err)
	}

	dec := json.NewDecoder(bytes.NewReader(data))
	out := []string{}

	for {
		var pkg listedPackage
		if err = dec.Decode(&pkg); errors.Is(err, io.EOF) {
			break
		}

		if err != nil {
			return nil, err
		}

		if pkg.Module == nil || pkg.Module.Dir != root {
			continue
		}

		names := append(append(append(pkg.GoFiles, pkg.CgoFiles...), pkg.IgnoredGoFiles...), pkg.EmbedFiles...)
		for _, name := range names {
			if strings.HasSuffix(name, "_test.go") {
				continue
			}

			path, err := checkedRuntimePath(root, pkg.Dir, name)
			if err != nil {
				return nil, err
			}

			out = append(out, path)
		}
	}

	return out, nil
}

func offlineEnvironment() []string {
	env := []string{}

	for _, v := range os.Environ() {
		if !strings.HasPrefix(v, "GOPROXY=") && !strings.HasPrefix(v, "GOTOOLCHAIN=") && !strings.HasPrefix(v, "GOFLAGS=") {
			env = append(env, v)
		}
	}

	return append(env, "GOPROXY=off", "GOTOOLCHAIN=local")
}

func checkedRuntimePath(root, dir, name string) (string, error) {
	path := filepath.Join(dir, name)

	relative, err := filepath.Rel(root, path)
	if err != nil || !filepath.IsLocal(relative) {
		return "", errors.New("scanner source outside project")
	}

	info, err := os.Stat(path)
	if err != nil || !info.Mode().IsRegular() {
		return "", errors.New("scanner source missing or nonregular")
	}

	return path, nil
}
