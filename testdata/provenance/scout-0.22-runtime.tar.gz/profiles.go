package scout

import (
	"errors"
	"fmt"

	"github.com/skarm/scout/frontend"
	"github.com/skarm/scout/internal/model"
	"github.com/skarm/scout/signatures"
)

type InspectionPlan = model.InspectionPlan

// ConfigForProfile selects a reproducible check set. It never grants network or
// source-upload permission, configures a provider, or changes resource budgets.
// Semantic therefore still needs operator consent and a trusted provider.
func ConfigForProfile(name string) (Config, error) {
	if name == "" {
		return Config{}, errors.New("profile name required; choose basic, extended or semantic")
	}

	c := DefaultConfig()
	c.Profile = name

	return c.ResolveProfile()
}

// InspectionPlan returns a fresh description of the scanner's effective check set.
func (s *Scanner) InspectionPlan() InspectionPlan {
	p, _ := s.config.InspectionPlan()
	return p
}

// ResolveProfile adds the named profile's required checks. Explicit flags may
// add checks, but cannot weaken extended/semantic requirements. Empty Profile
// preserves the legacy API/CLI selection; its effective name is inferred.
func (c Config) ResolveProfile() (Config, error) {
	switch c.Profile {
	case "", "basic":
	case "extended", valueSemantic:
		c.SkillspectorPatterns = true
		c.Frontends.Python, c.Frontends.YAML, c.Frontends.TOML = true, true, true

		c.Signatures.Enabled = true
		if c.Profile == valueSemantic {
			c.Semantic.Enabled = true
		}
	default:
		return Config{}, fmt.Errorf("unknown inspection profile %q; choose basic, extended or semantic", c.Profile)
	}

	return c, nil
}

// InspectionPlan is a read-only preflight view: no artifact, credential, cache,
// provider or network is accessed. It can describe missing prerequisites; New
// performs the full configuration validation before any scan can start.
func (c Config) InspectionPlan() (InspectionPlan, error) {
	c, err := c.ResolveProfile()
	if err != nil {
		return InspectionPlan{}, err
	}

	full := c.SkillspectorPatterns && c.Frontends.Python && c.Frontends.YAML && c.Frontends.TOML && c.Signatures.Enabled
	anyExtra := c.SkillspectorPatterns || c.Frontends.Enabled() || c.Signatures.Enabled || c.Semantic.Enabled || c.Vulnerabilities.Enabled || c.Semantic.QualityPolicy || len(c.Signatures.ExtraRules) > 0
	name := "custom"

	switch {
	case !anyExtra:
		name = "basic"
	case full && !c.Vulnerabilities.Enabled && !c.Semantic.QualityPolicy && len(c.Signatures.ExtraRules) == 0:
		name = "extended"
		if c.Semantic.Enabled {
			name = valueSemantic
		}
	}

	p := InspectionPlan{
		Name: name, RequestedProfile: c.Profile, Checks: []model.InspectionCheck{}, Requirements: []string{},
		Egress: model.InspectionEgress{Download: c.Download.Enabled, VulnerabilityNetwork: c.Vulnerabilities.AllowNetwork, SourceUpload: c.Semantic.AllowSourceUpload},
	}
	add := func(id string, selected, available bool, reason string) {
		p.Checks = append(p.Checks, model.InspectionCheck{ID: id, Selected: selected, Available: available, Reason: reason})
		if selected && !available {
			p.Requirements = append(p.Requirements, id+": linked backend required")
		}
	}
	add("builtins", true, true, "")
	add("adapted_patterns", c.SkillspectorPatterns, true, "")

	for _, item := range []struct {
		id       string
		selected bool
	}{{"python", c.Frontends.Python}, {"yaml", c.Frontends.YAML}, {"toml", c.Frontends.TOML}} {
		b := frontend.BackendFor(item.id)
		add(item.id, item.selected, b.Available, b.Reason)
	}

	b := signatures.Backend()
	add("yara", c.Signatures.Enabled, b.Available, b.Reason)
	add("vulnerabilities", c.Vulnerabilities.Enabled, true, "")
	add(valueSemantic, c.Semantic.Enabled, true, "")
	add("quality", c.Semantic.QualityPolicy, true, "")

	if c.Semantic.Enabled {
		if !c.Semantic.AllowSourceUpload {
			p.Requirements = append(p.Requirements, "semantic: explicit source-upload consent required")
		}

		if c.Provider == nil {
			p.Requirements = append(p.Requirements, "semantic: trusted provider configuration required")
		}
	}

	if c.Vulnerabilities.Enabled && !c.Vulnerabilities.AllowNetwork && len(c.Vulnerabilities.Offline) == 0 {
		p.Requirements = append(p.Requirements, "vulnerabilities: explicit cache or network consent required")
	}

	return p, nil
}
